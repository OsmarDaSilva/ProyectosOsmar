import React, { Suspense } from 'react';
    import ReactDOM from 'react-dom/client';
    import App from '@/App';
    import '@/index.css';
    import { HelmetProvider } from 'react-helmet-async';
    import { HashRouter } from 'react-router-dom';
    import { LanguageProvider } from '@/contexts/LanguageContext';
    import { Toaster } from '@/components/ui/toaster';
    import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
    import ErrorBoundary from '@/components/ErrorBoundary';
    import LoadingScreen from '@/components/LoadingScreen';
    import './i18n';
    import { logError, setupGlobalErrorHandling } from '@/lib/error-logger';
    import { SWRConfig } from 'swr';

    // BUILD-ID: EVID-CR-SYNTHESIS-FIX-08
    console.log('// BUILD-ID: EVID-CR-SYNTHESIS-FIX-08');

    if (import.meta.env.MODE !== 'production') {
      navigator.serviceWorker?.getRegistrations?.().then(rs => rs.forEach(r => r.unregister()));
    }

    setupGlobalErrorHandling();

    const queryClient = new QueryClient({
      defaultOptions: {
        queries: {
          retry: (failureCount, error) => {
            if (error.message.includes('Failed to fetch') || error.message.includes('401') || error.message.includes('403') || error.code === 'PGRST116') {
              return false;
            }
            return failureCount < 2;
          },
          staleTime: 1000 * 60 * 5, // 5 minutes
        },
        mutations: {
            onError: (error) => {
                logError(error, { module: 'react-query-mutation' });
            },
        },
      },
    });

    const rootEl = document.getElementById('root');
    const portalEl = document.createElement('div');
    portalEl.id = 'portal-root';
    document.body.appendChild(portalEl);


    ReactDOM.createRoot(rootEl).render(
      <React.StrictMode>
        <Suspense fallback={<LoadingScreen />}>
          <HelmetProvider>
            <HashRouter>
              <QueryClientProvider client={queryClient}>
                 <SWRConfig value={{ provider: () => new Map(), shouldRetryOnError: false }}>
                  <ErrorBoundary>
                    <LanguageProvider>
                      <App />
                      <Toaster />
                    </LanguageProvider>
                  </ErrorBoundary>
                </SWRConfig>
              </QueryClientProvider>
            </HashRouter>
          </HelmetProvider>
        </Suspense>
      </React.StrictMode>
    );