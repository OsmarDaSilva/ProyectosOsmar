import React, { useState } from 'react';
    import { NavLink, useLocation, useNavigate } from 'react-router-dom';
    import { cn } from '@/lib/utils';
    import {
        LayoutDashboard, Users, Settings, Tractor, LineChart, BarChart2,
        Sprout, Wheat, Beef, FileBarChart, Wrench, MessageSquare, BookOpen,
        HelpCircle, Warehouse, Briefcase, HardHat, ShoppingCart, Leaf, Database, Bot, Package
    } from 'lucide-react';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
    import { useTranslation } from 'react-i18next';

    const NavItemContent = ({ href, label, icon: Icon, onLinkClick }) => (
      <NavLink
        to={href}
        onClick={onLinkClick}
        end
        className={({ isActive }) =>
          cn(
            "flex items-center gap-4 rounded-xl px-3 py-2 text-foreground transition-all hover:text-primary-foreground hover:bg-primary/90",
            isActive ? "bg-primary text-primary-foreground shadow-lg" : "text-muted-foreground"
          )
        }
      >
        <Icon className="h-5 w-5" />
        {label}
      </NavLink>
    );

    const AppNavbar = ({ onLinkClick }) => {
      const { t } = useTranslation(['nav', 'catalog', 'assistant', 'support']);
      const location = useLocation();
      const navigate = useNavigate();

      const menuConfig = [
        {
          section: t('sections.main'),
          items: [
            { href: '/dashboard', label: t('dashboard'), icon: LayoutDashboard },
            { href: '/my-projects', label: t('myProjects'), icon: Briefcase },
            { href: '/calculator', label: t('calculator'), icon: Tractor },
          ]
        },
        {
            section: t('sections.database'),
            items: [
              { href: '/production-database', label: t('productionDatabase'), icon: Database },
              { href: '/forage-database', label: t('forageDatabase'), icon: Sprout },
            ]
        },
        {
          section: t('sections.analysis'),
          items: [
            // { href: '/simulations', label: t('simulations'), icon: BarChart2 },
            { href: '/livestock-simulation', label: t('livestockSimulation'), icon: Beef },
            { href: '/agricultural-simulation', label: t('agriculturalSimulation'), icon: Wheat },
            { href: '/analisis/forrajero', label: t('forageAnalysis'), icon: Leaf },
            { href: '/forage-dashboard', label: t('forageDashboard'), icon: Sprout },
          ]
        },
        {
          section: t('sections.crm'),
          items: [
            { href: '/crm-dashboard', label: t('crmDashboard'), icon: BarChart2 },
            { href: '/clients', label: t('clients'), icon: Users },
            { href: '/pipeline', label: t('pipeline'), icon: LineChart },
            { href: '/activities', label: t('activities'), icon: Wrench },
            { href: '/campaigns', label: t('campaigns'), icon: MessageSquare },
            { href: '/marketing', label: t('marketing'), icon: BookOpen },
          ]
        },
        {
          section: t('sections.support'),
          items: [
            { href: '/product-catalog', label: t('pageTitle', { ns: 'catalog' }), icon: ShoppingCart },
            { href: '/inventory', label: t('inventory'), icon: Warehouse },
            { href: '/purchase-orders', label: t('purchaseOrderList.title', { ns: 'support' }), icon: Package },
            { href: '/equipment-registry', label: t('equipmentRegistry'), icon: HardHat },
            { href: '/customer-service', label: t('customerService'), icon: Wrench },
            { href: '/help-desk', label: t('helpDesk'), icon: HelpCircle },
            { href: '/knowledge-base', label: t('knowledgeBase'), icon: BookOpen },
          ]
        },
        {
          section: t('sections.system'),
          items: [
            { href: '/ai-assistant', label: t('title', {ns: 'assistant'}), icon: Bot },
            { href: '/chat', label: t('chat'), icon: MessageSquare },
            { href: '/user-management', label: t('userManagement'), icon: Users },
            { href: '/settings', label: t('settings'), icon: Settings },
          ]
        }
      ];

      const getActiveSections = () => {
        const activeSections = new Set();
        const currentPath = location.pathname;
        
        // Special case for root of analysis
        if (currentPath.startsWith('/analisis')) {
            activeSections.add(t('sections.analysis'));
        }

        menuConfig.forEach(section => {
          section.items.forEach(item => {
            if (item.href && currentPath.startsWith(item.href) && item.href !== '/') {
              activeSections.add(section.section);
            }
            if (item.children) {
              item.children.forEach(child => {
                if (child.href && currentPath.startsWith(child.href)) {
                  activeSections.add(section.section);
                }
              });
            }
          });
        });
        return Array.from(activeSections);
      };

      return (
        <div className="hidden border-r bg-muted/40 md:block">
          <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
              <div onClick={() => navigate('/my-projects')} className="flex items-center gap-2 font-semibold cursor-pointer">
                <img src="https://horizons-cdn.hostinger.com/54c4497f-3436-4816-989e-099d0c8f0a52/c7bd10f1a70ef32143417eab40b50154.png" alt="AGROinvest Paraguay Logo" className="h-8 object-contain" />
              </div>
            </div>
            <ScrollArea className="flex-1 px-2">
              <nav className="grid items-start gap-1 text-sm font-medium">
                <Accordion type="multiple" defaultValue={getActiveSections()}>
                  {menuConfig.map((section) => (
                    <AccordionItem value={section.section} key={section.section} className="border-b-0">
                      <AccordionTrigger className="px-3 text-xs uppercase text-muted-foreground hover:no-underline">{section.section}</AccordionTrigger>
                      <AccordionContent className="pl-2 pr-1 space-y-1">
                        {section.items.map((item) =>
                          item.children ? (
                            <Accordion key={item.label} type="single" collapsible defaultValue={item.children.some(c => location.pathname.startsWith(c.href)) ? item.label : null}>
                              <AccordionItem value={item.label} className="border-b-0">
                                <AccordionTrigger className={cn(
                                  "flex items-center gap-4 rounded-xl px-3 py-2 text-foreground transition-all hover:text-primary-foreground hover:bg-primary/90",
                                  item.children.some(c => location.pathname.startsWith(c.href)) && "bg-accent text-accent-foreground"
                                )}>
                                  <div className="flex items-center gap-4">
                                    <item.icon className="h-5 w-5" />
                                    {item.label}
                                  </div>
                                </AccordionTrigger>
                                <AccordionContent className="pt-1 pl-6 space-y-1">
                              {item.children.map(child => (
                                <NavItemContent key={child.href} {...child} onLinkClick={onLinkClick} />
                              ))}
                            </AccordionContent>
                          </AccordionItem>
                        </Accordion>
                      ) : (
                        <NavItemContent key={item.href} {...item} onLinkClick={onLinkClick} />
                      )
                    )}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </nav>
        </ScrollArea>
      </div>
    </div>
  );
};

export default AppNavbar;