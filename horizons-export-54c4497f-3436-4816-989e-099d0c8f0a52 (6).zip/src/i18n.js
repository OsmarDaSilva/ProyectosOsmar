import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import common_es from './locales/es/common.json';
import app_es from './locales/es/app.json';
import nav_es from './locales/es/nav.json';
import auth_es from './locales/es/auth.json';
import support_es from './locales/es/support.json';
import viability_es from './locales/es/viability.json';
import calculator_es from './locales/es/calculator.json';
import forageBalance_es from './locales/es/forageBalance.json';
import forageDatabase_es from './locales/es/forageDatabase.json';
import catalog_es from './locales/es/catalog.json';
import crm_es from './locales/es/crm.json';
import simulations_es from './locales/es/simulations.json';
import carbonBalance_es from './locales/es/carbonBalance.json';
import intensivePasture_es from './locales/es/intensivePasture.json';
import assistant_es from './locales/es/assistant.json';

import common_en from './locales/en/common.json';
import app_en from './locales/en/app.json';
import nav_en from './locales/en/nav.json';
import auth_en from './locales/en/auth.json';
import support_en from './locales/en/support.json';
import viability_en from './locales/en/viability.json';
import calculator_en from './locales/en/calculator.json';
import forageBalance_en from './locales/en/forageBalance.json';
import forageDatabase_en from './locales/en/forageDatabase.json';
import catalog_en from './locales/en/catalog.json';
import crm_en from './locales/en/crm.json';
import simulations_en from './locales/en/simulations.json';
import carbonBalance_en from './locales/en/carbonBalance.json';
import intensivePasture_en from './locales/en/intensivePasture.json';
import assistant_en from './locales/en/assistant.json';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    debug: false,
    fallbackLng: 'es',
    supportedLngs: ['es', 'en'],
    nonExplicitSupportedLngs: true,
    load: 'all',
    cleanCode: true,
    interpolation: {
      escapeValue: false, 
    },
    resources: {
      es: {
        common: common_es,
        app: app_es,
        nav: nav_es,
        auth: auth_es,
        support: support_es,
        viability: viability_es,
        calculator: calculator_es,
        forageBalance: forageBalance_es,
        forageDatabase: forageDatabase_es,
        catalog: catalog_es,
        crm: crm_es,
        simulations: simulations_es,
        carbonBalance: carbonBalance_es,
        intensivePasture: intensivePasture_es,
        assistant: assistant_es,
      },
      en: {
        common: common_en,
        app: app_en,
        nav: nav_en,
        auth: auth_en,
        support: support_en,
        viability: viability_en,
        calculator: calculator_en,
        forageBalance: forageBalance_en,
        forageDatabase: forageDatabase_en,
        catalog: catalog_en,
        crm: crm_en,
        simulations: simulations_en,
        carbonBalance: carbonBalance_en,
        intensivePasture: intensivePasture_en,
        assistant: assistant_en,
      },
    },
    ns: ['common','app','nav','auth','support','viability','calculator','forageBalance','forageDatabase','catalog','crm','simulations','intensivePasture','carbonBalance', 'assistant'],
    defaultNS: 'common',
    detection: {
      order: ['localStorage','querystring','navigator'],
      caches: ['localStorage']
    }
  });

export default i18n;