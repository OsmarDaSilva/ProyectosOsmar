import { useMemo } from 'react';

    const p = (value) => {
      if (typeof value === 'number') return value;
      const strValue = String(value).replace(/\./g, '').replace(/,/g, '.');
      return parseFloat(strValue) || 0;
    };

    const formatCurrency = (value) => {
      return new Intl.NumberFormat('es-PY', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(value);
    };

    export const useInitialCalculations = (projectData) => {
      const calculations = useMemo(() => {
        if (!projectData || !projectData.investments) {
          return {};
        }
        
        const data = projectData;
        
        const totalInvestment = data.investments.reduce((acc, item) => {
          return acc + (p(item.cantidad) * p(item.valorUnitario));
        }, 0);
        
        const plazo = p(data.plazo);
        const tasaInteres = p(data.tasaInteres);
        const tasaInteresAnual = tasaInteres / 100;

        let cuotaAnual = 0;
        if (totalInvestment > 0 && plazo > 0) {
            if (tasaInteresAnual > 0) {
                cuotaAnual = totalInvestment * (tasaInteresAnual * Math.pow(1 + tasaInteresAnual, plazo)) / (Math.pow(1 + tasaInteresAnual, plazo) - 1);
            } else {
                cuotaAnual = totalInvestment / plazo;
            }
        }
        const totalPagado = cuotaAnual * plazo;
        const totalIntereses = totalPagado > 0 ? totalPagado - totalInvestment : 0;
        const totalFinancingCost = totalInvestment + totalIntereses;
        
        return {
          valorPrestamo: {
            label: 'Valor del Préstamo',
            value: formatCurrency(totalInvestment),
          },
          cuotaAnual: {
            label: 'Cuota Anual del Préstamo',
            value: formatCurrency(cuotaAnual),
          },
          totalIntereses: {
            label: 'Total Intereses del Préstamo',
            value: formatCurrency(totalIntereses),
          },
          totalFinancingCost: {
            label: 'Costo Total de Financiación',
            value: formatCurrency(totalFinancingCost),
          },
          rawTotalIntereses: totalIntereses,
          rawTotalInvestment: totalInvestment,
        };
      }, [projectData]);

      return calculations;
    };