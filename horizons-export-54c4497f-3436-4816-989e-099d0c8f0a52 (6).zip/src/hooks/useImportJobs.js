import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { logUserAction } from '@/lib/logger';

const fetchJobs = async ({ queryKey }) => {
    const [_key, userId, jobType] = queryKey;
    if (!userId) return [];
    
    let query = supabase
        .from('import_jobs')
        .select('*')
        .eq('user_id', userId)
        .eq('bucket', jobType)
        .order('created_at', { ascending: false })
        .limit(10);
        
    const { data, error } = await query;

    if (error) throw error;
    return data;
};

export const useImportJobs = (userId, jobType) => {
    const queryClient = useQueryClient();
    
    const { data: jobs, refetch, isLoading } = useQuery({
        queryKey: ['import_jobs', userId, jobType],
        queryFn: fetchJobs,
        enabled: !!userId,
        refetchInterval: (query) => {
          const data = query.state.data;
          const isProcessing = data?.some(job => ['queued', 'processing'].includes(job.status));
          return isProcessing ? 5000 : 30000;
        },
    });

    const cancelJobMutation = useMutation({
      mutationFn: async (jobId) => {
        const { error } = await supabase
          .from('import_jobs')
          .update({ status: 'failed', summary: { error: "Cancelado por el usuario." } })
          .eq('id', jobId);
        if (error) throw error;
        await logUserAction('cancel_import_job', jobType, { jobId });
      },
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['import_jobs', userId, jobType] });
      }
    });

    const resumeJobMutation = useMutation({
        mutationFn: async ({jobId, userId, jobType}) => {
            const { data: job, error: jobError } = await supabase.from('import_jobs').select('bucket').eq('id', jobId).single();
            if (jobError) throw jobError;

            const jobTypeFromFile = job.bucket;
            let functionName;
            if (jobTypeFromFile === 'catalog_imports') {
                functionName = 'import-catalog';
            } else if (jobTypeFromFile === 'production_imports') {
                functionName = 'import-production-data';
            } else if (jobTypeFromFile === 'forage_imports') {
                functionName = 'import-forage-data';
            } else if (jobTypeFromFile === 'marketing_assets' || jobTypeFromFile === 'equipment_files') {
                functionName = 'process-asset-upload';
            } else {
                throw new Error('Tipo de trabajo de importación no válido');
            }
            
            await supabase.from('import_jobs').update({ processing_lock: null, lock_expires_at: null, status: 'queued' }).eq('id', jobId);
            
            await logUserAction('resume_import_job', jobTypeFromFile, { jobId });

            const { data, error } = await supabase.functions.invoke(functionName, { body: { jobId, bucket: jobTypeFromFile ?? 'production_imports' } });
            if (error) throw error;
            return data;
        },
        onSuccess: (_data, variables) => {
            queryClient.invalidateQueries({ queryKey: ['import_jobs', variables.userId, variables.jobType] });
        },
        onError: async (error, variables) => {
            await logUserAction('failed_import_job_resume', variables.jobType, { jobId: variables.jobId, error: error.message });
        }
    });
    
    return {
        jobs,
        isLoading,
        refetch,
        cancelJob: cancelJobMutation.mutateAsync,
        resumeJob: resumeJobMutation.mutateAsync,
        isCancelling: cancelJobMutation.isPending,
        isResuming: resumeJobMutation.isPending,
    };
};

export const useCreateImportJob = () => {
    const queryClient = useQueryClient();
    const startImportMutation = useStartImport();

    return useMutation({
        mutationFn: async ({ file, user, jobType, metadata = {} }) => {
            const fileExt = file.name.split('.').pop();
            const filePathInBucket = `${user.id}/${Date.now()}.${fileExt}`;
            
            const { error: uploadError } = await supabase.storage
                .from(jobType)
                .upload(filePathInBucket, file, {
                    upsert: true,
                    contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                });

            if (uploadError) throw new Error(`Error de subida: ${uploadError.message}`);

            const { data: job, error: dbError } = await supabase
                .from('import_jobs')
                .insert({ user_id: user.id, file_path: filePathInBucket, bucket: jobType, status: 'queued', summary: metadata })
                .select()
                .single();
            
            if (dbError) throw new Error(`Error de base de datos: ${dbError.message}`);
            
            await logUserAction('create_import_job', jobType, { jobId: job.id, fileName: filePathInBucket });
            
            await startImportMutation.mutateAsync({ jobId: job.id, jobType, userId: user.id });

            return job;
        },
        onSuccess: (data, variables) => {
            queryClient.invalidateQueries({ queryKey: ['import_jobs', variables.user.id, variables.jobType] });
        }
    });
};

export const useStartImport = () => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: async ({ jobId, jobType, userId }) => {
            let functionName;
            if (jobType === 'catalog_imports') {
                functionName = 'import-catalog';
            } else if (jobType === 'production_imports') {
                functionName = 'import-production-data';
            } else if (jobType === 'forage_imports') {
                functionName = 'import-forage-data';
            } else if (jobType === 'marketing_assets' || jobType === 'equipment_files') {
                functionName = 'process-asset-upload';
            } else {
                throw new Error('Tipo de trabajo de importación no válido');
            }
            
            const { data, error } = await supabase.functions.invoke(functionName, { body: { jobId, bucket: jobType } });
            if (error) throw error;
            return data;
        },
        onSuccess: (data, variables) => {
            queryClient.invalidateQueries({ queryKey: ['import_jobs', variables.userId, variables.jobType] });
        }
    });
};