import { useMemo } from 'react';

export const usePastureProfiles = (fullForageData) => {
    return useMemo(() => {
        if (!fullForageData || !Array.isArray(fullForageData) || fullForageData.length === 0) {
            return [];
        }
        return fullForageData.map(profile => ({
            ...profile,
            // Create a unique identifier for selection, combining pasture type and production method.
            // This ensures that "Pastura X (Normal)" and "Pastura X (Regada)" are treated as distinct options.
            // The production_method defaults to 'Normal' if it's not explicitly defined in the data.
            unique_pasture_id: `${profile.pasture_type} - ${profile.production_method || 'Normal'}`
        }));
    }, [fullForageData]);
};