import { useState, useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useSWRConfig } from 'swr';
import { v4 as uuidv4 } from 'uuid';

const useAiAssistant = () => {
    const { user } = useAuth();
    const [messages, setMessages] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const { toast } = useToast();
    const { cache } = useSWRConfig();

    const handleQuery = useCallback(async (query, isRetry = false, intent = null) => {
        setIsLoading(true);
        setError(null);
        
        const userMessage = { type: 'user', content: query, id: uuidv4() };

        if (!isRetry) {
            setMessages(prev => [...prev, userMessage]);
        }

        try {
            const forageKeywords = ['pasture', 'forraje', 'pasto', 'gramínea', 'zuri', 'forage'];
            const lowerCaseQuery = query.toLowerCase();
            const isForageQuery = forageKeywords.some(keyword => lowerCaseQuery.includes(keyword)) || intent === 'pasture';

            const requestBody = { 
                query,
                intent,
                cache_buster: Date.now(),
                data_source: isForageQuery ? 'forage_profiles_compat_v' : null
            };
            
            console.log("Invoking ask-ai with body:", requestBody);

            const { data, error: invokeError } = await supabase.functions.invoke('ask-ai', {
                body: JSON.stringify(requestBody)
            });

            if (invokeError) {
                throw new Error(invokeError.message);
            }
            
            if (data.error) {
                const errorMessage = data.error;
                let finalMessage = { 
                    type: 'ai', 
                    isError: true, 
                    answer: `Error: ${errorMessage}`, 
                    id: uuidv4(),
                    query: query,
                    isRetryable: !errorMessage.includes('PostgREST error')
                };

                if (errorMessage.includes('PostgREST error')) {
                    finalMessage.answer = `Lo siento, encontré un problema de conexión con la base de datos (${errorMessage}). Por favor, verifica los permisos y la conexión.`;
                } else if (errorMessage.includes('JSON')) {
                    finalMessage.answer = `Tuve un problema interpretando la respuesta del servidor. Inténtalo de nuevo.`;
                } else {
                    finalMessage.answer = `Ocurrió un error inesperado al procesar tu solicitud: ${errorMessage}`;
                }
                
                setMessages(prev => [...prev, finalMessage]);
            } else {
                 if (isForageQuery && (!data.results || data.results.length === 0)) {
                    setMessages(prev => [...prev, { type: 'ai', answer: 'No se encontraron datos de forrajes para su consulta.', sources: [], results: [], id: uuidv4() }]);
                } else {
                    setMessages(prev => [...prev, { type: 'ai', ...data, id: uuidv4() }]);
                }
            }

        } catch (e) {
            const err = { 
                type: 'ai', 
                isError: true, 
                answer: `Ocurrió un error inesperado al contactar al asistente. Por favor, revisa tu conexión a internet e inténtalo de nuevo. Detalles: ${e.message}`, 
                id: uuidv4(),
                query: query,
                isRetryable: true
            };
            setMessages(prev => [...prev, err]);
            setError({ message: e.message, query });
        } finally {
            setIsLoading(false);
        }
    }, [supabase, toast, cache]);

    const retryQuery = useCallback((queryToRetry) => {
        setMessages(prev => prev.filter(m => !m.isError));
        handleQuery(queryToRetry, true);
    }, [handleQuery]);

    return { messages, setMessages, isLoading, error, handleQuery, retryQuery };
};

export default useAiAssistant;