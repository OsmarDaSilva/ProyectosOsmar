import { useMemo } from 'react';
import { ProjectData, InitialCalculations, FinancialCalculations } from '@/types/project';

const p = (value: string | number | undefined): number => {
  if (typeof value === 'number') return value;
  const strValue = String(value).replace(/\./g, '').replace(/,/g, '.');
  return parseFloat(strValue) || 0;
};

const useFinancialCalculations = (projectData: ProjectData | null, initialCalculations: InitialCalculations | null): FinancialCalculations | null => {
  const calculations = useMemo(() => {
    if (!projectData || !initialCalculations || !initialCalculations.traditional || !initialCalculations.tech) {
      return null;
    }

    const {
      traditional: traditionalInitial,
      tech: techInitial,
      totalInvestment,
      totalFinancingCost,
      paybackPeriod,
      tir,
      van,
      roi
    } = initialCalculations;

    const calculateModel = (initialModelData: any, investment: number) => {
      if (!initialModelData) {
        return { revenue: 0, totalCosts: 0, grossProfit: 0, netProfit: 0, totalInvestment: 0, profitMargin: 0, roi: 0 };
      }
      const { revenue, totalCosts, grossProfit } = initialModelData;
      const profitMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;
      
      return {
        revenue,
        totalCosts,
        grossProfit,
        totalInvestment: investment,
        profitMargin,
        roi: roi ? roi * 100 : 0,
      };
    };
    
    const traditionalModel = calculateModel(traditionalInitial, 0);
    const techModel = calculateModel(techInitial, totalInvestment);
    
    const revenueDifference = techModel.revenue - traditionalModel.revenue;
    const costDifference = techModel.totalCosts - traditionalModel.totalCosts;
    const profitDifference = techModel.grossProfit - traditionalModel.grossProfit;
    const revenueIncrease = traditionalModel.revenue !== 0 ? (revenueDifference / Math.abs(traditionalModel.revenue)) * 100 : (techModel.revenue > 0 ? Infinity : 0);
    const costIncrease = traditionalModel.totalCosts !== 0 ? (costDifference / Math.abs(traditionalModel.totalCosts)) * 100 : (techModel.totalCosts > 0 ? Infinity : 0);
    const profitIncrease = traditionalModel.grossProfit !== 0 ? (profitDifference / Math.abs(traditionalModel.grossProfit)) * 100 : (techModel.grossProfit > 0 ? Infinity : 0);

    const comparison = {
      revenueDifference,
      costDifference,
      profitDifference,
      revenueIncrease,
      costIncrease,
      profitIncrease,
      isMoreProfitable: profitDifference > 0,
    };

    const cashFlow = [];
    const projectInvestment = techModel.totalInvestment;
    
    let cumulativeTrad = 0;
    let cumulativeTech = -projectInvestment;

    cashFlow.push({
      year: 0,
      traditionalCashFlow: 0,
      techCashFlow: -projectInvestment,
      cumulativeTraditional: 0,
      cumulativeTech: cumulativeTech,
    });

    const projectYears = projectData?.projectYears ? p(projectData.projectYears) : 10;

    for (let year = 1; year <= projectYears; year++) {
      const traditionalCashFlow = traditionalModel.grossProfit;
      const techCashFlow = techModel.grossProfit;
      
      cumulativeTrad += traditionalCashFlow;
      cumulativeTech += techCashFlow;
      
      cashFlow.push({
        year,
        traditionalCashFlow,
        techCashFlow,
        cumulativeTraditional: cumulativeTrad,
        cumulativeTech,
      });
    }
    
    return {
      traditionalModel,
      techModel,
      comparison,
      cashFlow,
      paybackPeriod,
      npv: van,
      irr: tir,
      totalFinancingCost: totalFinancingCost,
    };

  }, [projectData, initialCalculations]);

  return calculations;
};

export default useFinancialCalculations;