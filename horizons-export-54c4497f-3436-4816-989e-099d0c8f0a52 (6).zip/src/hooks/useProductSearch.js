import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDebounce } from './useDebounce';

const searchProducts = async (user, searchTerm, limit = 20) => {
    if (!user || !searchTerm) {
        return [];
    }

    const { data, error } = await supabase.rpc('search_products', {
        p_user_id: user.id,
        p_term: searchTerm,
        p_limit: limit,
    });

    if (error) {
        console.error('Error searching products:', error);
        throw new Error(error.message);
    }

    return data;
};

export const useProductSearch = (searchTerm) => {
    const { user } = useAuth();
    const debouncedSearchTerm = useDebounce(searchTerm, 250);

    return useQuery({
        queryKey: ['product_search', { term: debouncedSearchTerm, userId: user?.id }],
        queryFn: () => searchProducts(user, debouncedSearchTerm),
        enabled: !!user && !!debouncedSearchTerm,
        staleTime: 5 * 60 * 1000, // 5 minutes
    });
};