import { useMemo } from 'react';
    import { calculateSafra } from '@/utils/agricultureCalculations';

    export const useAgricultureCalculations = (agricultureData) => {
        const totalCalculations = useMemo(() => {
            const safras = agricultureData?.cultivos;
            if (!safras || !Array.isArray(safras) || safras.length === 0) {
                return {
                    tradicional: 0,
                    tecnified: 0,
                    diferencia: 0,
                    diferenciaPct: 0,
                    tradicionalTotalCostos: 0,
                    tecnifiedTotalCostos: 0,
                    tradicionalTotalIngresos: 0,
                    tecnifiedTotalIngresos: 0,
                    tradicionalTotalImpuestos: 0,
                    tecnifiedTotalImpuestos: 0,
                    tradicionalTotalGananciaNeta: 0,
                    tecnifiedTotalGananciaNeta: 0,
                    totalHectareasTradicional: 0,
                    totalHectareasTecnified: 0,
                    avgDosisNTradicional: 0,
                    avgDosisNTecnified: 0,
                };
            }

            const enabledSafras = safras.filter(s => s.isEnabled);

            const totals = enabledSafras.reduce((acc, safra) => {
                const tradCalcs = calculateSafra(safra.traditional);
                const techCalcs = calculateSafra(safra.tecnified);
                
                acc.tradicional += tradCalcs.gananciaLiquidaFinalArea;
                acc.tecnified += techCalcs.gananciaLiquidaFinalArea;

                acc.tradicionalTotalCostos += tradCalcs.totalCostosEgresos;
                acc.tecnifiedTotalCostos += techCalcs.totalCostosEgresos;

                acc.tradicionalTotalIngresos += tradCalcs.totalVentasIngresos;
                acc.tecnifiedTotalIngresos += techCalcs.totalVentasIngresos;

                acc.tradicionalTotalImpuestos += tradCalcs.impuestoTotal;
                acc.tecnifiedTotalImpuestos += techCalcs.impuestoTotal;
                
                acc.tradicionalTotalGananciaNeta += tradCalcs.gananciaNetaArea;
                acc.tecnifiedTotalGananciaNeta += techCalcs.gananciaNetaArea;

                acc.totalHectareasTradicional += tradCalcs.hectareas;
                acc.totalHectareasTecnified += techCalcs.hectareas;
                
                acc.dosisNTradicionalHa += tradCalcs.dosis_n * tradCalcs.hectareas;
                acc.dosisNTecnifiedHa += techCalcs.dosis_n * techCalcs.hectareas;
                
                return acc;
            }, { 
                tradicional: 0, 
                tecnified: 0, 
                tradicionalTotalCostos: 0, 
                tecnifiedTotalCostos: 0,
                tradicionalTotalIngresos: 0,
                tecnifiedTotalIngresos: 0,
                tradicionalTotalImpuestos: 0,
                tecnifiedTotalImpuestos: 0,
                tradicionalTotalGananciaNeta: 0,
                tecnifiedTotalGananciaNeta: 0,
                totalHectareasTradicional: 0,
                totalHectareasTecnified: 0,
                dosisNTradicionalHa: 0,
                dosisNTecnifiedHa: 0,
            });

            const diferencia = totals.tecnified - totals.tradicional;
            const diferenciaPct = totals.tradicional !== 0 ? (diferencia / Math.abs(totals.tradicional)) : (totals.tecnified > 0 ? Infinity : 0);

            const avgDosisNTradicional = totals.totalHectareasTradicional > 0 ? totals.dosisNTradicionalHa / totals.totalHectareasTradicional : 0;
            const avgDosisNTecnified = totals.totalHectareasTecnified > 0 ? totals.dosisNTecnifiedHa / totals.totalHectareasTecnified : 0;


            return { ...totals, diferencia, diferenciaPct, avgDosisNTradicional, avgDosisNTecnified };
        }, [agricultureData]);

        return { totalCalculations };
    };