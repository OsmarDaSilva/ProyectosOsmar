import { useState, useEffect, useMemo } from 'react';

    const parseNum = (val) => {
        if (typeof val === 'number') return val;
        if (typeof val !== 'string') return 0;
        const cleanVal = String(val).replace(/\./g, '').replace(',', '.');
        return parseFloat(cleanVal) || 0;
    };

    const parsePercentage = (val) => {
        if (typeof val !== 'string' && typeof val !== 'number') return 0;
        const cleanVal = String(val).replace('%', '').replace(',', '.');
        return parseFloat(cleanVal) / 100 || 0;
    };

    const formatDateForInput = (dateString) => {
        if (!dateString) return '';
        try {
            const date = new Date(dateString);
            if (isNaN(date.getTime())) return '';
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        } catch (error) {
            return '';
        }
    };

    const emptyModelCalculations = {
        totalCabezas: 0, diasEngorde: 0, duracionAnos: 0, fleteTotal: 0, comisionTotal: 0, costoCompra: 0, costoCompraAnimal: 0,
        totalInteresesPeriodo: 0, valorRebano: 0, totalSuplementacion: 0, totalAdministrativo: 0,
        totalVacunacion: 0, totalFertilizacion: 0, totalEnergia: 0, totalManutencion: 0,
        totalCombustible: 0, totalOtrosCostos: 0, totalMortandad: 0, interesCostoOperativo: 0,
        totalCostosArea: 0, costoProduccionAnimal: 0, totalCompraCostosOp: 0, costoTotalAnimal: 0,
        valorVentaRebano: 0, margenNeto: 0, totalIragro: 0, totalIrp: 0, gananciaFinalRebano: 0,
        gananciaFinalAnimal: 0, gananciaFinalHectarea: 0, engordeDiario: 0, cabezasMuertas: 0
    };

    const defaultFormData = {
      isEnabled: true,
      use_traditional: true,
      use_intensive: true,
      params: {
        tipoAnimal: 'Novillo Toro',
        pesoVivoEntrada: '200',
        precioCompraKgVivo: '2,00',
        hectareasTradicional: "400",
        hectareasIntensivo: "400",
        pesoVivoSalida: '500',
        desbaste: '3%',
        precioVentaKgGancho: '3,50',
        rendimientoCarcaza: '54,00%',
        tasaInteresAnual: '7,0%',
        aprovechamientoForraje: '85%',
        consumoDiarioMS: '2.5%',
      },
      tradicional: {
        cantidad: '1,1',
        fechaEntrada: '2026-01-01',
        fechaSalida: '2027-06-30',
        fleteEntrada: '25',
        comisionVendedor: '3,00%',
        costoSuplementacion: '50,00',
        costoAdministrativo: '25,00',
        costoVacunacion: '15',
        costoFertilizacion: '0',
        costoEnergia: '2,5',
        costoManutencion: '2,5',
        combustibleGasoil: '1',
        otrosCostos: '2,5',
        mortandad: '1,0%',
        impuestoIragro: '5,00%',
        impuestoIrp: '10,00%',
      },
      intensivo: {
        cantidad: '10',
        fechaEntrada: '2026-01-01',
        fechaSalida: '2027-01-01',
        fleteEntrada: '25',
        comisionVendedor: '3,00%',
        costoSuplementacion: '100,00',
        costoAdministrativo: '35,00',
        costoVacunacion: '15',
        costoFertilizacion: '200',
        costoEnergia: '350',
        costoManutencion: '2',
        combustibleGasoil: '5',
        otrosCostos: '5',
        mortandad: '1,0%',
        impuestoIragro: '5,00%',
        impuestoIrp: '10,00%',
      },
      pastureAnalysis: {}
    };

    const calculateModel = (hectareas, params, modelData, derivedParams) => {
        const { tasaInteresAnual, kgCarneGancho, precioVentaKgGancho } = derivedParams;

        const cantidadAnHaRebano = parseNum(modelData.cantidad);
        const totalCabezas = hectareas * cantidadAnHaRebano;

        const fechaEntrada = new Date(modelData.fechaEntrada);
        const fechaSalida = new Date(modelData.fechaSalida);
        const diasEngorde = fechaEntrada.toString() !== "Invalid Date" && fechaSalida.toString() !== "Invalid Date" && fechaSalida > fechaEntrada
          ? (fechaSalida.getTime() - fechaEntrada.getTime()) / (1000 * 60 * 60 * 24)
          : 0;
        const duracionAnos = diasEngorde > 0 ? diasEngorde / 365 : 0;

        const pesoVivoEntrada = parseNum(params.pesoVivoEntrada);
        const precioCompraKgVivo = parseNum(params.precioCompraKgVivo);
        const costoCompraAnimalBase = pesoVivoEntrada * precioCompraKgVivo;
        
        const fletePorAnimal = parseNum(modelData.fleteEntrada);
        
        const comisionVendedorPct = parsePercentage(modelData.comisionVendedor);
        const comisionPorAnimal = costoCompraAnimalBase * comisionVendedorPct;
        
        const costoCompraAnimal = costoCompraAnimalBase + fletePorAnimal + comisionPorAnimal;
        
        const valorCompraRebano = totalCabezas * costoCompraAnimalBase;
        const fleteTotal = fletePorAnimal * totalCabezas;
        const comisionTotal = valorCompraRebano * comisionVendedorPct;
        
        const totalInteresesPeriodo = totalCabezas * costoCompraAnimal * tasaInteresAnual * duracionAnos;
        const valorRebanoCompleto = valorCompraRebano + fleteTotal + comisionTotal + totalInteresesPeriodo;
        
        const costoSuplementacionAn = parseNum(modelData.costoSuplementacion);
        const totalSuplementacion = costoSuplementacionAn * totalCabezas * duracionAnos;
        
        const costoAdministrativoAn = parseNum(modelData.costoAdministrativo);
        const totalAdministrativo = costoAdministrativoAn * totalCabezas * duracionAnos;
        
        const costoVacunacionAn = parseNum(modelData.costoVacunacion);
        const totalVacunacion = costoVacunacionAn * totalCabezas * duracionAnos;
        
        const costoFertilizacionHa = parseNum(modelData.costoFertilizacion);
        const totalFertilizacion = costoFertilizacionHa * hectareas * duracionAnos;
        
        const costoEnergiaHa = parseNum(modelData.costoEnergia);
        const totalEnergia = costoEnergiaHa * hectareas * duracionAnos;

        const costoManutencionHa = parseNum(modelData.costoManutencion);
        const totalManutencion = costoManutencionHa * hectareas * duracionAnos;

        const costoCombustibleHa = parseNum(modelData.combustibleGasoil);
        const totalCombustible = costoCombustibleHa * hectareas * duracionAnos;

        const costoOtrosHa = parseNum(modelData.otrosCostos);
        const totalOtrosCostos = costoOtrosHa * hectareas * duracionAnos;

        const mortandadPct = parsePercentage(modelData.mortandad);
        const cabezasMuertas = totalCabezas * mortandadPct * duracionAnos;
        const totalMortandad = cabezasMuertas * costoCompraAnimalBase;

        const costoOperativoBruto = totalSuplementacion + totalAdministrativo + totalVacunacion + totalFertilizacion + totalEnergia + totalManutencion + totalCombustible + totalOtrosCostos + totalMortandad;
        const interesCostoOperativo = costoOperativoBruto * tasaInteresAnual * duracionAnos;

        const totalCostosArea = costoOperativoBruto + interesCostoOperativo;
        const costoProduccionAnimal = totalCabezas > 0 ? totalCostosArea / totalCabezas : 0;
        
        const totalCompraCostosOp = valorRebanoCompleto + totalCostosArea;
        const costoTotalAnimal = totalCabezas > 0 ? totalCompraCostosOp / totalCabezas : 0;

        const cabezasVenta = totalCabezas - cabezasMuertas;
        const valorVentaRebano = cabezasVenta * kgCarneGancho * precioVentaKgGancho;

        const margenNeto = valorVentaRebano - totalCompraCostosOp;
        
        const impuestoIragroPct = parsePercentage(modelData.impuestoIragro);
        const impuestoIrpPct = parsePercentage(modelData.impuestoIrp);

        const ivaVenta = valorVentaRebano * (impuestoIragroPct / (1 + impuestoIragroPct));
        const ivaCompra = totalCompraCostosOp * (impuestoIragroPct / (1 + impuestoIragroPct));
        const totalIragro = ivaVenta - ivaCompra > 0 ? ivaVenta - ivaCompra : 0;

        const baseImponibleIrp = (margenNeto - totalIragro) > 0 ? (margenNeto - totalIragro) : 0;
        const totalIrp = baseImponibleIrp * impuestoIrpPct;
        
        const gananciaFinalRebano = margenNeto - totalIragro - totalIrp;
        const gananciaFinalAnimal = cabezasVenta > 0 ? gananciaFinalRebano / cabezasVenta : 0;
        const gananciaFinalHectarea = hectareas > 0 ? gananciaFinalRebano / hectareas : 0;

        const pesoVivoSalida = parseNum(params.pesoVivoSalida);
        const kilosEngordado = pesoVivoSalida - pesoVivoEntrada;
        const engordeDiarioGramos = diasEngorde > 0 ? (kilosEngordado / diasEngorde) * 1000 : 0;

        return {
            totalCabezas, diasEngorde, duracionAnos, fleteTotal, comisionTotal, costoCompra: valorCompraRebano, costoCompraAnimal,
            totalInteresesPeriodo, valorRebano: valorRebanoCompleto, totalSuplementacion, totalAdministrativo,
            totalVacunacion, totalFertilizacion, totalEnergia, totalManutencion,
            totalCombustible, totalOtrosCostos, totalMortandad, interesCostoOperativo,
            totalCostosArea, costoProduccionAnimal, totalCompraCostosOp, costoTotalAnimal,
            valorVentaRebano, margenNeto, totalIragro, totalIrp, gananciaFinalRebano,
            gananciaFinalAnimal, gananciaFinalHectarea, engordeDiario: engordeDiarioGramos,
            cabezasMuertas
        };
    };

    export const useGanaderiaCalculations = (initialData) => {
        const [formData, setFormData] = useState(defaultFormData);

        useEffect(() => {
            if (initialData && typeof initialData === 'object' && Object.keys(initialData).length > 0) {
                setFormData(prev => {
                    const merged = {
                        ...defaultFormData,
                        ...initialData,
                        params: { ...defaultFormData.params, ...initialData.params },
                        tradicional: { ...defaultFormData.tradicional, ...initialData.tradicional },
                        intensivo: { ...defaultFormData.intensivo, ...initialData.intensivo },
                        isEnabled: initialData.isEnabled !== undefined ? initialData.isEnabled : true,
                        use_traditional: initialData.use_traditional !== undefined ? initialData.use_traditional : true,
                        use_intensive: initialData.use_intensive !== undefined ? initialData.use_intensive : true,
                    };
                    return merged;
                });
            } else {
                setFormData(defaultFormData);
            }
        }, [initialData]);

        const calculations = useMemo(() => {
            if (!formData) {
                return {
                    params: {},
                    tradicional: emptyModelCalculations,
                    intensivo: emptyModelCalculations,
                    comparativos: {},
                    formatDateForInput
                };
            }
            
            const params = formData.params;
            const tasaInteresAnual = parsePercentage(params.tasaInteresAnual);
            const tasaInteresMensual = tasaInteresAnual / 12;

            const pesoVivoEntrada = parseNum(params.pesoVivoEntrada);
            const pesoVivoSalida = parseNum(params.pesoVivoSalida);
            const kilosEngordado = pesoVivoSalida - pesoVivoEntrada;

            const desbastePct = parsePercentage(params.desbaste);
            const pesoFinalDesbaste = pesoVivoSalida * (1 - desbastePct);

            const rendimientoCarcaza = parsePercentage(params.rendimientoCarcaza);
            const precioVentaKgGancho = parseNum(params.precioVentaKgGancho);
            const precioVentaKgVivo = precioVentaKgGancho * rendimientoCarcaza;
            const kgCarneGancho = pesoVivoSalida * rendimientoCarcaza;

            const derivedParams = {
                tasaInteresAnual,
                kgCarneGancho,
                precioVentaKgGancho
            };

            const hectareasTradicional = parseNum(params.hectareasTradicional);
            const hectareasIntensivo = parseNum(params.hectareasIntensivo);

            const tradicional = (formData.isEnabled && formData.use_traditional)
                ? calculateModel(hectareasTradicional, params, formData.tradicional, derivedParams)
                : emptyModelCalculations;

            const intensivo = (formData.isEnabled && formData.use_intensive)
                ? calculateModel(hectareasIntensivo, params, formData.intensivo, derivedParams)
                : emptyModelCalculations;

            const comparativos = {
                animales: intensivo.totalCabezas - tradicional.totalCabezas,
                animalesPct: tradicional.totalCabezas > 0 ? (intensivo.totalCabezas / tradicional.totalCabezas) - 1 : (intensivo.totalCabezas > 0 ? Infinity : 0),
                margenPorHa: intensivo.gananciaFinalHectarea - tradicional.gananciaFinalHectarea,
                margenPorHaPct: tradicional.gananciaFinalHectarea !== 0 ? (intensivo.gananciaFinalHectarea / tradicional.gananciaFinalHectarea) - 1 : (intensivo.gananciaFinalHectarea > 0 ? Infinity : 0),
                tiempo: tradicional.duracionAnos - intensivo.duracionAnos,
                tiempoPct: tradicional.duracionAnos > 0 ? ((tradicional.duracionAnos - intensivo.duracionAnos) / tradicional.duracionAnos) : 0,
            };

            return {
                params: {
                    tasaInteresMensual,
                    kilosEngordado,
                    precioVentaKgGancho,
                    precioVentaKgVivo,
                    kgCarneGancho,
                    pesoFinalDesbaste,
                },
                tradicional,
                intensivo,
                comparativos,
                formatDateForInput
            };
        }, [formData]);

        return { formData, setFormData, calculations };
    };