import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { v4 as uuidv4 } from 'uuid';

// Fetch documents for a specific category and project
const fetchDocuments = async (projectId, category) => {
    if (!projectId || !category) return [];
    const { data, error } = await supabase
        .from('project_documents')
        .select('*')
        .eq('project_id', projectId)
        .eq('category', category)
        .order('created_at', { ascending: false });
        
    if (error) throw error;
    return data;
};

export const useProjectDocuments = (projectId, category) => {
    return useQuery({
        queryKey: ['project_documents', projectId, category],
        queryFn: () => fetchDocuments(projectId, category),
        enabled: !!projectId && !!category,
    });
};

// Hook for document mutations
export const useDocumentMutations = (projectId, category) => {
    const queryClient = useQueryClient();
    const { user } = useAuth();

    const invalidateQueries = () => {
        queryClient.invalidateQueries({ queryKey: ['project_documents', projectId, category] });
        queryClient.invalidateQueries({ queryKey: ['projectDocSummary', projectId] });
    };

    // UPLOAD/CREATE mutation
    const uploadDocumentMutation = useMutation({
        mutationFn: async ({ title, status, file }) => {
            if (!file) throw new Error("Archivo es requerido.");
            
            const newDocumentId = uuidv4();
            
            const { data: existingDocs, error: existingError } = await supabase
                .from('project_documents')
                .select('version')
                .eq('project_id', projectId)
                .eq('category', category)
                .eq('title', title)
                .order('version', { ascending: false })
                .limit(1);

            if (existingError) throw existingError;
            
            const newVersion = (existingDocs && existingDocs.length > 0) ? parseInt(existingDocs[0].version, 10) + 1 : 1;

            const { data: newDoc, error: insertError } = await supabase
                .from('project_documents')
                .insert({
                    id: newDocumentId,
                    project_id: projectId,
                    category,
                    title,
                    status,
                    version: newVersion,
                    user_id: user.id,
                    file_path: 'pending'
                })
                .select()
                .single();

            if (insertError) throw insertError;

            const filePath = `${projectId}/${category}/${newDocumentId}/v${newVersion}.pdf`;
            const { error: uploadError } = await supabase.storage
                .from('project-docs')
                .upload(filePath, file);

            if (uploadError) {
                await supabase.from('project_documents').delete().eq('id', newDoc.id);
                throw uploadError;
            }

            const { data: updatedDoc, error: updateError } = await supabase
                .from('project_documents')
                .update({ file_path: filePath })
                .eq('id', newDoc.id)
                .select()
                .single();
            
            if (updateError) throw updateError;

            return updatedDoc;
        },
        onSuccess: invalidateQueries,
    });

    // UPDATE mutation
    const updateDocumentMutation = useMutation({
        mutationFn: async ({ id, title, status }) => {
            const { data, error } = await supabase
                .from('project_documents')
                .update({ title, status, updated_at: new Date().toISOString() })
                .eq('id', id)
                .select()
                .single();
            if (error) throw error;
            return data;
        },
        onSuccess: invalidateQueries,
    });

    // DELETE mutation (now calls edge function)
    const deleteDocumentMutation = useMutation({
        mutationFn: async (document) => {
            if (!document || !document.id) {
                throw new Error("Documento o ID de documento inválido.");
            }
            const { data, error } = await supabase.functions.invoke('delete-project-doc', {
                body: { document_id: document.id },
            });
            if (error) throw error;
            if (data.error) throw new Error(data.error);
            return data;
        },
        onSuccess: invalidateQueries,
    });

    return {
        uploadDocument: uploadDocumentMutation.mutateAsync,
        updateDocument: updateDocumentMutation.mutateAsync,
        deleteDocument: deleteDocumentMutation.mutateAsync,
        isUploading: uploadDocumentMutation.isPending,
        isUpdating: updateDocumentMutation.isPending,
        isDeleting: deleteDocumentMutation.isPending,
    };
};