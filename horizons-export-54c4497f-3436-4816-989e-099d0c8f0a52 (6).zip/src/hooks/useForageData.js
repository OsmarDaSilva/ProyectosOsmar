import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';

    const fetchForageData = async (userId) => {
        if (!userId) return [];
        
        const { data, error } = await supabase
          .from('forage_profiles_compat_v')
          .select('id, pasture_type, method, country, region, months');

        if (error) {
            console.error("Error fetching forage data:", error);
            throw error;
        }
        
        return data.map(row => {
            const newMonths = {};
            if (row.months) {
                for (const key in row.months) {
                    const value = row.months[key];
                    // The value is 100 times larger than it should be. Divide by 100.
                    newMonths[key] = (value === null || value === undefined) ? null : Number(value) / 100;
                }
            }

            return {
                id: row.id,
                user_id: userId,
                pasture_type: row.pasture_type,
                method: row.method,
                country: row.country,
                region: row.region,
                months: newMonths,
            };
        });
    };

    export const useForageData = (userId) => {
        return useQuery({
            queryKey: ['forageProfilesCompat', userId],
            queryFn: () => fetchForageData(userId),
            enabled: !!userId,
            staleTime: 1000 * 60 * 5, // 5 minutes
        });
    };

    export const useUpsertForageProfile = () => {
        const queryClient = useQueryClient();
        return useMutation({
            mutationFn: async (row) => {
                console.warn("Upserting to a view is not directly supported. Please implement an RPC function for this.", row);
                // This is a placeholder. An actual RPC function 'upsert_forage_profile' is needed.
                // const { error } = await supabase.rpc('upsert_forage_profile', { profile_data: row });
                // if (error) throw error;
                return row.user_id;
            },
            onSuccess: (user_id) => {
                queryClient.invalidateQueries({ queryKey: ['forageProfilesCompat', user_id] });
            },
        });
    };

    export const useDeleteForageProfile = () => {
        const queryClient = useQueryClient();
        return useMutation({
            mutationFn: async ({ id, userId }) => {
                console.warn("Deleting from a view is not directly supported. Please implement an RPC function for this.", id);
                // This is a placeholder. An actual RPC function 'delete_forage_profile' is needed.
                // const { error } = await supabase.rpc('delete_forage_profile', { profile_id: id });
                // if (error) throw error;
                return userId;
            },
            onSuccess: (userId) => {
                queryClient.invalidateQueries({ queryKey: ['forageProfilesCompat', userId] });
            },
        });
    };