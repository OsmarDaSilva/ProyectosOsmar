import { useMutation, useQueryClient } from '@tanstack/react-query';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { v4 as uuidv4 } from 'uuid';
    import { logUserAction } from '@/lib/logger';
    import { useCreateImportJob } from '@/hooks/useImportJobs';

    const useForageImport = (userId) => {
        const { toast } = useToast();
        const createJobMutation = useCreateImportJob();

        const importFile = async (file) => {
            if (!file || !userId) {
                toast({ variant: 'destructive', title: 'Error', description: 'Falta el archivo o el ID de usuario.' });
                return;
            }

            createJobMutation.mutate({ file, user: { id: userId }, jobType: 'forage_imports' }, {
                onSuccess: () => {
                    toast({
                        title: 'Importación Iniciada',
                        description: 'Tu archivo se está procesando. Verás el progreso en la pestaña de Importación.',
                    });
                    logUserAction('start_forage_import', 'forage_database', { fileName: file.name });
                },
                onError: (error) => {
                    toast({
                        variant: 'destructive',
                        title: 'Error de Importación',
                        description: error.message,
                    });
                }
            });
        };

        return {
            importFile,
            isLoading: createJobMutation.isPending,
        };
    };

    export default useForageImport;