import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const fetchProducts = async ({ user, searchTerm, page, pageSize, sorting }) => {
    if (!user) {
        return { data: [], count: 0, totalPages: 0 };
    }

    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let countQuery = supabase
        .from('product_catalog')
        .select('sku', { count: 'exact', head: true })
        .eq('user_id', user.id);

    let dataQuery = supabase
        .from('product_catalog')
        .select('*')
        .eq('user_id', user.id);
    
    const cleanedSearch = searchTerm?.trim();
    if (cleanedSearch) {
        const searchPattern = `%${cleanedSearch}%`;
        const orFilter = `sku.ilike.${searchPattern},product_name.ilike.${searchPattern},brand.ilike.${searchPattern},category.ilike.${searchPattern}`;
        countQuery = countQuery.or(orFilter);
        dataQuery = dataQuery.or(orFilter);
    }
        
    if (sorting && sorting.length > 0) {
        dataQuery = dataQuery.order(sorting[0].id, { ascending: !sorting[0].desc });
    } else {
        dataQuery = dataQuery.order('sku', { ascending: true });
    }
    
    dataQuery = dataQuery.range(from, to);

    const [
        { count, error: countError },
        { data, error: dataError }
    ] = await Promise.all([countQuery, dataQuery]);

    if (countError) throw new Error(`Error al contar productos: ${countError.message}`);
    if (dataError) throw new Error(`Error al obtener productos: ${dataError.message}`);
    
    const totalCount = count || 0;
    const totalPages = Math.ceil(totalCount / pageSize);

    return { data: data || [], count: totalCount, totalPages };
};

export const useProductCatalog = ({ searchTerm, page, pageSize, sorting }) => {
    const { user } = useAuth();
    return useQuery({
        queryKey: ['products', { searchTerm, page, pageSize, sorting, userId: user?.id }],
        queryFn: () => fetchProducts({ user, searchTerm, page, pageSize, sorting }),
        enabled: !!user,
        keepPreviousData: true,
    });
};

const upsertProduct = async (productData) => {
    const { data, error } = await supabase
        .from('product_catalog')
        .upsert(productData, { onConflict: 'user_id, sku' })
        .select();
        
    if (error) throw error;
    return data;
};

export const useUpsertProduct = () => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: upsertProduct,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['products'] });
        },
    });
};

const deleteProduct = async ({ userId, sku }) => {
    const { error } = await supabase
        .from('product_catalog')
        .delete()
        .eq('user_id', userId)
        .eq('sku', sku);
    if (error) throw error;
};

export const useDeleteProduct = () => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: deleteProduct,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['products'] });
        },
    });
};

const duplicateProduct = async (product) => {
    const newSku = `${product.sku}-copia-${Date.now()}`;
    const { sku, created_at, updated_at, ...rest } = product;
    const newProduct = { ...rest, sku: newSku };
    
    const { data, error } = await supabase
        .from('product_catalog')
        .insert(newProduct)
        .select()
        .single();
        
    if (error) throw error;
    return data;
};

export const useDuplicateProduct = () => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: duplicateProduct,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['products'] });
        },
    });
};