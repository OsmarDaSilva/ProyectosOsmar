import { useCallback, useState } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const BUCKET = 'catalog_imports';

const useProductImport = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);

  const startImport = useCallback(
    async ({ file }) => {
      if (!user?.id) {
        const msg = 'Sesión no válida. Inicia sesión nuevamente.';
        toast({ variant: 'destructive', title: 'Error', description: msg });
        throw new Error(msg);
      }

      setIsUploading(true);

      try {
        const path = `${user.id}/${Date.now()}.xlsx`;
        const { error: upErr } = await supabase.storage
          .from(BUCKET)
          .upload(path, file, { 
            upsert: true,
            contentType: file?.type || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          });

        if (upErr) {
          console.error('Upload error:', upErr);
          throw new Error(upErr.message || 'No se pudo subir el archivo al almacenamiento.');
        }

        const { data: jobRow, error: insErr } = await supabase
          .from('import_jobs')
          .insert({
            user_id: user.id,
            file_path: path,
            status: 'queued',
            summary: { fileName: file.name },
          })
          .select('id')
          .single();

        if (insErr) {
          console.error('Insert job error:', insErr);
          throw new Error(insErr.message || "No se pudo crear el registro del trabajo.");
        }

        const { error: fnErr } = await supabase.functions.invoke('import-catalog', {
          body: { jobId: jobRow.id }
        });

        if (fnErr) {
          console.error('Edge function error:', fnErr);
          throw new Error(fnErr.message || 'No se pudo iniciar el procesamiento en el servidor.');
        }

        toast({
          title: 'Importación iniciada',
          description: 'Tu archivo se está procesando. Revisa el Historial de Importaciones.',
        });

        return { jobId: jobRow.id };
      } catch (err) {
        const msg =
          err?.message ||
          err?.error?.message ||
          'Ocurrió un error al iniciar la importación.';
        toast({
          variant: 'destructive',
          title: 'No se pudo crear el trabajo',
          description: msg,
        });
        throw err;
      } finally {
        setIsUploading(false);
      }
    },
    [user, toast]
  );

  return { startImport, isUploading };
};

export default useProductImport;