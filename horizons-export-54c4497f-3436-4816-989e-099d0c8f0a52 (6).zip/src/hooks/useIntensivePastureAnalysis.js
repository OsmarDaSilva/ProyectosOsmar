import { useMemo } from 'react';
    import { toNumber, toNumberSafe, normalizeText } from '@/lib/utils';
    import { addMonths, startOfMonth, format, getDaysInMonth } from 'date-fns';
    import { es } from 'date-fns/locale';
    
    const useIntensivePastureAnalysis = (params) => {
        const {
            selectedPastureId,
            hectares,
            headsPerHectare,
            animalType,
            startWeight,
            endWeight,
            purchasePricePerHead,
            dailyConsumptionPercentage,
            supplementaryFeedCost,
            initialInvestment,
            annualOperatingCostPerHead,
            plazo,
            tasaInteres,
            dailySupplementGram,
            supplementGdpGain,
            mortalityRate,
            taxRate,
            pastureUtilization,
            carcassYieldPercentage,
            salePricePerKgHook,
            forageData,
            startDate
        } = params;
    
        const results = useMemo(() => {
            const h = toNumberSafe(hectares);
            const cabezasPorHa = toNumberSafe(headsPerHectare);
            const totalHeads = Math.round(h * cabezasPorHa);
            const pesoInicial = toNumberSafe(startWeight);
            const pesoFinalObjetivo = toNumberSafe(endWeight);
            const consumoDiarioPct = toNumberSafe(dailyConsumptionPercentage) / 100;
            const utilizacionPastura = toNumberSafe(pastureUtilization) / 100;
            
            const gdpBasePastura = 0.710;
            const gdpConSuplemento = gdpBasePastura + (toNumberSafe(supplementGdpGain) / 1000);
    
            const pesoGanar = pesoFinalObjetivo - pesoInicial;
            const diasEngorde = (pesoGanar > 0 && gdpConSuplemento > 0) ? pesoGanar / gdpConSuplemento : 0;
            
            const baseDate = startOfMonth(new Date(startDate || new Date()));
            const monthsMeta = Array.from({ length: 12 }, (_, i) => {
                const d = addMonths(baseDate, i);
                return {
                    key: format(d, 'yyyy-MM'),
                    label: format(d, 'MMM', { locale: es }),
                    days: getDaysInMonth(d),
                    date: d,
                };
            });
    
            const suplementoTotalMS = monthsMeta.reduce((acc, month) => {
                const suplementoDiarioKg = toNumberSafe(dailySupplementGram) / 1000;
                const suplementoMesKg = suplementoDiarioKg * totalHeads * month.days;
                return acc + (suplementoMesKg / 1000);
            }, 0);
    
            const rendimientoCarcaza = toNumberSafe(carcassYieldPercentage) / 100;
            const kgCarcasaPorCabeza = pesoFinalObjetivo * rendimientoCarcaza;
            const carneTotalKg = kgCarcasaPorCabeza * totalHeads;
            const carneTotalTon = carneTotalKg / 1000;
            const precioVentaKgGancho = toNumberSafe(salePricePerKgHook);
            const ingresoPorVentaAnimal = kgCarcasaPorCabeza * precioVentaKgGancho;
            
            const costoCompraCab = toNumberSafe(purchasePricePerHead);
            const costoOperativoAnualCab = toNumberSafe(annualOperatingCostPerHead);
            const costoSuplementoUSDkg = toNumberSafe(supplementaryFeedCost);
            
            const costoSuplementoTotal = suplementoTotalMS * 1000 * costoSuplementoUSDkg;
            const costoCompraTotal = costoCompraCab * totalHeads;
            const costoOperativoTotal = costoOperativoAnualCab * totalHeads;
            
            const ingresoBrutoTotal = carneTotalKg * precioVentaKgGancho;
            const margenBruto = ingresoBrutoTotal - costoCompraTotal - costoOperativoTotal - costoSuplementoTotal;
            
            const margenPorAnimal = totalHeads > 0 ? margenBruto / totalHeads : 0;
            const margenPorHa = h > 0 ? margenBruto / h : 0;
    
            const emptyPerformance = {
                totalHeads: { value: totalHeads },
                hectares: { value: h },
                stockingRate: { value: cabezasPorHa },
                fatteningDays: { value: diasEngorde },
                dailyWeightGain: { value: gdpConSuplemento },
                totalWeightGain: { value: pesoGanar > 0 ? pesoGanar : 0},
                supplementaryFeed: { value: suplementoTotalMS },
                annualRevenuePerHead: { value: ingresoPorVentaAnimal },
                kgCarcasaPorCabeza: { value: kgCarcasaPorCabeza },
                carneTotalTon: { value: carneTotalTon },
            };
    
            if (!selectedPastureId || !forageData || !pastureUtilization) {
                 return {
                    balanceData: [],
                    performanceSummary: emptyPerformance,
                    financialSummary: {},
                    viabilityMetrics: {},
                    totals: { oferta: 0, demanda: 0, balance: 0, balancePercentage: 0 }
                };
            }
    
            const pasture = forageData.find(p => p.id === selectedPastureId);
            
            if (!pasture) {
                return {
                    balanceData: [],
                    performanceSummary: emptyPerformance,
                    financialSummary: {},
                    viabilityMetrics: {},
                    totals: { oferta: 0, demanda: 0, balance: 0, balancePercentage: 0 }
                };
            }
            
            let pesoAnimalActual = pesoInicial;
            
            const balanceData = monthsMeta.map((monthMeta) => {
                const monthKey = format(monthMeta.date, 'MMMM', { locale: es }).toLowerCase();
                const produccionKgHaMes = pasture.months?.[monthKey] ? toNumberSafe(pasture.months[monthKey]) : 0;
    
                const ofertaTotalKg = produccionKgHaMes * h * utilizacionPastura;
                const ofertaTotalTon = ofertaTotalKg / 1000;
    
                const consumoDiarioPorAnimalKg = pesoAnimalActual * consumoDiarioPct;
                const demandaTotalKg = consumoDiarioPorAnimalKg * totalHeads * monthMeta.days;
                const demandaTotalTon = demandaTotalKg / 1000;
    
                const balanceTon = ofertaTotalTon - demandaTotalTon;
                const balancePct = demandaTotalTon > 0 ? (balanceTon / demandaTotalTon) * 100 : 0;
                
                const gdpDiaria = balanceTon >= 0 ? gdpConSuplemento : gdpConSuplemento * 0.5; // Penalty for deficit
                const gananciaPesoMes = gdpDiaria * monthMeta.days;
    
                const monthData = {
                    key: monthMeta.key,
                    month: monthMeta.label,
                    animalWeight: pesoAnimalActual,
                    oferta: ofertaTotalTon,
                    demanda: demandaTotalTon,
                    balance: balanceTon,
                    balancePercentage: balancePct,
                };
                
                if (pesoAnimalActual < pesoFinalObjetivo) {
                   pesoAnimalActual += gananciaPesoMes;
                }
                if(pesoAnimalActual > pesoFinalObjetivo) {
                    pesoAnimalActual = pesoFinalObjetivo;
                }
    
                return monthData;
            });
            
            
            const performanceSummary = {
                totalHeads: { value: totalHeads },
                hectares: { value: h },
                stockingRate: { value: cabezasPorHa },
                fatteningDays: { value: diasEngorde },
                dailyWeightGain: { value: gdpConSuplemento },
                totalWeightGain: { value: pesoGanar > 0 ? pesoGanar : 0 },
                supplementaryFeed: { value: suplementoTotalMS },
                annualRevenuePerHead: { value: ingresoPorVentaAnimal },
                kgCarcasaPorCabeza: { value: kgCarcasaPorCabeza },
                carneTotalTon: { value: carneTotalTon },
            };
    
            const inversionTotal = costoCompraTotal + toNumberSafe(initialInvestment);
            
            const financialSummary = {
                totalRevenue: { value: ingresoBrutoTotal },
                animalPurchaseCost: { value: costoCompraTotal },
                supplementaryFeedCost: { value: costoSuplementoTotal },
                annualOperatingCost: { value: costoOperativoTotal },
                grossMargin: { value: margenBruto },
                profitPerAnimal: { value: margenPorAnimal },
                profitPerHectare: { value: margenPorHa },
            };
            
            const USE_ADVANCED_NPV = false;
            let van;
    
            if (USE_ADVANCED_NPV) {
                const t = toNumberSafe(plazo);
                const r = toNumberSafe(tasaInteres) / 100;
                van = Array.from({ length: t }, (_, i) => (margenBruto) / Math.pow(1 + r, i + 1)).reduce((acc, val) => acc + val, 0) - inversionTotal;
            } else {
                van = margenBruto;
            }
    
            const paybackValue = inversionTotal > 0 && margenBruto > 0 ? inversionTotal / margenBruto : 0;
    
            const viabilityMetrics = {
                van: { value: van },
                tir: { value: 0 }, // Placeholder
                payback: { value: paybackValue },
                roi: { value: inversionTotal > 0 ? (margenBruto) / inversionTotal * 100 : 0 },
            };
    
            const totals = balanceData.reduce((acc, item) => ({
                oferta: acc.oferta + item.oferta,
                demanda: acc.demanda + item.demanda,
            }), { oferta: 0, demanda: 0 });
            totals.balance = totals.oferta - totals.demanda;
            totals.balancePercentage = totals.demanda > 0 ? (totals.balance / totals.demanda) * 100 : 0;
    
            return { balanceData, performanceSummary, financialSummary, viabilityMetrics, totals };
        }, [
            selectedPastureId, hectares, headsPerHectare, animalType, startWeight, endWeight,
            purchasePricePerHead, dailyConsumptionPercentage, supplementaryFeedCost,
            initialInvestment, annualOperatingCostPerHead, plazo, tasaInteres, dailySupplementGram,
            supplementGdpGain, mortalityRate, taxRate, pastureUtilization, carcassYieldPercentage,
            salePricePerKgHook, forageData, startDate
        ]);
    
        return { results };
    };
    
    export default useIntensivePastureAnalysis;