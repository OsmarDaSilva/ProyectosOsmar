import { useMemo, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const parseNum = (val) => {
    if (typeof val === 'number') return val;
    if (typeof val !== 'string') return 0;
    const cleanVal = String(val).replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanVal) || 0;
};

const parsePercentage = (val) => {
    if (typeof val !== 'string' && typeof val !== 'number') return 0;
    const cleanVal = String(val).replace('%', '').replace(',', '.');
    return parseFloat(cleanVal) / 100 || 0;
};

export const useGanaderiaForageAnalysis = ({ ganaderiaData, fullForageData }) => {
    const { t } = useTranslation('common');
    const monthNames = useMemo(() => Object.values(t('months', { returnObjects: true })).slice(0, 12), [t]);

    const [selectedPastureId, setSelectedPastureId] = useState(null);

    const isLoading = !ganaderiaData || !fullForageData;

    const pastureOptions = useMemo(() => {
        if (!fullForageData || !Array.isArray(fullForageData)) return [];
        return fullForageData.map(p => ({
            id: p.id,
            label: `${p.pasture_type} (${p.production_method}) - ${p.country || 'N/A'}`
        }));
    }, [fullForageData]);

    const results = useMemo(() => {
        if (isLoading || !Array.isArray(fullForageData) || fullForageData.length === 0) return null;

        const { params, intensivo } = ganaderiaData;
        if (!params || !intensivo) return null;

        let effectivePastureId = selectedPastureId;
        if (!effectivePastureId && pastureOptions.length > 0) {
          effectivePastureId = pastureOptions[0].id;
        }
        
        const pastureProfile = fullForageData.find(p => p.id === effectivePastureId);

        if (!pastureProfile || !pastureProfile.monthly_production) return null;

        const hectareas = parseNum(params.hectareasIntensivo);
        const animalesPorHa = parseNum(intensivo.cantidad);
        const totalAnimales = hectareas * animalesPorHa;
        const pesoEntrada = parseNum(params.pesoVivoEntrada);
        const pesoSalida = parseNum(params.pesoVivoSalida);
        const pastureUtilization = parsePercentage(params.aprovechamientoForraje) || 0.85;
        const dailyConsumptionPercentage = parsePercentage(params.consumoDiarioMS) || 0.025;
        
        const fechaEntradaStr = intensivo.fechaEntrada;
        if (!fechaEntradaStr || !/^\d{4}-\d{2}-\d{2}$/.test(fechaEntradaStr)) return null;
        const [yearEntrada, monthEntrada, dayEntrada] = fechaEntradaStr.split('-').map(Number);
        const fechaEntrada = new Date(Date.UTC(yearEntrada, monthEntrada - 1, dayEntrada));

        const fechaSalidaStr = intensivo.fechaSalida;
        if (!fechaSalidaStr || !/^\d{4}-\d{2}-\d{2}$/.test(fechaSalidaStr)) return null;
        const [yearSalida, monthSalida, daySalida] = fechaSalidaStr.split('-').map(Number);
        const fechaSalida = new Date(Date.UTC(yearSalida, monthSalida - 1, daySalida));

        const diasEngorde = (fechaSalida.getTime() > fechaEntrada.getTime()) ? (fechaSalida.getTime() - fechaEntrada.getTime()) / (1000 * 60 * 60 * 24) : 0;
        const gananciaDiariaKg = diasEngorde > 0 ? (pesoSalida - pesoEntrada) / diasEngorde : 0;

        const ofertaForrajeMensual = pastureProfile.monthly_production.map(p => (parseNum(p) || 0) * hectareas * pastureUtilization);

        const balanceData = Array.from({ length: 12 }).map((_, i) => {
            const monthIndex = (fechaEntrada.getUTCMonth() + i) % 12;
            const yearOffset = Math.floor((fechaEntrada.getUTCMonth() + i) / 12);
            const currentYear = fechaEntrada.getUTCFullYear() + yearOffset;
            const currentMonthStartDate = new Date(Date.UTC(currentYear, monthIndex, 1));
            const nextMonthStartDate = new Date(Date.UTC(currentYear, monthIndex + 1, 1));
            
            const isCycleActive = currentMonthStartDate < fechaSalida && nextMonthStartDate > fechaEntrada;

            const ofertaMes = ofertaForrajeMensual[monthIndex] || 0;
            
            if (!isCycleActive) {
                return {
                    month: monthNames[monthIndex],
                    pesoAnimal: 0,
                    oferta: ofertaMes,
                    demanda: 0,
                    balance: ofertaMes,
                    balancePct: ofertaMes > 0 ? 1 : 0,
                };
            }

            let diasAcumulados = 0;
            if(currentMonthStartDate > fechaEntrada) {
                diasAcumulados = (currentMonthStartDate.getTime() - fechaEntrada.getTime()) / (1000 * 60 * 60 * 24);
            }
            
            const diasMes = new Date(currentYear, monthIndex + 1, 0).getUTCDate();
            
            const pesoAnimalInicioMes = pesoEntrada + (gananciaDiariaKg * diasAcumulados);
            const gananciaMes = gananciaDiariaKg * diasMes;
            const pesoPromedioMes = pesoAnimalInicioMes + (gananciaMes / 2);

            const consumoDiarioAnimal = pesoPromedioMes * dailyConsumptionPercentage; 
            const demandaMensualRebano = (consumoDiarioAnimal * totalAnimales * diasMes) / 1000;

            const balanceMes = ofertaMes - demandaMensualRebano;
            const balancePct = ofertaMes > 0 ? balanceMes / ofertaMes : (balanceMes < 0 ? -1 : 0);

            const currentAnimalWeight = pesoAnimalInicioMes > pesoSalida ? pesoSalida : pesoAnimalInicioMes;

            return {
                month: monthNames[monthIndex],
                pesoAnimal: currentAnimalWeight,
                oferta: ofertaMes,
                demanda: demandaMensualRebano,
                balance: balanceMes,
                balancePct: balancePct,
            };
        });

        return { balanceData };

    }, [ganaderiaData, fullForageData, isLoading, monthNames, selectedPastureId, pastureOptions, t]);

    useEffect(() => {
        if (!selectedPastureId && pastureOptions.length > 0) {
            setSelectedPastureId(pastureOptions[0].id);
        }
    }, [pastureOptions, selectedPastureId]);


    return { results, isLoading, pastureOptions, selectedPastureId, setSelectedPastureId };
};