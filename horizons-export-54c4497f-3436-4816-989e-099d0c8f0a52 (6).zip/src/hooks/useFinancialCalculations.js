import { useMemo } from 'react';
import { useGanaderiaCalculations } from './useGanaderiaCalculations';
import { useAgricultureCalculations } from './useAgricultureCalculations';
import { parseNum } from '@/utils/financial';

const useFinancialCalculations = (projectData, agricultureData, ganaderiaData, tirVanCalculations) => {
    const { calculations: ganaderiaCalculations } = useGanaderiaCalculations(ganaderiaData, projectData);
    const { totalCalculations: agricultureTotals } = useAgricultureCalculations({ cultivos: agricultureData?.cultivos });

    const calculations = useMemo(() => {
        if (!projectData) return null;

        const isGanaderiaEnabled = projectData.modules?.ganaderia && ganaderiaData?.isEnabled;
        const isAgriculturaEnabled = projectData.modules?.agricultura && agricultureData?.isEnabled;

        // Para el Resumen Ejecutivo (Antes de Impuestos), usamos el margen bruto de ganadería
        // y la ganancia bruta (antes de impuestos) de agricultura.
        const ganaderiaTradicionalProfit = isGanaderiaEnabled ? (ganaderiaCalculations?.tradicional?.margenNeto || 0) : 0;
        const ganaderiaTecnificadoProfit = isGanaderiaEnabled ? (ganaderiaCalculations?.intensivo?.margenNeto || 0) : 0;

        // agricultureTotals.tradicionalTotalGananciaNeta y tecnifiedTotalGananciaNeta ya son antes de impuestos
        const agriculturaTradicionalProfit = isAgriculturaEnabled ? (agricultureTotals?.tradicionalTotalGananciaNeta || 0) : 0;
        const agriculturaTecnificadoProfit = isAgriculturaEnabled ? (agricultureTotals?.tecnifiedTotalGananciaNeta || 0) : 0;

        const traditional = {
            revenue: ganaderiaTradicionalProfit + agriculturaTradicionalProfit,
            ganaderia: ganaderiaTradicionalProfit,
            agricultura: agriculturaTradicionalProfit,
        };

        const tech = {
            revenue: ganaderiaTecnificadoProfit + agriculturaTecnificadoProfit,
            ganaderia: ganaderiaTecnificadoProfit,
            agricultura: agriculturaTecnificadoProfit,
        };

        const totalInvestment = projectData.investments?.reduce((acc, item) => acc + (parseNum(item.cantidad) * parseNum(item.valorUnitario)), 0) || 0;
        const financialCost = tirVanCalculations?.loanDetails?.totalIntereses || 0;
        
        const projectHectares = (isGanaderiaEnabled ? parseNum(ganaderiaData?.params?.hectareasIntensivo) : 0) + 
                               (isAgriculturaEnabled ? (agricultureTotals?.totalHectareasTecnified || 0) : 0);

        return {
            traditional,
            tech,
            profitDifference: tech.revenue - traditional.revenue,
            totalInvestment,
            financialCost,
            paybackPeriod: tirVanCalculations?.metrics?.payback || 'N/A',
            projectHectares,
            npv: tirVanCalculations?.metrics?.van || 0,
            irr: tirVanCalculations?.metrics?.tir || 'N/A',
            roi: tirVanCalculations?.metrics?.roi || 0,
            totalFinancingCost: tirVanCalculations?.loanDetails?.totalIntereses || 0,
        };
    }, [projectData, agricultureData, ganaderiaData, ganaderiaCalculations, agricultureTotals, tirVanCalculations]);

    return calculations;
};

export default useFinancialCalculations;