import { useMemo } from 'react';
    import { useAgricultureCalculations } from '@/hooks/useAgricultureCalculations';
    import { useGanaderiaCalculations } from '@/hooks/useGanaderiaCalculations';

    const p = (value) => {
      if (typeof value === 'number') return value;
      if (typeof value === 'string') {
          const strValue = value.replace(/\./g, '').replace(/,/g, '.');
          const num = parseFloat(strValue);
          return isNaN(num) ? 0 : num;
      }
      return 0;
    };

    export const useCarbonCalculations = (ganaderiaData, agricultureData, projectData) => {
      const { totalCalculations: agCalculations } = useAgricultureCalculations(agricultureData);
      const { calculations: ganaderiaCalculations } = useGanaderiaCalculations(ganaderiaData, projectData);

      const calculations = useMemo(() => {
        const emissionFactors = {
          entericFermentation: 0.056, // tCO2e/cabeza/año
          manureManagement: 0.005, // tCO2e/cabeza/año
          pastureSequestration: 0.75, // tCO2e/ha/año - Pastura degradada/tradicional con baja renovación
          improvedPastureSequestration: 4.5, // tCO2e/ha/año - Pastura tecnificada con riego y rotación
          forestSequestration: 7.5, // tCO2e/ha/año
          reforestationSequestration: 15.0, // tCO2e/ha/año
          fertilizerN: 0.0058, // tCO2e/kg N
          diesel: 0.00268, // tCO2e/litro
        };

        const projectYears = p(projectData?.projectYears) || 1;
        const modules = projectData?.modules || { ganaderia: true, agricultura: true };

        let projectHectares = 0;
        if (modules.ganaderia && ganaderiaData?.isEnabled) {
            projectHectares = p(ganaderiaData.params.hectareasIntensivo);
        } else if (modules.agricultura && agricultureData && agricultureData.length > 0) {
            const firstEnabledSafra = agricultureData.find(s => s.isEnabled);
            if (firstEnabledSafra) {
                const tradHa = p(firstEnabledSafra.traditional.hectareas);
                const techHa = p(firstEnabledSafra.tecnified.hectareas);
                projectHectares = Math.max(tradHa, techHa);
            }
        }
        
        if (projectHectares === 0 && projectData?.investments) {
            projectHectares = p(projectData.investments.find(inv => inv.descripcion.toLowerCase() === 'tierra')?.cantidad) || 0;
        }

        let projectType = 'No definido';
        if (modules.ganaderia && modules.agricultura) {
            projectType = 'Proyecto Mixto (Ganadería y Agricultura)';
        } else if (modules.ganaderia) {
            projectType = 'Proyecto de Ganadería';
        } else if (modules.agricultura) {
            projectType = 'Proyecto de Agricultura';
        }

        const hectareasConservacion = p(projectData?.hectareasConservacion);
        const hectareasReforestacion = p(projectData?.hectareasReforestacion);
        
        const hectareasPastura = Math.max(0, projectHectares - hectareasConservacion - hectareasReforestacion);

        const sequestrationPasture = hectareasPastura * emissionFactors.pastureSequestration;
        const sequestrationImprovedPasture = hectareasPastura * emissionFactors.improvedPastureSequestration;
        const sequestrationForest = hectareasConservacion * emissionFactors.forestSequestration;
        const sequestrationReforestation = hectareasReforestacion * emissionFactors.reforestationSequestration;

        const totalSequestrationTraditional = sequestrationPasture + sequestrationForest + sequestrationReforestation;
        const totalSequestrationTech = sequestrationImprovedPasture + sequestrationForest + sequestrationReforestation;

        let traditionalEmissions = 0;
        let techEmissions = 0;
        
        const dieselEmissions = p(projectData?.consumoDieselAnual) * emissionFactors.diesel;
        traditionalEmissions += dieselEmissions;
        techEmissions += dieselEmissions;

        if (modules.ganaderia && ganaderiaData?.isEnabled) {
          const traditionalCattle = p(ganaderiaCalculations.tradicional.totalCabezas);
          traditionalEmissions += (traditionalCattle * emissionFactors.entericFermentation) + (traditionalCattle * emissionFactors.manureManagement);

          const techCattle = p(ganaderiaCalculations.intensivo.totalCabezas);
          techEmissions += (techCattle * emissionFactors.entericFermentation) + (techCattle * emissionFactors.manureManagement);
        }

        if (modules.agricultura && agricultureData && agricultureData.length > 0) {
            const haTradicional = agCalculations.totalHectareasTradicional;
            if (haTradicional > 0) {
              traditionalEmissions += agCalculations.avgDosisNTradicional * haTradicional * emissionFactors.fertilizerN;
            }
            const haTecnificado = agCalculations.totalHectareasTecnified;
            if (haTecnificado > 0) {
              techEmissions += agCalculations.avgDosisNTecnified * haTecnificado * emissionFactors.fertilizerN;
            }
        }

        const calculateModel = (totalEmissions, totalSequestration) => {
          const netBalance = totalEmissions - totalSequestration;
          const totalProjectBalance = netBalance * projectYears;
          const potentialRevenue = netBalance < 0 ? Math.abs(totalProjectBalance) * p(projectData?.precioTonCO2) : 0;
          return {
            totalEmissions,
            totalSequestration,
            netBalance,
            totalProjectBalance,
            potentialRevenue,
          };
        };

        const traditional = calculateModel(traditionalEmissions, totalSequestrationTraditional);
        const tech = calculateModel(techEmissions, totalSequestrationTech);

        const emissionsReduction = traditional.totalEmissions - tech.totalEmissions;
        const emissionsReductionPct = traditional.totalEmissions > 0 ? emissionsReduction / traditional.totalEmissions : 0;
        
        const sequestrationIncrease = tech.totalSequestration - traditional.totalSequestration;
        const sequestrationIncreasePct = traditional.totalSequestration > 0 ? sequestrationIncrease / traditional.totalSequestration : 0;

        const netBalanceChange = tech.netBalance - traditional.netBalance;
        const netBalancePct = traditional.netBalance !== 0 ? netBalanceChange / Math.abs(traditional.netBalance) : 0;

        const comparison = {
            emissionsReduction,
            emissionsReductionPct,
            sequestrationIncrease,
            sequestrationIncreasePct,
            netBalanceChange,
            netBalancePct
        };

        return { traditional, tech, projectType, projectHectares, comparison };
      }, [ganaderiaData, agricultureData, projectData, agCalculations, ganaderiaCalculations]);

      const emissionFactors = {
        entericFermentation: 0.056,
        manureManagement: 0.005,
        pastureSequestration: 0.75,
        improvedPastureSequestration: 4.5,
        forestSequestration: 7.5,
        reforestationSequestration: 15.0,
        fertilizerN: 0.0058,
        diesel: 0.00268,
      };

      return { calculations, emissionFactors };
    };