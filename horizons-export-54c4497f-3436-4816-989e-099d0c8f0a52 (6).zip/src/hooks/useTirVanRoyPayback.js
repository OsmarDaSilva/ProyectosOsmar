import { useMemo } from 'react';
import { useGanaderiaCalculations } from './useGanaderiaCalculations';
import { useAgricultureCalculations } from './useAgricultureCalculations';

const toNumber = (v) => {
  if (v == null) return 0;
  if (typeof v === 'number' && isFinite(v)) return v;
  let s = String(v).replace(/USD|\s|\u00A0/g, '').replace(/\./g, '').replace(/,/g, '.');
  const n = Number(s);
  return isFinite(n) ? n : 0;
};

const parsePercentage = (val) => {
    if (val === null || val === undefined) return 0;
    const num = toNumber(val);
    return num / 100;
};

export const useTirVanRoyPayback = ({ projectData, agricultureData, ganaderiaData }) => {
    const { calculations: ganaderiaCalculations } = useGanaderiaCalculations(ganaderiaData);
    const { totalCalculations: agricultureTotals } = useAgricultureCalculations({ cultivos: agricultureData?.cultivos });

    const calculations = useMemo(() => {
        if (!projectData || !projectData.investments) {
            return { tableData: [], metrics: {}, cashFlows: [], error: "Faltan datos del proyecto o de inversión." };
        }

        try {
            const plazo = parseInt(projectData.projectYears, 10) || 10;
            const investments = projectData.investments || [];
            
            const financial = {
                tasaDescuento: projectData.discountRate,
                costoOportunidad: projectData.costoOportunidad,
                tasaInteres: projectData.tasaInteres,
            };

            const isGanaderiaEnabled = projectData.modules?.ganaderia && ganaderiaData?.isEnabled;
            const isAgriculturaEnabled = projectData.modules?.agricultura && agricultureData?.isEnabled;

            const gananciaBrutaGanaderiaTrad = isGanaderiaEnabled ? (toNumber(ganaderiaCalculations?.tradicional?.margenNeto) || 0) : 0;
            const gananciaBrutaGanaderiaTecn = isGanaderiaEnabled ? (toNumber(ganaderiaCalculations?.intensivo?.margenNeto) || 0) : 0;
            
            const gananciaBrutaAgriculturaTrad = isAgriculturaEnabled ? (toNumber(agricultureTotals?.tradicionalTotalGananciaNeta) || 0) : 0;
            const gananciaBrutaAgriculturaTecn = isAgriculturaEnabled ? (toNumber(agricultureTotals?.tecnifiedTotalGananciaNeta) || 0) : 0;
            
            const flujoCajaBrutoAnualTotal = gananciaBrutaGanaderiaTrad + gananciaBrutaGanaderiaTecn + gananciaBrutaAgriculturaTrad + gananciaBrutaAgriculturaTecn;

            const impuestosAnualesGanaderiaTrad = isGanaderiaEnabled ? ((toNumber(ganaderiaCalculations?.tradicional?.totalIragro) || 0) + (toNumber(ganaderiaCalculations?.tradicional?.totalIrp) || 0)) : 0;
            const impuestosAnualesGanaderiaTecn = isGanaderiaEnabled ? ((toNumber(ganaderiaCalculations?.intensivo?.totalIragro) || 0) + (toNumber(ganaderiaCalculations?.intensivo?.totalIrp) || 0)) : 0;
            
            const impuestosAnualesAgriculturaTrad = isAgriculturaEnabled ? (toNumber(agricultureTotals?.tradicionalTotalImpuestos) || 0) : 0;
            const impuestosAnualesAgriculturaTecn = isAgriculturaEnabled ? (toNumber(agricultureTotals?.tecnifiedTotalImpuestos) || 0) : 0;

            const impuestosAnualesTotalUnificado = impuestosAnualesGanaderiaTrad + impuestosAnualesGanaderiaTecn + impuestosAnualesAgriculturaTrad + impuestosAnualesAgriculturaTecn;

            const tableData = [];
            for (let year = 0; year <= plazo; year++) {
                const inversionFija = investments.reduce((acc, inv) => {
                    const investmentYear = parseInt(inv.year, 10);
                    const effectiveYear = isNaN(investmentYear) ? 0 : investmentYear;
                    return (effectiveYear === year) ? acc + (toNumber(inv.cantidad) * toNumber(inv.valorUnitario)) : acc;
                }, 0);

                const valorResidual = investments.reduce((acc, inv) => {
                    const vidaUtil = parseInt(inv.vidaUtil, 10);
                    const investmentYear = parseInt(inv.year, 10);
                    const effectiveYear = isNaN(investmentYear) ? 0 : investmentYear;
                    if (year === plazo && vidaUtil > 0 && (effectiveYear + vidaUtil) > plazo) {
                        return acc + (toNumber(inv.cantidad) * toNumber(inv.valorUnitario) * parsePercentage(inv.valorResidualPct));
                    }
                    return acc;
                }, 0);

                const flujoCajaBruto = year > 0 ? flujoCajaBrutoAnualTotal : 0;
                const impuestos = year > 0 ? impuestosAnualesTotalUnificado : 0;
                
                const flujoCajaNeto = (year === 0)
                    ? -inversionFija
                    : flujoCajaBruto - impuestos - inversionFija;

                tableData.push({
                    year,
                    valorResidual,
                    flujoCajaBruto,
                    impuestos: -impuestos,
                    flujoCajaNeto,
                    flujoCajaAcumulado: 0,
                    inversionFija,
                    capitalTrabajo: 0, 
                    recuperoCapitalTrabajo: 0,
                });
            }

            const years = tableData.length;
            if (years === 0) return { tableData: [], metrics: {}, cashFlows: [], error: "No hay datos para calcular la viabilidad." };

            const cashFlows = tableData.map((row, i) => {
                const neto = toNumber(row.flujoCajaNeto);
                const residual = i === years - 1 ? toNumber(row.valorResidual) : 0;
                return neto + residual;
            });

            if (cashFlows.length > 0 && cashFlows[0] > 0) {
                cashFlows[0] = -Math.abs(cashFlows[0]);
            }
            
            tableData.forEach((row, i) => {
              row.flujoCajaNeto = cashFlows[i];
            });

            let flujoCajaAcumulado = 0;
            tableData.forEach((row, i) => {
                flujoCajaAcumulado += cashFlows[i];
                row.flujoCajaAcumulado = flujoCajaAcumulado;
            });
            
            const discountRateRaw = toNumber(financial?.tasaDescuento);
            const opportunityCostRaw = toNumber(financial?.costoOportunidad);
            const interestRateRaw = toNumber(financial?.tasaInteres);

            let discountRate = 0;
            if (discountRateRaw > 0) {
                discountRate = discountRateRaw / 100;
            } else if (opportunityCostRaw > 0) {
                discountRate = opportunityCostRaw / 100;
            } else if (interestRateRaw > 0) {
                discountRate = interestRateRaw / 100;
            }

            const VAN = cashFlows.reduce((acc, cf, t) => acc + cf / Math.pow(1 + discountRate, t), 0);

            const irr = (cfs, guess = 0.1) => {
                const f = (x) => cfs.reduce((a, cf, t) => a + cf / Math.pow(1 + x, t), 0);
                const df = (x) => cfs.reduce((a, cf, t) => a - (t * cf) / Math.pow(1 + x, t + 1), 0);
                let x = guess;
                for (let i = 0; i < 50; i++) {
                    const fx = f(x), dfx = df(x);
                    if (Math.abs(dfx) < 1e-12) break;
                    const x1 = x - fx / dfx;
                    if (!isFinite(x1)) break;
                    if (Math.abs(x1 - x) < 1e-10) return x1;
                    x = x1;
                }
                let lo = -0.99, hi = 5;
                for (let i = 0; i < 200; i++) {
                    const mid = (lo + hi) / 2;
                    if (f(mid) === 0 || (hi - lo) < 1e-10) return mid;
                    (f(lo) * f(mid) < 0) ? (hi = mid) : (lo = mid);
                }
                return NaN;
            };
            const TIR = irr(cashFlows);

            const payback = (() => {
                let acc = 0;
                for (let t = 0; t < cashFlows.length; t++) {
                    const prev = acc;
                    acc += cashFlows[t];
                    if (acc >= 0) {
                        const needed = -prev;
                        const obtained = cashFlows[t];
                        const frac = obtained !== 0 ? needed / obtained : 0;
                        return (t - 1 + frac);
                    }
                }
                return -1;
            })();

            const totalInvestmentValue = tableData.reduce((sum, row) => sum + toNumber(row.inversionFija), 0);
            const sumOfPositiveFlows = cashFlows.slice(1).reduce((sum, flow) => sum + (flow > 0 ? flow : 0), 0);
            
            const roi = totalInvestmentValue > 0 && years > 1 ? ((sumOfPositiveFlows / (years - 1)) / totalInvestmentValue) : 0;

            const totalInvestment = investments.reduce((acc, item) => acc + (toNumber(item.cantidad) * toNumber(item.valorUnitario)), 0);
            const plazoPrestamo = toNumber(projectData.plazo);
            const tasaInteresPrestamo = parsePercentage(projectData.tasaInteres);
            let cuotaAnual = 0;
            if (totalInvestment > 0 && plazoPrestamo > 0) {
                if (tasaInteresPrestamo > 0) {
                    cuotaAnual = totalInvestment * (tasaInteresPrestamo * Math.pow(1 + tasaInteresPrestamo, plazoPrestamo)) / (Math.pow(1 + tasaInteresPrestamo, plazoPrestamo) - 1);
                } else {
                    cuotaAnual = totalInvestment / plazoPrestamo;
                }
            }
            const totalPagado = cuotaAnual * plazoPrestamo;
            const totalIntereses = totalPagado > 0 && totalInvestment > 0 ? totalPagado - totalInvestment : 0;
            
            const gananciaLiquidaFinalTradicional = gananciaBrutaGanaderiaTrad + gananciaBrutaAgriculturaTrad - (impuestosAnualesGanaderiaTrad + impuestosAnualesAgriculturaTrad);
            const gananciaLiquidaFinalTecnificado = gananciaBrutaGanaderiaTecn + gananciaBrutaAgriculturaTecn - (impuestosAnualesGanaderiaTecn + impuestosAnualesAgriculturaTecn);

            return {
                tableData,
                cashFlows,
                metrics: {
                    van: VAN,
                    tir: isFinite(TIR) ? TIR : null,
                    roi: roi,
                    payback: payback !== -1 ? payback.toFixed(2) : 'N/A',
                    plazo: years - 1,
                    discountRate: discountRateRaw,
                    opportunityCost: opportunityCostRaw,
                    discountRateUsed: discountRate * 100,
                    totalInvestment: totalInvestmentValue,
                },
                loanDetails: {
                    valorPrestamo: totalInvestment,
                    cuotaAnual,
                    totalIntereses,
                },
                traditional: {
                    gananciaNetaAnual: gananciaLiquidaFinalTradicional,
                },
                tecnificado: {
                    gananciaNetaAnual: gananciaLiquidaFinalTecnificado,
                },
                error: null,
            };
        } catch (e) {
            console.error("Error en useTirVanRoyPayback:", e);
            return { tableData: [], metrics: {}, cashFlows: [], error: `Error en los cálculos de viabilidad: ${e.message}` };
        }
    }, [projectData, agricultureData, ganaderiaData, ganaderiaCalculations, agricultureTotals]);

    return calculations;
};