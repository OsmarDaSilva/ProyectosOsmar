import { useQuery, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';

    const fetchProjectData = async (userId) => {
        if (!userId) return null;
        const { data, error } = await supabase
            .from('projects')
            .select('*')
            .eq('user_id', userId)
            .single();
        
        if (error && error.code !== 'PGRST116') { // PGRST116 means no rows found
            throw new Error(error.message);
        }
        return data;
    };

    export const useProjectData = (userId) => {
        return useQuery({
            queryKey: ['projectData', userId],
            queryFn: () => fetchProjectData(userId),
            enabled: !!userId,
        });
    };