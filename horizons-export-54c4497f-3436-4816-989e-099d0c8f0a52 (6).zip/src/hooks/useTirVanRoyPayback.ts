import { useMemo } from 'react';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { parseNumber } from '@/lib/utils';

interface Investment {
    descripcion: string;
    cantidad: string | number;
    valorUnitario: string | number;
    vidaUtil: string | number;
    valorResidual: string | number;
}

interface GanaderiaParams {
    [key: string]: any;
}

interface CashFlowResult {
    cashFlow: any[];
    summary: {
        van: number;
        tir: number;
        payback: number | string;
        totalInvestment: number;
    };
}

const calculateNPV = (rate: number, cashflows: number[]): number => {
    return cashflows.reduce((acc, val, i) => acc + val / Math.pow(1 + rate, i), 0);
};

const calculateIRR = (cashflows: number[], guess = 0.1): number => {
    const maxIterations = 100;
    const precision = 1e-7;
    let x0 = guess;

    for (let i = 0; i < maxIterations; i++) {
        const npv = calculateNPV(x0, cashflows);
        const derivative = cashflows.reduce((acc, val, j) => {
            if (j === 0) return acc;
            return acc - (j * val) / Math.pow(1 + x0, j + 1);
        }, 0);

        if (Math.abs(derivative) < precision) break;

        const x1 = x0 - npv / derivative;
        if (Math.abs(x1 - x0) < precision) return x1;
        x0 = x1;
    }
    return x0;
};

export const useTirVanRoyPayback = (ganaderiaData: GanaderiaParams, activeModel: 'tradicional' | 'intensivo'): CashFlowResult => {
    const { projectData } = useProjectData();

    return useMemo(() => {
        const p = parseNumber;
        const { investments = [], plazo = '10', tasaDescuento = '11' } = projectData || {};
        const modelData = ganaderiaData[activeModel] || {};
        const params = ganaderiaData.params || {};

        const projectDuration = p(plazo);
        const discountRate = p(tasaDescuento) / 100;

        const totalFixedInvestment = investments.reduce((sum: number, item: Investment) => sum + p(item.cantidad) * p(item.valorUnitario), 0);

        const annualDepreciation = investments.reduce((sum: number, item: Investment) => {
            const vidaUtil = p(item.vidaUtil);
            if (vidaUtil > 0) {
                const cost = p(item.cantidad) * p(item.valorUnitario);
                const residualValue = cost * (p(item.valorResidual) / 100);
                return sum + (cost - residualValue) / vidaUtil;
            }
            return sum;
        }, 0);

        const residualValueAtEnd = investments.reduce((sum: number, item: Investment) => {
            const vidaUtil = p(item.vidaUtil);
            if (vidaUtil > projectDuration) {
                const cost = p(item.cantidad) * p(item.valorUnitario);
                const residualAtEnd = cost * (1 - projectDuration / vidaUtil);
                return sum + residualAtEnd;
            }
            return sum;
        }, 0);

        const cabezas = p(params.hectareas) * p(modelData.cantidad);
        const pesoEntrada = p(params.pesoVivoEntrada);
        const pesoSalida = p(params.pesoVivoSalida);
        const precioCompraKg = p(params.precioCompraKgVivo);
        const precioVentaKgGancho = p(params.precioVentaKgGancho);
        const rendimientoCarcaza = p(params.rendimientoCarcaza) / 100;

        const fechaEntrada = new Date(modelData.fechaEntrada || '2025-01-01');
        const fechaSalida = new Date(modelData.fechaSalida || '2026-01-01');
        const cycleDurationDays = (fechaSalida.getTime() - fechaEntrada.getTime()) / (1000 * 3600 * 24);
        const cycleDurationYears = cycleDurationDays > 0 ? cycleDurationDays / 365.25 : 1;

        const annualSales = (cabezas * pesoSalida * rendimientoCarcaza * precioVentaKgGancho) / cycleDurationYears;

        const annualCosts = {
            suplementacion: (p(modelData.costoSuplementacion) * cabezas) / cycleDurationYears,
            sanidad: (p(modelData.costoVacunacion) * cabezas) / cycleDurationYears,
            flete: (p(modelData.fleteEntrada) * cabezas) / cycleDurationYears,
            comision: (p(modelData.comisionVendedor) / 100) * (cabezas * pesoEntrada * precioCompraKg) / cycleDurationYears,
            administrativo: (p(modelData.costoAdministrativo) * cabezas) / cycleDurationYears,
            fertilizacion: (p(modelData.costoFertilizacion) * p(params.hectareas)) / cycleDurationYears,
            energia: (p(modelData.costoEnergia) * p(params.hectareas)) / cycleDurationYears,
            manutencion: (p(modelData.costoManutencion) * p(params.hectareas)) / cycleDurationYears,
            combustible: (p(modelData.combustibleGasoil) * p(params.hectareas)) / cycleDurationYears,
            otros: (p(modelData.otrosCostos) * cabezas) / cycleDurationYears,
        };

        const totalAnnualOperatingCosts = Object.values(annualCosts).reduce((sum, cost) => sum + cost, 0);
        const workingCapitalInvestment = totalAnnualOperatingCosts;

        const cashFlow = Array.from({ length: projectDuration + 1 }, (_, year) => {
            if (year === 0) {
                return {
                    year: 0,
                    inversionFija: -totalFixedInvestment,
                    inversionCapitalTrabajo: 0,
                    valorResidual: 0,
                    flujoBruto: 0,
                    impuestos: 0,
                    flujoNeto: -totalFixedInvestment,
                };
            }

            const inversionCapitalTrabajo = year === 1 ? -workingCapitalInvestment : 0;
            const recuperoCapitalTrabajo = year === projectDuration ? workingCapitalInvestment : 0;
            const valorResidual = year === projectDuration ? residualValueAtEnd : 0;

            const ebitda = annualSales - totalAnnualOperatingCosts;
            const ebit = ebitda - annualDepreciation;
            const taxRate = p(modelData.impuestoIragro) / 100;
            const impuestos = ebit > 0 ? ebit * taxRate : 0;
            const flujoBruto = ebitda;
            const flujoNeto = flujoBruto - impuestos + inversionCapitalTrabajo + valorResidual + recuperoCapitalTrabajo;

            return {
                year,
                inversionFija: 0,
                inversionCapitalTrabajo,
                valorResidual: valorResidual + recuperoCapitalTrabajo,
                flujoBruto,
                impuestos: -impuestos,
                flujoNeto,
            };
        });

        const netCashFlows = cashFlow.map(cf => cf.flujoNeto);
        const van = calculateNPV(discountRate, netCashFlows);
        const tir = calculateIRR(netCashFlows);

        let cumulativeCashFlow = 0;
        let payback = 'No recupera';
        for (let i = 0; i < cashFlow.length; i++) {
            cumulativeCashFlow += netCashFlows[i];
            if (cumulativeCashFlow > 0) {
                const lastNegativeYear = i - 1;
                const lastNegativeCumulative = cumulativeCashFlow - netCashFlows[i];
                payback = lastNegativeYear + Math.abs(lastNegativeCumulative) / netCashFlows[i];
                break;
            }
        }

        return {
            cashFlow,
            summary: {
                van,
                tir,
                payback,
                totalInvestment: totalFixedInvestment + workingCapitalInvestment,
            },
        };

    }, [projectData, ganaderiaData, activeModel]);
};