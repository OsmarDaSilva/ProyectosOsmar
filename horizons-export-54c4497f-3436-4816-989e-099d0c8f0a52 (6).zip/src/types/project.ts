export interface ProjectInvestment {
      id: string;
      descripcion: string;
      cantidad: number | string;
      valorUnitario: number | string;
      vidaUtil: number | string;
      valorResidualPct: number | string;
    }

    export interface ProjectData {
      projectName: string;
      ownerName: string;
      propertyLocation: string;
      totalArea: string;
      modules: {
        ganaderia: boolean;
        agricultura: boolean;
      };
      investments?: ProjectInvestment[];
      projectYears?: number;
      plazo?: number;
      tasaInteres?: number;
      discountRate?: number;
      rucCi?: string;
      location?: string;
      hectareasConservacion?: number;
      hectareasReforestacion?: number;
      consumoDieselAnual?: number;
      precioTonCO2?: number;
    }

    export interface GanaderiaParams {
      tipoAnimal: string;
      pesoVivoEntrada: string;
      precioCompraKgVivo: string;
      hectareasTradicional: string;
      hectareasIntensivo: string;
      pesoVivoSalida: string;
      desbaste: string;
      precioVentaKgGancho: string;
      rendimientoCarcaza: string;
      tasaInteresAnual: string;
    }

    export interface GanaderiaModelData {
      cantidad: string;
      fechaEntrada: string;
      fechaSalida: string;
      fleteEntrada: string;
      comisionVendedor: string;
      costoSuplementacion: string;
      costoAdministrativo: string;
      costoVacunacion: string;
      costoFertilizacion: string;
      costoEnergia: string;
      costoManutencion: string;
      combustibleGasoil: string;
      otrosCostos: string;
      mortandad: string;
      impuestoIragro: string;
      impuestoIrp: string;
    }

    export interface GanaderiaData {
      isEnabled: boolean;
      params: GanaderiaParams;
      tradicional: GanaderiaModelData;
      intensivo: GanaderiaModelData;
    }

    export interface AgricultureData {
      isEnabled: boolean;
      cultivos: any[];
    }

    export interface FullForageData {
      headers: string[];
      rows: any[];
    }

    export interface InitialCalculationsModel {
      revenue: number;
      totalCosts: number;
      grossProfit: number;
    }
    export interface InitialCalculations {
      traditional: InitialCalculationsModel;
      tech: InitialCalculationsModel;
      totalInvestment: number;
      totalFinancingCost: number;
      paybackPeriod: string;
      tir: string;
      van: number;
      roi: number;
      plazo: number;
      tasaInteres: number;
    }

    export interface FinancialModel {
      revenue: number;
      totalCosts: number;
      grossProfit: number;
      totalInvestment: number;
      profitMargin: number;
      roi: number;
    }

    export interface CashFlowYear {
      year: number;
      traditionalCashFlow: number;
      techCashFlow: number;
      cumulativeTraditional: number;
      cumulativeTech: number;
    }

    export interface FinancialCalculations {
      traditionalModel: FinancialModel;
      techModel: FinancialModel;
      comparison: {
        revenueDifference: number;
        costDifference: number;
        profitDifference: number;
        revenueIncrease: number;
        costIncrease: number;
        profitIncrease: number;
        isMoreProfitable: boolean;
      };
      cashFlow: CashFlowYear[];
      paybackPeriod: string;
      npv: number;
      irr: string;
      totalFinancingCost: number;
    }

    export interface TableDataRow {
      year: number;
      inversionesFijas: number;
      inversionesCapitalTrabajo: number;
      valorResidual: number;
      flujoCajaBruto: number;
      impuestos: number;
      flujoCajaNeto: number;
      flujoCajaAcumulado: number;
      factorDescuento: number;
      flujoCajaNetoActualizado: number;
    }

    export interface TirVanMetrics {
      tir: string | number;
      van: number;
      payback: string;
      roi: number;
    }

    export interface TirVanCalculations {
      tableData: TableDataRow[];
      metrics: TirVanMetrics;
      error: string | null;
      ingresosTradicional?: number;
      costosTradicional?: number;
      flujoNetoOperativoTradicional?: number;
      ingresosTecnificado?: number;
      costosTecnificado?: number;
      flujoNetoOperativoTecnificado?: number;
      flujoNetoOperativoAnualTotal?: number;
    }