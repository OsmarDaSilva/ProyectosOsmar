export type TicketStatus = 'Abierto' | 'En Progreso' | 'Resuelto' | 'Cerrado';
export type TicketPriority = 'Baja' | 'Media' | 'Alta' | 'Urgente';

export interface Client {
  id: string;
  name: string;
}

export interface UserProfile {
  id: string;
  email: string;
}

export interface Ticket {
  id: string;
  ticket_number: number;
  client_id: string | null;
  created_by: string;
  assigned_to: string | null;
  subject: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  created_at: string;
  updated_at: string;
  client?: { name: string } | null;
  assigned_user?: { email: string } | null;
}