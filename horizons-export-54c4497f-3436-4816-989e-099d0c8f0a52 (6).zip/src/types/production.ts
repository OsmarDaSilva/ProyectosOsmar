export interface ProductionData {
  id: string;
  user_id: string;
  country: string | null;
  department_province: string | null;
  city_locality: string | null;
  year: number | null;
  crop: string | null;
  production_purpose: string | null;
  sowing_season: string | null;
  cultivation_method: string | null;
  yield_ton_ha: number | null;
  input_cost_ha: number | null;
  machinery_cost_ha: number | null;
  freight_cost_ha: number | null;
  land_rent_ha: number | null;
  electrical_energy_cost_ha: number | null;
  maintenance_repair_cost_ha: number | null;
  created_at: string;
  updated_at: string | null;
  // Calculated fields (optional, might not exist in DB)
  cost_ha_normal?: number;
  final_cost_ha?: number;
  actions?: any;
}