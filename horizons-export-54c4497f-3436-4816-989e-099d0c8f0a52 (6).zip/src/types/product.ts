export interface ProductSpecifications {
  [key: string]: any;
  _headerOrder?: string[];
}

export interface Product {
  user_id: string;
  product_name: string;
  brand: string | null;
  category: string | null;
  sku: string;
  specifications: ProductSpecifications;
  description: string | null;
  sale_price: number;
  purchase_price: number;
  created_at: string;
  updated_at: string;
  fts: any;
  embedding: any;
}