import React, { createContext, useState, useContext, useEffect } from 'react';

const GlobalAssistantContext = createContext();

export const useGlobalAssistant = () => useContext(GlobalAssistantContext);

const rawEnabled = import.meta.env.VITE_ENABLE_GLOBAL_ASSISTANT;
const enabledDefault = typeof rawEnabled === "string" && rawEnabled !== ""
    ? rawEnabled.toLowerCase() === "true"
    : true;

export const GlobalAssistantProvider = ({ children }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [enabled] = useState(enabledDefault);

    useEffect(() => {
        if (typeof window !== "undefined") {
            window.__dbgAssistant = { 
                enabled: enabled, 
                raw: rawEnabled, 
                path: window.location.hash 
            };
        }
    }, [enabled]);

    const toggleAssistant = () => setIsOpen(prev => !prev);
    const openAssistant = () => setIsOpen(true);
    const closeAssistant = () => setIsOpen(false);

    return (
        <GlobalAssistantContext.Provider value={{ isOpen, enabled, toggleAssistant, openAssistant, closeAssistant }}>
            {children}
        </GlobalAssistantContext.Provider>
    );
};