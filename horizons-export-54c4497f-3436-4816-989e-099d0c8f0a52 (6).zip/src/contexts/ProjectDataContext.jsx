import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
    import { useToast } from '@/components/ui/use-toast';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { supabase } from '@/lib/customSupabaseClient';
    import LoadingScreen from '@/components/LoadingScreen';
    import { useNavigate } from 'react-router-dom';
    import { useForageData } from '@/hooks/useForageData';

    const defaultFormData = {
        projectName: 'Nuevo Proyecto',
        ownerName: 'Propietario',
        rucCi: 'N/A',
        country: 'Paraguay',
        department: 'Alto Paraná',
        location: 'Ubicación',
        projectYears: 10,
        discountRate: 5,
        costoOportunidad: 5,
        tasaInteres: 8,
        plazo: 5,
        precioTonCO2: 15,
        consumoDieselAnual: 0,
        hectareasConservacion: 0,
        hectareasReforestacion: 0,
        modules: {
            ganaderia: true,
            agricultura: true,
        },
        investments: [
            { id: 'tierra', descripcion: 'Compra de propiedad / tierra', cantidad: 0, valorUnitario: 0, vidaUtil: 100, valorResidualPct: 100, year: 0 },
            { id: 'riego', descripcion: 'Sistemas de riego', cantidad: 100, valorUnitario: 3000, vidaUtil: 25, valorResidualPct: 10, year: 0 },
            { id: 'infraestructura', descripcion: 'Infraestructura general', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 20, year: 0 },
            { id: 'mecanizacion', descripcion: 'Mecanización y preparación de suelo, pasturas, alambrados y bebederos', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 10, year: 0 },
            { id: 'fotovoltaica', descripcion: 'Energia Fotovoltaica / Otras', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 10, year: 0 },
            { id: 'otros', descripcion: 'Otros / Varios', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 0, year: 0 },
        ],
    };

    const defaultGanaderiaData = {
        isEnabled: true,
        params: { tipoAnimal: "Novillo Toro", pesoVivoEntrada: "200", precioCompraKgVivo: "2,00", hectareasTradicional: "400", hectareasIntensivo: "100", pesoVivoSalida: "500", precioVentaKgGancho: "3,50", rendimientoCarcaza: "54,00%", tasaInteresAnual: "7,0%", desbaste: '4.00%' },
        tradicional: { cantidad: "1,1", fechaEntrada: "2026-01-01", fechaSalida: "2027-06-30", fleteEntrada: "25", comisionVendedor: "3,00%", costoSuplementacion: "50,00", costoAdministrativo: "25,00", costoVacunacion: "15", costoFertilizacion: "0", costoEnergia: "2,5", costoManutencion: "2,5", combustibleGasoil: "1", otrosCostos: "2,5", mortandad: "1,0%", impuestoIragro: "5,00%", impuestoIrp: "10,00%" },
        intensivo: { cantidad: "10", fechaEntrada: "2026-01-01", fechaSalida: "2027-01-01", fleteEntrada: "25", comisionVendedor: "3,00%", costoSuplementacion: "100,00", costoAdministrativo: "35,00", costoVacunacion: "15", costoFertilizacion: "200", costoEnergia: "350", costoManutencion: "2", combustibleGasoil: "5", otrosCostos: "5", mortandad: "1,0%", impuestoIragro: "5,00%", impuestoIrp: "10,00%" },
    };

    const defaultAgricultureData = {
        isEnabled: true,
        cultivos: []
    };

    const defaultProductionDbData = [];

    const ProjectDataContext = createContext();

    export const useProjectData = () => useContext(ProjectDataContext);

    export const ProjectDataProvider = ({ children }) => {
        const { toast } = useToast();
        const { user, loading: authLoading } = useAuth();
        const navigate = useNavigate();
        const [projectData, setProjectData] = useState(defaultFormData);
        const [agricultureData, setAgricultureData] = useState(defaultAgricultureData);
        const [ganaderiaData, setGanaderiaData] = useState(defaultGanaderiaData);
        const [productionDbData, setProductionDbData] = useState(defaultProductionDbData);
        const { data: fullForageData, isLoading: isForageLoading } = useForageData(user?.id);
        const [activeClientProject, setActiveClientProject] = useState(null);
        const [isSaving, setIsSaving] = useState(false);
        const [isSyncing, setIsSyncing] = useState(false);
        const [lastSync, setLastSync] = useState(null);
        const [isDataLoaded, setIsDataLoaded] = useState(false);

        const handleDataImported = useCallback((data, client) => {
            const baseProjectData = data.projectData || defaultFormData;
            setProjectData({
                ...defaultFormData,
                ...baseProjectData,
                ownerName: client.name,
                rucCi: client.ruc_ci,
                country: client.country || baseProjectData.country || 'Paraguay',
                department: client.department_province || baseProjectData.department || 'Alto Paraná',
            });
            setAgricultureData(data.agricultureData || defaultAgricultureData);
            setGanaderiaData(data.ganaderiaData || defaultGanaderiaData);
            setProductionDbData(data.productionDbData || defaultProductionDbData);
        }, []);

        const loadClientProject = useCallback((client, project) => {
            let newProjectData;
            if (project.project_data) {
                const baseProjectData = project.project_data.projectData || defaultFormData;
                newProjectData = {
                    ...defaultFormData,
                    ...baseProjectData,
                    ownerName: client.name,
                    rucCi: client.ruc_ci,
                    projectName: project.project_name,
                    location: project.location || baseProjectData.location || '',
                    country: client.country || baseProjectData.country || 'Paraguay',
                    department: client.department_province || baseProjectData.department || 'Alto Paraná',
                };
                setAgricultureData(project.project_data.agricultureData || defaultAgricultureData);
                setGanaderiaData(project.project_data.ganaderiaData || defaultGanaderiaData);
                setProductionDbData(project.project_data.productionDbData || defaultProductionDbData);
            } else {
                newProjectData = {
                    ...defaultFormData,
                    ownerName: client.name,
                    rucCi: client.ruc_ci,
                    projectName: project.project_name,
                    location: project.location || '',
                    country: client.country || 'Paraguay',
                    department: client.department_province || 'Alto Paraná',
                };
                setAgricultureData(defaultAgricultureData);
                setGanaderiaData(defaultGanaderiaData);
                setProductionDbData(defaultProductionDbData);
            }
            setProjectData(newProjectData);
            setActiveClientProject({ client, project: { ...project, project_data: { ...project.project_data, projectData: newProjectData } } });
            if (user) {
                localStorage.setItem(`lastActiveProject_${user.id}`, JSON.stringify({ client, project }));
            }
            toast({
                title: "Proyecto Cargado",
                description: `Se cargó el proyecto "${project.project_name}". Ya puede ir a la Calculadora.`,
            });
            navigate('/calculator');
        }, [user, navigate, toast]);

        const saveToClientProject = async (clientProjectId) => {
            if (!clientProjectId) {
                 toast({ variant: 'destructive', title: 'Error', description: 'Ningún proyecto de cliente está activo para guardar.' });
                 return;
            }
            setIsSaving(true);
            setIsSyncing(true);
            const dataToSave = { projectData, agricultureData, ganaderiaData, productionDbData };
            const { error } = await supabase
                .from('client_projects')
                .update({ project_data: dataToSave, updated_at: new Date().toISOString(), updated_by: user?.id })
                .eq('id', clientProjectId);
            setIsSaving(false);
            setIsSyncing(false);
            if (error) {
                toast({ variant: 'destructive', title: 'Error al Guardar', description: error.message });
            } else {
                setLastSync(new Date());
                toast({ title: '¡Éxito!', description: 'El estado actual de la calculadora se ha guardado en el proyecto del cliente.' });
            }
        };

        const resetProjectData = () => {
          setProjectData(defaultFormData);
          setAgricultureData(defaultAgricultureData);
          setGanaderiaData(defaultGanaderiaData);
          setProductionDbData(defaultProductionDbData);
          setActiveClientProject(null);
          if (user) {
            localStorage.removeItem(`lastActiveProject_${user.id}`);
          }
        };

        useEffect(() => {
            if (!authLoading && user && !isDataLoaded) {
                const lastProjectRaw = localStorage.getItem(`lastActiveProject_${user.id}`);
                if (lastProjectRaw) {
                    try {
                        const lastProject = JSON.parse(lastProjectRaw);
                        if (lastProject && lastProject.client && lastProject.project) {
                            setActiveClientProject(lastProject);
                            if (lastProject.project.project_data) {
                                handleDataImported(lastProject.project.project_data, lastProject.client);
                            }
                        }
                    } catch (e) {
                        console.error("Error parsing last active project from localStorage", e);
                        localStorage.removeItem(`lastActiveProject_${user.id}`);
                    }
                }
                setIsDataLoaded(true);
            } else if (!authLoading && !user) {
                setIsDataLoaded(true);
            }
        }, [authLoading, user, isDataLoaded, handleDataImported]);

        const value = {
            projectData,
            agricultureData,
            ganaderiaData,
            fullForageData: fullForageData || [],
            productionDbData,
            isDataLoaded: isDataLoaded && !isForageLoading,
            handleProjectUpdate: setProjectData,
            handleAgricultureUpdate: setAgricultureData,
            handleGanaderiaUpdate: setGanaderiaData,
            handleProductionDbUpdate: setProductionDbData,
            loadClientProject,
            saveToClientProject,
            activeClientProject,
            setActiveClientProject,
            resetProjectData,
            isSaving,
            isSyncing,
            lastSync,
        };

        if (authLoading || !isDataLoaded) {
            return <LoadingScreen message="Sincronizando datos..." />;
        }

        return (
            <ProjectDataContext.Provider value={value}>
                {children}
            </ProjectDataContext.Provider>
        );
    };