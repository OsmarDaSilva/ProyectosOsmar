import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { logError } from '@/lib/error-logger';

const AuthContext = createContext(undefined);

const fetchUserProfileWithRetry = async (userId, retries = 5, delay = 2000) => {
  for (let i = 0; i < retries; i++) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('role, full_name, phone')
        .eq('user_id', userId)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') { // PGRST116 is "Not Found"
        throw error;
      }
      
      if (data) return data;
    } catch (error) {
      logError(error, { module: 'SupabaseAuthContext', function: 'fetchUserProfileWithRetry', userId, attempt: i + 1 });
      if (i === retries - 1) { // If it's the last retry, rethrow to be caught outside
        throw error;
      }
    }
    
    // Wait before retrying, with exponential backoff
    await new Promise((r) => setTimeout(r, delay * Math.pow(2, i)));
  }
  
  console.warn(`User profile for ${userId} not found after ${retries} retries. Assigning default role.`);
  return { role: 'collaborator', full_name: null, phone: null };
};

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isRecovery, setIsRecovery] = useState(false);

  const processUserSession = useCallback(async (authUser) => {
    if (!authUser) return null;
    
    try {
      const profile = await fetchUserProfileWithRetry(authUser.id);
      
      const { data: company } = await supabase
        .from('companies')
        .select('id, name')
        .eq('user_id', authUser.id)
        .maybeSingle();

      return {
        ...authUser,
        profile,
        company,
        role: profile?.role || 'collaborator',
        full_name: profile?.full_name || authUser.user_metadata?.full_name || '',
        phone: profile?.phone || authUser.user_metadata?.phone || '',
      };
    } catch (error) {
      logError(error, { module: 'SupabaseAuthContext', function: 'processUserSession' });
      toast({
        variant: "destructive",
        title: "Error de Perfil",
        description: "No se pudo cargar la configuración del usuario. Se usará una configuración por defecto.",
      });
      return { ...authUser, role: 'collaborator', full_name: authUser.user_metadata?.full_name || '', phone: authUser.user_metadata?.phone || '' };
    }
  }, [toast]);

  useEffect(() => {
    setLoading(true);
    let isMounted = true;

    const initializeSession = async () => {
        try {
            const { data: { session: currentSession }, error: sessionError } = await supabase.auth.getSession();
            if (sessionError) throw sessionError;
            if (!isMounted) return;

            setSession(currentSession);
            if (currentSession?.user) {
                const userWithProfile = await processUserSession(currentSession.user);
                if (isMounted) setUser(userWithProfile);
            } else {
                if (isMounted) setUser(null);
            }
        } catch(error) {
            logError(error, { module: 'SupabaseAuthContext', function: 'initializeSession' });
        } finally {
            if (isMounted) setLoading(false);
        }
    };
    
    initializeSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, newSession) => {
        if (!isMounted) return;
        setLoading(true);

        if (_event === 'PASSWORD_RECOVERY') {
            setIsRecovery(true);
        } else {
            setIsRecovery(false);
        }
        
        setSession(newSession);

        if (newSession?.user) {
            const userWithProfile = await processUserSession(newSession.user);
            if(isMounted) setUser(userWithProfile);
        } else {
            if(isMounted) setUser(null);
        }
        
        if(isMounted) setLoading(false);
      }
    );

    return () => {
        isMounted = false;
        subscription?.unsubscribe();
    };
  }, [processUserSession]);

  const signUp = useCallback(async (email, password, options) => {
    const { error } = await supabase.auth.signUp({ email, password, options });
    if (error) {
      logError(error, { module: 'AuthActions', function: 'signUp' });
      toast({ variant: "destructive", title: "Sign up Failed", description: error.message });
    }
    return { error };
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      logError(error, { module: 'AuthActions', function: 'signIn' });
      toast({ variant: "destructive", title: "Sign in Failed", description: error.message });
    }
    return { error };
  }, [toast]);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      logError(error, { module: 'AuthActions', function: 'signOut' });
      toast({ variant: "destructive", title: "Sign out Failed", description: error.message });
    } else {
      setIsRecovery(false); 
      navigate('/auth', { replace: true });
    }
    return { error };
  }, [toast, navigate]);

  const value = useMemo(() => ({
    user,
    session,
    loading,
    isRecovery,
    signUp,
    signIn,
    signOut,
    setUser,
    supabase,
  }), [user, session, loading, isRecovery, signUp, signIn, signOut]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useSupabase = useAuth;