import React, { useEffect, lazy, Suspense } from 'react';
    import { Helmet, HelmetProvider } from 'react-helmet-async';
    import { Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
    import AuthComponent from '@/components/Auth';
    import LoadingScreen from '@/components/LoadingScreen';
    import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext';
    import { ProjectDataProvider } from '@/contexts/ProjectDataContext';
    import DashboardLayout from '@/components/layout/DashboardLayout';
    import { useTranslation } from 'react-i18next';
    import i18n from './i18n';
    import { GlobalAssistantProvider } from '@/contexts/GlobalAssistantContext';

    const I18N_BUILD = 'i18n-2025-09-08-08';

    const AuthCallback = () => {
      const { session, loading } = useAuth();
      const location = useLocation();
      const navigate = useNavigate();

      useEffect(() => {
        if (!loading && session) {
          const params = new URLSearchParams(location.search);
          const next = params.get('next') || '/my-projects';
          navigate(next, { replace: true });
        }
      }, [session, loading, location, navigate]);

      return <LoadingScreen message="Procesando autenticación..." />;
    };

    const AuthRedirector = () => {
        const { session, loading, isRecovery } = useAuth();

        if (loading) {
            return <LoadingScreen message="Verificando sesión..." />;
        }

        if (isRecovery) {
            return <Navigate to="/update-password" replace />;
        }

        if (session) {
            return <Navigate to="/my-projects" replace />;
        }

        return <Navigate to="/auth" replace />;
    };

    const ProtectedRoute = ({ children }) => {
      const { session, loading } = useAuth();
      const location = useLocation();

      if (loading) {
        return <LoadingScreen message="Verificando autenticación..." />;
      }

      if (!session) {
        return <Navigate to="/auth" state={{ from: location }} replace />;
      }

      return children;
    };

    const GeneralDashboardPage = lazy(() => import('@/pages/GeneralDashboardPage'));
    const MyProjectsPage = lazy(() => import('@/pages/MyProjectsPage'));
    const CalculatorPage = lazy(() => import('@/pages/CalculatorPage'));
    const LivestockSimulationPage = lazy(() => import('@/pages/LivestockSimulationPage'));
    const AgriculturalSimulationPage = lazy(() => import('@/pages/AgriculturalSimulationPage'));
    const ProductionDatabasePage = lazy(() => import('@/pages/ProductionDatabasePage'));
    const ForageDashboardPage = lazy(() => import('@/pages/ForageDashboardPage'));
    const ForageDatabasePage = lazy(() => import('@/pages/ForageDatabasePage.jsx'));
    const ForageAnalysisPage = lazy(() => import('@/pages/ForageAnalysisPage'));
    const CarbonBalancePage = lazy(() => import('@/pages/CarbonBalancePage'));
    const ClientsPage = lazy(() => import('@/pages/ClientsPage'));
    const ProjectDocumentsPage = lazy(() => import('@/pages/ProjectDocumentsPage'));
    const PipelinePage = lazy(() => import('@/pages/PipelinePage'));
    const ActivitiesPage = lazy(() => import('@/pages/ActivitiesPage'));
    const CRMDashboardPage = lazy(() => import('@/pages/CRMDashboardPage'));
    const EquipmentRegistryPage = lazy(() => import('@/pages/EquipmentRegistryPage'));
    const UserManagementPage = lazy(() => import('@/pages/UserManagementPage'));
    const CampaignsPage = lazy(() => import('@/pages/CampaignsPage'));
    const MarketingPage = lazy(() => import('@/pages/MarketingPage'));
    const ChatPage = lazy(() => import('@/pages/ChatPage'));
    const VideoConferencePage = lazy(() => import('@/pages/VideoConferencePage'));
    const HelpDeskPage = lazy(() => import('@/pages/HelpDeskPage'));
    const TicketDetailPage = lazy(() => import('@/pages/TicketDetailPage'));
    const KnowledgeBasePage = lazy(() => import('@/pages/KnowledgeBasePage'));
    const AiAssistantPage = lazy(() => import('@/pages/AiAssistantPage'));
    const InventoryPage = lazy(() => import('@/pages/InventoryPage'));
    const CustomerServicePage = lazy(() => import('@/pages/CustomerServicePage'));
    const SuppliersPage = lazy(() => import('@/pages/SuppliersPage'));
    const ExecutiveTrackingPage = lazy(() => import('@/pages/ExecutiveTrackingPage'));
    const SettingsPage = lazy(() => import('@/pages/SettingsPage'));
    const UserProfilePage = lazy(() => import('@/pages/UserProfilePage'));
    const ProductCatalogPage = lazy(() => import('@/pages/ProductCatalogPage'));
    const UpdatePasswordPage = lazy(() => import('@/pages/UpdatePasswordPage'));
    const ConnectivityCheckPage = lazy(() => import('@/pages/ConnectivityCheckPage'));
    const DonLindomarReportPage = lazy(() => import('@/pages/DonLindomarReportPage'));
    const PurchaseOrdersPage = lazy(() => import('@/pages/PurchaseOrdersPage'));
    // const SimulationsPage = lazy(() => import('@/pages/SimulationsPage')); // Removed as per user request

    const AppContent = () => {
      const { t } = useTranslation('common');
      return (
        <DashboardLayout>
        <Suspense fallback={<LoadingScreen message={t('loading.module')} />}>
            <Routes>
            <Route path="/dashboard" element={<GeneralDashboardPage />} />
            <Route path="/my-projects" element={<MyProjectsPage />} />
            <Route path="/calculator/*" element={<CalculatorPage />} />
            <Route path="/livestock-simulation" element={<LivestockSimulationPage />} />
            <Route path="/agricultural-simulation" element={<AgriculturalSimulationPage />} />
            <Route path="/analisis/forrajero" element={<ForageAnalysisPage />} />
            {/* <Route path="/simulations" element={<SimulationsPage />} /> */} {/* Removed as per user request */}
            <Route path="/production-database" element={<ProductionDatabasePage />} />
            <Route path="/forage-dashboard" element={<ForageDashboardPage />} />
            <Route path="/forage-database" element={<ForageDatabasePage />} />
            <Route path="/clients" element={<ClientsPage />} />
            <Route path="/projects/:projectId/documents" element={<ProjectDocumentsPage />} />
            <Route path="/pipeline" element={<PipelinePage />} />
            <Route path="/activities" element={<ActivitiesPage />} />
            <Route path="/crm-dashboard" element={<CRMDashboardPage />} />
            <Route path="/equipment-registry" element={<EquipmentRegistryPage />} />
            <Route path="/user-management" element={<UserManagementPage />} />
            <Route path="/campaigns" element={<CampaignsPage />} />
            <Route path="/marketing" element={<MarketingPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/meet/:roomName" element={<VideoConferencePage />} />
            <Route path="/help-desk" element={<HelpDeskPage />} />
            <Route path="/help-desk/ticket/:ticketId" element={<TicketDetailPage />} />
            <Route path="/knowledge-base" element={<KnowledgeBasePage />} />
            <Route path="/inventory" element={<InventoryPage />} />
            <Route path="/customer-service" element={<CustomerServicePage />} />
            <Route path="/purchase-orders" element={<PurchaseOrdersPage />} />
            <Route path="/suppliers" element={<SuppliersPage />} />
            <Route path="/executive-tracking" element={<ExecutiveTrackingPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/user-profile" element={<UserProfilePage />} />
            <Route path="/product-catalog" element={<ProductCatalogPage />} />
            <Route path="/connectivity-check" element={<ConnectivityCheckPage />} />
            <Route path="/ai-assistant" element={<AiAssistantPage />} />
            <Route path="/don-lindomar-report" element={<DonLindomarReportPage />} />
            <Route path="*" element={<Navigate to="/my-projects" />} />
            </Routes>
        </Suspense>
        </DashboardLayout>
      );
    }

    function App() {
      const { t } = useTranslation('app');

      useEffect(() => {
        const prev = localStorage.getItem('APP_I18N_BUILD');
        if (prev !== I18N_BUILD) {
          localStorage.setItem('APP_I18N_BUILD', I18N_BUILD);
          localStorage.removeItem('i18nextLng');
        }
        
        document.documentElement.setAttribute('lang', i18n.language?.slice(0,2) || 'es');
        document.documentElement.setAttribute('translate', 'no');
      }, []);

      return (
        <HelmetProvider>
          <Helmet>
            <title>{t('title')}</title>
            <meta name="description" content={t('description')} />
          </Helmet>
          <AuthProvider>
            <GlobalAssistantProvider>
              <Routes>
                <Route path="/" element={<AuthRedirector />} />
                <Route path="/auth" element={<AuthComponent />} />
                <Route path="/auth/callback" element={<AuthCallback />} />
                <Route path="/update-password" element={<UpdatePasswordPage />} />
                <Route
                  path="/*"
                  element={
                    <ProtectedRoute>
                      <ProjectDataProvider>
                        <AppContent />
                      </ProjectDataProvider>
                    </ProtectedRoute>
                  }
                />
              </Routes>
            </GlobalAssistantProvider>
          </AuthProvider>
        </HelmetProvider>
      );
    }

    export default App;