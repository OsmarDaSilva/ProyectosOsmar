import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle, Truck, MoreHorizontal, Edit, Trash2, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import AddEditSupplierDialog from '@/components/suppliers/AddEditSupplierDialog';
import { Skeleton } from '@/components/ui/skeleton';
import { useTranslation } from 'react-i18next';

const SuppliersPage = () => {
    const { t } = useTranslation(['suppliers', 'common']);
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const { toast } = useToast();
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [selectedSupplier, setSelectedSupplier] = useState(null);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [supplierToDelete, setSupplierToDelete] = useState(null);

    const { data: suppliers, isLoading, isError, error } = useQuery({
        queryKey: ['suppliers'],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('v_suppliers')
                .select('id,name,contact_person,email,phone,address');
            if (error) throw error;
            return data;
        },
        enabled: !!user,
        onError: (err) => {
            if (err.name !== 'AbortError' && !err.message.includes('fetch')) {
                 toast({
                    variant: "destructive",
                    title: t('common:error'),
                    description: t('common:errorApi')
                });
            }
        }
    });

    const deleteMutation = useMutation({
        mutationFn: async (id) => {
            const { error } = await supabase.from('suppliers').delete().eq('id', id);
            if (error) throw error;
        },
        onSuccess: () => {
            toast({ title: t('common:success'), description: t('toasts.deleted') });
            queryClient.invalidateQueries({ queryKey: ['suppliers'] });
            setIsDeleteDialogOpen(false);
        },
        onError: (error) => {
            toast({ variant: "destructive", title: t('common:error'), description: error.message });
        },
    });

    const handleNewSupplier = () => {
        setSelectedSupplier(null);
        setIsDialogOpen(true);
    };

    const handleEditSupplier = (supplier) => {
        setSelectedSupplier(supplier);
        setIsDialogOpen(true);
    };

    const handleDeleteSupplier = (supplier) => {
        setSupplierToDelete(supplier);
        setIsDeleteDialogOpen(true);
    };
    
    const confirmDelete = () => {
      if(supplierToDelete) deleteMutation.mutate(supplierToDelete.id);
    };

    const TableLoader = () => (
        <TableBody>
            {[...Array(5)].map((_, i) => (
                <TableRow key={i}>
                    <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-48" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-48" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                </TableRow>
            ))}
        </TableBody>
    );

    return (
        <>
            <Helmet>
                <title>{t('pageTitle')} - AGROinvest</title>
                <meta name="description" content={t('supplierListDescription')} />
            </Helmet>
            <div className="container mx-auto p-4 md:p-8">
                <div className="flex items-center justify-between space-y-2 mb-6">
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
                        <Truck className="h-8 w-8" />
                        {t('pageTitle')}
                    </h1>
                    <Button onClick={handleNewSupplier}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        {t('newSupplier')}
                    </Button>
                </div>
                <Card>
                    <CardHeader>
                        <CardTitle>{t('supplierList')}</CardTitle>
                        <CardDescription>{t('supplierListDescription')}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>{t('table.name')}</TableHead>
                                    <TableHead>{t('table.contactPerson')}</TableHead>
                                    <TableHead>{t('table.email')}</TableHead>
                                    <TableHead>{t('table.phone')}</TableHead>
                                    <TableHead>{t('table.address')}</TableHead>
                                    <TableHead className="text-right">{t('table.actions')}</TableHead>
                                </TableRow>
                            </TableHeader>
                            {isLoading ? <TableLoader /> : (
                            <TableBody>
                                {isError && !error.message.includes('fetch') ? (
                                    <TableRow><TableCell colSpan={6} className="text-center text-red-500 py-8">{error?.message || t('common:errorApi')}</TableCell></TableRow>
                                ) : suppliers?.length > 0 ? (
                                    suppliers.map(supplier => (
                                        <TableRow key={supplier.id}>
                                            <TableCell className="font-medium">{supplier.name || '–'}</TableCell>
                                            <TableCell>{supplier.contact_person || '–'}</TableCell>
                                            <TableCell>{supplier.email || '–'}</TableCell>
                                            <TableCell>{supplier.phone || '–'}</TableCell>
                                            <TableCell>{supplier.address || '–'}</TableCell>
                                            <TableCell className="text-right">
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" className="h-8 w-8 p-0"><MoreHorizontal className="h-4 w-4" /></Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem onClick={() => handleEditSupplier(supplier)}><Edit className="mr-2 h-4 w-4" /> {t('common:edit')}</DropdownMenuItem>
                                                        <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteSupplier(supplier)}><Trash2 className="mr-2 h-4 w-4" /> {t('common:delete')}</DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={6} className="h-24 text-center">
                                            <h3 className="text-lg font-semibold">{t('emptyState.title')}</h3>
                                            <p className="text-sm text-muted-foreground">{t('emptyState.description')}</p>
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                            )}
                        </Table>
                    </CardContent>
                </Card>
            </div>

            <AddEditSupplierDialog
                isOpen={isDialogOpen}
                setIsOpen={setIsDialogOpen}
                supplier={selectedSupplier}
            />

            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>{t('common:areYouSure')}</AlertDialogTitle>
                        <AlertDialogDescription>
                            {t('deleteConfirmation', { supplierName: supplierToDelete?.name })}
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>{t('common:cancel')}</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending}>
                            {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {t('common:delete')}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
};

export default SuppliersPage;