import React, { useState, useEffect, useCallback } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { useParams, useNavigate } from 'react-router-dom';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { ArrowLeft, MessageSquare, Send, Pencil, Trash2 } from 'lucide-react';
    import LoadingScreen from '@/components/LoadingScreen';
    import { Badge } from '@/components/ui/badge';
    import { getStatusBadgeVariant, getPriorityBadgeVariant } from '@/components/help-desk/TicketsDataTable';
    import { Avatar, AvatarFallback } from '@/components/ui/avatar';
    import { Textarea } from '@/components/ui/textarea';
    import { format } from 'date-fns';
    import { es } from 'date-fns/locale';
    import AddEditTicketDialog from '@/components/help-desk/AddEditTicketDialog';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";

    const TicketDetailPage = () => {
      const { ticketId } = useParams();
      const navigate = useNavigate();
      const { user } = useAuth();
      const { toast } = useToast();
      
      const [ticket, setTicket] = useState(null);
      const [comments, setComments] = useState([]);
      const [clients, setClients] = useState([]);
      const [users, setUsers] = useState([]);
      const [newComment, setNewComment] = useState('');
      const [loading, setLoading] = useState(true);
      const [isSaving, setIsSaving] = useState(false);
      const [isAddEditTicketOpen, setIsAddEditTicketOpen] = useState(false);
      const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);


      const fetchData = useCallback(async () => {
        setLoading(true);
        try {
          const [ticketRes, commentsRes, clientsRes, usersRes] = await Promise.all([
            supabase.from('tickets').select('*, client:clients(name), created_by_user:profiles!tickets_created_by_fkey(full_name), assigned_to_user:profiles!tickets_assigned_to_fkey(full_name)').eq('id', ticketId).single(),
            supabase.from('ticket_comments').select('*, user:profiles(full_name)').eq('ticket_id', ticketId).order('created_at', { ascending: true }),
            supabase.from('clients').select('id, name'),
            supabase.functions.invoke('get-users')
          ]);

          if (ticketRes.error) throw ticketRes.error;
          if (commentsRes.error) throw commentsRes.error;
          if (clientsRes.error) throw clientsRes.error;
          if (usersRes.error) throw new Error(usersRes.error.message);

          setTicket(ticketRes.data);
          setComments(commentsRes.data);
          setClients(clientsRes.data);
          setUsers(usersRes.data || []);

        } catch (error) {
          toast({ variant: 'destructive', title: 'Error al cargar el ticket', description: error.message });
          navigate('/help-desk');
        } finally {
          setLoading(false);
        }
      }, [ticketId, toast, navigate]);

      useEffect(() => {
        fetchData();
      }, [fetchData]);

      const handleAddComment = async (e) => {
        e.preventDefault();
        if (!newComment.trim()) return;
        setIsSaving(true);
        
        const { data, error } = await supabase
          .from('ticket_comments')
          .insert({
            ticket_id: ticketId,
            user_id: user.id,
            comment: newComment,
          })
          .select('*, user:profiles(full_name)')
          .single();

        if (error) {
          toast({ variant: 'destructive', title: 'Error al añadir comentario', description: error.message });
        } else {
          setComments(prev => [...prev, data]);
          setNewComment('');
        }
        setIsSaving(false);
      };

      const handleSaveTicket = async (ticketData) => {
        const { id, ...updateData } = ticketData;
        const { error } = await supabase.from('tickets').update(updateData).eq('id', id);
        if (error) {
            toast({ variant: 'destructive', title: 'Error al actualizar ticket', description: error.message });
            return false;
        } else {
            toast({ title: 'Ticket actualizado' });
            fetchData();
            return true;
        }
    };

    const handleDeleteConfirm = async () => {
        const { error } = await supabase.from('tickets').delete().eq('id', ticket.id);
        if (error) {
            toast({ variant: 'destructive', title: 'Error al eliminar ticket', description: error.message });
        } else {
            toast({ title: 'Ticket eliminado' });
            navigate('/help-desk');
        }
        setIsDeleteDialogOpen(false);
    };

      if (loading) {
        return <LoadingScreen message="Cargando detalles del ticket..." />;
      }

      if (!ticket) {
        return null;
      }

      return (
        <>
          <Helmet><title>Ticket #{ticket.ticket_number} - AGROinvest</title></Helmet>
          <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <header className="mb-6 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate('/help-desk')}><ArrowLeft className="h-4 w-4" /></Button>
                <div>
                  <h1 className="text-2xl font-bold text-gray-800">Ticket #{ticket.ticket_number}</h1>
                  <p className="text-sm text-gray-500">{ticket.subject}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsAddEditTicketOpen(true)}><Pencil className="mr-2 h-4 w-4" /> Editar</Button>
                <Button variant="destructive" onClick={() => setIsDeleteDialogOpen(true)}><Trash2 className="mr-2 h-4 w-4" /> Eliminar</Button>
              </div>
            </header>

            <main className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2"><MessageSquare /> Comentarios</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {comments.map(comment => (
                        <div key={comment.id} className="flex gap-3">
                          <Avatar>
                            <AvatarFallback>{comment.user?.full_name?.[0].toUpperCase() || 'U'}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between items-baseline">
                              <p className="font-semibold text-sm">{comment.user?.full_name || 'Usuario'}</p>
                              <p className="text-xs text-gray-500">{format(new Date(comment.created_at), 'd MMM yyyy, HH:mm', { locale: es })}</p>
                            </div>
                            <div className="mt-1 bg-gray-100 p-3 rounded-lg">
                              <p className="text-sm whitespace-pre-wrap">{comment.comment}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                      {comments.length === 0 && <p className="text-center text-gray-500 py-8">No hay comentarios aún.</p>}
                    </div>
                    <form onSubmit={handleAddComment} className="mt-8 flex gap-4 items-start">
                      <Textarea 
                        placeholder="Escribe un comentario..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        rows={3}
                      />
                      <Button type="submit" disabled={isSaving || !newComment.trim()}>
                        <Send className="h-4 w-4 mr-2" />
                        {isSaving ? 'Enviando...' : 'Enviar'}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Detalles</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm">
                    <div className="flex justify-between">
                      <span className="font-semibold">Cliente:</span>
                      <span>{ticket.client?.name || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold">Estado:</span>
                      <Badge variant={getStatusBadgeVariant(ticket.status)}>{ticket.status}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold">Prioridad:</span>
                      <Badge variant={getPriorityBadgeVariant(ticket.priority)}>{ticket.priority}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold">Creado por:</span>
                      <span>{ticket.created_by_user?.full_name || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold">Asignado a:</span>
                      <span>{ticket.assigned_to_user?.full_name || 'Sin asignar'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-semibold">Fecha de Creación:</span>
                      <span>{format(new Date(ticket.created_at), 'd MMM yyyy', { locale: es })}</span>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Descripción Completa</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap">{ticket.description || 'Sin descripción detallada.'}</p>
                  </CardContent>
                </Card>
              </div>
            </main>
          </div>
          <AddEditTicketDialog
            isOpen={isAddEditTicketOpen}
            onOpenChange={setIsAddEditTicketOpen}
            ticket={ticket}
            clients={clients}
            users={users}
            onSave={handleSaveTicket}
          />
           <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>¿Estás seguro de eliminar este ticket?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Esta acción no se puede deshacer. Esto eliminará permanentemente el ticket
                            y todos sus comentarios asociados.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDeleteConfirm}>Eliminar</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
      );
    };

    export default TicketDetailPage;