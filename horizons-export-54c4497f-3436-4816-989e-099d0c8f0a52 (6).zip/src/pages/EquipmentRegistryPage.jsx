import React, { useState, useMemo } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { HardHat, PlusCircle, MoreHorizontal, Edit, Trash2 } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { DataTable } from '@/components/ui/data-table';
    import AddEditEquipmentDialog from '@/components/equipment/AddEditEquipmentDialog';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
    import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
    import QueryStateWrapper from '@/components/QueryStateWrapper';
    import { Input } from '@/components/ui/input';

    const fetchEquipment = async (userId) => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from('equipment')
        .select(`
          *, 
          client:clients(name),
          equipment_files(*)
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (error) throw new Error(error.message);
      return data;
    };

    const fetchClients = async (userId) => {
        if (!userId) return [];
        const { data, error } = await supabase.from('clients').select('id, name').eq('user_id', userId);
        if (error) throw new Error(error.message);
        return data;
    };

    const EquipmentRegistryPage = () => {
      const { user } = useAuth();
      const { toast } = useToast();
      const queryClient = useQueryClient();
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [editingEquipment, setEditingEquipment] = useState(null);
      const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
      const [equipmentToDelete, setEquipmentToDelete] = useState(null);
      const [filter, setFilter] = useState('');

      const { data: equipment, isLoading: isLoadingEquipment, isError: isErrorEquipment, error: errorEquipment, refetch: refetchEquipment } = useQuery({
        queryKey: ['equipment', user?.id],
        queryFn: () => fetchEquipment(user.id),
        enabled: !!user,
      });

      const { data: clients, isLoading: isLoadingClients, isError: isErrorClients, error: errorClients, refetch: refetchClients } = useQuery({
        queryKey: ['clientsForEquipment', user?.id],
        queryFn: () => fetchClients(user.id),
        enabled: !!user,
      });
      
      const equipmentMutation = useMutation({
        mutationFn: async (equipmentData) => {
          const { filesToSave, ...dataToSave } = equipmentData;

          const { id, ...equipmentFields } = dataToSave;
          const { data: savedEquipment, error: equipmentError } = await supabase
            .from('equipment')
            .upsert({ id, ...equipmentFields, user_id: user.id }, { onConflict: 'id' })
            .select()
            .single();

          if (equipmentError) throw equipmentError;

          if (filesToSave) {
            const { data: currentFiles, error: fetchError } = await supabase
              .from('equipment_files')
              .select('id, file_path')
              .eq('equipment_id', savedEquipment.id);

            if (fetchError) throw fetchError;
            
            const filesToUpsert = filesToSave.map(file => {
              const { file: localFile, ...dbFile } = file; // eslint-disable-line no-unused-vars
              return { ...dbFile, equipment_id: savedEquipment.id, user_id: user.id };
            });
            
            const { error: filesError } = await supabase.from('equipment_files').upsert(filesToUpsert, { onConflict: 'id'});
            if(filesError) throw filesError;

            const filesToDeleteInDb = currentFiles.filter(dbFile => !filesToSave.some(newFile => newFile.id === dbFile.id));
            if (filesToDeleteInDb.length > 0) {
              const fileIdsToDelete = filesToDeleteInDb.map(f => f.id);
              const filePathsToDelete = filesToDeleteInDb.map(f => f.file_path);

              await supabase.storage.from('equipment_files').remove(filePathsToDelete);
              await supabase.from('equipment_files').delete().in('id', fileIdsToDelete);
            }
          }

          return savedEquipment;
        },
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['equipment', user.id] });
          setIsDialogOpen(false);
          setEditingEquipment(null);
          toast({ title: 'Éxito', description: 'El equipo se ha guardado correctamente.' });
        },
        onError: (error) => {
          toast({ variant: 'destructive', title: 'Error al guardar', description: `Hubo un problema al guardar el equipo: ${error.message}. Si el problema persiste, intente recargar la página.` });
        }
      });

      const deleteMutation = useMutation({
        mutationFn: async (item) => {
            const { data: files, error: filesError } = await supabase
              .from('equipment_files')
              .select('file_path')
              .eq('equipment_id', item.id);

            if (filesError) throw filesError;

            if (files.length > 0) {
              const filePaths = files.map(f => f.file_path);
              const { error: storageError } = await supabase.storage.from('equipment_files').remove(filePaths);
              if (storageError) console.error("Error deleting files from storage, but proceeding to delete db record:", storageError);
            }
            
            const { error: dbError } = await supabase.from('equipment').delete().eq('id', item.id);
            if (dbError) throw dbError;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({queryKey: ['equipment', user.id]});
            toast({ title: 'Equipo eliminado', description: 'El registro del equipo y sus archivos han sido eliminados.' });
            setIsDeleteDialogOpen(false);
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
        }
      });

      const handleAddNew = () => {
        setEditingEquipment(null);
        setIsDialogOpen(true);
      };

      const handleEdit = (item) => {
        setEditingEquipment(item);
        setIsDialogOpen(true);
      };
      
      const handleDelete = (item) => {
        setEquipmentToDelete(item);
        setIsDeleteDialogOpen(true);
      };
      
      const confirmDelete = () => {
        if(equipmentToDelete) {
            deleteMutation.mutate(equipmentToDelete);
        }
      }

      const filteredEquipment = useMemo(() => {
        if (!equipment) return [];
        if (!filter) return equipment;

        const lowercasedFilter = filter.toLowerCase();
        return equipment.filter(item => 
          item.serial_number.toLowerCase().includes(lowercasedFilter) ||
          (item.client?.name && item.client.name.toLowerCase().includes(lowercasedFilter)) ||
          (item.equipment_files && item.equipment_files.some(file => file.title && file.title.toLowerCase().includes(lowercasedFilter)))
        );
      }, [equipment, filter]);

      const columns = useMemo(() => [
        { accessorKey: 'serial_number', header: 'N° de Serie' },
        { accessorKey: 'equipment_type', header: 'Tipo' },
        { accessorKey: 'brand', header: 'Marca' },
        { accessorKey: 'model', header: 'Modelo' },
        { 
          accessorKey: 'client.name', 
          header: 'Cliente',
          cell: ({ row }) => row.original.client?.name || 'N/A',
        },
        { accessorKey: 'status', header: 'Estado' },
        {
          id: 'actions',
          cell: ({ row }) => (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0">
                  <span className="sr-only">Abrir menú</span>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleEdit(row.original)}><Edit className="mr-2 h-4 w-4" /> Editar</DropdownMenuItem>
                <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(row.original)}><Trash2 className="mr-2 h-4 w-4" /> Eliminar</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ),
        },
      ], []);

      return (
        <>
          <Helmet>
            <title>Registro de Equipos - AGROinvest</title>
          </Helmet>
          <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
            <div className="flex items-center justify-between space-y-2">
              <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2"><HardHat /> Registro de Equipos y Máquinas</h1>
              <Button onClick={handleAddNew}><PlusCircle className="mr-2 h-4 w-4" /> Añadir Equipo</Button>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>Equipos Registrados</CardTitle>
                <CardDescription>Lista de todos los equipos vendidos o instalados a clientes.</CardDescription>
              </CardHeader>
              <CardContent>
                <QueryStateWrapper
                  isLoading={isLoadingEquipment || isLoadingClients}
                  isError={isErrorEquipment || isErrorClients}
                  error={errorEquipment || errorClients}
                  data={equipment && clients}
                  onRetry={() => { refetchEquipment(); refetchClients(); }}
                >
                    <>
                      <div className="flex items-center py-4">
                          <Input
                              placeholder="Filtrar por N° de serie, cliente o ficha técnica..."
                              value={filter}
                              onChange={(event) => setFilter(event.target.value)}
                              className="max-w-sm"
                          />
                      </div>
                      <DataTable
                          columns={columns}
                          data={filteredEquipment}
                          isLoading={isLoadingEquipment}
                      />
                    </>
                </QueryStateWrapper>
              </CardContent>
            </Card>
          </div>
          <AddEditEquipmentDialog
            isOpen={isDialogOpen}
            setIsOpen={setIsDialogOpen}
            equipment={editingEquipment}
            onSave={equipmentMutation.mutate}
            clients={clients || []}
            isLoading={equipmentMutation.isPending}
          />
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>¿Está seguro?</AlertDialogTitle>
                <AlertDialogDescription>Esta acción eliminará permanentemente el registro del equipo y todos sus archivos asociados. No se puede deshacer.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending} className="bg-destructive hover:bg-destructive/90">Eliminar</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </>
      );
    };

    export default EquipmentRegistryPage;