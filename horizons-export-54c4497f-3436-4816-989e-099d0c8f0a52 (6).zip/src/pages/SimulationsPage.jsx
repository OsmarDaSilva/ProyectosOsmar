import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Tractor, PawPrint } from 'lucide-react';

const SimulationsPage = () => {
    return (
        <>
            <Helmet>
                <title>Simulaciones - AGROinvest</title>
                <meta name="description" content="Acceda a los simuladores de agricultura y ganadería." />
            </Helmet>
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                <header className="mb-6">
                    <h1 className="text-3xl font-bold text-gray-800">Simulaciones</h1>
                    <p className="text-muted-foreground mt-1">
                        Seleccione el tipo de simulación que desea realizar.
                    </p>
                </header>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Link to="/agricultural-simulation">
                        <Card className="hover:shadow-lg transition-shadow duration-300 h-full">
                            <CardHeader>
                                <div className="flex items-center gap-3">
                                    <Tractor className="h-8 w-8 text-yellow-600" />
                                    <CardTitle>Simulador Agrícola</CardTitle>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <CardDescription>
                                    Analice la viabilidad y rentabilidad de sus cultivos. Configure zafras, costos y precios para obtener un análisis financiero detallado.
                                </CardDescription>
                            </CardContent>
                        </Card>
                    </Link>
                    <Link to="/livestock-simulation">
                        <Card className="hover:shadow-lg transition-shadow duration-300 h-full">
                            <CardHeader>
                                <div className="flex items-center gap-3">
                                    <PawPrint className="h-8 w-8 text-orange-600" />
                                    <CardTitle>Simulador Ganadero</CardTitle>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <CardDescription>
                                    Compare modelos de producción ganadera, analice el balance forrajero y evalúe la viabilidad de sus sistemas de pastoreo intensivo.
                                </CardDescription>
                            </CardContent>
                        </Card>
                    </Link>
                </div>
            </div>
        </>
    );
};

export default SimulationsPage;