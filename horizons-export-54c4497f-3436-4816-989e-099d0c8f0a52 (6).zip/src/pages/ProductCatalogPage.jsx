import React, { useState, useRef, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Upload, List, FileText, PlusCircle, Download, RefreshCw, FileDown, Wrench, PlayCircle, AlertTriangle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useImportJobs, useStartImport } from '@/hooks/useImportJobs';
import * as XLSX from 'xlsx';
import AddEditProductDialog from '@/components/catalog/AddEditProductDialog';
import ProductCatalogTable from '@/components/catalog/ProductCatalogTable';
import ImportCorrector from '@/components/catalog/ImportCorrector';
import useProductImport from '@/hooks/useProductImport';
import { supabase } from '@/lib/customSupabaseClient';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { logUserAction } from '@/lib/logger';
import { useTranslation } from 'react-i18next';

const ImportHistory = ({ jobs, isLoading, onRefresh, onDownloadErrors, onCorrectErrors, onResume, isResuming }) => {
    const { t } = useTranslation('catalog');
    const { toast } = useToast();
    
    const handleForceFail = async (job) => {
      if (!job) return;
      const { error } = await supabase
          .from('import_jobs')
          .update({ status: 'failed', summary: { error: t('importHistory.forcedToFail') } })
          .eq('id', job.id);

      if (error) {
          toast({ variant: "destructive", title: t('common.error'), description: `${t('importHistory.cannotForceFail')}: ${error.message}` });
      } else {
          toast({ title: t('common.success'), description: t('importHistory.jobMarkedAsFailed') });
          await logUserAction('force_fail_import_job', 'catalog', { jobId: job.id });
          onRefresh();
      }
    };

    const isJobStuck = (job) => {
      if (job.status !== 'processing') return false;
      const lastUpdate = new Date(job.updated_at);
      const now = new Date();
      return (now.getTime() - lastUpdate.getTime()) > 120000; 
    };
    
    const statusMapping = useMemo(() => ({
      queued: { text: t('importStatus.queued'), variant: "default" },
      processing: { text: t('importStatus.processing'), variant: "secondary" },
      completed: { text: t('importStatus.completed'), variant: "success" },
      completed_with_errors: { text: t('importStatus.completed_with_errors'), variant: "destructive" },
      failed: { text: t('importStatus.failed'), variant: "destructive" },
    }), [t]);
    
    return (
        <Card className="mt-6">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2"><List /> {t('importHistory.title')}</CardTitle>
                <Button variant="ghost" size="sm" onClick={onRefresh} disabled={isLoading}><RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`}/></Button>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {(jobs?.length ?? 0) === 0 ? <p className="text-sm text-muted-foreground">{t('importHistory.noRecentImports')}</p> :
                     jobs?.map(job => {
                        const stuck = isJobStuck(job);
                        const { text, variant } = statusMapping[job.status] || { text: t('importStatus.unknown'), variant: 'secondary' };
                        const progress = job.total_rows > 0 ? Math.round(((job.processed_rows || 0) / job.total_rows) * 100) : 0;
                        return (
                            <div key={job.id} className={`p-3 border rounded-lg ${stuck ? 'bg-yellow-50 border-yellow-300' : 'bg-background'}`}>
                                <div className="flex justify-between items-start flex-wrap gap-2">
                                    <div className="flex-1 min-w-[200px]">
                                        <p className="font-semibold text-sm truncate" title={job.summary?.fileName || job.file_path?.split('/').pop()}>
                                          {job.summary?.fileName || job.file_path?.split('/').pop() || t('importHistory.correctionJob')}
                                        </p>
                                        <div className="flex items-center gap-2 flex-wrap">
                                            <Badge variant={stuck ? "destructive" : variant}>{stuck ? t('importStatus.stuck') : text}</Badge>
                                            <p className="text-xs text-muted-foreground">{new Date(job.created_at).toLocaleString()}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2 flex-wrap">
                                        {(job.status === 'failed') && (
                                            <Button size="sm" variant="outline" onClick={() => onResume(job.id)} disabled={isResuming}>
                                                <PlayCircle className="mr-2 h-4 w-4"/> {isResuming ? t('importHistory.resuming') : t('importHistory.resume')}
                                            </Button>
                                        )}
                                        {stuck && (
                                            <AlertDialog>
                                                <AlertDialogTrigger asChild>
                                                    <Button size="sm" variant="destructive">
                                                        <AlertTriangle className="mr-2 h-4 w-4"/> {t('importHistory.forceFail')}
                                                    </Button>
                                                </AlertDialogTrigger>
                                                <AlertDialogContent>
                                                    <AlertDialogHeader>
                                                        <AlertDialogTitle>{t('common.areYouSure')}</AlertDialogTitle>
                                                        <AlertDialogDescription>{t('importHistory.forceFailDesc')}</AlertDialogDescription>
                                                    </AlertDialogHeader>
                                                    <AlertDialogFooter>
                                                        <AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel>
                                                        <AlertDialogAction onClick={() => handleForceFail(job)}>{t('importHistory.yesForceFail')}</AlertDialogAction>
                                                    </AlertDialogFooter>
                                                </AlertDialogContent>
                                            </AlertDialog>
                                        )}
                                        {job.status === 'completed_with_errors' && (
                                            <>
                                             <Button size="sm" variant="secondary" onClick={() => onCorrectErrors(job)}>
                                                <Wrench className="mr-2 h-4 w-4"/> {t('importHistory.correct')}
                                              </Button>
                                             <Button size="sm" variant="outline" onClick={() => onDownloadErrors(job)}>
                                                <Download className="mr-2 h-4 w-4"/> {t('importHistory.downloadErrors')}
                                              </Button>
                                            </>
                                        )}
                                    </div>
                                </div>
                                {(job.status === 'processing') && job.total_rows && (
                                    <div className="mt-2">
                                        <Progress value={progress} className="w-full" />
                                        <p className="text-xs text-muted-foreground text-right mt-1">{job.processed_rows || 0} / {job.total_rows} {t('importHistory.rows')}</p>
                                    </div>
                                )}
                                { (job.status.startsWith('completed') || job.status === 'failed') && job.summary && (
                                  <div className="text-xs mt-2 border-t pt-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
                                    <p>{t('importHistory.total')}: <span className="font-bold">{job.summary.total ?? job.total_rows}</span></p>
                                    <p className="text-green-600">{t('common.success')}: <span className="font-bold">{job.summary.success ?? job.successful_rows ?? 0}</span></p>
                                    <p className="text-red-600">{t('importHistory.failures')}: <span className="font-bold">{job.summary.failed ?? job.failed_rows ?? 0}</span></p>
                                    {job.summary.error && <p className="text-red-600 col-span-full">{t('importHistory.reason')}: {job.summary.error}</p>}
                                  </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
};

const ProductCatalogPage = () => {
  const { t } = useTranslation('catalog');
  const { toast } = useToast();
  const { user } = useAuth();
  const fileInputRef = useRef(null);
  
  const [isAddEditOpen, setIsAddEditOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [jobToCorrect, setJobToCorrect] = useState(null);
  const [activeTab, setActiveTab] = useState("products");

  const { jobs, isLoading: isLoadingJobs, refetch } = useImportJobs(user?.id, 'catalog_imports');
  const { startImport, isUploading } = useProductImport();
  const startImportMutation = useStartImport();

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel', 'text/csv'].includes(file.type)) {
      toast({ variant: 'destructive', title: t('common.error'), description: t('invalidFileFormat') });
      return;
    }
    
    try {
        await startImport({ file });
        setTimeout(() => refetch(), 2000);
        setActiveTab('import');
    } catch (error) {
        console.error("Import failed at page level:", error);
    }

    if(fileInputRef.current) fileInputRef.current.value = '';
  };
  
  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet([
      { 'SKU': 'SKU-001', 'Producto': 'Tractor Agrícola 50HP', 'Precio de Venta': 25000.50, 'Precio de Compra': 20000, 'Marca': 'Marca A', 'Categoria': 'Maquinaria', 'Potencia (HP)': 50 },
      { 'SKU': 'FERT-002', 'Producto': 'Fertilizante NPK 20-10-10', 'Precio de Venta': '55,75', 'Precio de Compra': 40, 'Marca': 'Marca B', 'Categoria': 'Insumos', 'Presentación': 'Bolsa 50kg' },
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Plantilla");
    XLSX.writeFile(wb, t('templateFilename'));
  };
  
  const downloadErrors = (job) => {
    const errorData = job.error_details?.rows?.map(e => ({ Fila: e.row, Error: e.error, ...e.data })) || [];
    if (!errorData.length) {
      toast({ title: t('common.info'), description: t('noErrorsToDownload') });
      return;
    }
    const ws = XLSX.utils.json_to_sheet(errorData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Errores");
    XLSX.writeFile(wb, `errores_${job.file_path?.split('/').pop().split('.')[0] || job.id}.xlsx`);
  };

  const handleCorrectErrors = (job) => {
    setJobToCorrect(job);
    setActiveTab("corrector");
  };

  const handleResume = async (jobId) => {
    try {
      await startImportMutation.mutateAsync({ jobId, jobType: 'catalog_imports', userId: user.id, isResume: true });
      toast({ title: t('common.success'), description: t('resumingImport') });
      setTimeout(() => refetch(), 1000);
    } catch (error) {
      toast({ 
        variant: 'destructive', 
        title: t('resumeError'), 
        description: `${t('resumeErrorDesc')}: ${error.message}` 
      });
    }
  };

  const handleJobCompletion = async () => {
    await supabase.from('import_jobs').update({ status: 'completed' }).eq('id', jobToCorrect.id);
    setJobToCorrect(null);
    setActiveTab("import");
    refetch();
  };
  
  const handleAddNew = () => {
    setSelectedProduct(null);
    setIsAddEditOpen(true);
  };
  
  const handleEdit = (product) => {
    setSelectedProduct(product);
    setIsAddEditOpen(true);
  };

  return (
    <>
      <Helmet>
        <title>{t('pageTitle')} - AGROinvest</title>
      </Helmet>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <h1 className="text-3xl font-bold tracking-tight">{t('pageTitle')}</h1>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={downloadTemplate}><FileDown className="mr-2 h-4 w-4" /> {t('templateButton')}</Button>
            <Button onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
              <Upload className="mr-2 h-4 w-4" />{isUploading ? t('common.uploading') : t('importButton')}
            </Button>
            <Button onClick={handleAddNew}><PlusCircle className="mr-2 h-4 w-4" /> {t('newProductButton')}</Button>
            <input ref={fileInputRef} type="file" className="sr-only" onChange={handleFileChange} disabled={isUploading} accept=".xlsx, .xls, .csv" />
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList>
                <TabsTrigger value="products">{t('tabs.myProducts')}</TabsTrigger>
                <TabsTrigger value="import">{t('tabs.import')}</TabsTrigger>
                {jobToCorrect && <TabsTrigger value="corrector">{t('tabs.corrector')}</TabsTrigger>}
            </TabsList>
            <TabsContent value="products" className="mt-4">
                <ProductCatalogTable onEdit={handleEdit} />
            </TabsContent>
            <TabsContent value="import" className="mt-4">
                 <Card>
                    <CardHeader><CardTitle className="flex items-center gap-2"><FileText /> {t('importInstructions.title')}</CardTitle></CardHeader>
                    <CardContent className="text-sm text-muted-foreground space-y-2">
                        <p>1. {t('importInstructions.step1')}</p>
                        <p>2. {t('importInstructions.step2')}</p>
                        <p>3. {t('importInstructions.step3')}</p>
                        <p>4. {t('importInstructions.step4')}</p>
                    </CardContent>
                </Card>
                <ImportHistory jobs={jobs} isLoading={isLoadingJobs} onRefresh={refetch} onDownloadErrors={downloadErrors} onCorrectErrors={handleCorrectErrors} onResume={handleResume} isResuming={startImportMutation.isPending} />
            </TabsContent>
            <TabsContent value="corrector" className="mt-4">
              {jobToCorrect ? (
                <ImportCorrector job={jobToCorrect} onBack={() => { setJobToCorrect(null); setActiveTab('import'); }} onJobCompletion={handleJobCompletion} />
              ) : (
                <p>{t('selectJobToCorrect')}</p>
              )}
            </TabsContent>
        </Tabs>

        <AddEditProductDialog open={isAddEditOpen} onOpenChange={setIsAddEditOpen} product={selectedProduct} />
      </div>
    </>
  );
};

export default ProductCatalogPage;