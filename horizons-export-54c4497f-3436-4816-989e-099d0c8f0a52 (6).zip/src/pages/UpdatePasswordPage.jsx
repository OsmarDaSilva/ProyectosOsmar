import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Auth as SupabaseAuthUI } from '@supabase/auth-ui-react';
import { ThemeSupa } from '@supabase/auth-ui-shared';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { KeyRound } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useTranslation } from 'react-i18next';
import LanguageSelector from '@/components/LanguageSelector';

const UpdatePasswordPage = () => {
    const navigate = useNavigate();
    const { toast } = useToast();
    const { t, i18n } = useTranslation('auth');

    useEffect(() => {
        const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
            if (event === 'PASSWORD_RECOVERY') {
                toast({
                    title: t('recoveryTitle'),
                    description: t('recoveryDesc'),
                });
            } else if (event === 'USER_UPDATED') {
                 toast({
                    title: t('passwordUpdatedTitle'),
                    description: t('passwordUpdatedDesc'),
                    className: "bg-green-100 border-green-400",
                });
                navigate('/auth', { replace: true });
            }
        });

        return () => {
            subscription.unsubscribe();
        };
    }, [navigate, toast, t]);

    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="w-full max-w-md"
            >
                <Card className="shadow-2xl">
                    <CardHeader className="text-center relative">
                        <div className="absolute top-4 right-4">
                            <LanguageSelector />
                        </div>
                        <div className="mx-auto bg-blue-600 text-white rounded-full p-3 w-fit mt-8">
                           <KeyRound className="h-8 w-8" />
                        </div>
                        <CardTitle className="mt-4 text-2xl font-bold">
                            {t('setPasswordTitle')}
                        </CardTitle>
                        <CardDescription>
                            {t('updatePasswordDesc')}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <SupabaseAuthUI
                            supabaseClient={supabase}
                            appearance={{ theme: ThemeSupa }}
                            providers={[]}
                            view="update_password"
                            key={`update_password-${i18n.language}`}
                            localization={{
                                variables: {
                                    update_password: { 
                                        password_label: t('newPasswordLabel'),
                                        button_label: t('updatePasswordButton')
                                    }
                                }
                            }}
                            showLinks={false}
                        />
                    </CardContent>
                </Card>
            </motion.div>
        </div>
    );
};

export default UpdatePasswordPage;