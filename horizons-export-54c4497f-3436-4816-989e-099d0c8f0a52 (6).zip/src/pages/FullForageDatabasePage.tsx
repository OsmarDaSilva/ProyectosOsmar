import React, { useState, useRef, FC } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PlusCircle, Sprout, ArrowLeft, Upload, Save, XCircle, Edit, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface ForageRow {
    id: string;
    user_id: string;
    pasture_type: string;
    production_method: 'Normal' | 'Regada';
    country: string | null;
    region: string | null;
    monthly_production: number[];
}

const ForagePageLoader: FC = () => (
    <Card className="shadow-lg">
        <CardHeader>
            <Skeleton className="h-8 w-1/2" />
            <Skeleton className="h-4 w-3/4" />
        </CardHeader>
        <CardContent>
            <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
            </div>
        </CardContent>
    </Card>
);

const fetchForageData = async (userId: string): Promise<ForageRow[]> => {
    if (!userId) return [];
    const { data, error } = await supabase
      .from('forage_production')
      .select('id, user_id, tipo_pastura, forma_producida, pais, region_pais, ene, feb, mar, abr, may, jun, jul, ago, sep, oct, nov, dic')
      .eq('user_id', userId)
      .order('pais')
      .order('region_pais')
      .order('tipo_pastura');

    if (error) throw error;
    
    return data.map(row => ({
        id: row.id,
        user_id: row.user_id,
        pasture_type: row.tipo_pastura,
        production_method: row.forma_producida,
        country: row.pais,
        region: row.region_pais,
        monthly_production: [
            (row.ene || 0) / 1000, (row.feb || 0) / 1000, (row.mar || 0) / 1000, (row.abr || 0) / 1000,
            (row.may || 0) / 1000, (row.jun || 0) / 1000, (row.jul || 0) / 1000, (row.ago || 0) / 1000,
            (row.sep || 0) / 1000, (row.oct || 0) / 1000, (row.nov || 0) / 1000, (row.dic || 0) / 1000
        ]
    }));
};

const normalizeHeader = (header: any): string => {
    if (!header) return '';
    return String(header).trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9_]/g, '_').replace(/[\s/]+/g, '_');
};

const FullForageDatabasePage: FC = () => {
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const { toast } = useToast();
    const navigate = useNavigate();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [editingRowId, setEditingRowId] = useState<string | null>(null);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

    const { data: forageData, isLoading, isError, error, refetch } = useQuery({
        queryKey: ['forageProduction', user?.id],
        queryFn: () => fetchForageData(user!.id),
        enabled: !!user,
        staleTime: 1000 * 60 * 5,
    });
    
    const forageMutation = useMutation({
        mutationFn: async (updatedData: ForageRow[]) => {
            const payload = updatedData.map(row => ({
                id: row.id,
                user_id: row.user_id,
                tipo_pastura: row.pasture_type,
                forma_producida: row.production_method,
                pais: row.country,
                region_pais: row.region,
                ene: row.monthly_production[0] * 1000,
                feb: row.monthly_production[1] * 1000,
                mar: row.monthly_production[2] * 1000,
                abr: row.monthly_production[3] * 1000,
                may: row.monthly_production[4] * 1000,
                jun: row.monthly_production[5] * 1000,
                jul: row.monthly_production[6] * 1000,
                ago: row.monthly_production[7] * 1000,
                sep: row.monthly_production[8] * 1000,
                oct: row.monthly_production[9] * 1000,
                nov: row.monthly_production[10] * 1000,
                dic: row.monthly_production[11] * 1000,
            }));

            const { error } = await supabase.from('forage_production').upsert(payload);
            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['forageProduction', user?.id] });
            setEditingRowId(null);
            toast({ title: '¡Éxito!', description: 'Base de datos de forraje actualizada.', className: 'bg-green-100 border-green-400' });
        },
        onError: (error: any) => {
            toast({ variant: 'destructive', title: 'Error al guardar', description: error.message });
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (rowId: string) => {
            const { error } = await supabase.from('forage_production').delete().eq('id', rowId);
            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['forageProduction', user?.id] });
            setShowDeleteConfirm(null);
            toast({ title: 'Registro eliminado', description: 'El perfil de pastura ha sido eliminado.' });
        },
        onError: (error: any) => {
            toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
        },
    });

    const importMutation = useMutation({
        mutationFn: async (file: File) => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = async (event) => {
                    try {
                        const data = event.target!.result;
                        const workbook = XLSX.read(data, { type: 'binary' });
                        const sheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[sheetName];
                        
                        const json: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, raw: false, defval: "" });
                        if (json.length === 0) reject(new Error("El archivo está vacío."));

                        const headers = json[0].map(h => normalizeHeader(h));
                        
                        const monthsMap = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
                        
                        const findHeaderIndex = (keywords: string[]) => {
                            for (const keyword of keywords) {
                                const normalizedKeyword = normalizeHeader(keyword);
                                const index = headers.findIndex(h => h.includes(normalizedKeyword));
                                if (index !== -1) return index;
                            }
                            return -1;
                        };

                        const pastureTypeKeywords = ['tipo_pastura', 'tipo de pastura', 'pastura'];
                        const productionMethodKeywords = ['forma_producida', 'metodo', 'metodo_produccion', 'tipo_produccion'];
                        const countryKeywords = ['pais', 'country', 'nacion'];
                        const regionKeywords = ['region', 'region_pais', 'departamento'];
                        const monthKeywords = ['meses', 'mes'];
                        const productionValueKeywords = ['produccion_ton_ha', 'produccion_kg_ha', 'kg_ms_mes_region', 'produccion', 'produccion_mensual', 'kgmsha', 'kg_ms_ha'];

                        const wideFormatMonthIndices = monthsMap.map(month => headers.findIndex(h => h.includes(month)));
                        const isWideFormat = wideFormatMonthIndices.filter(i => i !== -1).length >= 10;

                        let newForageData: ForageRow[] = [];

                        if (isWideFormat) {
                            const pastureTypeIndex = findHeaderIndex(pastureTypeKeywords);
                            const productionMethodIndex = findHeaderIndex(productionMethodKeywords);
                            const countryIndex = findHeaderIndex(countryKeywords);
                            const regionIndex = findHeaderIndex(regionKeywords);

                            if (pastureTypeIndex === -1) reject(new Error("Formato Ancho: No se encontró la columna de tipo de pastura (ej. 'Tipo de Pastura', 'Pastura')."));

                            json.slice(1).forEach(row => {
                                const pastureType = row[pastureTypeIndex];
                                if (!pastureType || String(pastureType).trim() === '') return;

                                const productionMethodRaw = productionMethodIndex !== -1 ? (row[productionMethodIndex] || 'Normal').toString() : 'Normal';
                                const productionMethod : 'Normal' | 'Regada' = productionMethodRaw.toLowerCase().includes('regada') ? 'Regada' : 'Normal';
                                const country = countryIndex !== -1 ? (row[countryIndex] || null) : null;
                                const region = regionIndex !== -1 ? (row[regionIndex] || null) : null;
                                
                                const monthly_production = wideFormatMonthIndices.map(index => {
                                    if (index === -1) return 0;
                                    const value = row[index];
                                    return (parseFloat(String(value || '0').replace(',', '.')) || 0);
                                });

                                newForageData.push({
                                    id: uuidv4(),
                                    user_id: user!.id,
                                    pasture_type: pastureType,
                                    production_method: productionMethod,
                                    country: country,
                                    region: region,
                                    monthly_production: monthly_production,
                                });
                            });

                        } else {
                            const pastureTypeIndex = findHeaderIndex(pastureTypeKeywords);
                            const productionMethodIndex = findHeaderIndex(productionMethodKeywords);
                            const countryIndex = findHeaderIndex(countryKeywords);
                            const regionIndex = findHeaderIndex(regionKeywords);
                            const monthIndex = findHeaderIndex(monthKeywords);
                            const productionIndex = findHeaderIndex(productionValueKeywords);

                            if (pastureTypeIndex === -1) reject(new Error("Formato Largo: No se encontró la columna de tipo de pastura (ej. 'Tipo de Pastura', 'Pastura')."));
                            if (monthIndex === -1) reject(new Error("Formato Largo: No se encontró la columna de meses (ej. 'Meses', 'Mes')."));
                            if (productionIndex === -1) reject(new Error("Formato Largo: No se encontró la columna de producción (ej. 'Produccion (ton/ha)')."));
                            
                            const groupedData: { [key: string]: ForageRow } = {};
                            
                            json.slice(1).forEach(row => {
                                const pastureType = row[pastureTypeIndex];
                                if (!pastureType || String(pastureType).trim() === '') return;

                                const productionMethodRaw = productionMethodIndex !== -1 ? (row[productionMethodIndex] || 'Normal').toString() : 'Normal';
                                const productionMethod : 'Normal' | 'Regada' = productionMethodRaw.toLowerCase().includes('regada') ? 'Regada' : 'Normal';
                                const country = countryIndex !== -1 ? (row[countryIndex] || null) : null;
                                const region = regionIndex !== -1 ? (row[regionIndex] || null) : null;
                                
                                const monthValue = (row[monthIndex] || '').toString().toLowerCase().substring(0, 3);
                                const productionValue = (parseFloat(String(row[productionIndex] || '0').replace(',', '.')) || 0);
                                const monthNumeric = monthsMap.indexOf(monthValue);

                                if (pastureType && monthNumeric !== -1 && !isNaN(productionValue)) {
                                    const key = `${country || 'N/A'}-${region || 'N/A'}-${pastureType}-${productionMethod}`;
                                    if (!groupedData[key]) {
                                        groupedData[key] = {
                                            id: uuidv4(),
                                            user_id: user!.id,
                                            pasture_type: pastureType,
                                            production_method: productionMethod,
                                            country: country,
                                            region: region,
                                            monthly_production: Array(12).fill(0),
                                        };
                                    }
                                    groupedData[key].monthly_production[monthNumeric] = productionValue;
                                }
                            });
                            newForageData = Object.values(groupedData);
                        }

                        if (newForageData.length === 0) reject(new Error("No se encontraron datos válidos para importar. Verifique el formato del archivo y que las columnas estén presentes."));
                        
                        const newForageDataInKg = newForageData.map(row => ({
                            id: row.id,
                            user_id: row.user_id,
                            tipo_pastura: row.pasture_type,
                            forma_producida: row.production_method,
                            pais: row.country,
                            region_pais: row.region,
                            ene: row.monthly_production[0] * 1000,
                            feb: row.monthly_production[1] * 1000,
                            mar: row.monthly_production[2] * 1000,
                            abr: row.monthly_production[3] * 1000,
                            may: row.monthly_production[4] * 1000,
                            jun: row.monthly_production[5] * 1000,
                            jul: row.monthly_production[6] * 1000,
                            ago: row.monthly_production[7] * 1000,
                            sep: row.monthly_production[8] * 1000,
                            oct: row.monthly_production[9] * 1000,
                            nov: row.monthly_production[10] * 1000,
                            dic: row.monthly_production[11] * 1000,
                        }));

                        const { error: deleteError } = await supabase.from('forage_production').delete().eq('user_id', user!.id);
                        if (deleteError) throw deleteError;

                        const { error: insertError } = await supabase.from('forage_production').insert(newForageDataInKg);
                        if (insertError) throw insertError;

                        resolve({ count: newForageData.length });

                    } catch (e) { reject(e); }
                };
                reader.readAsBinaryString(file);
            });
        },
        onSuccess: ({count}: {count: number}) => {
            queryClient.invalidateQueries({ queryKey: ['forageProduction', user?.id] });
            toast({ title: '¡Importación Exitosa!', description: `${count} perfiles de pastura importados.`, className: 'bg-green-100 border-green-400' });
        },
        onError: (error: any) => {
            toast({ variant: 'destructive', title: 'Error de Importación', description: error.message });
        },
        onSettled: () => {
          if (fileInputRef.current) fileInputRef.current.value = "";
        }
    });

    const handleAddNew = () => {
        const newRow: ForageRow = {
            id: uuidv4(),
            user_id: user!.id,
            pasture_type: 'Nueva Pastura',
            production_method: 'Normal',
            country: null,
            region: null,
            monthly_production: Array(12).fill(0),
        };
        queryClient.setQueryData(['forageProduction', user?.id], (old: ForageRow[] | undefined) => [newRow, ...(old || [])]);
        setEditingRowId(newRow.id);
    };

    const handleCancelEdit = (id: string) => {
        refetch();
        setEditingRowId(null);
    };

    const handleSave = (rowData: ForageRow) => {
        forageMutation.mutate([rowData]);
    };

    const handleDelete = (rowId: string) => deleteMutation.mutate(rowId);
    
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

    const EditableRow: FC<{ row: ForageRow, onSave: (row: ForageRow) => void, onCancel: (id: string) => void }> = ({ row, onSave, onCancel }) => {
        const [editedRow, setEditedRow] = useState(row);
        const handleChange = (field: keyof ForageRow, value: any) => setEditedRow({ ...editedRow, [field]: value });
        const handleMonthChange = (index: number, value: string) => {
            const newMonthlyProduction = [...editedRow.monthly_production];
            newMonthlyProduction[index] = parseFloat(String(value).replace(',', '.')) || 0;
            setEditedRow({ ...editedRow, monthly_production: newMonthlyProduction });
        };
        return (
            <TableRow className="bg-green-50">
                <TableCell><Input value={editedRow.pasture_type} onChange={(e) => handleChange('pasture_type', e.target.value)} className="h-8 min-w-[150px]" /></TableCell>
                <TableCell><Input value={editedRow.country || ''} onChange={(e) => handleChange('country', e.target.value)} className="h-8 min-w-[100px]" /></TableCell>
                <TableCell><Input value={editedRow.region || ''} onChange={(e) => handleChange('region', e.target.value)} className="h-8 min-w-[100px]" /></TableCell>
                <TableCell>
                  <Select value={editedRow.production_method} onValueChange={(v: 'Normal' | 'Regada') => handleChange('production_method', v)}>
                      <SelectTrigger className="h-8 w-[120px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                          <SelectItem value="Normal">Normal</SelectItem>
                          <SelectItem value="Regada">Regada</SelectItem>
                      </SelectContent>
                  </Select>
                </TableCell>
                {months.map((_, index) => (
                    <TableCell key={index}><Input type="number" step="0.001" value={editedRow.monthly_production[index]} onChange={(e) => handleMonthChange(index, e.target.value)} className="h-8 w-24" /></TableCell>
                ))}
                <TableCell className="sticky right-0 bg-green-50 z-10">
                    <div className="flex gap-2">
                        <Button size="sm" onClick={() => onSave(editedRow)} disabled={forageMutation.isPending}><Save className="h-4 w-4" /></Button>
                        <Button size="sm" variant="outline" onClick={() => onCancel(row.id)} disabled={forageMutation.isPending}><XCircle className="h-4 w-4" /></Button>
                    </div>
                </TableCell>
            </TableRow>
        );
    };

    const isMutating = forageMutation.isPending || deleteMutation.isPending || importMutation.isPending;

    return (
        <>
            <Helmet><title>Base de Datos de Forraje - AGROinvest</title></Helmet>
            <div className="container mx-auto p-4">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                    <Card className="shadow-lg">
                        <CardHeader>
                            <div className="flex justify-between items-start flex-wrap gap-4">
                                <div>
                                    <div className="flex items-center gap-3"><Sprout className="h-8 w-8 text-green-600" /><CardTitle className="text-3xl font-bold">Base de Datos de Forraje</CardTitle></div>
                                    <CardDescription className="mt-2">Gestione la producción de materia seca (ton/ha) de sus pasturas por país y región.</CardDescription>
                                </div>
                                <div className="flex flex-wrap gap-2 justify-end">
                                    <Button onClick={() => navigate('/calculator')} variant="outline" disabled={isMutating}><ArrowLeft className="mr-2 h-4 w-4" />Volver</Button>
                                    <Button onClick={() => fileInputRef.current?.click()} variant="secondary" disabled={isMutating}><Upload className="mr-2 h-4 w-4" />Importar</Button>
                                    <Button onClick={handleAddNew} disabled={isMutating}><PlusCircle className="mr-2 h-4 w-4" />Añadir Perfil</Button>
                                    <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls" onChange={(e) => e.target.files && importMutation.mutate(e.target.files[0])} />
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <QueryStateWrapper isLoading={isLoading} isError={isError} error={error as Error} data={forageData} loader={<ForagePageLoader />} onRetry={refetch}>
                                {(data) => (
                                    <div className="overflow-x-auto">
                                        <Table>
                                            <TableHeader>
                                                <TableRow>
                                                    <TableHead className="min-w-[150px]">Tipo de Pastura</TableHead>
                                                    <TableHead className="min-w-[100px]">País</TableHead>
                                                    <TableHead className="min-w-[100px]">Región</TableHead>
                                                    <TableHead className="min-w-[120px]">Método</TableHead>
                                                    {months.map(month => <TableHead key={month} className="text-center">{month}</TableHead>)}
                                                    <TableHead className="sticky right-0 bg-background z-10">Acciones</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {data.length === 0 ? (
                                                    <TableRow><TableCell colSpan={17} className="text-center h-24">No hay datos. Puede añadir un perfil o importar una planilla.</TableCell></TableRow>
                                                ) : (
                                                    data.map(row => (
                                                        editingRowId === row.id ? (
                                                            <EditableRow key={row.id} row={row} onSave={handleSave} onCancel={handleCancelEdit} />
                                                        ) : (
                                                            <TableRow key={row.id}>
                                                                <TableCell className="font-medium">{row.pasture_type || 'N/A'}</TableCell>
                                                                <TableCell>{row.country || 'N/A'}</TableCell>
                                                                <TableCell>{row.region || 'N/A'}</TableCell>
                                                                <TableCell><span className={`px-2 py-1 rounded-full text-xs font-semibold ${row.production_method === 'Regada' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>{row.production_method || 'N/A'}</span></TableCell>
                                                                {row.monthly_production.map((prod, index) => <TableCell key={index} className="text-center">{new Intl.NumberFormat('es-PY', { minimumFractionDigits: 0, maximumFractionDigits: 3 }).format(prod)}</TableCell>)}
                                                                <TableCell className="sticky right-0 bg-background z-10">
                                                                    <div className="flex gap-2">
                                                                        <Button size="sm" variant="outline" onClick={() => setEditingRowId(row.id)} disabled={isMutating}><Edit className="h-4 w-4" /></Button>
                                                                        <Button size="sm" variant="destructive" onClick={() => setShowDeleteConfirm(row.id)} disabled={isMutating}><Trash2 className="h-4 w-4" /></Button>
                                                                    </div>
                                                                </TableCell>
                                                            </TableRow>
                                                        )
                                                    ))
                                                )}
                                            </TableBody>
                                        </Table>
                                    </div>
                                )}
                            </QueryStateWrapper>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
            <AlertDialog open={!!showDeleteConfirm} onOpenChange={(open) => !open && setShowDeleteConfirm(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle><AlertDialogDescription>Esta acción eliminará permanentemente el perfil de pastura.</AlertDialogDescription></AlertDialogHeader>
                    <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDelete(showDeleteConfirm!)}>Eliminar</AlertDialogAction></AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
};

export default FullForageDatabasePage;