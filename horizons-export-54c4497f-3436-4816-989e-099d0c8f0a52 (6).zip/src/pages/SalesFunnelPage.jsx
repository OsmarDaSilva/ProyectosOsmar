import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SalesFunnelPage = () => {
  const navigate = useNavigate();

  return (
    <>
      <Helmet><title>Análisis de Funnel (Redirigido) - AGRO invest</title></Helmet>
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl font-bold text-gray-800 mb-4"
          >
            Análisis de Funnel ahora en el Dashboard CRM
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg text-gray-600 mb-8"
          >
            Hemos integrado el embudo de ventas y la calificación de oportunidades directamente en tu Dashboard CRM para una vista más completa.
          </motion.p>
          <Button onClick={() => navigate('/crm-dashboard')}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Ir al Dashboard CRM
          </Button>
        </div>
      </div>
    </>
  );
};

export default SalesFunnelPage;