import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Sprout, AlertTriangle, BarChart } from 'lucide-react';
import LoadingScreen from '@/components/LoadingScreen';
import ForageSummaryChart from '@/components/pasture/ForageSummaryChart';
import ForageAlerts from '@/components/pasture/ForageAlerts';

const ForageDashboardPage = () => {
    const { user } = useAuth();
    const { ganaderiaData, fullForageData, isDataLoaded } = useProjectData();

    if (!isDataLoaded) {
        return <LoadingScreen message="Cargando datos del dashboard..." />;
    }

    return (
        <>
            <Helmet>
                <title>Dashboard de Forraje - AGROinvest</title>
                <meta name="description" content="Dashboard técnico con resumen dinámico de forraje consumido vs producido y alertas inteligentes." />
            </Helmet>
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                <div className="space-y-6">
                    <header>
                        <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
                            <Sprout className="h-8 w-8 text-green-600" />
                            Dashboard Técnico de Forraje
                        </h1>
                        <p className="text-muted-foreground mt-1">
                            Análisis de producción, consumo y alertas proactivas.
                        </p>
                    </header>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <Card className="lg:col-span-2">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <BarChart className="h-5 w-5 text-blue-600" />
                                    Resumen Anual: Producido vs. Consumido
                                </CardTitle>
                                <CardDescription>
                                    Comparación de la oferta total de materia seca contra la demanda del hato ganadero.
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="h-80">
                                    <ForageSummaryChart 
                                        ganaderiaData={ganaderiaData} 
                                        fullForageData={fullForageData} 
                                    />
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <AlertTriangle className="h-5 w-5 text-yellow-500" />
                                    Alertas Inteligentes
                                </CardTitle>
                                <CardDescription>
                                    Notificaciones automáticas sobre el estado de su sistema forrajero.
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <ForageAlerts 
                                    ganaderiaData={ganaderiaData} 
                                    fullForageData={fullForageData} 
                                />
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ForageDashboardPage;