import React, { useState } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { Button } from '@/components/ui/button';
    import { ArrowLeft, Mail, MessageSquare } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
    import EmailCampaigns from '@/components/campaigns/EmailCampaigns';
    import WhatsAppCampaigns from '@/components/campaigns/WhatsAppCampaigns';

    const CampaignsPage = () => {
      const navigate = useNavigate();

      return (
        <>
          <Helmet><title>Campañas - AGRO invest</title></Helmet>
          <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <header className="mb-6 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate('/')}>
                    <ArrowLeft className="h-4 w-4" />
                </Button>
                <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                    Gestor de Campañas
                </h1>
              </div>
            </header>
            <main>
                <Tabs defaultValue="email" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="email">
                            <Mail className="mr-2 h-4 w-4" />
                            Email
                        </TabsTrigger>
                        <TabsTrigger value="whatsapp">
                            <MessageSquare className="mr-2 h-4 w-4" />
                            WhatsApp
                        </TabsTrigger>
                    </TabsList>
                    <TabsContent value="email">
                        <EmailCampaigns />
                    </TabsContent>
                    <TabsContent value="whatsapp">
                        <WhatsAppCampaigns />
                    </TabsContent>
                </Tabs>
            </main>
          </div>
        </>
      );
    };

    export default CampaignsPage;