import React, { useState, useCallback, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlusCircle, Database, ArrowLeft, Upload, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';
import { ProductionDataTable } from '@/components/ProductionDataTable';
import { v4 as uuidv4 } from 'uuid';
import { logUserAction } from '@/lib/logger';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { Skeleton } from '@/components/ui/skeleton';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { ProductionData } from '@/types/production';

const fetchProductionData = async (userId: string | undefined): Promise<ProductionData[]> => {
  if (!userId) return [];
  const { data, error } = await supabase.from('Produccion_Agricola').select('*').eq('user_id', userId);
  if (error) throw new Error(error.message);
  return data as ProductionData[];
};

const ProductionDatabaseLoader = () => (
    <div className="space-y-4 p-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-full" />
    </div>
);

const ProductionDatabasePage: React.FC = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: productionDbData = [], isLoading, isError, error, refetch } = useQuery<ProductionData[]>({
    queryKey: ['productionData', user?.id],
    queryFn: () => fetchProductionData(user?.id),
    enabled: !!user,
  });

  const [editingRow, setEditingRow] = useState<ProductionData | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const updateMutation = useMutation({
    mutationFn: async (updatedData: ProductionData[]) => {
      const { error } = await supabase.from('Produccion_Agricola').upsert(updatedData);
      if (error) throw error;
      return updatedData;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['productionData', user?.id] });
      toast({ title: '¡Éxito!', description: 'Base de datos actualizada.', className: 'bg-green-100 border-green-400' });
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: `No se pudo actualizar la base de datos: ${error.message}` });
    },
  });

  const bulkReplaceMutation = useMutation({
    mutationFn: async (newData: ProductionData[]) => {
        const { error: deleteError } = await supabase.from('Produccion_Agricola').delete().eq('user_id', user!.id);
        if (deleteError) throw deleteError;

        if (newData.length > 0) {
            const { error: insertError } = await supabase.from('Produccion_Agricola').insert(newData);
            if (insertError) throw insertError;
        }
        return newData;
    },
    onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['productionData', user?.id] });
    },
    onError: (error: Error) => {
        toast({ variant: "destructive", title: "Error de Mutación", description: `No se pudo procesar la operación: ${error.message}` });
    }
  });


  const handleAddNew = () => {
    const newRow: ProductionData = {
      id: `new-${uuidv4()}`,
      user_id: user!.id,
      country: '', department_province: '', city_locality: '',
      year: new Date().getFullYear(), crop: '', production_purpose: '',
      sowing_season: '', cultivation_method: 'Normal',
      yield_ton_ha: 0, input_cost_ha: 0, machinery_cost_ha: 0,
      freight_cost_ha: 0, land_rent_ha: 0, electrical_energy_cost_ha: 0,
      maintenance_repair_cost_ha: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    queryClient.setQueryData(['productionData', user?.id], (oldData: ProductionData[] | undefined) => [newRow, ...(oldData || [])]);
    setEditingRow(newRow);
  };

  const handleCancelEdit = () => {
    if (editingRow && editingRow.id.toString().startsWith('new-')) {
       queryClient.setQueryData(['productionData', user?.id], (oldData: ProductionData[] | undefined) => (oldData || []).filter(row => row.id !== editingRow.id));
    }
    setEditingRow(null);
  };

  const handleSave = (rowData: ProductionData) => {
    const isNew = rowData.id.toString().startsWith('new-');
    const finalRow = isNew ? { ...rowData, id: uuidv4() } : rowData;

    updateMutation.mutate([finalRow], {
      onSuccess: () => {
        setEditingRow(null);
        logUserAction(isNew ? 'create' : 'edit', 'production_database', { crop: rowData.crop, year: rowData.year });
      }
    });
  };

  const handleDelete = (rowId: string) => {
    const rowToDelete = productionDbData.find(row => row.id === rowId);
    const updatedData = productionDbData.filter(row => row.id !== rowId);
    bulkReplaceMutation.mutate(updatedData, {
      onSuccess: () => {
        setShowDeleteConfirm(null);
        toast({ title: 'Registro eliminado', description: 'El registro ha sido eliminado con éxito.' });
        if (rowToDelete) logUserAction('delete', 'production_database', { crop: rowToDelete.crop, year: rowToDelete.year });
      }
    });
  };

  const handleResetData = () => {
    bulkReplaceMutation.mutate([], {
        onSuccess: () => {
            setShowResetConfirm(false);
            toast({ title: 'Base de Datos Restaurada', description: 'Se han eliminado todos los datos de producción.' });
            logUserAction('reset', 'production_database', {});
        }
    });
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        if (!event.target?.result) throw new Error("No se pudo leer el archivo.");
        const data = event.target.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames.find(name => name.toLowerCase() === 'produccion') || workbook.SheetNames[0];
        if (!sheetName) throw new Error("No se encontró una hoja de cálculo válida.");

        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet, { raw: false, header: 1, defval: "" });
        if (json.length < 2) throw new Error("La hoja de cálculo está vacía.");
        
        const headers = (json[0] as string[]).map(h => (h || '').toString().trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[\s/().-]+/g, ' '));
        const dataRows = json.slice(1) as string[][];
        
        const columnMapping: { [key in keyof Partial<ProductionData>]: string[] } = {
          'country': ['pais'], 'department_province': ['dpto provincia'], 'city_locality': ['ciudad localidad'], 'year': ['ano'], 'crop': ['cultura'], 'production_purpose': ['finalidad'], 'sowing_season': ['epoca siembra'], 'cultivation_method': ['forma cultivo'], 'yield_ton_ha': ['prod ton ha'], 'input_cost_ha': ['costo insumos ha'], 'machinery_cost_ha': ['costo maquinas ha'], 'freight_cost_ha': ['costo fletes ha'], 'land_rent_ha': ['alquiler tierra ha'], 'electrical_energy_cost_ha': ['energia electrica ha'], 'maintenance_repair_cost_ha': ['manutencion ha'],
        };
        const headerMap: { [key: string]: number } = {};
        headers.forEach((header, index) => {
            for (const dbCol in columnMapping) {
                if (columnMapping[dbCol as keyof ProductionData]!.some(alias => header.includes(alias))) {
                    headerMap[dbCol] = index; break;
                }
            }
        });
        if (Object.keys(headerMap).length < 5) throw new Error("No se pudieron mapear suficientes columnas.");
        
        const parseNumericValue = (value: any): number => {
          if (value === null || value === undefined || String(value).trim() === '') return 0;
          const number = parseFloat(String(value).replace(/\./g, '').replace(',', '.'));
          return isNaN(number) ? 0 : number;
        };
        
        const recordsToInsert = dataRows.map((row): ProductionData | null => {
          if (row.every(cell => String(cell).trim() === "")) return null;
          const newRecord: Partial<ProductionData> = { id: uuidv4(), user_id: user!.id, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
          for (const dbCol in columnMapping) {
             const key = dbCol as keyof ProductionData;
             const colIndex = headerMap[key];
             if (colIndex !== undefined) {
                let value: any = row[colIndex];
                if (['yield_ton_ha', 'input_cost_ha', 'machinery_cost_ha', 'freight_cost_ha', 'land_rent_ha', 'electrical_energy_cost_ha', 'maintenance_repair_cost_ha', 'year'].includes(key)) {
                    (newRecord as any)[key] = parseNumericValue(value);
                } else {
                    (newRecord as any)[key] = String(value || '').trim();
                }
             }
          }
          return newRecord.country && newRecord.crop ? newRecord as ProductionData : null;
        }).filter((r): r is ProductionData => r !== null);
        
        if (recordsToInsert.length === 0) throw new Error("No se encontraron datos válidos para importar.");

        bulkReplaceMutation.mutate(recordsToInsert, {
          onSuccess: () => {
            logUserAction('import', 'production_database', { file_name: file.name, record_count: recordsToInsert.length });
            toast({ title: '¡Importación Exitosa!', description: `${recordsToInsert.length} registros han sido importados.`});
          }
        });

      } catch (error: any) {
        toast({ variant: 'destructive', title: 'Error de Importación', description: error.message });
      } finally {
        if(fileInputRef.current) fileInputRef.current.value = null;
      }
    };
    reader.readAsBinaryString(file);
  };

  const isMutating = updateMutation.isPending || bulkReplaceMutation.isPending;

  return (
    <>
      <Helmet>
        <title>Base de Datos de Producción - AGROinvest</title>
        <meta name="description" content="Gestione y analice datos históricos de producción agrícola." />
      </Helmet>
      <div className="container mx-auto p-4">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex justify-between items-start flex-wrap gap-4">
                <div>
                  <div className="flex items-center gap-3"><Database className="h-8 w-8 text-green-600" /><CardTitle className="text-3xl font-bold">Base de Datos de Producción</CardTitle></div>
                  <CardDescription className="mt-2">Gestione y analice datos históricos de producción agrícola.</CardDescription>
                </div>
                <div className="flex flex-wrap gap-2 justify-end">
                  <Button onClick={() => navigate('/')} variant="outline" disabled={isMutating}><ArrowLeft className="mr-2 h-4 w-4" />Volver</Button>
                  <Button onClick={() => fileInputRef.current?.click()} variant="secondary" disabled={isMutating}><Upload className="mr-2 h-4 w-4" />Importar</Button>
                  <Button onClick={() => setShowResetConfirm(true)} variant="outline" disabled={isMutating}><RefreshCw className="mr-2 h-4 w-4" />Restaurar</Button>
                  <Button onClick={handleAddNew} disabled={isMutating}><PlusCircle className="mr-2 h-4 w-4" />Añadir Registro</Button>
                  <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls" onChange={handleFileImport}/>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <QueryStateWrapper
                isLoading={isLoading}
                isError={isError}
                error={error as Error}
                data={productionDbData}
                loader={<ProductionDatabaseLoader />}
                onRetry={refetch}
              >
                {(data) => (
                    data && <ProductionDataTable
                        data={data}
                        editingRow={editingRow}
                        onEditRow={setEditingRow}
                        onSaveRow={handleSave}
                        onCancelEdit={handleCancelEdit}
                        onDeleteRow={setShowDeleteConfirm}
                    />
                )}
              </QueryStateWrapper>
            </CardContent>
          </Card>
        </motion.div>
      </div>
      <AlertDialog open={!!showDeleteConfirm} onOpenChange={(open) => !open && setShowDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle><AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente el registro.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDelete(showDeleteConfirm!)}>Eliminar</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
       <AlertDialog open={showResetConfirm} onOpenChange={setShowResetConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>¿Restaurar Base de Datos?</AlertDialogTitle><AlertDialogDescription>Esta acción reemplazará todos los datos actuales con la base de datos original. ¿Deseas continuar?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={handleResetData}>Sí, Restaurar</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default ProductionDatabasePage;