import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import GanaderiaForm from '@/components/GanaderiaForm';
import { PawPrint } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const LivestockSimulationPage = () => {
    const { t } = useTranslation('simulations');
    const [simulationData, setSimulationData] = useState(null);

    useEffect(() => {
        const defaultGanaderiaData = {
          isEnabled: true,
          use_traditional: true,
          use_intensive: true,
          params: {
              tipoAnimal: 'Novillo Toro',
              pesoVivoEntrada: '200',
              precioCompraKgVivo: '2,00',
              hectareasTradicional: '400',
              hectareasIntensivo: '400',
              pesoVivoSalida: '500',
              desbaste: '3%',
              precioVentaKgGancho: '3,50',
              rendimientoCarcaza: '54,00%',
              tasaInteresAnual: '7,0%'
          },
          tradicional: {
              cantidad: '1,1',
              fechaEntrada: '2026-01-01',
              fechaSalida: '2027-06-30',
              fleteEntrada: '25',
              comisionVendedor: '3,00%',
              costoSuplementacion: '50,00',
              costoAdministrativo: '25,00',
              costoVacunacion: '15',
              costoFertilizacion: '0',
              costoEnergia: '2,5',
              costoManutencion: '2,5',
              combustibleGasoil: '1',
              otrosCostos: '2,5',
              mortandad: '1,0%',
              impuestoIragro: '5,00%',
              impuestoIrp: '10,00%'
          },
          intensivo: {
              cantidad: '10',
              fechaEntrada: '2026-01-01',
              fechaSalida: '2027-01-01',
              fleteEntrada: '25',
              comisionVendedor: '3,00%',
              costoSuplementacion: '100,00',
              costoAdministrativo: '35,00',
              costoVacunacion: '15',
              costoFertilizacion: '200',
              costoEnergia: '350',
              costoManutencion: '2',
              combustibleGasoil: '5',
              otrosCostos: '5',
              mortandad: '1,0%',
              impuestoIragro: '5,00%',
              impuestoIrp: '10,00%'
          },
          pastureAnalysis: {}
        };
        setSimulationData(defaultGanaderiaData);
    }, []);

    const handleSimulationUpdate = (updatedData) => {
        setSimulationData(updatedData);
    };
    
    if (!simulationData) {
        return <div>{t('loading.simulator')}</div>;
    }

    return (
        <>
            <Helmet>
                <title>{t('livestock.title')} - AGROinvest</title>
                <meta name="description" content={t('livestock.lsDesc')} />
            </Helmet>
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                <div className="space-y-6">
                    <header>
                        <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
                            <PawPrint className="h-8 w-8 text-orange-600" />
                            {t('livestock.title')}
                        </h1>
                        <p className="text-muted-foreground mt-1">
                            {t('livestock.lsDesc')}
                        </p>
                    </header>
                    
                    <GanaderiaForm 
                        initialData={simulationData} 
                        onUpdate={handleSimulationUpdate} 
                        projectData={{ projectName: t('simulationProjectName') }} 
                    />
                </div>
            </div>
        </>
    );
};

export default LivestockSimulationPage;