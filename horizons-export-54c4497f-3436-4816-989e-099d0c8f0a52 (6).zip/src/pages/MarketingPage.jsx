import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PlusCircle, LayoutGrid, List as ListIcon, Search } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Skeleton } from '@/components/ui/skeleton';
import { useDebounce } from '@/hooks/useDebounce';
import { useImportJobs } from '@/hooks/useImportJobs';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AssetCard from '@/components/marketing/AssetCard';
import AssetRow from '@/components/marketing/AssetRow';
import AssetDialog from '@/components/marketing/AssetDialog';
import ImportHistory from '@/components/marketing/ImportHistory';

const MarketingPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [assets, setAssets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [deleteDialog, setDeleteDialog] = useState(null);
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const { jobs, refetch: refetchJobs, resumeJob, isResuming } = useImportJobs(user?.id, 'marketing_assets');

  const fetchAssets = useCallback(async () => {
    setIsLoading(true);
    let query = supabase.from('marketing_assets').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    if (debouncedSearchTerm) {
      query = query.or(`file_name.ilike.%${debouncedSearchTerm}%,description.ilike.%${debouncedSearchTerm}%,category.ilike.%${debouncedSearchTerm}%,subcategory.ilike.%${debouncedSearchTerm}%`);
    }
    if (categoryFilter !== 'all') {
      query = query.eq('category', categoryFilter);
    }
    const { data, error } = await query;
    if (error) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    } else {
      setAssets(data);
    }
    setIsLoading(false);
  }, [user.id, toast, debouncedSearchTerm, categoryFilter]);

  useEffect(() => {
    fetchAssets();
  }, [fetchAssets]);
  
  const uniqueCategories = useMemo(() => ['all', ...new Set(assets.map(a => a.category).filter(Boolean))], [assets]);

  const handleSave = async (assetData) => {
    if (assetData?.id) { // Editing existing asset
      const { error } = await supabase.from('marketing_assets').update(assetData).eq('id', assetData.id);
      if (error) {
        toast({ variant: 'destructive', title: 'Error', description: `No se pudo actualizar el activo: ${error.message}` });
      } else {
        toast({ title: 'Éxito', description: 'Activo actualizado correctamente.' });
        fetchAssets();
      }
    }
    setIsDialogOpen(false);
    setTimeout(() => refetchJobs(), 2000);
  };

  const handleDelete = async () => {
    if (!deleteDialog) return;
    const { error: dbError } = await supabase.from('marketing_assets').delete().eq('id', deleteDialog.id);
    if (dbError) {
      toast({ variant: 'destructive', title: 'Error', description: `Error al eliminar de la base de datos: ${dbError.message}` });
      return;
    }
    
    setAssets(prev => prev.filter(asset => asset.id !== deleteDialog.id));
    setDeleteDialog(null);
    toast({ title: 'Éxito', description: 'Activo eliminado permanentemente.' });

    const filePath = deleteDialog.file_url.split(`/storage/v1/object/public/marketing_assets/`)[1];
    if (filePath) {
        const { error: storageError } = await supabase.storage.from('marketing_assets').remove([filePath]);
        if (storageError) {
          console.error('Failed to delete from storage:', storageError.message);
        }
    }
  };

  const handleResumeJob = async (jobId) => {
    await resumeJob({jobId, userId: user.id, jobType: 'marketing_assets'});
    setTimeout(() => {
        refetchJobs();
        fetchAssets();
    }, 2000);
  };

  return (
    <>
      <Helmet><title>Centro de Marketing - AGROinvest</title></Helmet>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h1 className="text-3xl font-bold tracking-tight">Centro de Marketing</h1>
            <Button onClick={() => { setSelectedAsset(null); setIsDialogOpen(true); }}><PlusCircle className="mr-2 h-4 w-4" /> Subir Nuevo Activo</Button>
        </div>

        <Tabs defaultValue="assets" className="w-full">
            <TabsList>
                <TabsTrigger value="assets">Biblioteca de Activos</TabsTrigger>
                <TabsTrigger value="uploads">Historial de Subidas</TabsTrigger>
            </TabsList>
            <TabsContent value="assets" className="mt-4">
                <Card>
                    <CardHeader>
                      <div className="flex flex-col md:flex-row justify-between gap-4">
                        <div className="flex-1 flex gap-2">
                           <div className="relative w-full max-w-sm">
                              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                              <Input placeholder="Buscar activos..." className="pl-9" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                           </div>
                           <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                              <SelectTrigger className="w-[180px]">
                                <SelectValue placeholder="Categoría" />
                              </SelectTrigger>
                              <SelectContent>
                                {uniqueCategories.map(cat => <SelectItem key={cat} value={cat}>{cat === 'all' ? 'Todas las categorías' : cat}</SelectItem>)}
                              </SelectContent>
                           </Select>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-sm text-muted-foreground">Vista:</span>
                            <Button variant={viewMode === 'grid' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('grid')}><LayoutGrid className="h-4 w-4"/></Button>
                            <Button variant={viewMode === 'list' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('list')}><ListIcon className="h-4 w-4"/></Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        viewMode === 'grid' ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="aspect-video" />)}
                          </div>
                        ) : (
                          <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
                        )
                      ) : assets.length === 0 ? (
                        <div className="text-center py-16">
                          <p className="text-muted-foreground">No se encontraron activos. ¡Sube el primero!</p>
                        </div>
                      ) : viewMode === 'grid' ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                          {assets.map(asset => (
                            <AssetCard key={asset.id} asset={asset} onEdit={(assetToEdit) => { setSelectedAsset(assetToEdit); setIsDialogOpen(true); }} onDelete={setDeleteDialog} />
                          ))}
                        </div>
                      ) : (
                        <div className="border rounded-md">
                          <table className="w-full">
                            <thead className="bg-muted/50">
                              <tr>
                                <th className="p-2 w-10"></th>
                                <th className="p-2 text-left font-medium">Nombre</th>
                                <th className="p-2 text-left font-medium hidden md:table-cell">Categoría</th>
                                <th className="p-2 text-left font-medium hidden lg:table-cell">Subcategoría</th>
                                <th className="p-2 text-left font-medium hidden md:table-cell">Fecha</th>
                                <th className="p-2 text-right font-medium">Acciones</th>
                              </tr>
                            </thead>
                            <tbody>
                                {assets.map(asset => (
                                    <AssetRow key={asset.id} asset={asset} onEdit={() => { setSelectedAsset(asset); setIsDialogOpen(true); }} onDelete={() => setDeleteDialog(asset)} />
                                ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </CardContent>
                </Card>
            </TabsContent>
            <TabsContent value="uploads" className="mt-4">
                <ImportHistory jobs={jobs} onRefresh={refetchJobs} onResume={handleResumeJob} isResuming={isResuming}/>
            </TabsContent>
        </Tabs>
        
        <AssetDialog isOpen={isDialogOpen} setIsOpen={setIsDialogOpen} asset={selectedAsset} onSave={handleSave} />
        
        <AlertDialog open={!!deleteDialog} onOpenChange={() => setDeleteDialog(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Estás seguro de que quieres eliminar este activo?</AlertDialogTitle>
              <AlertDialogDescription>Esta acción es irreversible y eliminará "{deleteDialog?.file_name}" de forma permanente.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Eliminar</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </>
  );
};

export default MarketingPage;