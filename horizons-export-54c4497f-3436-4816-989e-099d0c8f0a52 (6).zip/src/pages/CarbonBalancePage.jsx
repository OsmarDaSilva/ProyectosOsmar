import React from 'react';
import { Helmet } from 'react-helmet-async';
import CarbonBalance from '@/components/CarbonBalance';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { useTranslation } from 'react-i18next';

const CarbonBalancePage = () => {
  const { t } = useTranslation('calculator');
  const { projectData, agricultureData, ganaderiaData } = useProjectData();

  return (
    <>
      <Helmet>
        <title>{t('carbonBalance.title')} - AGROinvest</title>
        <meta name="description" content={t('carbonBalance.detailedSummaryDesc')} />
      </Helmet>
      <CarbonBalance 
        projectData={projectData} 
        agricultureData={agricultureData} 
        ganaderiaData={ganaderiaData} 
      />
    </>
  );
};

export default CarbonBalancePage;