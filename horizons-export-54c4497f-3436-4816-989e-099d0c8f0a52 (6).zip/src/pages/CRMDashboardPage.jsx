import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Users, DollarSign, Cake, Star, ChevronUp, ChevronDown } from 'lucide-react';
import FunnelChartComponent from '@/components/pipeline/FunnelChart';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useQuery } from '@tanstack/react-query';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';
import { useTranslation } from 'react-i18next';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell, CartesianGrid } from 'recharts';

const fetchDashboardData = async () => {
    const [
        { data: clientsData, error: clientsError },
        { data: dealsData, error: dealsError },
        { data: activitiesData, error: activitiesError },
        { data: contactsData, error: contactsError },
        { data: funnelResData, error: funnelError }
    ] = await Promise.all([
        supabase.from('clients').select('id, birthday, name'),
        supabase.from('deals').select('stage, value, title, confidence, score, clients(name)'),
        supabase.from('activities').select('type, is_completed'),
        supabase.from('contacts').select('name, birthday, clients(name)'),
        supabase.from('deal_funnel').select('*')
    ]);

    if (clientsError) throw clientsError;
    if (dealsError) throw dealsError;
    if (activitiesError) throw activitiesError;
    if (contactsError) throw contactsError;
    if (funnelError) throw funnelError;

    const totalClients = clientsData.length;
    const totalValueWon = dealsData.filter(d => d.stage === 'Ganado').reduce((sum, d) => sum + (d.value || 0), 0);
    const dealsByStage = dealsData.reduce((acc, deal) => {
        const stage = deal.stage || 'Sin Etapa';
        const existing = acc.find(item => item.name === stage);
        if (existing) { existing.count += 1; }
        else { acc.push({ name: stage, count: 1 }); }
        return acc;
    }, []);
    const activitiesSummary = activitiesData.reduce((acc, activity) => {
        const type = activity.type || 'Sin Tipo';
        let existing = acc.find(item => item.name === type);
        if (!existing) {
            existing = { name: type, total: 0, completadas: 0 };
            acc.push(existing);
        }
        existing.total += 1;
        if (activity.is_completed) { existing.completadas += 1; }
        return acc;
    }, []);
    
    const upcomingBirthdays = [];
    const today = new Date();
    const next30Days = new Date();
    next30Days.setDate(today.getDate() + 30);
    const allPeople = [
        ...clientsData.map(c => ({ ...c, type: 'Cliente' })),
        ...contactsData.map(c => ({ ...c, name: `${c.name} (${c.clients.name})`, type: 'Contacto' }))
    ];
    allPeople.forEach(person => {
        if (person.birthday) {
            const birthDate = new Date(person.birthday);
            const birthMonth = birthDate.getMonth();
            const birthDay = birthDate.getDate() + 1;
            const currentYear = today.getFullYear();
            let nextBirthday = new Date(currentYear, birthMonth, birthDay);
            if (nextBirthday < today) { nextBirthday.setFullYear(currentYear + 1); }
            if (nextBirthday >= today && nextBirthday <= next30Days) {
                upcomingBirthdays.push({ name: person.name, date: nextBirthday, type: person.type });
            }
        }
    });
    upcomingBirthdays.sort((a, b) => a.date - b.date);

    const STAGE_ORDER = ['Lead', 'Contactado', 'Propuesta', 'Negociación', 'Ganado', 'Perdido'];
    const sortedFunnelData = funnelResData.sort((a, b) => STAGE_ORDER.indexOf(a.stage) - STAGE_ORDER.indexOf(b.stage));
    const funnelData = sortedFunnelData.map((stage, index, arr) => {
        const conversionRate = index > 0 && arr[index-1].deal_count > 0 ? ((stage.deal_count / arr[index - 1].deal_count) * 100).toFixed(1) : 100;
        return { ...stage, conversion: parseFloat(conversionRate) };
    });

    return {
        stats: {
            totalClients,
            totalValueWon,
            dealsByStage,
            activitiesSummary,
            upcomingBirthdays: upcomingBirthdays.slice(0, 5),
        },
        funnelData,
        deals: dealsData,
    };
};

const DashboardLoader = () => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28" />)}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Skeleton className="h-80" />
            <Skeleton className="h-80" />
        </div>
        <Skeleton className="h-64" />
        <Skeleton className="h-96" />
    </div>
);

const CRMDashboardPage = () => {
  const { t } = useTranslation('crm');
  const [sortConfig, setSortConfig] = useState({ key: 'weighted_value', direction: 'desc' });

  const { data: dashboardData, isLoading, isError, error, refetch } = useQuery({
      queryKey: ['crmDashboard'],
      queryFn: fetchDashboardData,
      staleTime: 1000 * 60 * 5,
  });

  const sortedDeals = useMemo(() => {
    if (!dashboardData?.deals) return [];
    let sortableDeals = [...dashboardData.deals].map(d => ({...d, weighted_value: (d.value || 0) * ((d.confidence || 0) / 100) }));
    if (sortConfig.key) {
      sortableDeals.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableDeals;
  }, [dashboardData?.deals, sortConfig]);

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  const formatCurrency = (value) => `$${(value || 0).toLocaleString('es-PY', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
  const StarRating = ({ score }) => (
    <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => <Star key={star} className={`h-4 w-4 ${score >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />)}
    </div>
  );
  const SortableHeader = ({ tkey, label }) => (
    <TableHead onClick={() => handleSort(tkey)} className="cursor-pointer hover:bg-gray-50">
      <div className="flex items-center gap-2">{label}{sortConfig.key === tkey && (sortConfig.direction === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />)}</div>
    </TableHead>
  );

  const ACTIVITY_COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  return (
    <>
      <Helmet><title>{t('dashboard.pageTitle')} - AGROinvest</title></Helmet>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-gray-800">{t('dashboard.pageTitle')}</h1>
          <QueryStateWrapper isLoading={isLoading} isError={isError} error={error} data={dashboardData} loader={<DashboardLoader />} onRetry={refetch}>
            {(data) => (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">{t('dashboard.totalClients')}</CardTitle>
                            <Users className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent><div className="text-2xl font-bold">{data.stats.totalClients}</div></CardContent>
                    </Card>
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">{t('dashboard.totalValueWon')}</CardTitle>
                            <DollarSign className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent><div className="text-2xl font-bold">{formatCurrency(data.stats.totalValueWon)}</div></CardContent>
                    </Card>
                    <Card className="lg:col-span-2">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">{t('dashboard.upcomingBirthdays')}</CardTitle>
                            <Cake className="h-4 w-4 text-muted-foreground" />
                        </CardHeader>
                        <CardContent>
                            {data.stats.upcomingBirthdays.length > 0 ? (
                            <ul className="space-y-2">
                                {data.stats.upcomingBirthdays.map((b, index) => (
                                <li key={index} className="flex justify-between items-center text-sm">
                                    <span className="font-medium">{b.name}</span>
                                    <span className="text-muted-foreground">{b.date.toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}</span>
                                </li>
                                ))}
                            </ul>
                            ) : (<p className="text-sm text-muted-foreground text-center py-4">{t('dashboard.noUpcomingBirthdays')}</p>)}
                        </CardContent>
                    </Card>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader><CardTitle>{t('dashboard.dealsByStage')}</CardTitle><CardDescription>{t('dashboard.dealsByStageDesc')}</CardDescription></CardHeader>
                        <CardContent className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%"><BarChart data={data.stats.dealsByStage}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis allowDecimals={false} /><Tooltip /><Legend /><Bar dataKey="count" name={t('dashboard.deals')} fill="#82ca9d" /></BarChart></ResponsiveContainer>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader><CardTitle>{t('dashboard.activitiesSummary')}</CardTitle><CardDescription>{t('dashboard.activitiesSummaryDesc')}</CardDescription></CardHeader>
                        <CardContent className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={data.stats.activitiesSummary} cx="50%" cy="50%" labelLine={false} label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`} outerRadius={80} fill="#8884d8" dataKey="total" nameKey="name">{data.stats.activitiesSummary.map((entry, index) => (<Cell key={`cell-${index}`} fill={ACTIVITY_COLORS[index % ACTIVITY_COLORS.length]} />))}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer>
                        </CardContent>
                    </Card>
                </div>

                <Card><CardHeader><CardTitle>{t('dashboard.salesFunnel')}</CardTitle><CardDescription>{t('dashboard.salesFunnelDesc')}</CardDescription></CardHeader><CardContent><FunnelChartComponent data={data.funnelData} /></CardContent></Card>
                
                <Card>
                    <CardHeader><CardTitle>{t('dashboard.dealsQualification')}</CardTitle><CardDescription>{t('dashboard.dealsQualificationDesc')}</CardDescription></CardHeader>
                    <CardContent>
                        <div className="overflow-x-auto">
                            <Table><TableHeader><TableRow><SortableHeader tkey="title" label={t('dashboard.deal')} /><SortableHeader tkey="stage" label={t('dashboard.stage')} /><SortableHeader tkey="value" label={t('dashboard.value')} /><SortableHeader tkey="confidence" label={`${t('dashboard.confidence')} (%)`} /><SortableHeader tkey="weighted_value" label={t('dashboard.weightedValue')} /><SortableHeader tkey="score" label={t('dashboard.score')} /></TableRow></TableHeader>
                                <TableBody>{sortedDeals.map(deal => (<TableRow key={deal.id}><TableCell className="font-medium">{deal.title}</TableCell><TableCell>{deal.stage}</TableCell><TableCell>{formatCurrency(deal.value)}</TableCell><TableCell>{deal.confidence || 0}%</TableCell><TableCell className="font-semibold">{formatCurrency(deal.weighted_value)}</TableCell><TableCell><StarRating score={deal.score} /></TableCell></TableRow>))}</TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
            )}
          </QueryStateWrapper>
      </div>
    </>
  );
};

export default CRMDashboardPage;