import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Helmet } from 'react-helmet-async';
import { Loader2, AlertTriangle, Users, Briefcase, Ticket, DollarSign, CheckCircle } from 'lucide-react';
import AlertHistoryChart from '@/components/dashboard/AlertHistoryChart';
import ResolvedAlertsWidget from '@/components/dashboard/ResolvedAlertsWidget';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { motion } from 'framer-motion';
import CriticalAlerts from '@/components/dashboard/CriticalAlerts';

const fetchDashboardData = async (userId) => {
    const { data: clientsData, error: clientsError } = await supabase
        .from('clients')
        .select('id', { count: 'exact' })
        .eq('created_by', userId);
    if (clientsError) throw clientsError;

    const { data: projectsData, error: projectsError } = await supabase
        .from('client_projects')
        .select('id', { count: 'exact' })
        .eq('created_by', userId);
    if (projectsError) throw projectsError;

    const { data: openTicketsData, error: openTicketsError } = await supabase
        .from('tickets')
        .select('id', { count: 'exact' })
        .neq('status', 'Cerrado');
    if (openTicketsError) throw openTicketsError;

    const { data: totalRevenueData, error: totalRevenueError } = await supabase
        .from('quotes')
        .select('total')
        .eq('user_id', userId)
        .eq('status', 'Aceptado');
    if (totalRevenueError) throw totalRevenueError;

    const totalRevenue = totalRevenueData ? totalRevenueData.reduce((sum, quote) => sum + (quote.total || 0), 0) : 0;

    return {
        totalClients: clientsData?.length || 0,
        totalProjects: projectsData?.length || 0,
        openTickets: openTicketsData?.length || 0,
        totalRevenue: totalRevenue,
    };
};

const GeneralDashboardPage = () => {
    const { user, userProfile } = useAuth();

    const { data: dashboardData, isLoading: isDashboardLoading, isError: isDashboardError } = useQuery({
        queryKey: ['generalDashboardData', user?.id],
        queryFn: () => fetchDashboardData(user.id),
        enabled: !!user?.id,
    });

    const cardVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 }
    };

    return (
        <>
            <Helmet>
                <title>Dashboard General - AGROinvest</title>
                <meta name="description" content="Vista consolidada de la inteligencia de su negocio, incluyendo clientes, proyectos, tickets y alertas." />
                <meta property="og:title" content="Dashboard General - AGROinvest" />
                <meta property="og:description" content="Vista consolidada de la inteligencia de su negocio, incluyendo clientes, proyectos, tickets y alertas." />
            </Helmet>
            <div className="p-4 sm:p-6 lg:p-8 space-y-8">
                <div className="text-center">
                    <h1 className="text-4xl font-extrabold text-gray-900 mb-2">
                        ¡Bienvenido, {userProfile?.full_name || user?.email || 'Usuario'}!
                    </h1>
                    <p className="text-lg text-muted-foreground">
                        Una vista consolidada de la inteligencia de su negocio.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <motion.div
                        variants={cardVariants}
                        initial="hidden"
                        animate="visible"
                        transition={{ delay: 0.1 }}
                    >
                        <Card className="h-full bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg">
                            <CardHeader className="flex flex-row items-center justify-between pb-2">
                                <CardTitle className="text-sm font-medium">Total Clientes</CardTitle>
                                <Users className="h-5 w-5 text-blue-200" />
                            </CardHeader>
                            <CardContent>
                                {isDashboardLoading ? (
                                    <Skeleton className="h-8 w-1/2 bg-blue-300" />
                                ) : isDashboardError ? (
                                    <span className="text-red-200">Error</span>
                                ) : (
                                    <div className="text-3xl font-bold">{dashboardData?.totalClients}</div>
                                )}
                                <p className="text-xs text-blue-100 mt-1">Clientes registrados</p>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        variants={cardVariants}
                        initial="hidden"
                        animate="visible"
                        transition={{ delay: 0.2 }}
                    >
                        <Card className="h-full bg-gradient-to-br from-green-500 to-green-600 text-white shadow-lg">
                            <CardHeader className="flex flex-row items-center justify-between pb-2">
                                <CardTitle className="text-sm font-medium">Proyectos Activos</CardTitle>
                                <Briefcase className="h-5 w-5 text-green-200" />
                            </CardHeader>
                            <CardContent>
                                {isDashboardLoading ? (
                                    <Skeleton className="h-8 w-1/2 bg-green-300" />
                                ) : isDashboardError ? (
                                    <span className="text-red-200">Error</span>
                                ) : (
                                    <div className="text-3xl font-bold">{dashboardData?.totalProjects}</div>
                                )}
                                <p className="text-xs text-green-100 mt-1">Proyectos en curso</p>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        variants={cardVariants}
                        initial="hidden"
                        animate="visible"
                        transition={{ delay: 0.3 }}
                    >
                        <Card className="h-full bg-gradient-to-br from-yellow-500 to-yellow-600 text-white shadow-lg">
                            <CardHeader className="flex flex-row items-center justify-between pb-2">
                                <CardTitle className="text-sm font-medium">Tickets Abiertos</CardTitle>
                                <Ticket className="h-5 w-5 text-yellow-200" />
                            </CardHeader>
                            <CardContent>
                                {isDashboardLoading ? (
                                    <Skeleton className="h-8 w-1/2 bg-yellow-300" />
                                ) : isDashboardError ? (
                                    <span className="text-red-200">Error</span>
                                ) : (
                                    <div className="text-3xl font-bold">{dashboardData?.openTickets}</div>
                                )}
                                <p className="text-xs text-yellow-100 mt-1">Tickets pendientes</p>
                            </CardContent>
                        </Card>
                    </motion.div>

                    <motion.div
                        variants={cardVariants}
                        initial="hidden"
                        animate="visible"
                        transition={{ delay: 0.4 }}
                    >
                        <Card className="h-full bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-lg">
                            <CardHeader className="flex flex-row items-center justify-between pb-2">
                                <CardTitle className="text-sm font-medium">Ingresos (Aceptados)</CardTitle>
                                <DollarSign className="h-5 w-5 text-purple-200" />
                            </CardHeader>
                            <CardContent>
                                {isDashboardLoading ? (
                                    <Skeleton className="h-8 w-1/2 bg-purple-300" />
                                ) : isDashboardError ? (
                                    <span className="text-red-200">Error</span>
                                ) : (
                                    <div className="text-3xl font-bold">
                                        ${(dashboardData?.totalRevenue || 0).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                    </div>
                                )}
                                <p className="text-xs text-purple-100 mt-1">De presupuestos aceptados</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <motion.div
                        className="lg:col-span-1 bg-white p-6 rounded-lg shadow-md"
                        variants={cardVariants}
                        initial="hidden"
                        animate="visible"
                        transition={{ delay: 0.5 }}
                    >
                        <h2 className="text-xl font-semibold mb-4 text-gray-800">Historial de Alertas (Últimos 30 días)</h2>
                        <AlertHistoryChart />
                    </motion.div>
                    <motion.div
                        className="lg:col-span-1"
                        variants={cardVariants}
                        initial="hidden"
                        animate="visible"
                        transition={{ delay: 0.6 }}
                    >
                        <ResolvedAlertsWidget />
                    </motion.div>
                </div>
                
                <motion.div
                    className="bg-white p-6 rounded-lg shadow-md"
                    variants={cardVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ delay: 0.7 }}
                >
                    <h2 className="text-xl font-semibold mb-4 text-gray-800">Alertas Críticas Activas</h2>
                    <CriticalAlerts />
                </motion.div>
            </div>
        </>
    );
};

export default GeneralDashboardPage;