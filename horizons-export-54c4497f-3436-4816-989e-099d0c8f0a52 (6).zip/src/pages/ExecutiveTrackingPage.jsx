import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { BarChart3, Filter, Loader2, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const fetchTrackingData = async () => {
    const { data: usersData, error: usersError } = await supabase.functions.invoke('get-users');
    if (usersError) throw new Error(`Error fetching users: ${usersError.message}`);
    const users = usersData;

    const [
        { data: alerts, error: alertsError },
        { data: activities, error: activitiesError },
        { data: clients, error: clientsError }
    ] = await Promise.all([
        supabase.from('alerts').select('*, client:client_id(name)').eq('is_resolved', false),
        supabase.from('activities').select('*, client:client_id(name)').eq('is_completed', false),
        supabase.from('clients').select('id, name')
    ]);

    if (alertsError) throw new Error(`Error fetching alerts: ${alertsError.message}`);
    if (activitiesError) throw new Error(`Error fetching activities: ${activitiesError.message}`);
    if (clientsError) throw new Error(`Error fetching clients: ${clientsError.message}`);
    
    const alertsWithUser = alerts.map(alert => {
        const assignedUser = users.find(u => u.id === alert.assigned_to);
        return { ...alert, assigned: { email: assignedUser?.email || 'N/A' }};
    });

    const activitiesWithUser = activities.map(activity => {
        const assignedUser = users.find(u => u.id === activity.user_id);
        return { ...activity, assigned: { email: assignedUser?.email || 'N/A' }};
    });

    return { alerts: alertsWithUser, activities: activitiesWithUser, users, clients };
};

const ExecutiveTrackingPage = () => {
    const { data, isLoading, isError, error } = useQuery({
        queryKey: ['executiveTrackingData'],
        queryFn: fetchTrackingData
    });

    const [filters, setFilters] = useState({
        alertStatus: 'all',
        alertUser: 'all',
        alertClient: 'all',
        taskStatus: 'all',
        taskUser: 'all',
        taskClient: 'all',
    });

    const handleFilterChange = (filterName, value) => {
        setFilters(prev => ({ ...prev, [filterName]: value }));
    };

    const filteredAlerts = useMemo(() => {
        if (!data?.alerts) return [];
        return data.alerts.filter(alert => {
            const userMatch = filters.alertUser === 'all' || alert.assigned_to === filters.alertUser;
            const clientMatch = filters.alertClient === 'all' || alert.client_id === filters.alertClient;
            return userMatch && clientMatch;
        });
    }, [data?.alerts, filters.alertUser, filters.alertClient]);

    const filteredActivities = useMemo(() => {
        if (!data?.activities) return [];
        return data.activities.filter(activity => {
            const userMatch = filters.taskUser === 'all' || activity.user_id === filters.taskUser;
            const clientMatch = filters.taskClient === 'all' || activity.client_id === filters.taskClient;
            const now = new Date();
            const dueDate = new Date(activity.due_date);
            const statusMatch = filters.taskStatus === 'all' || (filters.taskStatus === 'overdue' && dueDate < now) || (filters.taskStatus === 'upcoming' && dueDate >= now);
            return userMatch && clientMatch && statusMatch;
        });
    }, [data?.activities, filters.taskUser, filters.taskClient, filters.taskStatus]);

    if (isLoading) {
        return <div className="flex items-center justify-center h-screen"><Loader2 className="h-8 w-8 animate-spin" /> <span className="ml-2">Cargando datos...</span></div>;
    }

    if (isError) {
        return <div className="flex flex-col items-center justify-center h-screen text-red-600"><AlertTriangle className="h-12 w-12 mb-4" /> <h2 className="text-xl font-semibold">Error al cargar los datos</h2><p>{error.message}</p></div>;
    }

    return (
        <>
            <Helmet>
                <title>Seguimiento Ejecutivo - AGROinvest</title>
                <meta name="description" content="Panel de control para el seguimiento de alertas y tareas pendientes en la organización." />
            </Helmet>
            <div className="p-4 sm:p-6 lg:p-8 space-y-6">
                <header className="flex items-center gap-4">
                    <BarChart3 className="h-8 w-8 text-indigo-600" />
                    <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Seguimiento Ejecutivo</h1>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Alertas Activas</CardTitle>
                            <div className="flex flex-col sm:flex-row gap-2 pt-2">
                                <Select value={filters.alertUser} onValueChange={v => handleFilterChange('alertUser', v)}>
                                    <SelectTrigger><SelectValue placeholder="Filtrar por usuario" /></SelectTrigger>
                                    <SelectContent><SelectItem value="all">Todos los Usuarios</SelectItem>{data.users.map(u => <SelectItem key={u.id} value={u.id}>{u.email}</SelectItem>)}</SelectContent>
                                </Select>
                                <Select value={filters.alertClient} onValueChange={v => handleFilterChange('alertClient', v)}>
                                    <SelectTrigger><SelectValue placeholder="Filtrar por cliente" /></SelectTrigger>
                                    <SelectContent><SelectItem value="all">Todos los Clientes</SelectItem>{data.clients.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                                </Select>
                            </div>
                        </CardHeader>
                        <CardContent>
                             <Table>
                                <TableHeader><TableRow><TableHead>Descripción</TableHead><TableHead>Cliente</TableHead><TableHead>Asignado a</TableHead><TableHead>Severidad</TableHead></TableRow></TableHeader>
                                <TableBody>
                                    {filteredAlerts.length > 0 ? filteredAlerts.map(alert => (
                                        <TableRow key={alert.id}>
                                            <TableCell>{alert.description}</TableCell>
                                            <TableCell>{alert.client?.name || 'N/A'}</TableCell>
                                            <TableCell>{alert.assigned?.email || 'Sin asignar'}</TableCell>
                                            <TableCell><Badge variant={alert.severity === 'critical' ? 'destructive' : 'secondary'}>{alert.severity}</Badge></TableCell>
                                        </TableRow>
                                    )) : (
                                        <TableRow><TableCell colSpan="4" className="text-center">No hay alertas activas.</TableCell></TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Tareas Pendientes</CardTitle>
                            <div className="flex flex-col sm:flex-row gap-2 pt-2">
                                <Select value={filters.taskStatus} onValueChange={v => handleFilterChange('taskStatus', v)}>
                                    <SelectTrigger><SelectValue placeholder="Filtrar por estado" /></SelectTrigger>
                                    <SelectContent><SelectItem value="all">Todos</SelectItem><SelectItem value="overdue">Vencidas</SelectItem><SelectItem value="upcoming">Próximas</SelectItem></SelectContent>
                                </Select>
                                <Select value={filters.taskUser} onValueChange={v => handleFilterChange('taskUser', v)}>
                                    <SelectTrigger><SelectValue placeholder="Filtrar por usuario" /></SelectTrigger>
                                    <SelectContent><SelectItem value="all">Todos los Usuarios</SelectItem>{data.users.map(u => <SelectItem key={u.id} value={u.id}>{u.email}</SelectItem>)}</SelectContent>
                                </Select>
                                <Select value={filters.taskClient} onValueChange={v => handleFilterChange('taskClient', v)}>
                                    <SelectTrigger><SelectValue placeholder="Filtrar por cliente" /></SelectTrigger>
                                    <SelectContent><SelectItem value="all">Todos los Clientes</SelectItem>{data.clients.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                                </Select>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader><TableRow><TableHead>Tarea</TableHead><TableHead>Cliente</TableHead><TableHead>Responsable</TableHead><TableHead>Vencimiento</TableHead></TableRow></TableHeader>
                                <TableBody>
                                    {filteredActivities.length > 0 ? filteredActivities.map(activity => (
                                        <TableRow key={activity.id}>
                                            <TableCell>{activity.notes}</TableCell>
                                            <TableCell>{activity.client?.name || 'N/A'}</TableCell>
                                            <TableCell>{activity.assigned?.email || 'Sin asignar'}</TableCell>
                                            <TableCell className={new Date(activity.due_date) < new Date() ? 'text-red-600' : ''}>
                                                {format(new Date(activity.due_date), 'dd/MM/yyyy HH:mm', { locale: es })}
                                            </TableCell>
                                        </TableRow>
                                    )) : (
                                        <TableRow><TableCell colSpan="4" className="text-center">No hay tareas pendientes.</TableCell></TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </>
    );
};

export default ExecutiveTrackingPage;