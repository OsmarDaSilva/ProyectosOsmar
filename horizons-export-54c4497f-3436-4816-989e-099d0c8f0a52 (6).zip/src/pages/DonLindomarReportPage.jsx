import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { Bot, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatNumber } from '@/lib/utils';

const DonLindomarReportPage = () => {
  const { t } = useTranslation(['assistant', 'common']);
  const { user } = useAuth();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    const { data: reportData, error: reportError } = await supabase
      .from('forage_profiles_compat_v')
      .select('país, región, pasture_type, método, enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre, diciembre')
      .order('país')
      .order('región')
      .order('pasture_type');

    if (reportError) {
      setError(reportError);
    } else {
      setData(reportData);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

  const renderContent = () => {
    if (loading) {
      return (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
        </div>
      );
    }

    if (error) {
      return (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t('common:error')}</AlertTitle>
          <AlertDescription>
            {t('common:error_loading_data')}: {error.message}
            <Button variant="ghost" size="sm" onClick={fetchData} className="ml-2">
              <RefreshCw className="mr-2 h-4 w-4" />
              {t('common:retry')}
            </Button>
          </AlertDescription>
        </Alert>
      );
    }

    if (data.length === 0) {
      return (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t('noDataTitle')}</AlertTitle>
          <AlertDescription>{t('noDataDescription')}</AlertDescription>
        </Alert>
      );
    }

    return (
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="sticky left-0 bg-background z-10">País</TableHead>
              <TableHead className="sticky left-[100px] bg-background z-10">Región</TableHead>
              <TableHead className="sticky left-[200px] bg-background z-10">Pastura</TableHead>
              <TableHead>Método</TableHead>
              {months.map(month => (
                <TableHead key={month} className="text-right capitalize">{t(`common:months_short.${month}`)}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((row, index) => (
              <TableRow key={row.id || index}>
                <TableCell className="font-medium sticky left-0 bg-background z-10">{row['país'] || 'N/A'}</TableCell>
                <TableCell className="sticky left-[100px] bg-background z-10">{row['región'] || 'N/A'}</TableCell>
                <TableCell className="sticky left-[200px] bg-background z-10">{row.pasture_type || 'N/A'}</TableCell>
                <TableCell>{row['método'] || 'N/A'}</TableCell>
                {months.map(month => (
                  <TableCell key={month} className="text-right">{formatNumber(row[month], 3)}</TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  };

  return (
    <>
      <Helmet>
        <title>{t('donLindomarReport.title')} - AGROinvest</title>
        <meta name="description" content={t('donLindomarReport.description')} />
      </Helmet>
      <div className="container mx-auto p-4 sm:p-6 lg:p-8">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Bot className="h-8 w-8 text-primary" />
              <div>
                <CardTitle className="text-2xl">{t('donLindomarReport.title')}</CardTitle>
                <CardDescription>{t('donLindomarReport.description')}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {renderContent()}
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default DonLindomarReportPage;