import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet-async';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, BookOpen, Trash2, Edit, Search, ArrowLeft, FileText, Image as ImageIcon, Video, Download } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoadingScreen from '@/components/LoadingScreen';
import AddEditArticleDialog from '@/components/kb/AddEditArticleDialog';

const getFileIcon = (fileType) => {
  if (!fileType) return <BookOpen className="h-8 w-8 text-gray-400" />;
  if (fileType.startsWith('image/')) return <ImageIcon className="h-8 w-8 text-blue-500" />;
  if (fileType.startsWith('video/')) return <Video className="h-8 w-8 text-purple-500" />;
  if (fileType.includes('pdf')) return <FileText className="h-8 w-8 text-red-500" />;
  return <FileText className="h-8 w-8 text-gray-500" />;
};

const KnowledgeBasePage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingArticle, setEditingArticle] = useState(null);

  const fetchArticles = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('knowledge_base')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      if (error.code === '42P01') {
        console.warn("Knowledge base table not found. It might be created shortly.");
        setArticles([]);
      } else {
        toast({ variant: 'destructive', title: 'Error al cargar artículos', description: error.message });
      }
    } else {
      setArticles(data);
    }
    setLoading(false);
  }, [toast, user]);

  useEffect(() => {
    fetchArticles();
  }, [fetchArticles]);

  const handleSaveArticle = async (articleData) => {
    if (!articleData?.title) {
      toast({ variant: 'destructive', title: 'Campo requerido', description: 'El título es obligatorio.' });
      return null;
    }
    
    const articleToSave = {
      ...articleData,
      user_id: user.id,
      updated_at: new Date().toISOString(),
    };

    if (!articleToSave.id) {
        delete articleToSave.id;
    }

    try {
      const { data, error } = await supabase
        .from('knowledge_base')
        .upsert(articleToSave, { onConflict: 'id' })
        .select()
        .single();

      if (error) throw error;
      
      fetchArticles();
      return data;
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al guardar', description: error.message });
      return null;
    }
  };

  const handleDeleteArticle = async (articleId) => {
    const articleToDelete = articles.find(a => a.id === articleId);
    if (articleToDelete?.file_url) {
        const filePath = new URL(articleToDelete.file_url).pathname.split('/knowledge_base_files/')[1];
        await supabase.storage.from('knowledge_base_files').remove([filePath]);
    }

    const { error } = await supabase.from('knowledge_base').delete().eq('id', articleId);
    if (error) {
      toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
    } else {
      toast({ title: 'Artículo eliminado' });
      fetchArticles();
    }
  };

  const handleAddNew = () => {
    setEditingArticle(null);
    setIsDialogOpen(true);
  };

  const handleEdit = (article) => {
    setEditingArticle(article);
    setIsDialogOpen(true);
  };

  const filteredArticles = articles.filter(article =>
    article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (article.content && article.content.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (article.tags && Array.isArray(article.tags) && article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())))
  );

  if (loading) return <LoadingScreen message="Cargando base de conocimiento..." />;

  return (
    <>
      <Helmet><title>Base de Conocimiento - AGROinvest</title></Helmet>
      <div className="p-4 sm:p-6 lg:p-8">
        <header className="flex flex-wrap justify-between items-center gap-4 mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <BookOpen className="h-8 w-8 text-green-600" />
              Base de Conocimiento
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Buscar artículos o archivos..."
                className="pl-10"
              />
            </div>
            <Button onClick={handleAddNew}>
              <Plus className="mr-2 h-4 w-4" /> Nuevo
            </Button>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredArticles.map(article => (
            <Card key={article.id} className="flex flex-col">
              <CardHeader className="flex-row items-start gap-4">
                {getFileIcon(article.file_type)}
                <div>
                  <CardTitle className="text-base">{article.title}</CardTitle>
                  {article.tags && article.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {article.tags.map(tag => <span key={tag} className="text-xs bg-gray-200 text-gray-700 px-2 py-0.5 rounded-full">{tag}</span>)}
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-gray-600">{article.content || article.file_name}</p>
              </CardContent>
              <CardFooter className="p-2 border-t flex justify-end gap-1">
                {article.file_url && (
                  <Button asChild variant="ghost" size="sm">
                    <a href={article.file_url} target="_blank" rel="noopener noreferrer" download={article.file_name}>
                      <Download className="h-4 w-4" />
                    </a>
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => handleEdit(article)}>
                  <Edit className="h-4 w-4" />
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>¿Está seguro?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta acción no se puede deshacer. Esto eliminará permanentemente el artículo y su archivo asociado.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDeleteArticle(article.id)}>Eliminar</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardFooter>
            </Card>
          ))}
        </div>
        {filteredArticles.length === 0 && (
          <div className="text-center py-16 text-gray-500">
            <p>No se encontraron artículos. ¡Cree el primero!</p>
          </div>
        )}
      </div>

      <AddEditArticleDialog
        isOpen={isDialogOpen}
        setIsOpen={setIsDialogOpen}
        onSave={handleSaveArticle}
        article={editingArticle}
      />
    </>
  );
};

export default KnowledgeBasePage;