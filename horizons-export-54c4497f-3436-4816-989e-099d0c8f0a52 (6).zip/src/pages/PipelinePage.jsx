import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { DndContext, closestCenter, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
    import { SortableContext, useSortable } from '@dnd-kit/sortable';
    import { CSS } from '@dnd-kit/utilities';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
    import { Plus, ArrowLeft, DollarSign, Calendar, User, Star, LayoutGrid, List, Search, Building } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';
    import LoadingScreen from '@/components/LoadingScreen';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import AddEditDealDialog from '@/components/pipeline/AddEditDealDialog';
    import { Switch } from "@/components/ui/switch";
    import { Label } from "@/components/ui/label";
    import { Input } from "@/components/ui/input";
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
    import { Badge } from '@/components/ui/badge';

    const formatCurrency = (value) => {
        return new Intl.NumberFormat('es-PY', { style: 'currency', currency: 'USD' }).format(value || 0);
    };

    const StarRating = ({ score }) => (
        <div className="flex">
            {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className={`h-4 w-4 ${score >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
            ))}
        </div>
    );

    const DealCard = ({ deal, onEdit }) => {
      const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: deal.id });

      const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        zIndex: isDragging ? 10 : 'auto',
        opacity: isDragging ? 0.7 : 1,
      };

      return (
        <Card ref={setNodeRef} style={style} {...attributes} {...listeners} className="mb-4 bg-white shadow-sm touch-none cursor-grab" onClick={() => onEdit(deal)}>
          <CardHeader className="p-4 flex flex-row justify-between items-start">
            <CardTitle className="text-base font-semibold text-gray-800 pr-2">{deal.title}</CardTitle>
            <StarRating score={deal.score} />
          </CardHeader>
          <CardContent className="px-4 pb-2 text-sm text-gray-600 space-y-2">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-gray-400" />
              <span>{formatCurrency(deal.value)}</span>
            </div>
            {deal.clients && (
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-gray-400" />
                <span>{deal.clients.name}</span>
              </div>
            )}
          </CardContent>
          <CardFooter className="p-4 pt-2">
            {deal.expected_close_date && (
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Calendar className="h-3 w-3" />
                <span>Cierre: {new Date(deal.expected_close_date).toLocaleDateString()}</span>
              </div>
            )}
          </CardFooter>
        </Card>
      );
    };

    const PipelineColumn = ({ title, deals, id, onEditDeal }) => {
      const { setNodeRef } = useSortable({ id });

      return (
        <div ref={setNodeRef} className="flex-shrink-0 w-80 bg-gray-100 rounded-lg shadow-inner">
          <h3 className="p-4 text-lg font-semibold text-gray-700 tracking-wide sticky top-0 bg-gray-100 z-10">{title} ({deals.length})</h3>
          <div className="p-2 space-y-4 h-[calc(100vh-280px)] overflow-y-auto">
            <SortableContext items={deals.map(d => d.id)}>
              {deals.map(deal => (
                <DealCard key={deal.id} deal={deal} onEdit={onEditDeal}/>
              ))}
            </SortableContext>
          </div>
        </div>
      );
    };
    
    const ListView = ({ deals, onEditDeal, searchTerm }) => {
        const groupedDeals = useMemo(() => {
            const lowercasedFilter = searchTerm.toLowerCase();

            const filtered = deals.filter(deal => 
                deal.title.toLowerCase().includes(lowercasedFilter) ||
                (deal.clients?.name || 'Sin Cliente').toLowerCase().includes(lowercasedFilter)
            );

            const grouped = filtered.reduce((acc, deal) => {
                const clientName = deal.clients?.name || 'Sin Cliente Asignado';
                const clientId = deal.client_id || 'unassigned';
                if (!acc[clientId]) {
                    acc[clientId] = {
                        clientName,
                        deals: []
                    };
                }
                acc[clientId].deals.push(deal);
                return acc;
            }, {});
            return Object.entries(grouped).sort(([aKey, aVal], [bKey, bVal]) => aVal.clientName.localeCompare(bVal.clientName));
        }, [deals, searchTerm]);

        return (
            <Accordion type="multiple" className="w-full space-y-2">
                {groupedDeals.map(([clientId, group]) => (
                    <AccordionItem value={clientId} key={clientId}>
                        <AccordionTrigger className="bg-gray-100 hover:bg-gray-200 px-4 py-3 rounded-lg text-lg font-semibold border">
                           <div className="flex items-center gap-3">
                                <Building className="h-5 w-5 text-gray-600" />
                                {group.clientName}
                                <span className="text-sm font-normal text-gray-500">({group.deals.length} oportunidad/es)</span>
                            </div>
                        </AccordionTrigger>
                        <AccordionContent className="p-4 space-y-3">
                            {group.deals.map(deal => (
                                <Card key={deal.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => onEditDeal(deal)}>
                                    <CardContent className="p-4 flex justify-between items-center">
                                        <div>
                                            <p className="font-semibold text-base">{deal.title}</p>
                                            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                                                <span className="flex items-center gap-1"><DollarSign className="h-4 w-4"/> {formatCurrency(deal.value)}</span>
                                                <span className="flex items-center gap-1"><Calendar className="h-4 w-4"/> {deal.expected_close_date ? new Date(deal.expected_close_date).toLocaleDateString() : 'N/A'}</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <StarRating score={deal.score} />
                                            <Badge>{deal.stage}</Badge>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </AccordionContent>
                    </AccordionItem>
                ))}
            </Accordion>
        );
    };

    const PipelinePage = () => {
      const navigate = useNavigate();
      const { toast } = useToast();
      const { user } = useAuth();
      const [deals, setDeals] = useState([]);
      const [clients, setClients] = useState([]);
      const [loading, setLoading] = useState(true);
      const [isDealDialogOpen, setIsDealDialogOpen] = useState(false);
      const [editingDeal, setEditingDeal] = useState(null);
      const [viewMode, setViewMode] = useState('kanban'); // 'kanban' or 'list'
      const [searchTerm, setSearchTerm] = useState('');

      const STAGES = ['Lead', 'Contactado', 'Propuesta', 'Negociación', 'Ganado', 'Perdido'];

      const fetchData = useCallback(async () => {
        setLoading(true);
        const { data: dealsData, error: dealsError } = await supabase
          .from('deals')
          .select('*, clients(id, name)');
        
        if (dealsError) {
          toast({ variant: 'destructive', title: 'Error al cargar oportunidades', description: dealsError.message });
        } else {
          setDeals(dealsData);
        }
        
        const { data: clientsData, error: clientsError } = await supabase.from('clients').select('id, name');
        if (clientsError) {
            toast({ variant: 'destructive', title: 'Error al cargar clientes', description: clientsError.message });
        } else {
            setClients(clientsData || []);
        }

        setLoading(false);
      }, [toast]);

      useEffect(() => {
        fetchData();
      }, [fetchData]);

      const handleDragEnd = async (event) => {
        const { active, over } = event;

        if (!active || !over) return;
        
        const activeDeal = deals.find(d => d.id === active.id);
        const newStage = over.id;

        if (activeDeal && activeDeal.stage !== newStage) {
          const originalDeals = [...deals];
          const updatedDeals = deals.map(d => d.id === active.id ? { ...d, stage: newStage } : d);
          setDeals(updatedDeals);

          const { error } = await supabase
            .from('deals')
            .update({ stage: newStage, updated_at: new Date().toISOString() })
            .eq('id', active.id);
          
          if (error) {
            toast({ variant: 'destructive', title: 'Error al mover oportunidad', description: error.message });
            setDeals(originalDeals);
          } else {
            toast({ title: 'Oportunidad actualizada', description: `Movida a la etapa "${newStage}".` });
          }
        }
      };

      const handleSaveDeal = async (dealData) => {
        const dataToUpsert = {
          ...dealData,
          user_id: user.id,
          updated_at: new Date().toISOString(),
        };

        if (!dataToUpsert.id) {
            dataToUpsert.created_at = new Date().toISOString();
        }

        const { error } = await supabase.from('deals').upsert(dataToUpsert).select().single();

        if (error) {
          toast({ variant: 'destructive', title: 'Error al guardar oportunidad', description: error.message });
          return false;
        } else {
          toast({ title: 'Oportunidad guardada' });
          setIsDealDialogOpen(false);
          setEditingDeal(null);
          fetchData();
          return true;
        }
      };
      
      const handleEditDeal = (deal) => {
        setEditingDeal(deal);
        setIsDealDialogOpen(true);
      }

      const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }));

      if (loading) {
        return <LoadingScreen message="Cargando pipeline..." />;
      }

      const dealsByStage = STAGES.reduce((acc, stage) => {
        acc[stage] = deals.filter(deal => deal.stage === stage);
        return acc;
      }, {});

      return (
        <>
          <Helmet>
            <title>Pipeline de Ventas - AGROinvest</title>
            <meta name="description" content="Gestione su embudo de ventas de forma visual e interactiva." />
          </Helmet>
          <div className="flex flex-col h-screen bg-gray-50">
            <header className="bg-white shadow-sm sticky top-0 z-20">
              <div className="max-w-full mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center gap-4">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="icon" onClick={() => navigate('/crm-dashboard')}>
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <h1 className="text-2xl font-bold text-gray-800">Pipeline de Ventas</h1>
                </div>
                 <div className="flex-1 max-w-lg">
                   {viewMode === 'list' && (
                     <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input
                            placeholder="Buscar por oportunidad o cliente..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                     </div>
                   )}
                 </div>
                <div className="flex items-center gap-4">
                    <div className="flex items-center space-x-2">
                        <LayoutGrid className={`h-5 w-5 ${viewMode === 'kanban' ? 'text-green-600' : 'text-gray-400'}`} />
                        <Switch
                            checked={viewMode === 'list'}
                            onCheckedChange={(checked) => setViewMode(checked ? 'list' : 'kanban')}
                            id="view-mode-switch"
                        />
                        <List className={`h-5 w-5 ${viewMode === 'list' ? 'text-green-600' : 'text-gray-400'}`} />
                    </div>
                    <Button onClick={() => { setEditingDeal(null); setIsDealDialogOpen(true); }}>
                        <Plus className="mr-2 h-4 w-4" />
                        Nueva Oportunidad
                    </Button>
                </div>
              </div>
            </header>

            <main className="flex-grow p-4 overflow-x-auto">
              {viewMode === 'kanban' ? (
                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                  <div className="flex gap-6 h-full">
                    <SortableContext items={STAGES}>
                      {STAGES.map(stage => (
                        <PipelineColumn key={stage} id={stage} title={stage} deals={dealsByStage[stage] || []} onEditDeal={handleEditDeal}/>
                      ))}
                    </SortableContext>
                  </div>
                </DndContext>
              ) : (
                <ListView deals={deals} onEditDeal={handleEditDeal} searchTerm={searchTerm} />
              )}
            </main>
          </div>
          <AddEditDealDialog
            isOpen={isDealDialogOpen}
            setIsOpen={setIsDealDialogOpen}
            deal={editingDeal}
            clients={clients}
            onSave={handleSaveDeal}
          />
        </>
      );
    };

    export default PipelinePage;