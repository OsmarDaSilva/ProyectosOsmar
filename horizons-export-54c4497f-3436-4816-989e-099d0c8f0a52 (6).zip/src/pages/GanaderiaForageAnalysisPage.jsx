import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart2, List } from 'lucide-react';
import LoadingScreen from '@/components/LoadingScreen';
import useGanaderiaForageAnalysis from '@/hooks/useGanaderiaForageAnalysis';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ResponsiveContainer, ComposedChart, Bar, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ReferenceLine } from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

const MonthlyDetailTable = ({ data, pastureOptions, selectedPastureId, onPastureChange }) => {
    const { t } = useTranslation(['forageBalance', 'forageDatabase']);
    const formatNumber = (value, decimals = 2) => {
        const num = Number(value);
        if (isNaN(num)) return '0,00';
        return new Intl.NumberFormat('es-ES', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(num);
    };

    return (
        <div className="space-y-4">
             <div className="flex items-center gap-4">
                <Label htmlFor="pasture-selector" className="text-sm font-medium">{t('forageDatabase:table.pastureType')}:</Label>
                <Select
                    value={selectedPastureId || (pastureOptions[0]?.id || '')}
                    onValueChange={onPastureChange}
                >
                    <SelectTrigger id="pasture-selector" className="w-[350px]">
                        <SelectValue placeholder={t('forageDatabase:table.selectPasture', 'Seleccione una pastura')} />
                    </SelectTrigger>
                    <SelectContent>
                        {pastureOptions.map(option => (
                            <SelectItem key={option.id} value={option.id}>
                                {option.label}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>{t('forageBalance:month')}</TableHead>
                        <TableHead className="text-right">{t('forageBalance:animalWeight')}</TableHead>
                        <TableHead className="text-right">{t('forageBalance:forageSupply')}</TableHead>
                        <TableHead className="text-right">{t('forageBalance:herdDemand')}</TableHead>
                        <TableHead className="text-right">{t('forageBalance:balanceTon')}</TableHead>
                        <TableHead className="text-right">{t('forageBalance:balanceKgPerAnimal')}</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {data.map((row, index) => (
                        <TableRow key={index}>
                            <TableCell>{row.month}</TableCell>
                            <TableCell className="text-right">{formatNumber(row.pesoAnimal, 1)}</TableCell>
                            <TableCell className="text-right">{formatNumber(row.oferta, 2)}</TableCell>
                            <TableCell className="text-right">{formatNumber(row.demanda, 2)}</TableCell>
                            <TableCell className={`text-right font-semibold ${row.balance < 0 ? 'text-red-600' : 'text-green-600'}`}>
                                {formatNumber(row.balance, 2)}
                            </TableCell>
                            <TableCell className={`text-right font-semibold ${row.balancePct < 0 ? 'text-red-600' : 'text-green-600'}`}>
                                {formatNumber(row.balancePct * 100, 1)}%
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
};

const CustomTooltip = ({ active, payload, label }) => {
    const { t } = useTranslation(['forageBalance']);
     const formatNumber = (value, decimals = 2) => {
        const num = Number(value);
        if (isNaN(num)) return '0,00';
        return new Intl.NumberFormat('es-ES', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(num);
    };

    if (active && payload && payload.length) {
        return (
            <div className="p-2 bg-background/80 backdrop-blur-sm rounded-lg border shadow-lg">
                <p className="font-bold text-foreground">{label}</p>
                {payload.map((pld, index) => {
                    const unit = pld.dataKey === 'balancePct' ? '%' : 'ton MS';
                     const value = pld.dataKey === 'balancePct' ? pld.value * 100 : pld.value;
                    return (
                        <p key={index} style={{ color: pld.stroke || pld.fill }}>
                            {`${pld.name}: ${formatNumber(value, 2)} ${unit}`}
                        </p>
                    )
                })}
            </div>
        );
    }
    return null;
};


const AnnualChart = ({ data }) => {
    const { t } = useTranslation(['forageBalance', 'common']);
    const monthNames = useMemo(() => Object.values(t('common:months', { returnObjects: true })).slice(0, 12), [t]);

    const chartData = useMemo(() => {
        const lowerCaseMonthNames = monthNames.map(m => m.toLowerCase());
        return data.map(d => ({ ...d, month: monthNames[lowerCaseMonthNames.indexOf(d.month.toLowerCase())] || d.month }));
    }, [data, monthNames]);
    
    return (
        <ResponsiveContainer width="100%" height={400}>
            <ComposedChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis yAxisId="left" orientation="left" stroke="#4b5563" label={{ value: 'ton MS', angle: -90, position: 'insideLeft' }} />
                <YAxis yAxisId="right" orientation="right" stroke="#f97316" label={{ value: '%', angle: 90, position: 'insideRight' }} tickFormatter={(value) => `${value}%`} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <ReferenceLine y={0} yAxisId="left" stroke="#000" />
                <Bar yAxisId="left" dataKey="oferta" name={t('forageBalance:forageSupply')} fill="#16a34a" />
                <Bar yAxisId="left" dataKey="demanda" name={t('forageBalance:herdDemand')} fill="#dc2626" />
                <Line yAxisId="left" type="monotone" dataKey="balance" name={t('forageBalance:balanceTon')} stroke="#0ea5e9" strokeWidth={3} dot={{r: 4}} />
                <Line yAxisId="right" type="monotone" dataKey={(v) => v.balancePct * 100} name={t('forageBalance:balanceKgPerAnimal')} stroke="#f97316" strokeWidth={2} strokeDasharray="5 5" dot={false} />
            </ComposedChart>
        </ResponsiveContainer>
    );
};

const GanaderiaForageAnalysisPage = ({ ganaderiaData, fullForageData, isDataLoaded }) => {
    const { t } = useTranslation(['forageBalance', 'forageDatabase', 'common']);
    const { results, isLoading, pastureOptions, selectedPastureId, setSelectedPastureId } = useGanaderiaForageAnalysis({ ganaderiaData, fullForageData });

    if (isLoading || !isDataLoaded) {
        return <LoadingScreen message={t('common:loading.analysis')} />;
    }

    if (!results || !results.balanceData || results.balanceData.length === 0) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>{t('forageBalance:title')}</CardTitle>
                </CardHeader>
                <CardContent>
                    <p>{t('common:noData')}</p>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>{t('forageBalance:title')}</CardTitle>
                <CardDescription>{t('forageBalance:description')}</CardDescription>
            </CardHeader>
            <CardContent>
                <Tabs defaultValue="monthly-detail">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="monthly-detail">
                            <List className="mr-2 h-4 w-4" />
                            {t('forageBalance:monthlyDetail')}
                        </TabsTrigger>
                        <TabsTrigger value="annual-chart">
                            <BarChart2 className="mr-2 h-4 w-4" />
                            {t('forageBalance:annualChart')}
                        </TabsTrigger>
                    </TabsList>
                    <TabsContent value="monthly-detail" className="mt-4">
                        <MonthlyDetailTable 
                            data={results.balanceData} 
                            pastureOptions={pastureOptions}
                            selectedPastureId={selectedPastureId}
                            onPastureChange={setSelectedPastureId}
                        />
                    </TabsContent>
                    <TabsContent value="annual-chart" className="mt-4">
                        <Card>
                            <CardHeader>
                                <CardTitle>{t('forageBalance:annualChart')}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <AnnualChart data={results.balanceData} />
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
};

export default GanaderiaForageAnalysisPage;