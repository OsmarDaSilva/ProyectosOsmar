import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FolderOpen, Trash2, Plus, Loader2, Users, History, User, ShieldCheck, Search, Building } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';

const fetchUserProjects = async () => {
    const { data, error } = await supabase
        .from('client_projects')
        .select(`
            *, 
            clients(id, name, ruc_ci, created_by, is_confidential), 
            creator_profile:profiles!client_projects_created_by_fkey(full_name, user_id)
        `)
        .order('updated_at', { ascending: false });

    if (error) {
        console.error('Error fetching client projects:', error);
        throw new Error(`Error al cargar proyectos: ${error.message}`);
    }
    
    const userIdsToFetchEmail = [
        ...new Set(
            data
                .map((p) => p.creator_profile?.user_id || p.created_by)
                .filter(Boolean)
        ),
    ];

    if (userIdsToFetchEmail.length > 0) {
         const { data: usersData, error: usersError } = await supabase.rpc('get_users_by_id', {
            user_ids: userIdsToFetchEmail
         });

        if (usersError) {
            console.error("Error fetching user emails for projects:", usersError);
        } else {
             const emailMap = new Map(usersData.map(u => [u.id, u.email]));
             return data.map(p => ({
                 ...p,
                 creator_email: emailMap.get(p.created_by)
             }));
        }
    }

    return data;
};

const ProjectsLoader = () => (
    <div className="space-y-6">
        <div className="flex justify-between items-center">
            <div className="space-y-2">
                <Skeleton className="h-10 w-64" />
                <Skeleton className="h-4 w-80" />
            </div>
            <div className="flex gap-2">
                <Skeleton className="h-10 w-48" />
                <Skeleton className="h-10 w-40" />
            </div>
        </div>
         <Skeleton className="h-10 w-full" />
        <div className="space-y-4">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
        </div>
    </div>
);

const MyProjectsPage = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const { loadClientProject, resetProjectData, activeClientProject } = useProjectData();
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [projectToDelete, setProjectToDelete] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    const lastActiveProjectId = activeClientProject?.project?.id;

    const { data: projects, isLoading, isError, error, refetch } = useQuery({
        queryKey: ['userProjects'],
        queryFn: fetchUserProjects,
        enabled: !!user,
    });
    
    const groupedProjects = useMemo(() => {
        if (!projects) return {};
        const grouped = projects.reduce((acc, project) => {
            const client = project.clients;
            if (!client) return acc;
            
            if (!acc[client.id]) {
                acc[client.id] = {
                    clientInfo: client,
                    projects: []
                };
            }
            acc[client.id].projects.push(project);
            return acc;
        }, {});

        // Sort clients by name
        return Object.values(grouped).sort((a, b) => a.clientInfo.name.localeCompare(b.clientInfo.name));
    }, [projects]);
    
    const filteredGroupedProjects = useMemo(() => {
        if (!searchTerm) return groupedProjects;
        const lowercasedFilter = searchTerm.toLowerCase();
        
        return groupedProjects.map(group => {
            const filteredProjects = group.projects.filter(project => 
                project.project_name.toLowerCase().includes(lowercasedFilter)
            );
            if (group.clientInfo.name.toLowerCase().includes(lowercasedFilter) || filteredProjects.length > 0) {
                 return { ...group, projects: filteredProjects.length > 0 ? filteredProjects : group.projects };
            }
            return null;
        }).filter(Boolean);

    }, [searchTerm, groupedProjects]);

    const deleteMutation = useMutation({
        mutationFn: async (projectId) => {
            const { error } = await supabase.from('client_projects').delete().eq('id', projectId);
            if (error) throw error;
            return projectId;
        },
        onSuccess: (deletedProjectId) => {
            toast({ title: "Proyecto eliminado", description: "El proyecto ha sido eliminado exitosamente." });
            queryClient.invalidateQueries({queryKey: ['userProjects']});
            if(lastActiveProjectId === deletedProjectId) {
                resetProjectData();
            }
        },
        onError: (error) => {
            toast({ variant: "destructive", title: "Error al eliminar", description: error.message });
        },
        onSettled: () => {
            setProjectToDelete(null);
        },
    });

    const handleOpenProject = (project) => {
        loadClientProject({ ...project.clients }, project);
    };
    
    const handleNewProject = () => {
        navigate('/clients');
    };

    const handleResumeLastProject = () => {
        if (activeClientProject) {
            loadClientProject(activeClientProject.client, activeClientProject.project);
        }
    };
    
    const getCreatorDisplayName = (project) => {
        if (project.creator_profile?.full_name) {
            return project.creator_profile.full_name;
        }
        if (project.creator_email) {
            return project.creator_email;
        }
        return "Procesando...";
    }

    return (
        <>
            <Helmet>
                <title>Mis Proyectos - AGROinvest</title>
                <meta name="description" content="Gestione y analice todos sus proyectos agropecuarios." />
            </Helmet>
            <QueryStateWrapper
                isLoading={isLoading}
                isError={isError}
                error={error}
                data={projects}
                loader={<ProjectsLoader />}
                onRetry={refetch}
            >
                {(data) => (
                    <div className="space-y-6">
                        <motion.div
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="flex justify-between items-center flex-wrap gap-4"
                        >
                            <div>
                                <h1 className="text-4xl font-bold gradient-text">Mis Proyectos</h1>
                                <p className="text-gray-600">Gestione y analice todos sus proyectos agrupados por cliente.</p>
                            </div>
                            <div className="flex gap-2">
                                {activeClientProject && (
                                    <Button onClick={handleResumeLastProject} variant="outline">
                                        <History className="h-4 w-4 mr-2" />
                                        Reanudar Último Proyecto
                                    </Button>
                                )}
                                <Button onClick={handleNewProject}>
                                    <Plus className="h-4 w-4 mr-2" />
                                    Nuevo Proyecto
                                </Button>
                            </div>
                        </motion.div>
                         <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                            <Input
                                placeholder="Buscar por cliente o nombre de proyecto..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10"
                            />
                        </div>

                        {filteredGroupedProjects && filteredGroupedProjects.length === 0 ? (
                            <motion.div
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                            >
                                <Card className="glass-effect">
                                    <CardContent className="text-center py-12">
                                        <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                                        <h3 className="text-xl font-semibold text-gray-700 mb-2">
                                            {searchTerm ? 'No se encontraron proyectos' : 'No hay proyectos guardados'}
                                        </h3>
                                        <p className="text-gray-500 mb-6">
                                            {searchTerm ? 'Intente con otro término de búsqueda.' : 'Cree su primer proyecto desde la pestaña de Clientes.'}
                                        </p>
                                        {!searchTerm && 
                                            <Button onClick={handleNewProject}>
                                                <Plus className="h-4 w-4 mr-2" />
                                                Crear Primer Proyecto
                                            </Button>
                                        }
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ) : (
                           <Accordion type="multiple" className="w-full space-y-2">
                                {filteredGroupedProjects.map(({ clientInfo, projects }) => (
                                    <motion.div
                                        key={clientInfo.id}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ duration: 0.3 }}
                                    >
                                        <AccordionItem value={clientInfo.id} className="border-b-0">
                                            <AccordionTrigger className="bg-gray-100 hover:bg-gray-200 px-4 py-3 rounded-lg text-lg font-semibold border">
                                                <div className="flex items-center gap-3">
                                                    <Building className="h-5 w-5 text-gray-600" />
                                                    {clientInfo.name}
                                                    <span className="text-sm font-normal text-gray-500">({projects.length} proyecto/s)</span>
                                                </div>
                                            </AccordionTrigger>
                                            <AccordionContent className="p-4 space-y-4">
                                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                                    {projects.map((project) => (
                                                        <Card key={project.id} className={`hover:shadow-lg transition-shadow flex flex-col h-full ${lastActiveProjectId === project.id ? 'border-green-500 border-2' : ''}`}>
                                                            <CardHeader>
                                                                <CardTitle className="text-lg font-bold flex items-center gap-2">
                                                                    {project.is_confidential && <ShieldCheck className="h-5 w-5 text-yellow-500" title="Proyecto Confidencial"/>}
                                                                    {project.project_name}
                                                                </CardTitle>
                                                                <CardDescription>
                                                                    Actualizado: {new Date(project.updated_at || project.created_at).toLocaleDateString()}
                                                                </CardDescription>
                                                            </CardHeader>
                                                            <CardContent className="flex-grow flex flex-col justify-between">
                                                                <div>
                                                                    <div className="flex items-center text-xs text-gray-500 mb-4">
                                                                        <User className="h-3 w-3 mr-1" /> Creado por: {getCreatorDisplayName(project)}
                                                                    </div>
                                                                </div>
                                                                <div className="flex justify-between items-center mt-auto">
                                                                    <Button onClick={() => handleOpenProject(project)} className="bg-green-600 hover:bg-green-700">
                                                                        <FolderOpen className="h-4 w-4 mr-2" />
                                                                        Abrir
                                                                    </Button>
                                                                    <Button variant="ghost" size="icon" onClick={() => setProjectToDelete(project)}>
                                                                        <Trash2 className="h-4 w-4 text-red-500" />
                                                                    </Button>
                                                                </div>
                                                            </CardContent>
                                                        </Card>
                                                    ))}
                                                </div>
                                            </AccordionContent>
                                        </AccordionItem>
                                    </motion.div>
                                ))}
                            </Accordion>
                        )}
                    </div>
                )}
            </QueryStateWrapper>

            <AlertDialog open={!!projectToDelete} onOpenChange={(open) => !open && setProjectToDelete(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>¿Confirmar eliminación?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Esta acción eliminará permanentemente el proyecto "{projectToDelete?.project_name}". Esta acción no se puede deshacer.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={() => deleteMutation.mutate(projectToDelete.id)}
                            disabled={deleteMutation.isPending}
                            className="bg-red-600 hover:bg-red-700"
                        >
                            {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Eliminar
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
};

export default MyProjectsPage;