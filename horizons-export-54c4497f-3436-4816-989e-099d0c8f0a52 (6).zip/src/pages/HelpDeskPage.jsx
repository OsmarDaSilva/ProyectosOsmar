import React, { useState, useEffect, useCallback } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { useNavigate } from 'react-router-dom';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { ArrowLeft, Plus, LifeBuoy } from 'lucide-react';
    import LoadingScreen from '@/components/LoadingScreen';
    import { TicketsDataTable } from '@/components/help-desk/TicketsDataTable';
    import AddEditTicketDialog from '@/components/help-desk/AddEditTicketDialog.jsx';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";
    import { supabase } from '@/lib/supabase-helpers';

    const HelpDeskPage = () => {
      const navigate = useNavigate();
      const { user } = useAuth();
      const { toast } = useToast();
      
      const [tickets, setTickets] = useState([]);
      const [loading, setLoading] = useState(true);
      const [isAddEditTicketOpen, setIsAddEditTicketOpen] = useState(false);
      const [selectedTicket, setSelectedTicket] = useState(null);
      const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
      const [ticketToDelete, setTicketToDelete] = useState(null);


      const fetchData = useCallback(async () => {
        setLoading(true);
        try {
          const { data: ticketsData, error: ticketsError } = await supabase
            .from('tickets')
            .select(`
                *,
                client:clients(id, name),
                assigned_user:profiles!tickets_assigned_to_user_id_fkey(user_id, full_name),
                created_by_user:profiles!tickets_created_by_fkey(user_id, full_name)
            `)
            .order('created_at', { ascending: false });

          if (ticketsError) throw ticketsError;
      
          setTickets(ticketsData || []);

        } catch (error) {
          toast({ variant: 'destructive', title: 'Error al cargar datos', description: error.message });
        } finally {
          setLoading(false);
        }
      }, [toast]);

      useEffect(() => {
        fetchData();
      }, [fetchData]);

      const handleSave = () => {
        fetchData(); // Refetch data after saving
      };
      
      const handleEdit = (ticket) => {
        setSelectedTicket(ticket);
        setIsAddEditTicketOpen(true);
      };
    
      const handleDeleteRequest = (ticket) => {
        setTicketToDelete(ticket);
        setIsDeleteDialogOpen(true);
      };

      const handleDeleteConfirm = async () => {
        if (!ticketToDelete) return;
        const { error } = await supabase.from('tickets').delete().eq('id', ticketToDelete.id);
        if (error) {
            toast({ variant: 'destructive', title: 'Error al eliminar ticket', description: error.message });
        } else {
            toast({ title: 'Ticket eliminado' });
            fetchData();
        }
        setIsDeleteDialogOpen(false);
        setTicketToDelete(null);
      };

      if (loading) {
        return <LoadingScreen message="Cargando Mesa de Ayuda..." />;
      }

      return (
        <>
          <Helmet>
            <title>Mesa de Ayuda - AGROinvest</title>
            <meta name="description" content="Gestiona y haz seguimiento a los tickets de soporte al cliente de AGROinvest." />
          </Helmet>
          <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <header className="mb-6 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate(-1)}><ArrowLeft className="h-4 w-4" /></Button>
                <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                  <LifeBuoy className="text-red-500" /> Mesa de Ayuda
                </h1>
              </div>
              <Button onClick={() => { setSelectedTicket(null); setIsAddEditTicketOpen(true); }}>
                <Plus className="mr-2 h-4 w-4" /> Nuevo Ticket
              </Button>
            </header>

            <main>
              <Card>
                <CardHeader>
                  <CardTitle>Todos los Tickets</CardTitle>
                </CardHeader>
                <CardContent>
                  <TicketsDataTable data={tickets} onEdit={handleEdit} onDelete={handleDeleteRequest} />
                </CardContent>
              </Card>
            </main>
          </div>

          <AddEditTicketDialog
            isOpen={isAddEditTicketOpen}
            onOpenChange={setIsAddEditTicketOpen}
            ticket={selectedTicket}
            onSave={handleSave}
          />
          
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                    <AlertDialogDescription>
                        Esta acción no se puede deshacer. Esto eliminará permanentemente el ticket.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteConfirm}>Eliminar</AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </>
      );
    };

    export default HelpDeskPage;