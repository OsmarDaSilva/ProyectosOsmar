import React, { useState, useEffect, useCallback, FC } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { useNavigate } from 'react-router-dom';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { ArrowLeft, Plus, LifeBuoy } from 'lucide-react';
    import LoadingScreen from '@/components/LoadingScreen';
    import { TicketsDataTable } from '@/components/help-desk/TicketsDataTable';
    import AddEditTicketDialog from '@/components/help-desk/AddEditTicketDialog';
    import { Ticket, Client, UserProfile } from '@/types/tickets';

    const HelpDeskPage: FC = () => {
      const navigate = useNavigate();
      const { user } = useAuth();
      const { toast } = useToast();
      
      const [tickets, setTickets] = useState<Ticket[]>([]);
      const [clients, setClients] = useState<Client[]>([]);
      const [users, setUsers] = useState<UserProfile[]>([]);
      const [loading, setLoading] = useState<boolean>(true);
      const [isAddTicketOpen, setIsAddTicketOpen] = useState<boolean>(false);

      const fetchData = useCallback(async () => {
        setLoading(true);
        try {
          const [ticketsRes, clientsRes, usersRes] = await Promise.all([
            // Adjusted select to use a custom alias for the profiles join
            supabase.from('tickets').select('*, client:clients(name), assigned_user:profiles!tickets_assigned_to_fkey(full_name, email), created_by_user:profiles!tickets_created_by_fkey(full_name, email)').order('created_at', { ascending: false }),
            supabase.from('clients').select('id, name'),
            supabase.functions.invoke('get-users'),
          ]);

          if (ticketsRes.error) throw ticketsRes.error;
          if (clientsRes.error) throw clientsRes.error;
          if (usersRes.error) throw usersRes.error;

          setTickets(ticketsRes.data || []);
          setClients(clientsRes.data || []);
          setUsers(usersRes.data.data || []);

        } catch (error: any) {
          toast({ variant: 'destructive', title: 'Error al cargar datos', description: error.message });
          console.error("Error loading help desk data:", error);
        } finally {
          setLoading(false);
        }
      }, [toast]);

      useEffect(() => {
        fetchData();
      }, [fetchData]);

      const handleSaveTicket = async (ticketData: Partial<Ticket>) => {
        if (!user) {
            toast({ variant: 'destructive', title: 'Error de autenticación', description: 'No se encontró el usuario. Por favor, inicie sesión de nuevo.' });
            return false;
        }
        const dataToSave = { ...ticketData, created_by: user.id };
        const { error } = await supabase.from('tickets').insert(dataToSave as any);
        if (error) {
          toast({ variant: 'destructive', title: 'Error al guardar el ticket', description: error.message });
          return false;
        } else {
          toast({ title: 'Ticket guardado exitosamente' });
          fetchData();
          return true;
        }
      };

      if (loading) {
        return <LoadingScreen message="Cargando Mesa de Ayuda..." />;
      }

      return (
        <>
          <Helmet>
            <title>Mesa de Ayuda - AGROinvest</title>
            <meta name="description" content="Gestiona y haz seguimiento a los tickets de soporte al cliente de AGROinvest." />
            <meta property="og:title" content="Mesa de Ayuda - AGROinvest" />
            <meta property="og:description" content="Gestiona y haz seguimiento a los tickets de soporte al cliente de AGROinvest." />
          </Helmet>
          <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
            <header className="mb-6 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => navigate(-1)}><ArrowLeft className="h-4 w-4" /></Button>
                <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                  <LifeBuoy className="text-red-500" /> Mesa de Ayuda
                </h1>
              </div>
              <Button onClick={() => setIsAddTicketOpen(true)}>
                <Plus className="mr-2 h-4 w-4" /> Nuevo Ticket
              </Button>
            </header>

            <main>
              <Card>
                <CardHeader>
                  <CardTitle>Todos los Tickets</CardTitle>
                </CardHeader>
                <CardContent>
                  <TicketsDataTable data={tickets} />
                </CardContent>
              </Card>
            </main>
          </div>

          <AddEditTicketDialog
            isOpen={isAddTicketOpen}
            onOpenChange={setIsAddTicketOpen}
            clients={clients}
            users={users}
            onSave={handleSaveTicket}
          />
        </>
      );
    };

    export default HelpDeskPage;