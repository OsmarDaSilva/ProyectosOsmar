import React, { useState, useEffect } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { PlusCircle, Video, Search } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';
    import LoadingScreen from '@/components/LoadingScreen';
    import CreateChannelDialog from '@/components/chat/CreateChannelDialog';
    import DeleteChannelDialog from '@/components/chat/DeleteChannelDialog';
    import ChannelList from '@/components/chat/ChannelList';
    import MessageArea from '@/components/chat/MessageArea';
    import ChatHeader from '@/components/chat/ChatHeader';
    import ChatFooter from '@/components/chat/ChatFooter';
    import StartVideoConferenceDialog from '@/components/chat/StartVideoConferenceDialog';
    import CreateTaskFromMessageDialog from '@/components/chat/CreateTaskFromMessageDialog';
    import { useQuery, useQueryClient } from '@tanstack/react-query';
    import { Howl } from 'howler';
    import { Input } from '@/components/ui/input';

    const notificationSound = new Howl({
      src: ['data:audio/mp3;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU0AAAAAAAAAAAAAAP//3xEASQASXwAPEhMREhASEREQDxIPEQ8RDxAPDw8OEQ8ODw4ODg4NDg0NDg0MDAsLDAsLCwoKCgkKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgkKCgoKCQkJCAgICAcHBwYGBgYGBgYGBgYFBQUFBQQEBAMDAwEBAQAA']
    });

    const fetchChannels = async () => {
      const { data, error } = await supabase
        .from('channels')
        .select('*, client:client_id(name), channel_members(user_id, last_read_at)');
      if (error) throw error;
      return data;
    };

    const fetchChannelMembers = async (channelId) => {
      if (!channelId) return [];
      const { data, error } = await supabase.rpc('get_channel_members', { p_channel_id: channelId });
      if (error) throw error;
      return data;
    };

    const ChatPage = () => {
      const navigate = useNavigate();
      const { user } = useAuth();
      const { toast } = useToast();
      const queryClient = useQueryClient();
      
      const [selectedChannel, setSelectedChannel] = useState(null);
      const [isCreateChannelOpen, setIsCreateChannelOpen] = useState(false);
      const [isDeleteChannelOpen, setIsDeleteChannelOpen] = useState(false);
      const [channelToDelete, setChannelToDelete] = useState(null);
      const [isStartVideoConferenceOpen, setIsStartVideoConferenceOpen] = useState(false);
      const [isCreateTaskOpen, setIsCreateTaskOpen] = useState(false);
      const [messageForTask, setMessageForTask] = useState(null);
      const [unreadChannels, setUnreadChannels] = useState(new Set());
      const [searchTerm, setSearchTerm] = useState('');

      const { data: channels, isLoading: isLoadingChannels } = useQuery({
        queryKey: ['channels'],
        queryFn: fetchChannels,
        staleTime: 1000 * 60 * 5,
        onSuccess: (data) => {
          if (!selectedChannel && data.length > 0) {
            const generalChannel = data.find(c => c.name === 'General');
            setSelectedChannel(generalChannel || data[0]);
          }
        }
      });

      const { data: channelMembers = [] } = useQuery({
        queryKey: ['channelMembers', selectedChannel?.id],
        queryFn: () => fetchChannelMembers(selectedChannel?.id),
        enabled: !!selectedChannel,
      });

      const { data: crmData } = useQuery({
        queryKey: ['crmAuxData'],
        queryFn: async () => {
          const [clientsRes, dealsRes, usersRes] = await Promise.all([
            supabase.from('clients').select('id, name'),
            supabase.from('deals').select('id, title, client_id'),
            supabase.functions.invoke('get-users'),
          ]);
          if (clientsRes.error) throw clientsRes.error;
          if (dealsRes.error) throw dealsRes.error;
          if (usersRes.error) throw usersRes.error;
          return {
            clients: clientsRes.data || [],
            deals: dealsRes.data || [],
            users: usersRes.data || [],
          };
        },
        staleTime: 1000 * 60 * 15,
      });

      useEffect(() => {
        const handleMessage = (payload) => {
          const newMessage = payload.new;
          queryClient.setQueryData(['messages', newMessage.channel_id], (oldData) => {
            const oldMessages = oldData ?? [];
            const index = oldMessages.findIndex(m => m.id === newMessage.id);

            if (index !== -1) {
              const newMessages = [...oldMessages];
              newMessages[index] = { ...newMessage, isOptimistic: false };
              return newMessages;
            } else {
              return [...oldMessages, newMessage];
            }
          });

          if (newMessage.user_id !== user.id) {
            notificationSound.play();
            if (selectedChannel?.id !== newMessage.channel_id) {
              setUnreadChannels(prev => new Set(prev).add(newMessage.channel_id));
            }
          }
        };
        
        const handleReceipt = () => {
           queryClient.invalidateQueries({ queryKey: ['messages', selectedChannel?.id] });
        };

        const messageChannel = supabase.channel('public:messages')
          .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, handleMessage)
          .on('postgres_changes', { event: '*', schema: 'public', table: 'read_receipts' }, handleReceipt)
          .subscribe();

        const channelsSubscription = supabase.channel('public:channels')
          .on('postgres_changes', { event: '*', schema: 'public', table: 'channels' }, () => queryClient.invalidateQueries({ queryKey: ['channels'] }))
          .on('postgres_changes', { event: '*', schema: 'public', table: 'channel_members' }, () => queryClient.invalidateQueries({ queryKey: ['channels'] }))
          .subscribe();

        return () => {
          supabase.removeChannel(messageChannel);
          supabase.removeChannel(channelsSubscription);
        };
      }, [queryClient, user.id, selectedChannel?.id]);

      const handleSelectChannel = (channel) => {
        setSelectedChannel(channel);
        setUnreadChannels(prev => {
          const newSet = new Set(prev);
          newSet.delete(channel.id);
          return newSet;
        });
      };

      const handleChannelCreated = (newChannel) => {
        queryClient.invalidateQueries({ queryKey: ['channels'] });
        setSelectedChannel(newChannel);
      };
      
      const openDeleteDialog = (channel) => {
        setChannelToDelete(channel);
        setIsDeleteChannelOpen(true);
      };
      
      const handleChannelDeleted = () => {
        toast({ title: "Canal eliminado", description: `El canal "${channelToDelete.name}" ha sido eliminado.` });
        const deletedChannelId = channelToDelete.id;
        setChannelToDelete(null);
        setIsDeleteChannelOpen(false);
        
        queryClient.setQueryData(['channels'], (oldChannels) => oldChannels.filter(c => c.id !== deletedChannelId));
        
        if (selectedChannel?.id === deletedChannelId) {
            const currentChannels = queryClient.getQueryData(['channels']);
            const generalChannel = currentChannels.find(c => c.name === 'General');
            setSelectedChannel(generalChannel || currentChannels[0] || null);
        }
      };

      const handleStartTaskCreation = (message) => {
        setMessageForTask(message);
        setIsCreateTaskOpen(true);
      };

      const filteredChannels = (channels || []).filter(channel => {
        const term = searchTerm.toLowerCase();
        const channelName = channel.name.toLowerCase();
        const clientName = channel.client?.name.toLowerCase() || '';
        const description = channel.description?.toLowerCase() || '';
        return channelName.includes(term) || clientName.includes(term) || description.includes(term);
      });

      if (isLoadingChannels) {
        return <LoadingScreen message="Cargando chat..." />;
      }

      return (
        <>
          <Helmet><title>Chat Interno - AGRO invest</title></Helmet>
          <CreateChannelDialog isOpen={isCreateChannelOpen} onOpenChange={setIsCreateChannelOpen} onChannelCreated={handleChannelCreated} />
          {channelToDelete && <DeleteChannelDialog isOpen={isDeleteChannelOpen} onOpenChange={setIsDeleteChannelOpen} channel={channelToDelete} onChannelDeleted={handleChannelDeleted} />}
          <StartVideoConferenceDialog isOpen={isStartVideoConferenceOpen} onOpenChange={setIsStartVideoConferenceOpen} onCallStarted={(roomName) => window.open(`/meet/${roomName}`, '_blank')} />
          <CreateTaskFromMessageDialog isOpen={isCreateTaskOpen} onOpenChange={setIsCreateTaskOpen} message={messageForTask} clients={crmData?.clients || []} deals={crmData?.deals || []} users={crmData?.users || []} onTaskCreated={() => {}} />
          
          <div className="flex flex-col h-screen bg-gray-100 dark:bg-gray-800">
            <ChatHeader onBack={() => navigate('/dashboard')} />
            <div className="flex-grow flex overflow-hidden">
              <aside className="w-full md:w-1/3 lg:w-1/4 bg-white dark:bg-gray-900 border-r dark:border-gray-700 flex flex-col">
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                  <h2 className="text-lg font-semibold">Canales</h2>
                  <Button variant="ghost" size="icon" onClick={() => setIsCreateChannelOpen(true)}>
                    <PlusCircle className="h-5 w-5 text-gray-500 hover:text-green-600"/>
                  </Button>
                </div>
                <div className="p-2 border-b dark:border-gray-700">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Buscar canal..."
                      className="pl-8 bg-gray-100 dark:bg-gray-800"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <ChannelList 
                  channels={filteredChannels}
                  selectedChannel={selectedChannel}
                  onSelectChannel={handleSelectChannel}
                  onDeleteChannel={openDeleteDialog}
                  currentUser={user}
                  unreadChannels={unreadChannels}
                />
              </aside>
              <main className="w-full md:w-2/3 lg:w-3/4 flex flex-col bg-gray-200 dark:bg-gray-800">
                {selectedChannel ? (
                  <>
                    <header className="bg-white dark:bg-gray-900 p-4 border-b dark:border-gray-700 flex justify-between items-center shadow-sm">
                      <div>
                        <h2 className="text-xl font-bold">{selectedChannel.client ? selectedChannel.client.name : selectedChannel.name}</h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{selectedChannel.description}</p>
                      </div>
                      <Button variant="outline" onClick={() => setIsStartVideoConferenceOpen(true)}>
                        <Video className="h-5 w-5 mr-2 text-green-600" />
                        Iniciar Videollamada
                      </Button>
                    </header>
                    <MessageArea 
                      channel={selectedChannel} 
                      user={user} 
                      channelMembers={channelMembers}
                      onStartTaskCreation={handleStartTaskCreation}
                    />
                    <ChatFooter channel={selectedChannel} user={user} channelMembers={channelMembers} />
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-gray-500 dark:text-gray-400">Selecciona o crea un canal para empezar a chatear.</p>
                  </div>
                )}
              </main>
            </div>
          </div>
        </>
      );
    };

    export default ChatPage;