import React, { useState } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { Plus, Users, ArrowLeft, MoreHorizontal, Edit, Trash2, FileDown, Truck, Wrench, FileText } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';
    import { format } from 'date-fns';
    import { es } from 'date-fns/locale';
    import QueryStateWrapper from '@/components/QueryStateWrapper';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Skeleton } from '@/components/ui/skeleton';
    import { Badge } from '@/components/ui/badge';
    import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
    import AddEditServiceOrderDialog from '@/components/customer-service/AddEditServiceOrderDialog';
    import AddEditQuoteDialog from '@/components/customer-service/AddEditQuoteDialog';
    import AddEditPurchaseOrderDialog from '@/components/customer-service/AddEditPurchaseOrderDialog';
    import { exportDocumentToPdf } from '@/lib/pdfUtils';

    const fetchServiceOrders = async (userId) => {
        // This is a deprecated page, returning empty data to avoid errors.
        return [];
    };

    const fetchQuotes = async (userId) => {
        // This is a deprecated page, returning empty data to avoid errors.
        return [];
    };

    const fetchPurchaseOrders = async (userId) => {
        // This is a deprecated page, returning empty data to avoid errors.
        return [];
    };
    
    const fetchUsers = async () => {
        try {
            const { data, error } = await supabase.functions.invoke('get-users');
            if (error) throw error;
            return data;
        } catch (error) {
            console.error("Error fetching users:", error);
            return [];
        }
    };

    const fetchClients = async (userId) => {
        const { data, error } = await supabase
            .from('clients')
            .select('id, name')
            .eq('user_id', userId);
        if (error) throw error;
        return data;
    }
    
    const fetchClientProjects = async (userId) => {
        const { data, error } = await supabase
            .from('client_projects')
            .select('id, project_name');
        if (error) throw error;
        return data;
    }


    const TableLoader = () => (
        <div className="space-y-2">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
        </div>
    );

    const HistoricCustomerServicePage = () => {
        const navigate = useNavigate();
        const { user } = useAuth();
        const { toast } = useToast();
        const queryClient = useQueryClient();

        const [isServiceOrderDialogOpen, setIsServiceOrderDialogOpen] = useState(false);
        const [editingServiceOrder, setEditingServiceOrder] = useState(null);
        const [isQuoteDialogOpen, setIsQuoteDialogOpen] = useState(false);
        const [editingQuote, setEditingQuote] = useState(null);
        const [isPurchaseOrderDialogOpen, setIsPurchaseOrderDialogOpen] = useState(false);
        const [editingPurchaseOrder, setEditingPurchaseOrder] = useState(null);

        const { data: serviceOrders, isLoading: isLoadingSO, isError: isErrorSO, error: errorSO } = useQuery({ queryKey: ['serviceOrdersHistoric', user.id], queryFn: () => fetchServiceOrders(user.id) });
        const { data: quotes, isLoading: isLoadingQ, isError: isErrorQ, error: errorQ } = useQuery({ queryKey: ['quotesHistoric', user.id], queryFn: () => fetchQuotes(user.id) });
        const { data: purchaseOrders, isLoading: isLoadingPO, isError: isErrorPO, error: errorPO } = useQuery({ queryKey: ['purchaseOrdersHistoric', user.id], queryFn: () => fetchPurchaseOrders(user.id) });
        
        const { data: users, isLoading: isLoadingUsers } = useQuery({ queryKey: ['allUsers'], queryFn: fetchUsers });
        const { data: clients, isLoading: isLoadingClients } = useQuery({ queryKey: ['allClients', user.id], queryFn: () => fetchClients(user.id) });
        const { data: clientProjects, isLoading: isLoadingClientProjects } = useQuery({ queryKey: ['allClientProjects', user.id], queryFn: () => fetchClientProjects(user.id) });

        return (
            <>
                <Helmet>
                    <title>Histórico Atención al Cliente - AGROinvest</title>
                </Helmet>
                <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
                    <header className="mb-6">
                        <div className="flex items-center gap-4">
                            <Button variant="outline" size="icon" onClick={() => navigate('/dashboard')}>
                                <ArrowLeft className="h-4 w-4" />
                            </Button>
                            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                                <Users className="text-red-600" />
                                Histórico Atención al Cliente (deprecated)
                            </h1>
                        </div>
                         <p className="mt-2 text-red-700 bg-red-100 p-3 rounded-md">
                            Este módulo está obsoleto y ha sido reemplazado. Su contenido se mantiene solo para fines históricos y no debe ser utilizado.
                        </p>
                    </header>
                    <Tabs defaultValue="service-orders">
                        <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3">
                            <TabsTrigger value="service-orders"><Wrench className="w-4 h-4 mr-2"/>Órdenes de Servicio</TabsTrigger>
                            <TabsTrigger value="quotes"><FileText className="w-4 h-4 mr-2"/>Presupuestos</TabsTrigger>
                            <TabsTrigger value="purchase-orders"><Truck className="w-4 h-4 mr-2"/>Pedidos a Proveedores</TabsTrigger>
                        </TabsList>
                        
                         <TabsContent value="service-orders" className="mt-4">
                             <div className="text-center py-10 text-gray-500">Módulo obsoleto.</div>
                         </TabsContent>
                         <TabsContent value="quotes" className="mt-4">
                             <div className="text-center py-10 text-gray-500">Módulo obsoleto.</div>
                         </TabsContent>
                         <TabsContent value="purchase-orders" className="mt-4">
                             <div className="text-center py-10 text-gray-500">Módulo obsoleto.</div>
                         </TabsContent>
                    </Tabs>
                </div>
            </>
        );
    };

    export default HistoricCustomerServicePage;