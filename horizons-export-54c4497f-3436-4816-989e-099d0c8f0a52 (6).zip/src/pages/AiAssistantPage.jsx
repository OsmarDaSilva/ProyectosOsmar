import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import AiAssistantPanel from '@/components/assistant/AiAssistantPanel';
    import { useTranslation } from 'react-i18next';


    const AiAssistantPage = () => {
      const { t } = useTranslation('assistant');

      return (
        <>
          <Helmet>
            <title>{t('title')}</title>
            <meta name="description" content={t('metaDescription')} />
          </Helmet>
          <div className="flex h-[calc(100vh_-_theme(spacing.24))]">
            <AiAssistantPanel />
          </div>
        </>
      );
    };

    export default AiAssistantPage;