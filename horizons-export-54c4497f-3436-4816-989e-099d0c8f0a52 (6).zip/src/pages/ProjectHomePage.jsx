import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ProjectForm from '@/components/ProjectForm';
import AgricultureForm from '@/components/AgricultureForm';
import GanaderiaForm from '@/components/GanaderiaForm';
import { useProjectData } from '@/contexts/ProjectDataContext';
import ChartsView from '@/components/ChartsView';
import ExecutiveSummary from '@/components/ExecutiveSummary';
import FinancialAnalysisPage from '@/pages/FinancialAnalysisPage';
import CarbonBalance from '@/components/CarbonBalance';
import TirVanRoyPayback from '@/components/TirVanRoyPayback';
import { Leaf, Beef, BarChart3, FileText, Banknote, Recycle, GanttChartSquare, ClipboardCheck, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTirVanRoyPayback } from '@/hooks/useTirVanRoyPayback';
import { useInitialCalculations } from '@/hooks/useInitialCalculations';
import { useTranslation } from 'react-i18next';

const ProjectHomePage = () => {
  const { t } = useTranslation(['calculator']);
  const {
    projectData,
    agricultureData,
    ganaderiaData,
    handleProjectUpdate,
    handleAgricultureUpdate,
    handleGanaderiaUpdate,
    isDataLoaded,
    activeClientProject
  } = useProjectData();

  const initialCalculations = useInitialCalculations(projectData);
  const tirVanCalculations = useTirVanRoyPayback({ projectData, agricultureData, ganaderiaData });

  if (!isDataLoaded) {
    return <div>{t('loading.data')}</div>;
  }
  
  if (!activeClientProject) {
    return (
         <div className="text-center py-20 bg-gray-50 rounded-lg shadow-inner border-2 border-dashed border-gray-300">
            <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-800">Ningún Proyecto Activo</h2>
            <p className="text-gray-600 text-lg mt-2">
              Por favor, vaya a la sección "Mis Proyectos" para cargar un proyecto existente o a "Clientes" para crear uno nuevo.
            </p>
        </div>
    )
  }

  const isAgricultureEnabled = projectData?.modules?.agricultura ?? false;
  const isGanaderiaEnabled = projectData?.modules?.ganaderia ?? false;

  const tabsConfig = [
    { value: 'project', label: t('nav.home'), icon: FileText, content: <ProjectForm formData={projectData} onUpdate={handleProjectUpdate} calculations={initialCalculations} /> },
    { value: 'ganaderia', label: t('nav.livestock'), icon: Beef, enabled: isGanaderiaEnabled, content: <GanaderiaForm initialData={ganaderiaData} onUpdate={handleGanaderiaUpdate} projectData={projectData} /> },
    { value: 'agricultura', label: t('nav.agriculture'), icon: Leaf, enabled: isAgricultureEnabled, content: <AgricultureForm initialData={agricultureData} onUpdate={handleAgricultureUpdate} /> },
    { value: 'summary', label: t('nav.executiveSummary'), icon: GanttChartSquare, content: <ExecutiveSummary projectData={projectData} agricultureData={agricultureData} ganaderiaData={ganaderiaData} /> },
    { value: 'viability', label: t('nav.viabilityAnalysis'), icon: ClipboardCheck, content: <TirVanRoyPayback projectData={projectData} agricultureData={agricultureData} ganaderiaData={ganaderiaData} /> },
    { value: 'charts', label: t('nav.charts'), icon: BarChart3, content: <ChartsView projectData={projectData} agricultureData={agricultureData} ganaderiaData={ganaderiaData} /> },
    { value: 'financial', label: t('nav.financialAnalysis'), icon: Banknote, content: <FinancialAnalysisPage /> },
    { value: 'carbon', label: t('nav.carbonBalance'), icon: Recycle, content: <CarbonBalance ganaderiaData={ganaderiaData} agricultureData={agricultureData} projectData={projectData} /> }
  ];

  return (
    <>
      <Helmet>
        <title>{t('pageTitle')}</title>
        <meta name="description" content={t('pageDescription')} />
      </Helmet>
      <div className="container mx-auto p-4">
        <Tabs defaultValue="project" className="w-full">
          <TabsList className="flex flex-wrap justify-center gap-1 mb-4 bg-transparent p-0">
            {tabsConfig.filter(tab => tab.enabled !== false).map((tab, index) => (
               <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className={cn(
                    'flex-grow text-center px-4 py-3 font-semibold transition-all duration-300 ease-in-out',
                    'data-[state=active]:bg-[#00A859] data-[state=active]:text-white data-[state=active]:shadow-md',
                    'data-[state=inactive]:bg-gray-300 data-[state=inactive]:text-black hover:bg-gray-400/80',
                    'rounded-tr-lg rounded-bl-lg'
                  )}
                >
                <div className="flex flex-col items-center justify-center h-full">
                  <tab.icon className="w-5 h-5 mb-1" />
                  <span className="text-xs whitespace-pre-wrap leading-tight">{tab.label.replace(' ', '\n')}</span>
                </div>
              </TabsTrigger>
            ))}
          </TabsList>

          {tabsConfig.filter(tab => tab.enabled !== false).map(tab => (
             <TabsContent key={tab.value} value={tab.value} className="mt-6">
                {tab.content}
             </TabsContent>
          ))}

        </Tabs>
      </div>
    </>
  );
};

export default ProjectHomePage;