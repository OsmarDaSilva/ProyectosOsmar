import React, { useState, useRef, FC } from 'react';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PlusCircle, Sprout, ArrowLeft, Upload, FileText, Download, List, RefreshCw, XCircle as CircleX, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { ForageDataTable } from '@/components/forage/ForageDataTable';
import useForageData from '@/hooks/useForageData';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/components/ui/use-toast';
import { useImportJobs } from '@/hooks/useImportJobs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import * as XLSX from 'xlsx';
import { supabase } from '@/lib/customSupabaseClient';
import { v4 as uuidv4 } from 'uuid';
import { logUserAction } from '@/lib/logger';
import { useTranslation } from 'react-i18next';

const ForagePageLoader: FC = () => (
    <Card className="shadow-lg">
        <CardHeader>
            <div className="animate-pulse">
                <div className="h-8 bg-muted rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-muted rounded w-3/4"></div>
            </div>
        </CardHeader>
        <CardContent>
            <div className="space-y-2 animate-pulse">
                <div className="h-10 bg-muted rounded w-full"></div>
                <div className="h-10 bg-muted rounded w-full"></div>
                <div className="h-10 bg-muted rounded w-full"></div>
            </div>
        </CardContent>
    </Card>
);

const statusMapping = {
  queued: { text: "En Cola", variant: "default" },
  processing: { text: "Procesando", variant: "secondary" },
  completed: { text: "Completado", variant: "success" },
  completed_with_errors: { text: "Con Errores", variant: "destructive" },
  failed: { text: "Fallido", variant: "destructive" },
};

const ImportHistory = ({ jobs, onRefresh, onDownloadErrors, onCancelJob, onResumeJob, isResuming }) => {
    const { t } = useTranslation('forageBalance');
    return (
        <Card className="mt-6">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2"><List /> {t('importHistory.title')}</CardTitle>
                <Button variant="ghost" size="sm" onClick={onRefresh}><RefreshCw className="h-4 w-4"/></Button>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {(jobs?.length ?? 0) === 0 ? <p className="text-sm text-muted-foreground">{t('importHistory.noImports')}</p> :
                     jobs?.map(job => {
                        const { text, variant } = statusMapping[job.status] || { text: 'Desconocido', variant: 'secondary' };
                        const progress = job.total_rows > 0 ? Math.round((job.processed_rows / job.total_rows) * 100) : (job.status.startsWith('completed') || job.status === 'failed' ? 100 : 0);
                        return (
                            <div key={job.id} className="p-3 border rounded-lg bg-background">
                                <div className="flex justify-between items-start flex-wrap gap-2">
                                    <div className="flex-1 min-w-[200px]">
                                        <p className="font-semibold text-sm truncate" title={job.file_path?.split('/').pop()}>
                                          {job.file_path?.split('/').pop() || t('importHistory.noFile')}
                                        </p>
                                        <div className="flex items-center gap-2">
                                            <Badge variant={variant}>{text}</Badge>
                                            <p className="text-xs text-muted-foreground">{new Date(job.created_at).toLocaleString()}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        {job.status === 'failed' && (
                                            <Button size="sm" variant="outline" onClick={() => onResumeJob(job.id)} disabled={isResuming}>
                                                {isResuming ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <RefreshCw className="mr-2 h-4 w-4"/>} 
                                                {t('importHistory.resume')}
                                            </Button>
                                        )}
                                        {['queued', 'processing'].includes(job.status) && (
                                            <Button size="sm" variant="destructive" onClick={() => onCancelJob(job.id)}>
                                                <CircleX className="mr-2 h-4 w-4"/> {t('importHistory.cancel')}
                                            </Button>
                                        )}
                                        {job.status === 'completed_with_errors' && (
                                            <Button size="sm" variant="outline" onClick={() => onDownloadErrors(job)}>
                                              <Download className="mr-2 h-4 w-4"/> {t('importHistory.errors')}
                                            </Button>
                                        )}
                                    </div>
                                </div>
                                { (job.status === 'processing') && job.total_rows > 0 && (
                                    <div className="mt-2">
                                        <Progress value={progress} className="w-full" />
                                        <p className="text-xs text-muted-foreground text-right mt-1">{job.processed_rows || 0} / {job.total_rows} {t('importHistory.rows')}</p>
                                    </div>
                                )}
                                {job.status === 'failed' && job.error_details?.errors?.[0]?.error && (
                                  <div className="text-xs mt-2 border-t pt-2">
                                    <p className="text-red-600">
                                      <span className="font-bold">{t('importHistory.error')}:</span> {job.error_details.errors[0].error}
                                    </p>
                                  </div>
                                )}
                                { (job.status.startsWith('completed')) && job.summary && (
                                  <div className="text-xs mt-2 border-t pt-2 grid grid-cols-3 gap-2">
                                    <p>{t('importHistory.total')}: <span className="font-bold">{job.summary.total}</span></p>
                                    <p className="text-green-600">{t('importHistory.success')}: <span className="font-bold">{job.summary.success}</span></p>
                                    <p className="text-red-600">{t('importHistory.failed')}: <span className="font-bold">{job.summary.failed}</span></p>
                                  </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
};


const ForageDatabasePage: FC = () => {
    const { t } = useTranslation('forageBalance');
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const navigate = useNavigate();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { toast } = useToast();

    const { data, isLoading, isError, error, refetch } = useForageData(user?.id);
    const { jobs, cancelJob, resumeJob, refetchJobs, isResuming } = useImportJobs(user?.id, 'forage_imports');

    const [editingRowId, setEditingRowId] = useState<string | null>(null);

    const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        try {
            const { data: processingJob, error: checkError } = await supabase
                .from('import_jobs')
                .select('id')
                .eq('user_id', user!.id)
                .in('status', ['processing', 'queued'])
                .like('file_path', '%forage_imports%')
                .maybeSingle();

            if (checkError) throw checkError;
            if (processingJob) {
                toast({ variant: 'destructive', title: t('importError.title'), description: t('importError.alreadyProcessing') });
                if(fileInputRef.current) fileInputRef.current.value = '';
                return;
            }

            const fileExtension = file.name.split('.').pop();
            const filePath = `forage_imports/${user!.id}/${uuidv4()}.${fileExtension}`;
            
            const { error: uploadError } = await supabase.storage.from('forage_imports').upload(filePath, file);
            if (uploadError) throw uploadError;

            const { data: jobData, error: jobError } = await supabase
                .from('import_jobs').insert({ user_id: user!.id, file_path: filePath, status: 'queued' }).select().single();
            if (jobError) throw jobError;
            
            await logUserAction('create_import_job', 'forage', { jobId: jobData.id, file: file.name });
            
            const { error: functionError } = await supabase.functions.invoke('import-forage-data', { body: { jobId: jobData.id } });
            if (functionError) {
                const functionErrorMessage = typeof functionError === 'object' ? functionError.message : String(functionError);
                await supabase.from('import_jobs').update({ status: 'failed', error_details: { errors: [{ row: 0, error: `Error al invocar la función: ${functionErrorMessage}` }] } }).eq('id', jobData.id);
                throw functionError;
            }

            toast({ title: t('importSuccess.title'), description: t('importSuccess.description') });
            refetchJobs();

        } catch (error: any) {
             toast({ variant: 'destructive', title: t('importError.title'), description: error.message || t('importError.unexpected') });
        } finally {
            if(fileInputRef.current) fileInputRef.current.value = '';
        }
    };
    
    const downloadTemplate = () => {
        const wsData = [
          { 'País': 'Paraguay', 'Región': 'Alto Paraná', 'Tipo de Pastura': 'BRS Zuri', 'Forma Producida': 'Regada', 'Ene': 4789, 'Feb': 4033, 'Mar': 2753, 'Abr': 2577, 'May': 2753, 'Jun': 2501, 'Jul': 2207, 'Ago': 3154, 'Sep': 3200, 'Oct': 3234, 'Nov': 3900, 'Dic': 6129 },
          { 'País': 'Paraguay', 'Región': 'Chaco', 'Tipo de Pastura': 'Mombasa', 'Forma Producida': 'Normal', 'Ene': 2275, 'Feb': 2210, 'Mar': 2015, 'Abr': 1950, 'May': 1950, 'Jun': 1300, 'Jul': 1300, 'Ago': 1300, 'Sep': 1950, 'Oct': 2015, 'Nov': 2210, 'Dic': 2275 },
          { 'País': 'Paraguay', 'Región': 'Itapúa', 'Tipo de Pastura': 'Ruziziensis', 'Forma Producida': 'Normal', 'Meses': 'Enero', 'kg_ms_mes_region': 1625},
          { 'País': 'Paraguay', 'Región': 'Itapúa', 'Tipo de Pastura': 'Ruziziensis', 'Forma Producida': 'Normal', 'Meses': 'Febrero', 'kg_ms_mes_region': 1560},
        ];
        const ws = XLSX.utils.json_to_sheet(wsData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Forraje");
        XLSX.writeFile(wb, "plantilla_produccion_forraje.xlsx");
    };

    const downloadErrors = (job) => {
        if (!job.error_details?.errors?.length) {
          toast({ title: t('importHistory.info'), description: t('importHistory.noErrorsToDownload') });
          return;
        }
        const errorData = job.error_details.errors.map(e => ({ Fila: e.row, Error: e.error }));
        const ws = XLSX.utils.json_to_sheet(errorData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Errores");
        XLSX.writeFile(wb, `errores_forraje_${job.file_path.split('/').pop().split('.')[0]}.xlsx`);
    };

    const handleAddNew = () => {
        const newId = `new-${crypto.randomUUID()}`;
        setEditingRowId(newId);
    };

    return (
        <>
            <Helmet><title>{t('pageTitle')}</title></Helmet>
            <div className="container mx-auto p-4">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                    <div className="flex justify-between items-start flex-wrap gap-4 mb-6">
                        <div>
                            <div className="flex items-center gap-3"><Sprout className="h-8 w-8 text-green-600" /><CardTitle className="text-3xl font-bold">{t('mainTitle')}</CardTitle></div>
                            <p className="mt-2 text-muted-foreground">{t('mainDescription')}</p>
                        </div>
                        <Button onClick={() => navigate('/calculator')} variant="outline"><ArrowLeft className="mr-2 h-4 w-4" />{t('common:back')}</Button>
                    </div>

                     <Tabs defaultValue="data" className="w-full">
                        <TabsList>
                            <TabsTrigger value="data">{t('tabs.data')}</TabsTrigger>
                            <TabsTrigger value="import">{t('tabs.import')}</TabsTrigger>
                        </TabsList>
                        <TabsContent value="data" className="mt-4">
                            <Card className="shadow-lg">
                                <CardHeader>
                                    <div className="flex justify-between items-center">
                                        <CardTitle>{t('dataTab.cardTitle')}</CardTitle>
                                        <Button onClick={handleAddNew}><PlusCircle className="mr-2 h-4 w-4" />{t('dataTab.addProfile')}</Button>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <QueryStateWrapper isLoading={isLoading} isError={isError} error={error as Error} data={data} loader={<ForagePageLoader />} onRetry={refetch}>
                                        {(forageData) => (
                                            <ForageDataTable
                                                data={forageData}
                                                userId={user!.id}
                                                editingRowId={editingRowId}
                                                setEditingRowId={setEditingRowId}
                                                onRowDeleted={refetch}
                                                onRowSaved={() => {
                                                    setEditingRowId(null);
                                                    refetch();
                                                }}
                                                onCancelEdit={() => {
                                                    setEditingRowId(null);
                                                }}
                                            />
                                        )}
                                    </QueryStateWrapper>
                                </CardContent>
                            </Card>
                        </TabsContent>
                        <TabsContent value="import" className="mt-4">
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2"><FileText /> {t('importTab.cardTitle')}</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="text-sm text-muted-foreground space-y-2">
                                        <p>{t('importTab.instruction1')}</p>
                                        <p>{t('importTab.instruction2')}</p>
                                        <p>{t('importTab.instruction3')}</p>
                                    </div>
                                    <div className="flex gap-4">
                                        <Button variant="outline" onClick={downloadTemplate}><Download className="mr-2 h-4 w-4" /> {t('importTab.templateButton')}</Button>
                                        <Button onClick={() => fileInputRef.current?.click()}><Upload className="mr-2 h-4 w-4" />{t('importTab.importButton')}</Button>
                                        <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls, .csv" onChange={handleFileImport}/>
                                    </div>
                                </CardContent>
                            </Card>
                            <ImportHistory jobs={jobs} onRefresh={refetchJobs} onDownloadErrors={downloadErrors} onCancelJob={cancelJob} onResumeJob={resumeJob} isResuming={isResuming}/>
                        </TabsContent>
                    </Tabs>
                </motion.div>
            </div>
        </>
    );
};

export default ForageDatabasePage;