import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { Users, KeyRound } from 'lucide-react';
    import UserManagement from '@/components/UserManagement';

    const UserManagementPage = () => {
      return (
        <>
          <Helmet>
            <title>Gestión de Usuarios - AGRO invest</title>
          </Helmet>
          <div className="p-4 sm:p-6 lg:p-8">
            <div className="flex items-center gap-4 mb-6">
              <Users className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-800">
                Gestión de Usuarios y Colaboradores
              </h1>
            </div>
            
            <p className="mb-6 text-gray-600 max-w-3xl">
              Aquí puedes invitar nuevos colaboradores, gestionar roles y restablecer contraseñas. Los administradores tienen acceso a todas las funciones, mientras que los colaboradores tienen permisos limitados.
            </p>

            <UserManagement />
          </div>
        </>
      );
    };

    export default UserManagementPage;