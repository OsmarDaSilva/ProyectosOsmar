import React, { useState } from 'react';
    import { Helmet } from 'react-helmet-async';
    import { motion } from 'framer-motion';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Plus, Users, ArrowLeft } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';
    import ClientList from '@/components/clients/ClientList';
    import ClientDetail from '@/components/clients/ClientDetail';
    import AddEditClientDialog from '@/components/clients/AddEditClientDialog';
    import { useProjectData } from '@/contexts/ProjectDataContext';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { logUserAction } from '@/lib/logger';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import QueryStateWrapper from '@/components/QueryStateWrapper';
    import { Skeleton } from '@/components/ui/skeleton';

    const fetchClients = async () => {
      const { data, error } = await supabase
        .from('clients')
        .select(`
          *,
          creator_profile:profiles!clients_created_by_fkey(full_name),
          client_projects:client_projects(
            *, 
            creator_profile:profiles!client_projects_created_by_fkey(full_name, user_id),
            updater_profile:profiles!client_projects_updated_by_fkey(full_name, user_id)
          ),
          contacts:contacts(*)
        `)
        .order('created_at', { ascending: false });
      if (error) {
        console.error("Error fetching clients:", error);
        throw error;
      }
      return data;
    };

    const ClientPageLoader = () => (
        <div className="flex flex-col lg:flex-row gap-6">
            <div className="lg:w-1/3 space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
            </div>
            <div className="lg:w-2/3 space-y-4">
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-48 w-full" />
                <Skeleton className="h-48 w-full" />
            </div>
        </div>
    );

    const ClientsPage = () => {
      const navigate = useNavigate();
      const { toast } = useToast();
      const { user } = useAuth();
      const queryClient = useQueryClient();
      const { loadClientProject, saveToClientProject } = useProjectData();
      const [selectedClient, setSelectedClient] = useState(null);
      const [isClientDialogOpen, setIsClientDialogOpen] = useState(false);
      const [editingClient, setEditingClient] = useState(null);

      const { data: clients, isLoading, isError, error, refetch } = useQuery({
        queryKey: ['clients'],
        queryFn: fetchClients,
        staleTime: 1000 * 60 * 5, // 5 minutes
        onSuccess: (data) => {
            if (!selectedClient && data && data.length > 0) {
                setSelectedClient(data[0]);
            } else if (selectedClient) {
                const refreshedClient = data.find(c => c.id === selectedClient.id);
                setSelectedClient(refreshedClient || (data.length > 0 ? data[0] : null));
            }
        }
      });

      const clientMutation = useMutation({
        mutationFn: async ({clientData, assignedUserIds}) => {
            const dataToUpsert = { ...clientData };
            if (user) {
                dataToUpsert.updated_by = user.id;
                if (!clientData.id) { // isEditing
                    dataToUpsert.created_by = user.id;
                }
            }
            
            const { data, error } = await supabase.from('clients').upsert(dataToUpsert).select().single();
            
            if (error) throw error;

            // Handle confidential access
            if (data.is_confidential) {
                // Remove all existing access for this client
                const { error: deleteError } = await supabase.from('confidential_access').delete().eq('client_id', data.id);
                if (deleteError) throw deleteError;

                // Add new access list
                const accessRecords = assignedUserIds.map(userId => ({ client_id: data.id, user_id: userId }));
                const { error: insertError } = await supabase.from('confidential_access').insert(accessRecords);
                if (insertError) throw insertError;
            } else {
                // If not confidential, ensure no access rules exist
                await supabase.from('confidential_access').delete().eq('client_id', data.id);
            }

            return { data, isEditing: !!clientData.id };
        },
        onSuccess: ({ data, isEditing }) => {
            queryClient.invalidateQueries({queryKey: ['clients']});
            toast({ title: 'Cliente guardado', description: 'El cliente se ha guardado correctamente.' });
            logUserAction(isEditing ? 'edit_client' : 'create_client', 'clients', { client_name: data.name });
            setIsClientDialogOpen(false);
            setEditingClient(null);
            
            refetch();
            return true;
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error al guardar cliente', description: error.message });
            return false;
        }
      });

      const deleteClientMutation = useMutation({
        mutationFn: async (clientId) => {
          const { error } = await supabase.rpc('delete_client_and_dependents', { p_client_id: clientId });
          if (error) throw error;
          return clientId;
        },
        onSuccess: (clientId) => {
          queryClient.invalidateQueries({queryKey: ['clients']});
          const clientToDelete = clients?.find(c => c.id === clientId);
          toast({ title: 'Cliente eliminado', description: `El cliente ${clientToDelete?.name} y todos sus datos asociados han sido eliminados.` });
          logUserAction('delete_client', 'clients', { client_name: clientToDelete?.name });
          setSelectedClient(null);
        },
        onError: (error) => {
          toast({ variant: 'destructive', title: 'Error al eliminar cliente', description: error.message });
        }
      });

      const handleSaveClient = async (clientData, assignedUserIds) => {
        try {
            await clientMutation.mutateAsync({ clientData, assignedUserIds });
            return true;
        } catch(e) {
            return false;
        }
      };
      
      const handleAddNewClient = () => {
        setEditingClient(null);
        setIsClientDialogOpen(true);
      };

      const handleEditClient = (client) => {
        setEditingClient(client);
        setIsClientDialogOpen(true);
      };
      
      const handleLoadProjectData = (client, project) => {
        loadClientProject(client, project);
        navigate('/calculator');
      };

      const handleSaveProjectData = async (projectId) => {
        await saveToClientProject(projectId);
        queryClient.invalidateQueries({queryKey: ['clients']});
      };

      return (
        <>
          <Helmet>
            <title>Gestión de Clientes - AGRO invest</title>
            <meta name="description" content="Gestione centralmente sus clientes y los proyectos asociados." />
          </Helmet>
          <div className="min-h-screen bg-gray-50">
            <header className="bg-white shadow-sm sticky top-0 z-10">
              <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="icon" onClick={() => navigate('/dashboard')}>
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                    <Users className="text-green-600" />
                    Gestión de Clientes y Proyectos
                  </h1>
                </div>
                <Button onClick={handleAddNewClient} disabled={clientMutation.isPending}>
                  <Plus className="mr-2 h-4 w-4" />
                  Nuevo Cliente
                </Button>
              </div>
            </header>
            <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
              <QueryStateWrapper
                isLoading={isLoading}
                isError={isError}
                error={error}
                data={clients}
                loader={<ClientPageLoader />}
                onRetry={refetch}
              >
                {(data) => (
                    data && <div className="flex flex-col lg:flex-row gap-6">
                    <motion.div
                      initial={{ x: -50, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      className="lg:w-1/3"
                    >
                      <ClientList
                        clients={data}
                        selectedClient={selectedClient}
                        onSelectClient={setSelectedClient}
                      />
                    </motion.div>
                    <motion.div
                      initial={{ x: 50, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      className="lg:w-2/3"
                    >
                      <ClientDetail
                        client={selectedClient}
                        onEdit={handleEditClient}
                        onDelete={(id) => deleteClientMutation.mutate(id)}
                        refreshClients={() => queryClient.invalidateQueries({queryKey: ['clients']})}
                        onLoadProject={handleLoadProjectData}
                        onSaveProject={handleSaveProjectData}
                      />
                    </motion.div>
                  </div>
                )}
              </QueryStateWrapper>
            </main>
            <AddEditClientDialog
              isOpen={isClientDialogOpen}
              setIsOpen={setIsClientDialogOpen}
              client={editingClient}
              onSave={handleSaveClient}
            />
          </div>
        </>
      );
    };

    export default ClientsPage;