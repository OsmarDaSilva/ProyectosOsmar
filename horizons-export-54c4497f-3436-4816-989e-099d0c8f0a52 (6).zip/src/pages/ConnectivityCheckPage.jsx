import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Zap, Server, Database, Cloud } from 'lucide-react';

const ResultDisplay = ({ result }) => {
    if (!result) return null;

    const getStatusColor = (status) => {
        if (status >= 200 && status < 300) return 'bg-green-500';
        if (status >= 400 && status < 500) return 'bg-yellow-500';
        if (status >= 500) return 'bg-red-500';
        return 'bg-gray-500';
    };

    return (
        <div className="mt-4 p-4 bg-gray-900 rounded-lg text-white text-sm font-mono overflow-x-auto">
            {result.timestamp && <p className="mb-2 text-gray-400">// Executed at: {result.timestamp}</p>}
            {result.status && <p className="mb-2">Status: <span className={`px-2 py-1 rounded-full text-xs text-white ${getStatusColor(result.status)}`}>{result.status}</span></p>}
            <pre><code>{JSON.stringify(result.data, null, 2)}</code></pre>
        </div>
    );
};

const CodeSnippet = ({ code }) => (
    <div className="mt-4 p-3 bg-gray-800 text-gray-200 rounded-lg text-xs font-mono overflow-x-auto">
        <pre><code>{code.trim()}</code></pre>
    </div>
);

const ConnectivityCheckPage = () => {
    const { session } = useAuth();
    const [restLoading, setRestLoading] = useState(false);
    const [restResult, setRestResult] = useState(null);
    const [sdkLoading, setSdkLoading] = useState(false);
    const [sdkResult, setSdkResult] = useState(null);
    const [edgeLoading, setEdgeLoading] = useState(false);
    const [edgeResult, setEdgeResult] = useState(null);

    const SUPABASE_URL = supabase.supabaseUrl;
    const SUPABASE_ANON_KEY = supabase.supabaseKey;

    const handleRestTest = async () => {
        setRestLoading(true);
        setRestResult(null);
        const url = `${SUPABASE_URL}/rest/v1/hz_connectivity_check`;
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'apikey': SUPABASE_ANON_KEY,
                    'Authorization': `Bearer ${session.access_token}`,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    source: "REST",
                    test_id: "EVID-CR-REST",
                    payload: { ok: true }
                })
            });
            const data = await response.json();
            setRestResult({
                status: response.status,
                data: data[0] || data,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            setRestResult({
                status: 500,
                data: { error: error.message },
                timestamp: new Date().toISOString()
            });
        }
        setRestLoading(false);
    };

    const handleSdkTest = async () => {
        setSdkLoading(true);
        setSdkResult(null);
        try {
            const { data, error } = await supabase
              .from("hz_connectivity_check")
              .insert({
                test_id: "EVID-CR-SDK",
                source: "SDK",
                payload: { from: "sdk", when: new Date().toISOString() }
              })
              .select()
              .single();

            if (error) throw error;
            setSdkResult({
                status: 201,
                data,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            setSdkResult({
                status: 500,
                data: { error: error.message },
                timestamp: new Date().toISOString()
            });
        }
        setSdkLoading(false);
    };
    
    const handleEdgeFunctionTest = async () => {
        setEdgeLoading(true);
        setEdgeResult(null);
        try {
            const { data, error } = await supabase.functions.invoke('echo', {
                body: { test_id: "EVID-CR-FUNCTION", hello: "world" }
            });
            if (error) throw error;
            setEdgeResult({
                status: 200,
                data,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
             setEdgeResult({
                status: error.context?.status || 500,
                data: { error: error.message, context: error.context },
                timestamp: new Date().toISOString()
            });
        }
        setEdgeLoading(false);
    };

    const restSnippet = `
curl -i -X POST "$SUPABASE_URL/rest/v1/hz_connectivity_check" \\
  -H "apikey: $ANON_KEY" \\
  -H "Authorization: Bearer $ANON_KEY" \\
  -H "Content-Type: application/json" \\
  -H "Prefer: return=representation" \\
  -d '{"source":"REST","test_id":"EVID-CR-REST","payload":{"ok":true}}'`;

    const sdkSnippet = `
const { data, error } = await supabase
  .from("hz_connectivity_check")
  .insert({
    test_id: "EVID-CR-SDK",
    source: "SDK",
    payload: { from: "sdk", when: new Date().toISOString() }
  })
  .select();`;

    const edgeSnippet = `
curl -i -X POST "$SUPABASE_URL/functions/v1/echo" \\
  -H "Authorization: Bearer $ANON_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"test_id":"EVID-CR-FUNCTION"}'`;

    return (
        <>
            <Helmet>
                <title>Test de Conexión - AGROinvest</title>
                <meta name="description" content="Página para validar la conectividad con los servicios de Supabase." />
            </Helmet>
            <div className="p-4 sm:p-6 lg:p-8 space-y-8">
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-gray-800 flex items-center justify-center gap-3"><Zap className="text-yellow-500"/> Panel de Evidencia de Conectividad</h1>
                    <p className="text-muted-foreground mt-2">Ejecute estas pruebas para generar evidencia auditable de la conexión con Supabase.</p>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Server /> 0. Variables de Entorno</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 font-mono text-sm">
                        <div>
                            <p className="font-bold">SUPABASE_URL:</p>
                            <p className="p-2 bg-gray-100 rounded break-all">{SUPABASE_URL}</p>
                        </div>
                        <div>
                            <p className="font-bold">SUPABASE_ANON_KEY (primeros 24 caracteres):</p>
                            <p className="p-2 bg-gray-100 rounded">{SUPABASE_ANON_KEY.substring(0, 24)}...</p>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Database /> 1. Prueba REST (API PostgREST)</CardTitle>
                        <CardDescription>Realiza una inserción usando la API REST de Supabase con `test_id: EVID-CR-REST`.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <CodeSnippet code={restSnippet} />
                        <Button onClick={handleRestTest} disabled={restLoading} className="mt-4">
                            {restLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
                            Ejecutar Prueba REST
                        </Button>
                        <ResultDisplay result={restResult} />
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Database /> 2. Prueba con supabase-js (SDK)</CardTitle>
                        <CardDescription>Realiza una inserción utilizando el SDK oficial con `test_id: EVID-CR-SDK`.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <CodeSnippet code={sdkSnippet} />
                        <Button onClick={handleSdkTest} disabled={sdkLoading} className="mt-4">
                           {sdkLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
                            Ejecutar Prueba con SDK
                        </Button>
                         <ResultDisplay result={sdkResult} />
                    </CardContent>
                </Card>
                
                 <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Cloud /> 3. Prueba de Edge Function</CardTitle>
                        <CardDescription>Invoca una función "echo" que inserta un registro con `source: FUNCTION` y `test_id: EVID-CR-FUNCTION`.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <CodeSnippet code={edgeSnippet} />
                        <Button onClick={handleEdgeFunctionTest} disabled={edgeLoading} className="mt-4">
                           {edgeLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
                            Ejecutar Prueba de Edge Function
                        </Button>
                         <ResultDisplay result={edgeResult} />
                    </CardContent>
                </Card>

            </div>
        </>
    );
};

export default ConnectivityCheckPage;