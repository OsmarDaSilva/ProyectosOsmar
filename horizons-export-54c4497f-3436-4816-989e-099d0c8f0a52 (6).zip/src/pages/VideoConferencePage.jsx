import React from 'react';
    import { useParams } from 'react-router-dom';
    import { JitsiMeeting } from '@jitsi/react-sdk';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import LoadingScreen from '@/components/LoadingScreen';
    import { Helmet } from 'react-helmet-async';

    const VideoConferencePage = () => {
      const { roomName } = useParams();
      const { user } = useAuth();

      if (!user) {
        return <LoadingScreen message="Autenticando..." />;
      }

      return (
        <>
            <Helmet>
                <title>Reunión: {roomName} - AGRO invest</title>
            </Helmet>
            <div style={{ height: '100vh', width: '100vw', display: 'flex', flexDirection: 'column' }}>
            <JitsiMeeting
                roomName={roomName}
                userInfo={{
                displayName: user.email,
                email: user.email,
                }}
                configOverwrite={{
                startWithAudioMuted: false,
                startWithVideoMuted: false,
                prejoinPageEnabled: false,
                }}
                interfaceConfigOverwrite={{
                DEFAULT_BACKGROUND: '#474747',
                SHOW_CHROME_EXTENSION_BANNER: false,
                }}
                getIFrameRef={(iframe) => {
                iframe.style.height = '100%';
                iframe.style.width = '100%';
                iframe.style.border = 'none';
                }}
            />
            </div>
        </>
      );
    };

    export default VideoConferencePage;