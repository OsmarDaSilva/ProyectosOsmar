import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tractor } from 'lucide-react';
import AgricultureForm from '@/components/AgricultureForm';
import { initialSafraData } from '@/utils/agricultureCalculations';
import { useTranslation } from 'react-i18next';

const AgriculturalSimulationPage = () => {
    const { t } = useTranslation('simulations');
    const [simulationData, setSimulationData] = useState(null);

    useEffect(() => {
        const defaultData = {
            isEnabled: true,
            cultivos: [
              { id: 1, isEnabled: true, name: t('agriculture.safra1'), traditional: { ...initialSafraData, cultura: 'Soja', hectareas: '400', produccionHa: 2.8, precioVenta: 350, costoInsumosHa: 400, costoMaquinariasHa: 150, costoManutencionHa: 30, costoFletesTon: 7, costoEnergiaElectricaHa: 5, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '20' }, tecnified: { ...initialSafraData, cultura: 'Soja', hectareas: '400', produccionHa: 5, precioVenta: 350, costoInsumosHa: 500, costoMaquinariasHa: 170, costoManutencionHa: 60, costoFletesTon: 7, costoEnergiaElectricaHa: 100, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '30' } },
              { id: 2, isEnabled: true, name: t('agriculture.safra2'), traditional: { ...initialSafraData, cultura: 'Maíz', hectareas: '400', produccionHa: 5, precioVenta: 150, costoInsumosHa: 400, costoMaquinariasHa: 140, costoManutencionHa: 30, costoFletesTon: 7, costoEnergiaElectricaHa: 5, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '90' }, tecnified: { ...initialSafraData, cultura: 'Maíz', hectareas: '400', produccionHa: 10, precioVenta: 150, costoInsumosHa: 650, costoMaquinariasHa: 170, costoManutencionHa: 60, costoFletesTon: 7, costoEnergiaElectricaHa: 110, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '150' } },
              { id: 3, isEnabled: false, name: t('agriculture.safra3'), traditional: { ...initialSafraData, cultura: 'Frijol', hectareas: '400', impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '15' }, tecnified: { ...initialSafraData, cultura: 'Frijol', hectareas: '400', produccionHa: 2.5, precioVenta: 800, costoInsumosHa: 200, costoMaquinariasHa: 200, costoManutencionHa: 60, costoFletesTon: 7, costoEnergiaElectricaHa: 110, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '25' } },
            ]
        };
        setSimulationData(defaultData);
    }, [t]);

    const handleSimulationUpdate = (updatedData) => {
        setSimulationData(updatedData);
    };
    
    if (!simulationData) {
        return <div>{t('loading.simulator')}</div>;
    }

    return (
        <>
            <Helmet>
                <title>{t('agricultural')} - AGROinvest</title>
                <meta name="description" content={t('agDesc')} />
            </Helmet>
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                <div className="space-y-6">
                    <header>
                        <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
                            <Tractor className="h-8 w-8 text-yellow-600" />
                            {t('agricultural')}
                        </h1>
                        <p className="text-muted-foreground mt-1">
                            {t('agDesc')}
                        </p>
                    </header>

                    <div className="grid grid-cols-1 gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>{t('cropConfig')}</CardTitle>
                                <CardDescription>
                                    {t('cropConfigDesc')}
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <AgricultureForm 
                                    initialData={simulationData} 
                                    onUpdate={handleSimulationUpdate} 
                                />
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AgriculturalSimulationPage;