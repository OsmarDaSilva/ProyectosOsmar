import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { investmentSeedData } from '@/data/investmentSeedData';
import { formatCurrency, exportToExcel, parseCurrency, cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, FileDown, AlertTriangle, LandPlot, PlusCircle, Trash2, Copy, Rows, ChevronsRightLeft } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useDebounce } from '@/hooks/useDebounce';
import { v4 as uuidv4 } from 'uuid';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePersistentState } from '@/hooks/usePersistentState';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const EditableCell = ({ value, onSave, density }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [currentValue, setCurrentValue] = useState(value);

    useEffect(() => {
        setCurrentValue(value);
    }, [value]);

    const handleSave = () => {
        onSave(currentValue);
        setIsEditing(false);
    };

    if (isEditing) {
        return (
            <Input
                value={currentValue}
                onChange={(e) => setCurrentValue(e.target.value)}
                onBlur={handleSave}
                onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                autoFocus
                className={cn("h-8", density === 'compact' && "h-9 px-2 text-sm")}
            />
        );
    }

    return (
        <div onClick={() => setIsEditing(true)} className="cursor-pointer min-h-[32px] flex items-center">
            {value}
        </div>
    );
};

const InvestmentSection = ({ t, title, items, onUpdate, onAddItem, onDeleteItem, onDuplicateItem, currency, density }) => {
    const subtotal = useMemo(() => items.reduce((acc, item) => item.enabled ? acc + (item.quantity * item.unit_price_usd) : acc, 0), [items]);

    return (
        <Card className="mb-6">
            <Accordion type="single" collapsible defaultValue="item-1">
                <AccordionItem value="item-1">
                    <AccordionTrigger className="px-6">
                        <div className="flex justify-between items-center w-full">
                            <h3 className="text-xl font-semibold">{title}</h3>
                            <span className="text-lg font-bold text-green-700">{formatCurrency(subtotal, currency)}</span>
                        </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-6">
                        <div className={cn("w-full", density === 'compact' && "lg:hidden")}>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead className="w-[80px]">{t('investments.table.enabled')}</TableHead>
                                        <TableHead>{t('investments.table.description')}</TableHead>
                                        <TableHead className="w-[150px] text-right">{t('investments.table.quantity')}</TableHead>
                                        <TableHead className="w-[200px] text-right">{t('investments.table.unitPrice')}</TableHead>
                                        <TableHead className="w-[200px] text-right">{t('investments.table.subtotal')}</TableHead>
                                        <TableHead className="w-[100px] text-right">{t('investments.table.actions')}</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {items.map((item) => (
                                        <TableRow key={item.id} className={!item.enabled ? 'opacity-50' : ''}>
                                            <TableCell><Switch checked={item.enabled} onCheckedChange={(checked) => onUpdate({ ...item, enabled: checked })} /></TableCell>
                                            <TableCell>
                                                <EditableCell value={item.description} onSave={(newDesc) => onUpdate({ ...item, description: newDesc })} />
                                            </TableCell>
                                            <TableCell>
                                                <Input type="text" value={item.quantity} onChange={(e) => onUpdate({ ...item, quantity: parseCurrency(e.target.value) })} className="text-right" disabled={!item.enabled} />
                                            </TableCell>
                                            <TableCell>
                                                <Input type="text" value={item.unit_price_usd} onChange={(e) => onUpdate({ ...item, unit_price_usd: parseCurrency(e.target.value) })} className="text-right" disabled={!item.enabled} />
                                            </TableCell>
                                            <TableCell className="text-right font-medium">{formatCurrency(item.quantity * item.unit_price_usd, currency)}</TableCell>
                                            <TableCell className="text-right">
                                                <Button variant="ghost" size="icon" onClick={() => onDuplicateItem(item)}><Copy className="h-4 w-4" /></Button>
                                                <Button variant="ghost" size="icon" onClick={() => onDeleteItem(item.id)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                        <div className={cn("hidden", density === 'compact' && "lg:block")}>
                            <div className="grid grid-cols-[auto,1fr,120px,160px,160px,80px] gap-x-3 items-center border-b pb-2 mb-2">
                                <div className="font-medium text-muted-foreground text-sm">{t('investments.table.enabled')}</div>
                                <div className="font-medium text-muted-foreground text-sm">{t('investments.table.description')}</div>
                                <div className="font-medium text-muted-foreground text-sm text-right">{t('investments.table.quantity')}</div>
                                <div className="font-medium text-muted-foreground text-sm text-right">{t('investments.table.unitPrice')}</div>
                                <div className="font-medium text-muted-foreground text-sm text-right">{t('investments.table.subtotal')}</div>
                                <div className="font-medium text-muted-foreground text-sm text-right">{t('investments.table.actions')}</div>
                            </div>
                            <div className="space-y-1">
                                {items.map((item) => (
                                    <div key={item.id} className={cn("grid grid-cols-[auto,1fr,120px,160px,160px,80px] gap-x-3 items-center py-1 rounded-md", !item.enabled && 'opacity-50', item.enabled && 'hover:bg-accent')}>
                                        <Switch checked={item.enabled} onCheckedChange={(checked) => onUpdate({ ...item, enabled: checked })} className="scale-90" />
                                        <EditableCell value={item.description} onSave={(newDesc) => onUpdate({ ...item, description: newDesc })} density={density} />
                                        <Input type="text" value={item.quantity} onChange={(e) => onUpdate({ ...item, quantity: parseCurrency(e.target.value) })} className="h-9 px-2 text-sm text-right" disabled={!item.enabled} />
                                        <Input type="text" value={item.unit_price_usd} onChange={(e) => onUpdate({ ...item, unit_price_usd: parseCurrency(e.target.value) })} className="h-9 px-2 text-sm text-right" disabled={!item.enabled} />
                                        <div className="text-right text-sm font-medium">{formatCurrency(item.quantity * item.unit_price_usd, currency)}</div>
                                        <div className="text-right">
                                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onDuplicateItem(item)}><Copy className="h-4 w-4" /></Button>
                                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onDeleteItem(item.id)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="mt-4">
                            <Button variant="outline" onClick={onAddItem}>
                                <PlusCircle className="mr-2 h-4 w-4" />
                                {t('investments.actions.addItem')}
                            </Button>
                        </div>
                    </AccordionContent>
                </AccordionItem>
            </Accordion>
        </Card>
    );
};

const InvestmentsPage = () => {
    const { t } = useTranslation('calculator');
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const { user } = useAuth();
    const { activeClientProject } = useProjectData();
    const projectId = activeClientProject?.project.id;
    const [investments, setInvestments] = useState([]);
    const [isSaving, setIsSaving] = useState(false);
    const [density, setDensity] = usePersistentState('investmentsDensity', 'normal');

    const debouncedInvestments = useDebounce(investments, 500);

    const { data: fetchedData, isLoading: isLoadingInvestments, isError } = useQuery({
        queryKey: ['project_investments', projectId],
        queryFn: async () => {
            const { data, error } = await supabase.from('project_investments').select('*').eq('project_id', projectId).order('order_index');
            if (error) throw new Error(error.message);
            if (data && data.length > 0) return data;
            
            const seedWithIds = investmentSeedData.map(item => ({ ...item, id: uuidv4(), project_id: projectId, user_id: user.id }));
            return seedWithIds;
        },
        enabled: !!projectId && !!user,
    });

    useEffect(() => {
        if (fetchedData) {
            setInvestments(fetchedData);
        }
    }, [fetchedData]);

    const upsertMutation = useMutation({
        mutationFn: async (item) => {
            const { data, error } = await supabase.rpc('upsert_investment_item', { p_item: item });
            if (error) throw error;
            return data;
        },
        onMutate: async (updatedItem) => {
            await queryClient.cancelQueries({ queryKey: ['project_investments', projectId] });
            const previousInvestments = queryClient.getQueryData(['project_investments', projectId]);
            queryClient.setQueryData(['project_investments', projectId], old => old ? old.map(item => item.id === updatedItem.id ? updatedItem : item) : [updatedItem]);
            return { previousInvestments };
        },
        onError: (err, newItem, context) => {
            queryClient.setQueryData(['project_investments', projectId], context.previousInvestments);
            toast({ variant: 'destructive', title: t('investments.alerts.saveError'), description: err.message });
        },
        onSettled: () => {
            queryClient.invalidateQueries({ queryKey: ['project_investments', projectId] });
            setIsSaving(false);
        },
    });

    const deleteMutation = useMutation({
        mutationFn: (itemId) => supabase.rpc('delete_investment_item', { p_item_id: itemId }),
        onMutate: async (itemId) => {
            await queryClient.cancelQueries({ queryKey: ['project_investments', projectId] });
            const previousInvestments = queryClient.getQueryData(['project_investments', projectId]);
            queryClient.setQueryData(['project_investments', projectId], old => old ? old.filter(item => item.id !== itemId) : []);
            return { previousInvestments };
        },
        onError: (err, newItem, context) => {
            queryClient.setQueryData(['project_investments', projectId], context.previousInvestments);
            toast({ variant: 'destructive', title: t('investments.alerts.deleteError'), description: err.message });
        },
        onSettled: () => {
            queryClient.invalidateQueries({ queryKey: ['project_investments', projectId] });
        },
    });

    useEffect(() => {
        if (debouncedInvestments && debouncedInvestments.length > 0 && JSON.stringify(debouncedInvestments) !== JSON.stringify(fetchedData)) {
            setIsSaving(true);
            debouncedInvestments.forEach(item => {
                if (!item.project_id && projectId) {
                    item.project_id = projectId;
                }
                if(!item.user_id && user) {
                    item.user_id = user.id;
                }
                const originalItem = fetchedData?.find(i => i.id === item.id);
                if (JSON.stringify(item) !== JSON.stringify(originalItem)) {
                    upsertMutation.mutate(item);
                }
            });
        }
    }, [debouncedInvestments, fetchedData, projectId, user, upsertMutation]);

    const handleUpdate = useCallback((updatedItem) => {
        setInvestments(prev => prev.map(item => item.id === updatedItem.id ? updatedItem : item));
    }, []);

    const handleAddItem = useCallback((category) => {
        const newItem = {
            id: uuidv4(),
            project_id: projectId,
            user_id: user.id,
            category,
            description: 'Nuevo Ítem',
            enabled: true,
            quantity: 1,
            unit_price_usd: 0,
            order_index: (investments.filter(i => i.category === category).length),
            is_custom: true,
        };
        setInvestments(prev => [...prev, newItem]);
        upsertMutation.mutate(newItem);
    }, [projectId, investments, user, upsertMutation]);

    const handleDeleteItem = useCallback((itemId) => {
        setInvestments(prev => prev.filter(item => item.id !== itemId));
        deleteMutation.mutate(itemId);
    }, [deleteMutation]);

    const handleDuplicateItem = useCallback((itemToDuplicate) => {
        const newItem = {
            ...itemToDuplicate,
            id: uuidv4(),
            user_id: user.id,
            description: `${itemToDuplicate.description} (Copia)`,
            order_index: itemToDuplicate.order_index + 1,
        };
        setInvestments(prev => {
            const index = prev.findIndex(i => i.id === itemToDuplicate.id);
            const newArray = [...prev];
            newArray.splice(index + 1, 0, newItem);
            return newArray;
        });
        upsertMutation.mutate(newItem);
    }, [upsertMutation, user]);

    const handleExport = () => {
        const dataToExport = investments
          .filter(item => item.enabled)
          .map(item => ({
            Categoria: t(`investments.sections.${item.category}`),
            Descripcion: item.description,
            Cantidad: item.quantity,
            'Precio Unitario (USD)': item.unit_price_usd,
            'Subtotal (USD)': item.quantity * item.unit_price_usd,
          }));
        exportToExcel(dataToExport, `Inversiones_${activeClientProject.project.project_name}`);
    };
    
    const sections = useMemo(() => {
        const categoryOrder = ["land", "infrastructure", "vehicles", "irrigation", "feedlot", "mechanization", "machinery"];
        const grouped = investments.reduce((acc, item) => {
            if (!acc[item.category]) acc[item.category] = [];
            acc[item.category].push(item);
            return acc;
        }, {});
        
        categoryOrder.forEach(cat => {
            if (grouped[cat]) {
                grouped[cat].sort((a, b) => a.order_index - b.order_index);
            }
        });

        return grouped;
    }, [investments]);

    const grandTotal = useMemo(() => investments.reduce((acc, item) => item.enabled ? acc + (item.quantity * item.unit_price_usd) : acc, 0), [investments]);

    if (!projectId) {
        return (
            <div className="container mx-auto p-8">
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{t('investments.alerts.noProject')}</AlertDescription>
                </Alert>
            </div>
        );
    }
    
    if (isLoadingInvestments) {
        return (
          <div className="container mx-auto p-8 space-y-4">
              <Skeleton className="h-12 w-1/3" />
              <Skeleton className="h-8 w-2/3" />
              <Skeleton className="h-40 w-full" />
              <Skeleton className="h-40 w-full" />
              <Skeleton className="h-40 w-full" />
          </div>
        );
    }

    if (isError) {
        return <div className="text-red-500 p-8">{t('common:errorApi')}</div>;
    }

    return (
        <div className="container mx-auto p-4 md:p-8">
            <Card className="mb-6">
              <CardHeader>
                  <div className="flex justify-between items-start">
                      <div>
                          <CardTitle className="flex items-center text-3xl">
                              <LandPlot className="mr-3 h-8 w-8" />
                              {t('investments.title')}
                          </CardTitle>
                          <CardDescription>{t('investments.description')}</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">Densidad:</span>
                          <Select value={density} onValueChange={setDensity}>
                              <SelectTrigger className="w-[140px]">
                                  <SelectValue placeholder="Seleccionar densidad" />
                              </SelectTrigger>
                              <SelectContent>
                                  <SelectItem value="normal">
                                      <div className="flex items-center gap-2"><Rows className="h-4 w-4" /> Normal</div>
                                  </SelectItem>
                                  <SelectItem value="compact">
                                      <div className="flex items-center gap-2"><ChevronsRightLeft className="h-4 w-4" /> Compacto</div>
                                  </SelectItem>
                              </SelectContent>
                          </Select>
                      </div>
                  </div>
              </CardHeader>
            </Card>

            {Object.entries(sections).map(([key, items]) => (
                <InvestmentSection 
                    key={key} 
                    t={t} 
                    title={t(`investments.sections.${key}`)} 
                    items={items} 
                    onUpdate={handleUpdate}
                    onAddItem={() => handleAddItem(key)}
                    onDeleteItem={handleDeleteItem}
                    onDuplicateItem={handleDuplicateItem}
                    currency="USD" 
                    density={density}
                />
            ))}
            
            <div className="mt-8 flex justify-end items-center sticky bottom-0 bg-gray-50/80 backdrop-blur-sm py-4 px-6 rounded-t-lg border-t">
                <div className="flex items-center mr-6">
                    {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    <span className="text-sm text-muted-foreground">{isSaving ? t('investments.actions.saving') : t('investments.actions.saved')}</span>
                </div>
                <div className="text-2xl font-bold mr-6">
                    {t('investments.totals.grandTotal')}: <span className="text-green-700">{formatCurrency(grandTotal, "USD")}</span>
                </div>
                <Button onClick={handleExport} variant="outline" className="mr-2">
                    <FileDown className="mr-2 h-4 w-4" />
                    {t('investments.actions.export')}
                </Button>
            </div>
        </div>
    );
};

export default InvestmentsPage;