import React, { useState, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, Upload, List, Sprout, PlusCircle, RefreshCw, XCircle, Loader2 } from 'lucide-react';
import { ForageDataTable } from '@/components/forage/ForageDataTable';
import { useForageData, useUpsertForageProfile, useDeleteForageProfile } from '@/hooks/useForageData';
import { useCreateImportJob, useImportJobs } from '@/hooks/useImportJobs';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { v4 as uuidv4 } from 'uuid';
import * as xlsx from 'xlsx';

const ForagePageLoader = () => (
    <Card className="shadow-lg">
        <CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader>
        <CardContent><div className="space-y-2"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div></CardContent>
    </Card>
);

const statusMapping = {
  queued: { text: "En Cola", variant: "default" },
  processing: { text: "Procesando", variant: "secondary" },
  completed: { text: "Completado", variant: "success" },
  completed_with_errors: { text: "Con Errores", variant: "destructive" },
  failed: { text: "Fallido", variant: "destructive" },
};

const ImportHistory = ({ jobs, onRefresh, onDownloadErrors, onCancelJob, onResumeJob, isResuming, isCancelling }) => {
  const { t } = useTranslation('common');
  return (
    <Card className="mt-6">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2"><List /> Historial de Importaciones</CardTitle>
        <Button variant="ghost" size="sm" onClick={onRefresh} disabled={isCancelling || isResuming}><RefreshCw className="h-4 w-4" /></Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {(jobs?.length ?? 0) === 0 ? <p className="text-sm text-muted-foreground">No hay importaciones recientes.</p> :
            jobs?.map(job => {
              const { text, variant } = statusMapping[job.status] || { text: 'Desconocido', variant: 'secondary' };
              const summary = job.summary || {};
              const progress = summary.total > 0 ? Math.round(((summary.success + summary.failed) / summary.total) * 100) : (job.status.startsWith('completed') || job.status === 'failed' ? 100 : 0);
              return (
                <div key={job.id} className="p-3 border rounded-lg bg-background">
                  <div className="flex justify-between items-start flex-wrap gap-2">
                    <div className="flex-1 min-w-[200px]">
                      <p className="font-semibold text-sm truncate" title={job.file_path?.split('/').pop()}>{job.file_path?.split('/').pop() || 'Trabajo sin archivo'}</p>
                      <div className="flex items-center gap-2">
                        <Badge variant={variant}>{text}</Badge>
                        <p className="text-xs text-muted-foreground">{new Date(job.created_at).toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {job.status === 'failed' && <Button size="sm" variant="outline" onClick={() => onResumeJob(job.id)} disabled={isResuming}>{isResuming ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />} Reanudar</Button>}
                      {['queued', 'processing'].includes(job.status) && <Button size="sm" variant="destructive" onClick={() => onCancelJob(job.id)} disabled={isCancelling}>{isCancelling ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <XCircle className="mr-2 h-4 w-4" />} Cancelar</Button>}
                      {job.status === 'completed_with_errors' && summary?.errors?.length > 0 && <Button size="sm" variant="outline" onClick={() => onDownloadErrors(job)}><Download className="mr-2 h-4 w-4" /> Errores</Button>}
                    </div>
                  </div>
                  {job.status === 'processing' && summary.total > 0 && (
                    <div className="mt-2">
                      <Progress value={progress} className="w-full" />
                      <p className="text-xs text-muted-foreground text-right mt-1">{summary.success + summary.failed} / {summary.total} filas</p>
                    </div>
                  )}
                  {summary.error && <div className="text-xs mt-2 border-t pt-2"><p className="text-red-600 font-medium">{summary.error}</p></div>}
                  {job.status?.startsWith('completed') && summary && (
                    <div className="text-xs mt-2 border-t pt-2 grid grid-cols-3 gap-2">
                      <p>Total: <span className="font-bold">{summary.total}</span></p>
                      <p className="text-green-600">Éxito: <span className="font-bold">{summary.success}</span></p>
                      <p className="text-red-600">Fallos: <span className="font-bold">{summary.failed}</span></p>
                    </div>
                  )}
                </div>
              );
            })}
        </div>
      </CardContent>
    </Card>
  );
};

const ForageDatabasePage = () => {
  const { t } = useTranslation(['forageDatabase', 'common']);
  const [activeTab, setActiveTab] = useState('data');
  const { user } = useAuth();
  const fileInputRef = useRef(null);
  const { toast } = useToast();
  
  const { data, isLoading, isError, error, refetch } = useForageData(user?.id);
  const { jobs, cancelJob, resumeJob, refetchJobs, isResuming, isCancelling } = useImportJobs(user?.id, 'forage_imports');
  const createJobMutation = useCreateImportJob();
  const upsertMutation = useUpsertForageProfile();
  const deleteMutation = useDeleteForageProfile();

  const [editingRowId, setEditingRowId] = useState(null);

  const handleDownloadTemplate = (format) => {
    let data, fileName;
    if (format === 'wide') {
      data = [{'Tipo de Pastura': 'Ej: BRS Zuri','Forma Producida': 'Regada','País': 'Paraguay','Región': 'Alto Paraná','Ene (ton/ha)': 4.789,'Feb (ton/ha)': 4.033,'Mar (ton/ha)': 2.753,'Abr (ton/ha)': 2.577,'May (ton/ha)': 2.753,'Jun (ton/ha)': 2.501,'Jul (ton/ha)': 2.207,'Ago (ton/ha)': 3.154,'Sep (ton/ha)': 3.200,'Oct (ton/ha)': 3.234,'Nov (ton/ha)': 3.900,'Dic (ton/ha)': 6.129}];
      fileName = 'forraje_formato_ancho.xlsx';
    } else {
      data = [{'Tipo de Pastura': 'Ej: BRS Zuri','Forma Producida': 'Regada','País': 'Paraguay','Región': 'Alto Paraná','Mes': 'Ene','Producción (ton/ha)': 4.789},{'Tipo de Pastura': 'Ej: BRS Zuri','Forma Producida': 'Regada','País': 'Paraguay','Región': 'Alto Paraná','Mes': 'Feb','Producción (ton/ha)': 4.033}];
      fileName = 'forraje_formato_largo.xlsx';
    }
    const worksheet = xlsx.utils.json_to_sheet(data);
    const workbook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(workbook, worksheet, 'Plantilla');
    xlsx.writeFile(workbook, fileName);
  };
  
  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    createJobMutation.mutate({ file, user, jobType: 'forage_imports' }, {
        onSuccess: () => {
          toast({ title: 'Importación iniciada', description: 'Tu archivo se está procesando. Verás el progreso en la sección de historial.' });
          setTimeout(() => refetchJobs(), 1000);
        },
        onError: (err) => toast({ variant: 'destructive', title: 'Error de Importación', description: `No se pudo iniciar: ${err.message}` }),
        onSettled: () => { if (fileInputRef.current) fileInputRef.current.value = null; }
    });
  };

  const downloadErrors = (job) => {
    if (!job.summary?.errors?.length) {
        toast({ title: 'Info', description: 'No hay errores para descargar.' });
        return;
    }
    const errorData = job.summary.errors.map(e => ({ Hoja: e.sheet, Fila: e.row, Columna: e.column, Error: e.error }));
    const ws = xlsx.utils.json_to_sheet(errorData);
    const wb = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, "Errores");
    xlsx.writeFile(wb, `errores_forraje_${job.file_path.split('/').pop().split('.')[0]}.xlsx`);
  };

  const handleAddNew = () => {
    toast({
      variant: 'destructive',
      title: 'Función no disponible',
      description: 'La adición de nuevos perfiles no está disponible para esta vista de solo lectura.',
    });
  };
  const handleSave = (row) => {
    toast({
      variant: 'destructive',
      title: 'Función no disponible',
      description: 'La edición de perfiles no está disponible para esta vista de solo lectura.',
    });
  };
  const handleDelete = (id) => {
    toast({
      variant: 'destructive',
      title: 'Función no disponible',
      description: 'La eliminación de perfiles no está disponible para esta vista de solo lectura.',
    });
  };
  
  return (
    <>
      <Helmet><title>{t('pageTitle')}</title></Helmet>
      <div className="container mx-auto p-4">
        <div className="flex items-center gap-3 mb-6">
            <Sprout className="h-8 w-8 text-green-600" />
            <h1 className="text-3xl font-bold">{t('mainTitle')}</h1>
        </div>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList>
            <TabsTrigger value="data" className="flex items-center gap-2"><List className="h-4 w-4" />Perfiles de Producción</TabsTrigger>
            <TabsTrigger value="import" className="flex items-center gap-2"><Upload className="h-4 w-4" />{t('tabs.import')}</TabsTrigger>
          </TabsList>
          <TabsContent value="data" className="mt-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Perfiles de Producción de Forraje</CardTitle>
                  <Button onClick={handleAddNew} disabled={true}><PlusCircle className="mr-2 h-4 w-4" />Añadir Perfil</Button>
                </div>
              </CardHeader>
              <CardContent>
                <QueryStateWrapper isLoading={isLoading} isError={isError} error={error} data={data} loader={<ForagePageLoader />} onRetry={refetch}>
                  {(forageData) => (
                    <ForageDataTable
                      data={forageData}
                      userId={user.id}
                      editingRowId={editingRowId}
                      setEditingRowId={setEditingRowId}
                      onSave={handleSave}
                      onDelete={handleDelete}
                      onCancelEdit={() => setEditingRowId(null)}
                      isSaving={upsertMutation.isPending}
                      isDeleting={deleteMutation.isPending}
                    />
                  )}
                </QueryStateWrapper>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="import" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">Importar desde Excel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-muted-foreground space-y-2 mb-4">
                    <p>1. Descargue una de las plantillas para asegurar el formato correcto de las columnas.</p>
                    <p>2. Rellene la plantilla con sus datos. Las columnas 'Tipo de Pastura' y 'Forma Producida' son obligatorias.</p>
                    <p>3. Suba el archivo. El sistema **reemplazará todos los datos existentes** con el contenido del archivo.</p>
                </div>
                <div className="flex flex-wrap gap-2">
                    <Button variant="outline" onClick={() => handleDownloadTemplate('wide')}><Download className="mr-2 h-4 w-4" />Plantilla (Ancho)</Button>
                    <Button variant="outline" onClick={() => handleDownloadTemplate('long')}><Download className="mr-2 h-4 w-4" />Plantilla (Largo)</Button>
                    <Button onClick={() => fileInputRef.current?.click()} disabled={createJobMutation.isPending}><Upload className="mr-2 h-4 w-4" />Importar Archivo</Button>
                    <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls, .csv" onChange={handleFileSelect} />
                </div>
              </CardContent>
            </Card>
            <ImportHistory jobs={jobs} onRefresh={() => refetchJobs()} onDownloadErrors={downloadErrors} onCancelJob={(jobId) => cancelJob(jobId)} onResumeJob={(jobId) => resumeJob({ jobId, userId: user.id, jobType: 'forage_imports' })} isResuming={isResuming} isCancelling={isCancelling} />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default ForageDatabasePage;