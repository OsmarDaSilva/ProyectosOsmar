import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import PurchaseOrdersList from '@/components/customer-service/PurchaseOrdersList';
    import { Package, Truck } from 'lucide-react';
    import { useTranslation } from 'react-i18next';
    import { Button } from '@/components/ui/button';
    import { useNavigate } from 'react-router-dom';

    const PurchaseOrdersPage = () => {
      const { t } = useTranslation('support');
      const navigate = useNavigate();

      return (
        <>
          <Helmet>
            <title>{t('purchaseOrderList.title')} - AGROinvest</title>
            <meta name="description" content={t('purchaseOrderList.description')} />
          </Helmet>
          <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
             <div className="flex items-center justify-between space-y-2">
                <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
                    <Package className="h-8 w-8 text-primary" />
                    {t('purchaseOrderList.title')}
                </h1>
                <Button onClick={() => navigate('/suppliers')}>
                    <Truck className="mr-2 h-4 w-4" />
                    {t('customerService.manageSuppliers')}
                </Button>
            </div>
            <PurchaseOrdersList />
          </div>
        </>
      );
    };

    export default PurchaseOrdersPage;