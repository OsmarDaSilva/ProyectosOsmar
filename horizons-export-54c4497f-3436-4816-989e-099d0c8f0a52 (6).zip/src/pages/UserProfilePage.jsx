import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { User, Save } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const UserProfilePage = () => {
    const { toast } = useToast();
    const { user, setUser } = useAuth();
    const queryClient = useQueryClient();

    const [fullName, setFullName] = useState('');
    const [phone, setPhone] = useState('');
    const [role, setRole] = useState('');
    const [email, setEmail] = useState('');

    useEffect(() => {
        if (user) {
            setFullName(user.full_name || '');
            setPhone(user.phone || '');
            setRole(user.role || 'collaborator');
            setEmail(user.email || '');
        }
    }, [user]);

    const updateUserProfileMutation = useMutation({
        mutationFn: async (updatedData) => {
            const { data, error } = await supabase.functions.invoke('update-user-profile', {
                body: { 
                    userId: user.id, 
                    fullName: updatedData.full_name, 
                    phone: updatedData.phone,
                },
            });
            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['users'] });
            setUser(prevUser => ({
                ...prevUser,
                full_name: fullName,
                phone: phone,
            }));
            toast({
                title: "¡Éxito!",
                description: "Tu perfil ha sido actualizado correctamente.",
                className: "bg-green-100 border-green-400"
            });
        },
        onError: (error) => {
            toast({
                variant: "destructive",
                title: "Error al actualizar el perfil",
                description: error.message,
            });
        },
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        updateUserProfileMutation.mutate({ full_name: fullName, phone });
    };

    if (!user) {
        return (
            <div className="flex justify-center items-center h-full text-gray-600">
                Cargando perfil o no autenticado...
            </div>
        );
    }

    return (
        <>
            <Helmet>
                <title>Mi Perfil - AGROinvest</title>
                <meta name="description" content="Edita tu información de perfil y preferencias." />
            </Helmet>
            <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
                <div className="flex items-center justify-between space-y-2">
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
                        <User className="h-7 w-7 text-blue-600" />
                        Mi Perfil
                    </h1>
                </div>

                <Card className="max-w-2xl mx-auto">
                    <CardHeader>
                        <CardTitle>Datos Personales</CardTitle>
                        <CardDescription>
                            Actualiza tu nombre y teléfono. Tu rol solo puede ser modificado por un administrador.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid gap-2">
                                <Label htmlFor="email">Email</Label>
                                <Input id="email" type="email" value={email} disabled />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="full_name">Nombre Completo</Label>
                                <Input
                                    id="full_name"
                                    value={fullName}
                                    onChange={(e) => setFullName(e.target.value)}
                                    placeholder="Tu nombre completo"
                                    disabled={updateUserProfileMutation.isPending}
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="phone">Teléfono</Label>
                                <Input
                                    id="phone"
                                    value={phone}
                                    onChange={(e) => setPhone(e.target.value)}
                                    placeholder="Tu número de teléfono"
                                    disabled={updateUserProfileMutation.isPending}
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="role">Rol</Label>
                                <Select
                                    value={role}
                                    disabled={true}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Tu rol asignado" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="owner">Propietario</SelectItem>
                                        <SelectItem value="admin">Admin</SelectItem>
                                        <SelectItem value="collaborator">Colaborador</SelectItem>
                                    </SelectContent>
                                </Select>
                                <p className="text-sm text-muted-foreground">
                                    Tu rol es gestionado en la sección de Gestión de Usuarios.
                                </p>
                            </div>
                            <Button type="submit" disabled={updateUserProfileMutation.isPending}>
                                {updateUserProfileMutation.isPending ? 'Guardando...' : 'Guardar Cambios'}
                                <Save className="ml-2 h-4 w-4" />
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </>
    );
};

export default UserProfilePage;