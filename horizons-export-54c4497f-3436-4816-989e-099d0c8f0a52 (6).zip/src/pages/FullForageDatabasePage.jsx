import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { PlusCircle, Sprout, ArrowLeft, Upload, Save, XCircle, Edit, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';


const ForagePageLoader = () => (
    <Card className="shadow-lg">
        <CardHeader>
            <Skeleton className="h-8 w-1/2" />
            <Skeleton className="h-4 w-3/4" />
        </CardHeader>
        <CardContent>
            <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
            </div>
        </CardContent>
    </Card>
);

const fetchForageData = async (userId) => {
    if (!userId) return [];
    const { data, error } = await supabase.from('forage_production').select('*').eq('user_id', userId);
    if (error) throw error;
    return data;
};

const normalizeHeader = (header) => {
    if (typeof header !== 'string') return '';
    return header.trim().toLowerCase().replace(/[\s/]+/g, '_');
};

const FullForageDatabasePage = () => {
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const { toast } = useToast();
    const navigate = useNavigate();
    const fileInputRef = useRef(null);

    const [editingRowId, setEditingRowId] = useState(null);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);

    const { data: forageData, isLoading, isError, error, refetch } = useQuery({
        queryKey: ['forageProduction', user?.id],
        queryFn: () => fetchForageData(user.id),
        enabled: !!user,
        staleTime: 1000 * 60 * 5,
    });
    
    const forageMutation = useMutation({
        mutationFn: async (updatedData) => {
            const { error } = await supabase.from('forage_production').upsert(updatedData);
            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['forageProduction', user?.id]);
            setEditingRowId(null);
            toast({ title: '¡Éxito!', description: 'Base de datos de forraje actualizada.', className: 'bg-green-100 border-green-400' });
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error al guardar', description: error.message });
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (rowId) => {
            const { error } = await supabase.from('forage_production').delete().eq('id', rowId);
            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['forageProduction', user?.id]);
            setShowDeleteConfirm(null);
            toast({ title: 'Registro eliminado', description: 'El perfil de pastura ha sido eliminado.' });
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
        },
    });

    const importMutation = useMutation({
        mutationFn: async (file) => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (event) => {
                    try {
                        const data = event.target.result;
                        const workbook = XLSX.read(data, { type: 'binary' });
                        const sheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[sheetName];
                        
                        const json = XLSX.utils.sheet_to_json(worksheet, { header: 1, raw: false, defval: "" });
                        const headers = json[0].map(h => normalizeHeader((h || "").toString()));
                        
                        const findHeaderIndex = (keywords) => {
                            for (const keyword of keywords) {
                                const index = headers.findIndex(h => h.includes(keyword.replace(/[\s/]+/g, '_')));
                                if (index !== -1) return index;
                            }
                            return -1;
                        };

                        const pastureTypeIndex = findHeaderIndex(['tipo_pastura', 'tipo de pastura']);
                        const monthIndex = findHeaderIndex(['mes', 'meses']);
                        const productionIndex = findHeaderIndex(['kg_ms_mes_region', 'kg/ms/mes/region', 'produccion', 'kg ms/ha', 'kg ms ha']);

                        if (pastureTypeIndex === -1) reject(new Error("No se encontró la columna 'Tipo de Pastura' o similar."));
                        if (monthIndex === -1) reject(new Error("No se encontró la columna 'Mes' o similar."));
                        if (productionIndex === -1) reject(new Error("No se encontró la columna de producción ('kg/ms/mes/region' o similar)."));

                        const groupedData = {};
                        const monthsMap = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
                        
                        json.slice(1).forEach(row => {
                            const pastureType = row[pastureTypeIndex];
                            const monthValue = (row[monthIndex] || '').toString().toLowerCase().substring(0, 3);
                            const productionValue = parseFloat(String(row[productionIndex] || '0').replace(',', '.'));
                            const monthNumeric = monthsMap.indexOf(monthValue);

                            if (pastureType && monthNumeric !== -1 && !isNaN(productionValue)) {
                                const key = pastureType;
                                if (!groupedData[key]) {
                                    groupedData[key] = {
                                        id: uuidv4(),
                                        user_id: user.id,
                                        pasture_type: pastureType,
                                        monthly_production: Array(12).fill(0),
                                    };
                                }
                                groupedData[key].monthly_production[monthNumeric] = productionValue;
                            }
                        });
                        
                        const newForageData = Object.values(groupedData);

                        if (newForageData.length === 0) reject(new Error("No se encontraron datos válidos. Verifique el formato."));
                        
                        const upsertPromise = supabase.from('forage_production').delete().eq('user_id', user.id).then(() => {
                           return supabase.from('forage_production').insert(newForageData);
                        });

                        resolve({upsertPromise, count: newForageData.length});

                    } catch (e) { reject(e); }
                };
                reader.readAsBinaryString(file);
            });
        },
        onSuccess: ({count}) => {
            queryClient.invalidateQueries(['forageProduction', user?.id]);
            toast({ title: '¡Importación Exitosa!', description: `${count} perfiles de pastura importados.`, className: 'bg-green-100 border-green-400' });
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error de Importación', description: error.message });
        },
        onSettled: () => {
          if (fileInputRef.current) fileInputRef.current.value = null;
        }
    });

    const handleAddNew = () => {
        const newRow = {
            id: uuidv4(),
            user_id: user.id,
            pasture_type: 'Nueva Pastura',
            monthly_production: Array(12).fill(0),
        };
        queryClient.setQueryData(['forageProduction', user?.id], old => [newRow, ...(old || [])]);
        setEditingRowId(newRow.id);
    };

    const handleCancelEdit = (id) => {
        if (id.startsWith('new-')) {
            queryClient.setQueryData(['forageProduction', user?.id], old => old.filter(row => row.id !== id));
        }
        setEditingRowId(null);
    };

    const handleSave = (rowData) => {
        const updatedData = forageData.map(row => (row.id === rowData.id ? rowData : row));
        forageMutation.mutate(updatedData);
    };

    const handleDelete = (rowId) => deleteMutation.mutate(rowId);
    
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

    const EditableRow = ({ row, onSave, onCancel }) => {
        const [editedRow, setEditedRow] = useState(row);
        const handleChange = (field, value) => setEditedRow({ ...editedRow, [field]: value });
        const handleMonthChange = (index, value) => {
            const newMonthlyProduction = [...editedRow.monthly_production];
            newMonthlyProduction[index] = parseFloat(String(value).replace(',', '.')) || 0;
            setEditedRow({ ...editedRow, monthly_production: newMonthlyProduction });
        };
        return (
            <TableRow className="bg-green-50">
                <TableCell><Input value={editedRow.pasture_type} onChange={(e) => handleChange('pasture_type', e.target.value)} className="h-8" /></TableCell>
                {months.map((_, index) => (
                    <TableCell key={index}><Input type="number" step="0.001" value={editedRow.monthly_production[index]} onChange={(e) => handleMonthChange(index, e.target.value)} className="h-8 w-24" /></TableCell>
                ))}
                <TableCell className="sticky right-0 bg-green-50 z-10">
                    <div className="flex gap-2">
                        <Button size="sm" onClick={() => onSave(editedRow)} disabled={forageMutation.isPending}><Save className="h-4 w-4" /></Button>
                        <Button size="sm" variant="outline" onClick={() => onCancel(row.id)} disabled={forageMutation.isPending}><XCircle className="h-4 w-4" /></Button>
                    </div>
                </TableCell>
            </TableRow>
        );
    };

    const isMutating = forageMutation.isPending || deleteMutation.isPending || importMutation.isPending;

    return (
        <>
            <Helmet><title>Base de Datos de Forraje - AGROinvest</title></Helmet>
            <div className="container mx-auto p-4">
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                    <Card className="shadow-lg">
                        <CardHeader>
                            <div className="flex justify-between items-start flex-wrap gap-4">
                                <div>
                                    <div className="flex items-center gap-3"><Sprout className="h-8 w-8 text-green-600" /><CardTitle className="text-3xl font-bold">Base de Datos de Forraje</CardTitle></div>
                                    <CardDescription className="mt-2">Gestione la producción de materia seca (ton/ha) de sus pasturas.</CardDescription>
                                </div>
                                <div className="flex flex-wrap gap-2 justify-end">
                                    <Button onClick={() => navigate('/')} variant="outline" disabled={isMutating}><ArrowLeft className="mr-2 h-4 w-4" />Volver</Button>
                                    <Button onClick={() => fileInputRef.current.click()} variant="secondary" disabled={isMutating}><Upload className="mr-2 h-4 w-4" />Importar</Button>
                                    <Button onClick={handleAddNew} disabled={isMutating}><PlusCircle className="mr-2 h-4 w-4" />Añadir Perfil</Button>
                                    <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls" onChange={(e) => importMutation.mutate(e.target.files[0])} />
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <QueryStateWrapper isLoading={isLoading} isError={isError} error={error} data={forageData} loader={<ForagePageLoader />} onRetry={refetch}>
                                {(data) => (
                                    data && <div className="overflow-x-auto">
                                        <Table>
                                            <TableHeader><TableRow><TableHead>Tipo de Pastura</TableHead>{months.map(month => <TableHead key={month} className="text-center">{month}</TableHead>)}<TableHead className="sticky right-0 bg-white z-10">Acciones</TableHead></TableRow></TableHeader>
                                            <TableBody>
                                                {data.length === 0 ? (
                                                    <TableRow><TableCell colSpan={14} className="text-center h-24">No hay datos. Puede añadir un perfil o importar una planilla.</TableCell></TableRow>
                                                ) : (
                                                    data.map(row => (
                                                        editingRowId === row.id ? (
                                                            <EditableRow key={row.id} row={row} onSave={handleSave} onCancel={handleCancelEdit} />
                                                        ) : (
                                                            <TableRow key={row.id}>
                                                                <TableCell className="font-medium">{row.pasture_type}</TableCell>
                                                                {row.monthly_production.map((prod, index) => <TableCell key={index} className="text-center">{new Intl.NumberFormat('es-PY', { minimumFractionDigits: 3, maximumFractionDigits: 3 }).format(prod)}</TableCell>)}
                                                                <TableCell className="sticky right-0 bg-white z-10">
                                                                    <div className="flex gap-2">
                                                                        <Button size="sm" variant="outline" onClick={() => setEditingRowId(row.id)} disabled={isMutating}><Edit className="h-4 w-4" /></Button>
                                                                        <Button size="sm" variant="destructive" onClick={() => setShowDeleteConfirm(row.id)} disabled={isMutating}><Trash2 className="h-4 w-4" /></Button>
                                                                    </div>
                                                                </TableCell>
                                                            </TableRow>
                                                        )
                                                    ))
                                                )}
                                            </TableBody>
                                        </Table>
                                    </div>
                                )}
                            </QueryStateWrapper>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
            <AlertDialog open={!!showDeleteConfirm} onOpenChange={(open) => !open && setShowDeleteConfirm(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader><AlertDialogTitle>¿Estás seguro?</AlertDialogTitle><AlertDialogDescription>Esta acción eliminará permanentemente el perfil de pastura.</AlertDialogDescription></AlertDialogHeader>
                    <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDelete(showDeleteConfirm)}>Eliminar</AlertDialogAction></AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
};

export default FullForageDatabasePage;