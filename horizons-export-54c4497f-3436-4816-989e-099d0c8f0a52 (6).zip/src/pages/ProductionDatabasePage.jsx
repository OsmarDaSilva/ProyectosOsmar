import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';

import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProductionDatabaseHeader from '@/components/production-database/ProductionDatabaseHeader';
import DataTabContent from '@/components/production-database/DataTabContent';
import ImportTabContent from '@/components/production-database/ImportTabContent';

const ProductionDatabasePage = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const queryKey = ['productionData', user?.id];

  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('public:Produccion_Agricola')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'Produccion_Agricola', filter: `user_id=eq.${user.id}` },
        (payload) => {
          console.log('Change received!', payload);
          queryClient.invalidateQueries({ queryKey });
        }
      )
      .subscribe((status, err) => {
        if (err) console.error("Subscription error:", err);
      });
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient, queryKey]);

  return (
    <>
      <Helmet>
        <title>Base de Datos de Producción - AGROinvest</title>
        <meta name="description" content="Gestione y analice datos históricos de producción agrícola." />
      </Helmet>
      <div className="container mx-auto p-4">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <ProductionDatabaseHeader />
          <Tabs defaultValue="data" className="w-full">
            <TabsList>
              <TabsTrigger value="data">Datos</TabsTrigger>
              <TabsTrigger value="import">Importación</TabsTrigger>
            </TabsList>
            <TabsContent value="data" className="mt-4">
              <DataTabContent />
            </TabsContent>
            <TabsContent value="import" className="mt-4">
              <ImportTabContent />
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </>
  );
};

export default ProductionDatabasePage;