import React, { useState, useMemo, useCallback } from 'react';
import { Helmet } from 'react-helmet-async';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Plus, Calendar, CheckCircle, AlertCircle, ArrowLeft, Search, LayoutGrid, CalendarDays, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LoadingScreen from '@/components/LoadingScreen';
import AddEditActivityDialog from '@/components/pipeline/AddEditActivityDialog';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';

const fetchActivities = async () => {
  const { data, error } = await supabase
    .from('activities')
    .select('*, client:client_id(id, name), deal:deal_id(id, title)')
    .order('due_date', { ascending: true });
  if (error) throw error;
  return data;
};

const fetchClients = async () => {
  const { data, error } = await supabase.from('clients').select('id, name');
  if (error) throw error;
  return data;
};

const fetchDeals = async () => {
  const { data, error } = await supabase.from('deals').select('id, title, client_id');
  if (error) throw error;
  return data;
};

const ActivityCard = ({ activity, onEdit, onToggleComplete }) => (
    <Card className="mb-4 cursor-pointer hover:shadow-md transition-shadow" onClick={() => onEdit(activity)}>
      <CardContent className="p-4 flex justify-between items-center">
        <div className="flex-1 overflow-hidden">
          <p className="font-semibold truncate">{activity.type}: {activity.notes?.substring(0, 30) || 'Sin notas'}{activity.notes?.length > 30 ? '...' : ''}</p>
          <p className="text-sm text-muted-foreground truncate">{activity.client?.name || 'Sin cliente'}</p>
          {activity.due_date && (
            <p className="text-sm text-muted-foreground">
              Vence: {format(parseISO(activity.due_date), "PPP 'a las' p", { locale: es })}
            </p>
          )}
        </div>
        <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onToggleComplete(activity); }}>
          {activity.is_completed ? <CheckCircle className="text-green-500 h-6 w-6" /> : <div className="w-6 h-6 rounded-full border-2 border-gray-400" />}
        </Button>
      </CardContent>
    </Card>
);

const ActivitiesPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState(null);
  const [dialogDefaults, setDialogDefaults] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'calendar'
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({ type: 'all', client: 'all' });

  const { data: activities, isLoading: isLoadingActivities, isError: isErrorActivities, error: errorActivities, refetch: refetchActivities } = useQuery({
    queryKey: ['activities'],
    queryFn: fetchActivities,
    enabled: !!user,
  });

  const { data: clients } = useQuery({ queryKey: ['clients'], queryFn: fetchClients, enabled: !!user });
  const { data: deals } = useQuery({ queryKey: ['deals'], queryFn: fetchDeals, enabled: !!user });

  const activityMutation = useMutation({
    mutationFn: async (activityData) => {
      const activityToSave = { ...activityData, user_id: user.id, updated_at: new Date().toISOString() };
      if (!activityToSave.id) activityToSave.created_at = new Date().toISOString();
      const { error } = await supabase.from('activities').upsert(activityToSave);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['activities'] });
      toast({ title: 'Actividad guardada', description: 'La actividad ha sido guardada exitosamente.' });
      setIsDialogOpen(false);
      setEditingActivity(null);
      setDialogDefaults(null);
    },
    onError: (error) => toast({ variant: 'destructive', title: 'Error al guardar', description: error.message })
  });

  const toggleCompleteMutation = useMutation({
    mutationFn: async (activity) => {
      const { error } = await supabase.from('activities').update({ is_completed: !activity.is_completed, updated_at: new Date().toISOString() }).eq('id', activity.id);
      if (error) throw error;
      return activity;
    },
    onSuccess: (activity) => {
      queryClient.invalidateQueries({ queryKey: ['activities'] });
      toast({ title: `Actividad ${activity.is_completed ? 'marcada como pendiente' : 'completada'}` });
    },
    onError: (error) => toast({ variant: 'destructive', title: 'Error al actualizar', description: error.message })
  });

  const handleSaveActivity = async (activityData) => {
    try {
      await activityMutation.mutateAsync(activityData);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleAddNew = () => {
    setEditingActivity(null);
    setDialogDefaults(null);
    setIsDialogOpen(true);
  };

  const handleEdit = (activity) => {
    setEditingActivity(activity);
    setDialogDefaults(null);
    setIsDialogOpen(true);
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  const filteredActivities = useMemo(() => {
    if (!activities) return [];
    return activities.filter(a => {
      const typeMatch = filters.type === 'all' || a.type === filters.type;
      const clientMatch = filters.client === 'all' || a.client_id === filters.client;
      const searchMatch = searchTerm === '' || 
        a.notes?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.client?.name?.toLowerCase().includes(searchTerm.toLowerCase());
      return typeMatch && clientMatch && searchMatch;
    });
  }, [activities, filters, searchTerm]);

  const upcomingActivities = filteredActivities.filter(a => !a.is_completed && a.due_date && new Date(a.due_date) >= new Date());
  const overdueActivities = filteredActivities.filter(a => !a.is_completed && a.due_date && new Date(a.due_date) < new Date());
  const completedActivities = filteredActivities.filter(a => a.is_completed);

  const calendarEvents = useMemo(() => {
    return activities?.map(a => ({
      id: a.id,
      title: `${a.type}: ${a.client?.name || 'Sin cliente'}`,
      start: a.due_date ? parseISO(a.due_date) : new Date(),
      allDay: !a.due_date?.includes('T'),
      extendedProps: { ...a },
      backgroundColor: a.is_completed ? '#10B981' : (new Date(a.due_date) < new Date() ? '#EF4444' : '#3B82F6'),
      borderColor: a.is_completed ? '#059669' : (new Date(a.due_date) < new Date() ? '#DC2626' : '#2563EB'),
    })) || [];
  }, [activities]);

  const handleEventClick = (clickInfo) => {
    handleEdit(clickInfo.event.extendedProps);
  };

  const handleDateSelect = (selectInfo) => {
    setEditingActivity(null);
    setDialogDefaults({ due_date: selectInfo.startStr });
    setIsDialogOpen(true);
  };

  const handleEventDrop = async (dropInfo) => {
    const { id } = dropInfo.event;
    const newDueDate = dropInfo.event.start.toISOString();
    await activityMutation.mutateAsync({ id, due_date: newDueDate });
  };

  const ACTIVITY_TYPES = ['Llamada', 'Reunión', 'Tarea', 'Email'];

  return (
    <>
      <Helmet><title>Actividades - AGROinvest</title></Helmet>
      <div className="p-4 sm:p-6 lg:p-8 flex flex-col h-full">
        <header className="flex flex-wrap justify-between items-center gap-4 mb-6">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <Calendar className="h-8 w-8 text-blue-600" />
              Mis Actividades
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant={viewMode === 'list' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('list')}><LayoutGrid /></Button>
            <Button variant={viewMode === 'calendar' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('calendar')}><CalendarDays /></Button>
            <Button onClick={handleAddNew} disabled={activityMutation.isPending}>
              <Plus className="mr-2 h-4 w-4" /> Nueva Actividad
            </Button>
          </div>
        </header>

        {viewMode === 'list' && (
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input placeholder="Buscar actividad..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-10" />
            </div>
            <Select value={filters.type} onValueChange={v => handleFilterChange('type', v)}>
              <SelectTrigger className="w-full sm:w-[180px]"><SelectValue placeholder="Filtrar por tipo" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los tipos</SelectItem>
                {ACTIVITY_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.client} onValueChange={v => handleFilterChange('client', v)}>
              <SelectTrigger className="w-full sm:w-[180px]"><SelectValue placeholder="Filtrar por cliente" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los clientes</SelectItem>
                {clients?.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="ghost" onClick={() => { setSearchTerm(''); setFilters({ type: 'all', client: 'all' }); }}><X className="h-4 w-4 mr-2" /> Limpiar</Button>
          </div>
        )}

        <QueryStateWrapper
          isLoading={isLoadingActivities} isError={isErrorActivities} error={errorActivities} data={activities}
          loader={<LoadingScreen message="Cargando actividades..." />} onRetry={refetchActivities}
        >
          {viewMode === 'list' ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card><CardHeader><CardTitle className="flex items-center gap-2"><AlertCircle className="text-red-500" /> Vencidas ({overdueActivities.length})</CardTitle></CardHeader><CardContent>{overdueActivities.length > 0 ? overdueActivities.map(a => <ActivityCard key={a.id} activity={a} onEdit={handleEdit} onToggleComplete={toggleCompleteMutation.mutate} />) : <p className="text-muted-foreground">Sin actividades vencidas.</p>}</CardContent></Card>
              <Card><CardHeader><CardTitle className="flex items-center gap-2"><Calendar className="text-blue-500" /> Próximas ({upcomingActivities.length})</CardTitle></CardHeader><CardContent>{upcomingActivities.length > 0 ? upcomingActivities.map(a => <ActivityCard key={a.id} activity={a} onEdit={handleEdit} onToggleComplete={toggleCompleteMutation.mutate} />) : <p className="text-muted-foreground">Sin actividades próximas.</p>}</CardContent></Card>
              <Card><CardHeader><CardTitle className="flex items-center gap-2"><CheckCircle className="text-green-500" /> Completadas ({completedActivities.length})</CardTitle></CardHeader><CardContent>{completedActivities.length > 0 ? completedActivities.map(a => <ActivityCard key={a.id} activity={a} onEdit={handleEdit} onToggleComplete={toggleCompleteMutation.mutate} />) : <p className="text-muted-foreground">Sin actividades completadas.</p>}</CardContent></Card>
            </div>
          ) : (
            <Card className="flex-grow">
              <CardContent className="p-4 h-full">
                <FullCalendar
                  plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
                  headerToolbar={{ left: 'prev,next today', center: 'title', right: 'dayGridMonth,timeGridWeek,timeGridDay' }}
                  initialView="dayGridMonth"
                  events={calendarEvents}
                  locale={es}
                  editable={true}
                  selectable={true}
                  selectMirror={true}
                  dayMaxEvents={true}
                  select={handleDateSelect}
                  eventClick={handleEventClick}
                  eventDrop={handleEventDrop}
                  height="100%"
                />
              </CardContent>
            </Card>
          )}
        </QueryStateWrapper>
      </div>

      <AddEditActivityDialog
        isOpen={isDialogOpen}
        setIsOpen={setIsDialogOpen}
        onSave={handleSaveActivity}
        activity={editingActivity}
        clients={clients || []}
        deals={deals || []}
        defaults={dialogDefaults}
      />
    </>
  );
};

export default ActivitiesPage;