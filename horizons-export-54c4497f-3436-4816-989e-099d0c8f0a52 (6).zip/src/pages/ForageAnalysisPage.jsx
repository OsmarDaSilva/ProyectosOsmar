import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BarChart, Leaf, AlertCircle } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useForageData as useForageDataQuery } from '@/hooks/useForageData';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ForageAnalysisContent } from '@/components/intensive-pasture/ForageAnalysisContent';

const ForageAnalysisLoader = () => (
    <div className="space-y-4">
        <Skeleton className="h-12 w-1/3" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-64 w-full" />
    </div>
);

const ForageAnalysisPage = () => {
    const { t } = useTranslation('intensivePasture');
    const { user } = useAuth();
    const { data: forageData, isLoading: isLoadingForage, isError, error, refetch } = useForageDataQuery(user?.id);
    const navigate = useNavigate();

    return (
        <>
            <Helmet>
                <title>{t('title')} - AGROinvest</title>
                <meta name="description" content={t('description')} />
            </Helmet>
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                <div className="space-y-6">
                    <header>
                        <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100 flex items-center gap-3">
                            <Leaf className="h-8 w-8 text-green-600" />
                            {t('title')}
                        </h1>
                        <p className="text-muted-foreground mt-1">
                            {t('description')}
                        </p>
                    </header>
                    
                    <Card>
                        <CardHeader>
                            <div className="flex items-center gap-3">
                                <BarChart className="h-6 w-6 text-green-600" />
                                <CardTitle>{t('simulatorTitle')}</CardTitle>
                            </div>
                            <CardDescription>
                                {t('simulatorDescription')}
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                             <QueryStateWrapper
                                isLoading={isLoadingForage}
                                isError={isError}
                                error={error}
                                data={forageData}
                                loader={<ForageAnalysisLoader />}
                                onRetry={refetch}
                            >
                                {(data) => {
                                    if (!data || data.length === 0) {
                                        return (
                                            <Alert>
                                                <AlertCircle className="h-4 w-4" />
                                                <AlertTitle>{t('noProfilesTitle')}</AlertTitle>
                                                <AlertDescription>
                                                    {t('noProfilesDescription')}
                                                    <Button variant="link" className="p-0 h-auto ml-2" onClick={() => navigate('/forage-database')}>
                                                        {t('goToDatabase')}
                                                    </Button>
                                                </AlertDescription>
                                            </Alert>
                                        );
                                    }
                                    return <ForageAnalysisContent forageData={data} />;
                                }}
                            </QueryStateWrapper>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </>
    );
};

export default ForageAnalysisPage;