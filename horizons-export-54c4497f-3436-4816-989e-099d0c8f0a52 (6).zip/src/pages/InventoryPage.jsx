import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Warehouse, Plus, Minus, ArrowRightLeft, FileUp } from 'lucide-react';
import AddStockMovementDialog from '@/components/inventory/AddStockMovementDialog';
import TransferStockDialog from '@/components/inventory/TransferStockDialog';
import ImportStockDialog from '@/components/inventory/ImportStockDialog';
import ManageWarehousesDialog from '@/components/inventory/ManageWarehousesDialog';
import StockTable from '@/components/inventory/StockTable';
import ManualMovementsTable from '@/components/inventory/ManualMovementsTable';
import FlowVerificationPanel from '@/components/inventory/FlowVerificationPanel';
import { supabase } from '@/lib/supabase-helpers';

const InventoryPage = () => {
    const { toast } = useToast();
    const queryClient = useQueryClient();

    const [isMovementDialogOpen, setIsMovementDialogOpen] = useState(false);
    const [movementType, setMovementType] = useState('IN');
    const [isTransferDialogOpen, setIsTransferDialogOpen] = useState(false);
    const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
    const [isWarehouseDialogOpen, setIsWarehouseDialogOpen] = useState(false);

    const { data: warehouses } = useQuery({
        queryKey: ['warehouses'],
        queryFn: async () => {
            const { data, error } = await supabase.from('deposits').select('*');
            if (error) throw error;
            return data;
        },
    });

    const movementMutation = useMutation({
        mutationFn: async (moveData) => {
            const { error } = await supabase.from('stock_moves').insert([moveData]);
            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['inventory_stock'] });
            queryClient.invalidateQueries({ queryKey: ['inventory', 'kardex'] });
            toast({ title: 'Éxito', description: 'Movimiento de stock registrado.' });
            setIsMovementDialogOpen(false);
            setIsTransferDialogOpen(false);
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo registrar el movimiento: ${error.message}`});
        }
    });

    const handleOpenMovementDialog = (type) => {
        setMovementType(type);
        setIsMovementDialogOpen(true);
    };

    return (
        <>
            <Helmet>
                <title>Inventario - AGROinvest</title>
                <meta name="description" content="Gestione su inventario, stock por depósito, movimientos manuales y más." />
            </Helmet>
            <div className="p-4 sm:p-6 lg:p-8 space-y-6">
                <header className="flex flex-wrap justify-between items-center gap-4">
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
                        <Warehouse className="h-8 w-8 text-primary" />
                        Inventario
                    </h1>
                    <div className="flex flex-wrap items-center gap-2">
                        <Button variant="outline" onClick={() => setIsImportDialogOpen(true)}><FileUp className="mr-2 h-4 w-4" /> Importar Stock</Button>
                        <Button variant="outline" onClick={() => setIsWarehouseDialogOpen(true)}>Gestionar Depósitos</Button>
                    </div>
                </header>
                
                <FlowVerificationPanel />

                <Card>
                    <CardHeader>
                        <CardTitle>Operaciones Manuales de Stock</CardTitle>
                        <CardDescription>Registre entradas, salidas o transferencias de productos que no provienen de un flujo de compra/venta.</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-wrap gap-2">
                        <Button onClick={() => handleOpenMovementDialog('IN')}><Plus className="mr-2 h-4 w-4" /> Entrada</Button>
                        <Button variant="secondary" onClick={() => handleOpenMovementDialog('OUT')}><Minus className="mr-2 h-4 w-4" /> Salida/Ajuste</Button>
                        <Button variant="secondary" onClick={() => setIsTransferDialogOpen(true)}><ArrowRightLeft className="mr-2 h-4 w-4" /> Transferencia</Button>
                    </CardContent>
                </Card>

                <Tabs defaultValue="stock">
                    <TabsList>
                        <TabsTrigger value="stock">Stock por Depósito</TabsTrigger>
                        <TabsTrigger value="manual_moves">Kardex de Movimientos</TabsTrigger>
                    </TabsList>
                    <TabsContent value="stock">
                        <Card>
                            <CardHeader>
                                <CardTitle>Vista de Stock Actual</CardTitle>
                                <CardDescription>Consulte el stock disponible en sus depósitos.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <StockTable />
                            </CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="manual_moves">
                        <ManualMovementsTable />
                    </TabsContent>
                </Tabs>
            </div>
            
            <AddStockMovementDialog 
                isOpen={isMovementDialogOpen}
                onOpenChange={setIsMovementDialogOpen}
                movementType={movementType}
                warehouses={warehouses}
                mutation={movementMutation}
            />

            <TransferStockDialog
                isOpen={isTransferDialogOpen}
                onOpenChange={setIsTransferDialogOpen}
                warehouses={warehouses}
                mutation={movementMutation}
            />
            
            <ImportStockDialog
                isOpen={isImportDialogOpen}
                onOpenChange={setIsImportDialogOpen}
                warehouses={warehouses}
            />

            <ManageWarehousesDialog
                isOpen={isWarehouseDialogOpen}
                onOpenChange={setIsWarehouseDialogOpen}
            />
        </>
    );
};

export default InventoryPage;