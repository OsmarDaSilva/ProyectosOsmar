import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, FileArchive } from 'lucide-react';
import DocumentCategoryTab from '@/components/clients/project-tabs/DocumentCategoryTab';

const documentCategories = [
    { slug: 'disenos', label: 'Diseños de Proyectos' },
    { slug: 'ficha_tecnica', label: 'Ficha Técnica (equipos/instalación)' },
    { slug: 'carta_aspersion', label: 'Carta de Aspersión' },
    { slug: 'cotizaciones', label: 'Cotizaciones' },
    { slug: 'entrega_tecnica', label: 'Entrega Técnica' },
    { slug: 'docs_adicionales', label: 'Documentos Adicionales' },
    { slug: 'ordenes_servicio', label: 'Órdenes de Servicio' },
    { slug: 'mantenimientos', label: 'Mantenimientos' },
];

const fetchProjectInfo = async (projectId) => {
    const { data, error } = await supabase
        .from('client_projects')
        .select('project_name, clients(name)')
        .eq('id', projectId)
        .single();
    if (error) throw error;
    return data;
};

const ProjectDocumentsPage = () => {
    const { projectId } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();

    const [activeCategory, setActiveCategory] = useState(documentCategories[0]);

    const { data: projectInfo, isLoading: isProjectInfoLoading } = useQuery({
        queryKey: ['projectInfo', projectId],
        queryFn: () => fetchProjectInfo(projectId),
    });

    useEffect(() => {
        console.info('build: HORIZONS-20250831-FINAL-FIX');
    }, []);

    if (isProjectInfoLoading || !user) {
        return (
            <div className="p-8 space-y-6">
                <Skeleton className="h-10 w-1/2" />
                <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6">
                    <Skeleton className="h-96 w-full" />
                    <Skeleton className="h-screen w-full" />
                </div>
            </div>
        );
    }

    return (
        <>
            <Helmet>
                <title>Documentos de {projectInfo?.project_name || 'Proyecto'} - AGROinvest</title>
            </Helmet>
            <div className="p-4 sm:p-6 lg:p-8 space-y-6">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Button variant="outline" size="icon" onClick={() => navigate('/clients')}>
                            <ArrowLeft className="h-4 w-4" />
                        </Button>
                        <div>
                            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
                                <FileArchive /> Documentación del Proyecto
                            </h1>
                            <p className="text-muted-foreground">{projectInfo?.project_name} ({projectInfo?.clients?.name})</p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-6 items-start">
                    <Card>
                        <CardHeader>
                            <CardTitle>Categorías</CardTitle>
                        </CardHeader>
                        <CardContent className="p-2">
                            <nav className="flex flex-col gap-1">
                                {documentCategories.map(cat => (
                                    <Button
                                        key={cat.slug}
                                        variant={activeCategory.slug === cat.slug ? 'secondary' : 'ghost'}
                                        className="w-full justify-start"
                                        onClick={() => setActiveCategory(cat)}
                                    >
                                        {cat.label}
                                    </Button>
                                ))}
                            </nav>
                        </CardContent>
                    </Card>

                    <div className="h-full">
                       <DocumentCategoryTab key={activeCategory.slug} category={activeCategory} />
                    </div>
                </div>
            </div>
        </>
    );
};

export default ProjectDocumentsPage;