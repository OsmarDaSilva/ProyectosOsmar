import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { FileText, Wrench, Truck } from 'lucide-react';
    import QuotesList from '@/components/customer-service/QuotesList';
    import ServiceOrdersList from '@/components/customer-service/ServiceOrdersList';
    import { useNavigate } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { useTranslation } from 'react-i18next';

    const CustomerServicePage = () => {
      const { t } = useTranslation('support');
      const navigate = useNavigate();

      return (
        <>
          <Helmet>
            <title>{t('customerService.pageTitle')} - AGROinvest</title>
            <meta name="description" content={t('customerService.pageDescription')} />
          </Helmet>
          <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
            <div className="flex items-center justify-between space-y-2">
              <h1 className="text-3xl font-bold tracking-tight">{t('customerService.pageTitle')}</h1>
              <Button onClick={() => navigate('/suppliers')}>
                <Truck className="mr-2 h-4 w-4" />
                {t('customerService.manageSuppliers')}
              </Button>
            </div>

            <Tabs defaultValue="service-orders" className="space-y-4">
              <TabsList>
                <TabsTrigger value="service-orders">
                  <Wrench className="mr-2 h-4 w-4" />
                  {t('customerService.serviceOrders')}
                </TabsTrigger>
                <TabsTrigger value="quotes">
                  <FileText className="mr-2 h-4 w-4" />
                  {t('customerService.quotes')}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="service-orders" className="space-y-4">
                <ServiceOrdersList />
              </TabsContent>
              <TabsContent value="quotes" className="space-y-4">
                <QuotesList />
              </TabsContent>
            </Tabs>
          </div>
        </>
      );
    };

    export default CustomerServicePage;