import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useProjectData } from '@/contexts/ProjectDataContext';
import ChartsView from '@/components/ChartsView';
import { AlertTriangle } from 'lucide-react';

const ChartsPage = () => {
    const { projectData, agricultureData, ganaderiaData } = useProjectData();

    const hasDataForAnalysis =
        projectData &&
        (!projectData.modules?.agricultura || (agricultureData && Array.isArray(agricultureData.cultivos) && agricultureData.cultivos.length > 0)) &&
        (!projectData.modules?.ganaderia || (ganaderiaData && Object.keys(ganaderiaData).length > 0 && ganaderiaData.isEnabled));

    return (
        <>
            <Helmet>
                <title>Gráficos del Proyecto - AGROinvest</title>
                <meta name="description" content="Visualización de los indicadores clave del proyecto a través de gráficos interactivos." />
            </Helmet>
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
                {hasDataForAnalysis ? (
                    <ChartsView 
                        projectData={projectData} 
                        agricultureData={agricultureData} 
                        ganaderiaData={ganaderiaData}
                    />
                ) : (
                    <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
                        <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                        <h2 className="text-2xl font-bold text-gray-800">Datos Insuficientes</h2>
                        <p className="text-gray-600 text-lg mt-2">
                          No se pueden generar los gráficos.
                        </p>
                        <p className="text-gray-500 mt-1">
                          Por favor, asegúrate de que los datos del proyecto y los módulos habilitados estén completos y correctos.
                        </p>
                    </div>
                )}
            </div>
        </>
    );
};

export default ChartsPage;