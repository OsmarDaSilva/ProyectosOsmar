import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import CalculatorNavbar from '@/components/layout/CalculatorNavbar';
import PageContent from '@/components/layout/PageContent';
import { useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import InvestmentsPage from '@/pages/InvestmentsPage'; // Import the new page

const viewMap = {
    '': 'inicial',
    'project': 'inicial',
    'resumen-ejecutivo': 'resumen',
    'analisis-viabilidad': 'viabilidad',
    'graficos': 'graficos',
    'analisis-financiero': 'analisis',
    'agricultura': 'agricultura',
    'ganaderia': 'ganaderia',
    'balance-carbono': 'carbono',
    'inversiones': 'inversiones', // Add the new view
};

const CalculatorPage = () => {
    const { t } = useTranslation('calculator');
    const location = useLocation();
    
    const getViewFromPath = (pathname) => {
        const pathSegments = pathname.split('/').filter(Boolean);
        const lastSegment = pathSegments[pathSegments.length - 1];
        if (lastSegment === 'calculator') return 'inicial';
        return viewMap[lastSegment] || 'inicial';
    };

    const [currentView, setCurrentView] = useState(getViewFromPath(location.pathname));

    useEffect(() => {
        setCurrentView(getViewFromPath(location.pathname));
    }, [location.pathname]);

    // Special rendering for the new InvestmentsPage
    if (currentView === 'inversiones') {
        return (
            <>
                <Helmet>
                    <title>{t('investments.title')} - AGROinvest</title>
                    <meta name="description" content={t('investments.description')} />
                </Helmet>
                <div className="flex flex-col h-full bg-gray-50">
                    <CalculatorNavbar />
                    <InvestmentsPage />
                </div>
            </>
        );
    }
    
    return (
        <>
            <Helmet>
                <title>{t('pageTitle')} - AGROinvest</title>
                <meta name="description" content={t('pageDescription')} />
            </Helmet>
            <div className="flex flex-col h-full bg-gray-50">
                <CalculatorNavbar />
                <div className="flex-grow overflow-y-auto">
                    <PageContent currentView={currentView} />
                </div>
            </div>
        </>
    );
};

export default CalculatorPage;