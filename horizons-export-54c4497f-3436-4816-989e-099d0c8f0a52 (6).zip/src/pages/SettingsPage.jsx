import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, Bell, Shield, Building, Terminal } from 'lucide-react';
import UserManagement from '@/components/UserManagement';
import AlertSettingsDialog from '@/components/notifications/AlertSettingsDialog';
import AlertAssignmentRules from '@/components/settings/AlertAssignmentRules';
import CompanySettings from '@/components/settings/CompanySettings';
import SystemLogs from '@/components/settings/SystemLogs';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const SettingsPage = () => {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin' || profile?.role === 'owner';

  return (
    <>
      <Helmet>
        <title>Configuración - AGROinvest</title>
        <meta name="description" content="Gestione la configuración de su cuenta, usuarios, notificaciones y más." />
      </Helmet>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Configuración</h1>
        </div>

        <Tabs defaultValue="company" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
            <TabsTrigger value="company">
              <Building className="mr-2 h-4 w-4" />
              Empresa
            </TabsTrigger>
            <TabsTrigger value="users">
              <User className="mr-2 h-4 w-4" />
              Usuarios
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="mr-2 h-4 w-4" />
              Alertas
            </TabsTrigger>
            {isAdmin && (
              <TabsTrigger value="logs">
                <Terminal className="mr-2 h-4 w-4" />
                Logs
              </TabsTrigger>
            )}
            <TabsTrigger value="security">
              <Shield className="mr-2 h-4 w-4" />
              Seguridad
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="company" className="space-y-4">
            <CompanySettings />
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <UserManagement />
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <AlertSettingsDialog isPage={true} />
              <AlertAssignmentRules />
            </div>
          </TabsContent>
          
          {isAdmin && (
            <TabsContent value="logs" className="space-y-4">
              <SystemLogs />
            </TabsContent>
          )}

          <TabsContent value="security" className="space-y-4">
            <p>Configuraciones de seguridad (Próximamente).</p>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default SettingsPage;