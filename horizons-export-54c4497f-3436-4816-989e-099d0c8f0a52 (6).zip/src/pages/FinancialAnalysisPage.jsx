import React from 'react';
import { Helmet } from 'react-helmet-async';
import FinancialAnalysis from '@/components/FinancialAnalysis';

const FinancialAnalysisPage = () => {
  return (
    <>
      <Helmet>
        <title>Análisis Financiero - AGROinvest</title>
        <meta name="description" content="Análisis detallado del flujo de caja y la viabilidad financiera de su proyecto." />
      </Helmet>
      <div className="container mx-auto p-4">
        <FinancialAnalysis />
      </div>
    </>
  );
};

export default FinancialAnalysisPage;