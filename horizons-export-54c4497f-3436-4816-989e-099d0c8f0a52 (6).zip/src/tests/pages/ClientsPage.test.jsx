import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import { ProjectDataProvider } from '@/contexts/ProjectDataContext';
import { Toaster } from '@/components/ui/toaster';
import ClientsPage from '@/pages/ClientsPage';

vi.mock('@/lib/customSupabaseClient', () => ({
  supabase: {
    from: vi.fn().mockReturnValue({
      select: vi.fn().mockResolvedValue({ data: [], error: null }),
      insert: vi.fn().mockResolvedValue({ data: [{}], error: null }),
      upsert: vi.fn().mockResolvedValue({ data: [{id: 'new-client-id', name: 'Test Client'}], error: null, select: vi.fn().mockReturnThis(), single: vi.fn().mockReturnThis() }),
      delete: vi.fn().mockResolvedValue({ error: null }),
      order: vi.fn().mockReturnThis(),
    }),
    functions: {
      invoke: vi.fn().mockResolvedValue({ data: [], error: null }),
    },
    rpc: vi.fn().mockResolvedValue({ data: [], error: null }),
  },
}));

vi.mock('@/contexts/SupabaseAuthContext', async () => {
    const original = await vi.importActual('@/contexts/SupabaseAuthContext');
    return {
      ...original,
      useAuth: () => ({
        user: { id: 'test-user-id' },
        session: 'test-session',
        loading: false,
      }),
    };
});

const queryClient = new QueryClient();

const renderWithProviders = (ui) => {
  return render(
    <BrowserRouter>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <ProjectDataProvider>
            {ui}
            <Toaster />
          </ProjectDataProvider>
        </AuthProvider>
      </QueryClientProvider>
    </BrowserRouter>
  );
};

describe('ClientsPage', () => {
  it('should render the clients page and allow creating a new client', async () => {
    const { supabase } = await import('@/lib/customSupabaseClient');
    renderWithProviders(<ClientsPage />);

    expect(screen.getByText('Gestión de Clientes y Proyectos')).toBeInTheDocument();

    fireEvent.click(screen.getByText('Nuevo Cliente'));

    await waitFor(() => {
      expect(screen.getByText('Añadir Nuevo Cliente')).toBeInTheDocument();
    });

    fireEvent.change(screen.getByLabelText('Nombre del Cliente'), { target: { value: 'Nuevo Cliente de Prueba' } });
    fireEvent.change(screen.getByLabelText('RUC/CI'), { target: { value: '1234567-8' } });

    supabase.from().upsert().select().single.mockResolvedValue({ data: { id: '123', name: 'Nuevo Cliente de Prueba' }, error: null });

    fireEvent.click(screen.getByRole('button', { name: 'Guardar Cliente' }));
    
    await waitFor(() => {
        expect(supabase.from).toHaveBeenCalledWith('clients');
        expect(supabase.from().upsert).toHaveBeenCalled();
    });

  });
});