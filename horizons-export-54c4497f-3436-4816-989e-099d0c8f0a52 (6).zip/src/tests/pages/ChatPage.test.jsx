import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import { Toaster } from '@/components/ui/toaster';
import ChatPage from '@/pages/ChatPage';

vi.mock('@/lib/customSupabaseClient', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn().mockResolvedValue({ data: [], error: null }),
      insert: vi.fn().mockResolvedValue({ data: [{}], error: null }),
    })),
    channel: vi.fn(() => ({
      on: vi.fn().mockReturnThis(),
      subscribe: vi.fn(),
      unsubscribe: vi.fn(),
    })),
    removeChannel: vi.fn(),
    functions: {
        invoke: vi.fn().mockResolvedValue({ data: [], error: null })
    },
    rpc: vi.fn().mockResolvedValue({ data: [], error: null }),
  },
}));

vi.mock('@/contexts/SupabaseAuthContext', async () => {
  const originalModule = await vi.importActual('@/contexts/SupabaseAuthContext');
  return {
    ...originalModule,
    useAuth: () => ({
      user: { id: 'test-user-id', email: 'test@example.com' },
      session: { access_token: 'test-token' },
      loading: false,
    }),
  };
});

const queryClient = new QueryClient();

const renderWithProviders = (ui) => {
  return render(
    <BrowserRouter>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          {ui}
          <Toaster />
        </AuthProvider>
      </QueryClientProvider>
    </BrowserRouter>
  );
};

describe('ChatPage', () => {
  it('sends and displays a message', async () => {
    const { supabase } = await import('@/lib/customSupabaseClient');
    const mockChannels = [{ id: 'channel-1', name: 'General', description: 'Canal general' }];
    const mockMessages = [];

    supabase.from.mockImplementation((tableName) => {
        if (tableName === 'channels') {
            return { select: vi.fn().mockResolvedValue({ data: mockChannels, error: null }) };
        }
        if (tableName === 'messages') {
            return { 
                select: vi.fn().mockResolvedValue({ data: mockMessages, error: null }),
                insert: vi.fn((newMessage) => {
                    mockMessages.push(newMessage[0]);
                    // Simulate realtime update
                    queryClient.setQueryData(['messages', 'channel-1'], (old) => [...(old || []), newMessage[0]]);
                    return Promise.resolve({ data: [newMessage], error: null });
                })
            };
        }
        return { select: vi.fn().mockResolvedValue({ data: [], error: null }) };
    });

    renderWithProviders(<ChatPage />);
    
    await waitFor(() => {
        expect(screen.getByText('General')).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText('General'));
    
    await waitFor(() => {
        expect(screen.getByPlaceholderText('Escribe un mensaje...')).toBeInTheDocument();
    });
    
    const input = screen.getByPlaceholderText('Escribe un mensaje...');
    const sendButton = screen.getByRole('button', { name: /send/i });

    fireEvent.change(input, { target: { value: 'Hello, world!' } });
    fireEvent.click(sendButton);

    await waitFor(() => {
      expect(screen.getByText('Hello, world!')).toBeInTheDocument();
    });
  });
});