import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import ProductCatalogTable from '@/components/catalog/ProductCatalogTable';

// Mocking hooks and components
vi.mock('@/hooks/useProductCatalog', () => ({
  useProductCatalog: vi.fn(() => ({
    data: {
      data: [
        { sku: 'SKU001', product_name: 'Test Product 1', brand: 'Test Brand', price: 100, purchase_price: 50, updated_at: new Date().toISOString() },
        { sku: 'SKU002', product_name: 'Test Product 2', brand: 'Test Brand', price: 200, purchase_price: 100, updated_at: new Date().toISOString() },
      ],
      totalPages: 1,
      count: 2,
    },
    isLoading: false,
    isError: false,
  })),
  useDeleteProduct: vi.fn(() => ({ mutateAsync: vi.fn() })),
  useDuplicateProduct: vi.fn(() => ({ mutateAsync: vi.fn() })),
}));

vi.mock('@/contexts/SupabaseAuthContext', async () => {
  const originalModule = await vi.importActual('@/contexts/SupabaseAuthContext');
  return {
    ...originalModule,
    useAuth: () => ({
      user: { id: 'test-user-id' },
      session: { access_token: 'test-token' },
      loading: false,
    }),
  };
});

vi.mock('@/components/ui/use-toast', () => ({
  useToast: () => ({ toast: vi.fn() }),
}));

const queryClient = new QueryClient();

const renderWithProviders = (ui) => {
  return render(
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        {ui}
      </AuthProvider>
    </QueryClientProvider>
  );
};

describe('ProductCatalogTable', () => {
  it('renders the table with product data', async () => {
    renderWithProviders(<ProductCatalogTable onEdit={() => {}} />);

    // Wait for the products to be displayed
    await waitFor(() => {
      expect(screen.getByText('Test Product 1')).toBeInTheDocument();
      expect(screen.getByText('Test Product 2')).toBeInTheDocument();
    });

    // Check for SKU
    expect(screen.getByText('SKU001')).toBeInTheDocument();
    expect(screen.getByText('SKU002')).toBeInTheDocument();

    // Check for price
    expect(screen.getByText('$ 100,00')).toBeInTheDocument();
    expect(screen.getByText('$ 200,00')).toBeInTheDocument();
  });

  it('shows a message when no products are found', async () => {
    const { useProductCatalog } = await import('@/hooks/useProductCatalog');
    useProductCatalog.mockImplementation(() => ({
      data: { data: [], totalPages: 0, count: 0 },
      isLoading: false,
      isError: false,
    }));

    renderWithProviders(<ProductCatalogTable onEdit={() => {}} />);

    await waitFor(() => {
      expect(screen.getByText('No se encontraron resultados.')).toBeInTheDocument();
    });
  });

  it('shows an error message on fetch error', async () => {
    const { useProductCatalog } = await import('@/hooks/useProductCatalog');
    useProductCatalog.mockImplementation(() => ({
      data: null,
      isLoading: false,
      isError: true,
      error: new Error('Failed to fetch'),
    }));

    renderWithProviders(<ProductCatalogTable onEdit={() => {}} />);

    await waitFor(() => {
      expect(screen.getByText('Error: Failed to fetch')).toBeInTheDocument();
    });
  });
});