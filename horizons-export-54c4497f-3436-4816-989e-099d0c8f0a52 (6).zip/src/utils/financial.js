export const parseNum = (val) => {
    if (typeof val === 'number') return val;
    if (typeof val !== 'string') return 0;
    const cleanedString = val.trim();
    if (cleanedString === '') return 0;
    const hasDot = cleanedString.includes('.');
    const hasComma = cleanedString.includes(',');

    if (hasDot && hasComma) {
        if (cleanedString.lastIndexOf('.') < cleanedString.lastIndexOf(',')) {
            return parseFloat(cleanedString.replace(/\./g, '').replace(',', '.')) || 0;
        }
        return parseFloat(cleanedString.replace(/,/g, '')) || 0;
    }

    if (hasComma) {
        return parseFloat(cleanedString.replace(',', '.')) || 0;
    }

    return parseFloat(cleanedString) || 0;
};

export const parsePercentage = (val) => {
    if (typeof val !== 'string' && typeof val !== 'number') return 0;
    const s = String(val).replace('%', '').trim();
    return parseNum(s) / 100;
};

export const calculateIRR = (cashFlows) => {
    if (!cashFlows || cashFlows.length === 0 || cashFlows.every(c => c === 0)) {
        return 0;
    }
    try {
        let guess = 0.1;
        let iterations = 0;
        const maxIterations = 100;
        const tolerance = 1e-7;
        let npv = 0;

        do {
            npv = cashFlows.reduce((acc, val, i) => acc + val / Math.pow(1 + guess, i), 0);
            const derivative = cashFlows.reduce((acc, val, i) => {
                if (i === 0) return acc;
                return acc - i * val / Math.pow(1 + guess, i + 1);
            }, 0);

            if (Math.abs(derivative) < tolerance) {
                break; 
            }
            
            guess = guess - npv / derivative;
            iterations++;
        } while (Math.abs(npv) > tolerance && iterations < maxIterations);

        if (iterations >= maxIterations || !isFinite(guess)) {
            return 'N/A';
        }
        return guess;
    } catch (e) {
        return 'Error';
    }
};

export const calculateNPV = (cashFlows, rate) => {
    if (!cashFlows || cashFlows.length === 0) return 0;
    return cashFlows.reduce((acc, val, i) => acc + val / Math.pow(1 + rate, i), 0);
};