export const initialSafraData = {
      cultura: '',
      hectareas: '0',
      produccionHa: '0',
      precioVenta: '0',
      costoInsumosHa: '0',
      costoMaquinariasHa: '0',
      costoManutencionHa: '0',
      costoFletesTon: '0',
      costoEnergiaElectricaHa: '0',
      impuestosIrragroPct: '0%',
      impuestoRentaIRPPct: '0%',
      dosis_n: '0',
    };

    const parseNum = (val) => {
        if (typeof val === 'number') return val;
        if (typeof val !== 'string') return 0;
        
        const cleanedString = val.trim();
        if (cleanedString === '') return 0;

        const hasDot = cleanedString.includes('.');
        const hasComma = cleanedString.includes(',');

        if (hasDot && hasComma) {
            if (cleanedString.lastIndexOf('.') < cleanedString.lastIndexOf(',')) {
                return parseFloat(cleanedString.replace(/\./g, '').replace(',', '.')) || 0;
            }
            return parseFloat(cleanedString.replace(/,/g, '')) || 0;
        }

        if (hasComma) {
            return parseFloat(cleanedString.replace(',', '.')) || 0;
        }

        return parseFloat(cleanedString) || 0;
    };

    const parsePercentage = (val) => {
        if (typeof val !== 'string') return 0;
        return parseNum(val.replace('%', '')) / 100;
    };

    export const calculateSafra = (data) => {
      if (!data) {
        return { ...initialSafraData, totalProduccionAreaTon: 0, totalVentasIngresos: 0, totalCostosEgresos: 0, costosPromedioHa: 0, gananciaNetaArea: 0, impuestosIrragro: 0, impuestoRentaIRP: 0, gananciaLiquidaFinalArea: 0, rentabilidadSobreFacturacion: 0, gananciaPorHectarea: 0, impuestoTotal: 0 };
      }

      const hectareas = parseNum(data.hectareas);
      const produccionHa = parseNum(data.produccionHa);
      const precioVenta = parseNum(data.precioVenta);
      const costoInsumosHa = parseNum(data.costoInsumosHa);
      const costoMaquinariasHa = parseNum(data.costoMaquinariasHa);
      const costoManutencionHa = parseNum(data.costoManutencionHa);
      const costoFletesTon = parseNum(data.costoFletesTon);
      const costoEnergiaElectricaHa = parseNum(data.costoEnergiaElectricaHa);
      const impuestosIrragroPct = parsePercentage(data.impuestosIrragroPct);
      const impuestoRentaIRPPct = parsePercentage(data.impuestoRentaIRPPct);
      const dosis_n = parseNum(data.dosis_n);


      const totalProduccionAreaTon = hectareas * produccionHa;
      const totalVentasIngresos = totalProduccionAreaTon * precioVenta;

      const costoInsumosTotal = costoInsumosHa * hectareas;
      const costoMaquinariasTotal = costoMaquinariasHa * hectareas;
      const costoManutencionTotal = costoManutencionHa * hectareas;
      const costoFletesTotal = costoFletesTon * totalProduccionAreaTon;
      const costoEnergiaElectricaTotal = costoEnergiaElectricaHa * hectareas;

      const totalCostosEgresos = costoInsumosTotal + costoMaquinariasTotal + costoManutencionTotal + costoFletesTotal + costoEnergiaElectricaTotal;
      const costosPromedioHa = hectareas > 0 ? totalCostosEgresos / hectareas : 0;
      const gananciaNetaArea = totalVentasIngresos - totalCostosEgresos;

      const impuestosIrragro = totalVentasIngresos * impuestosIrragroPct;
      const baseImponibleIRP = gananciaNetaArea - impuestosIrragro;
      const impuestoRentaIRP = baseImponibleIRP > 0 ? baseImponibleIRP * impuestoRentaIRPPct : 0;
      const impuestoTotal = impuestosIrragro + impuestoRentaIRP;
      const gananciaLiquidaFinalArea = gananciaNetaArea - impuestoTotal;
      const rentabilidadSobreFacturacion = totalVentasIngresos > 0 ? (gananciaLiquidaFinalArea / totalVentasIngresos) : 0;
      const gananciaPorHectarea = hectareas > 0 ? gananciaLiquidaFinalArea / hectareas : 0;

      return {
        hectareas,
        dosis_n,
        totalProduccionAreaTon,
        totalVentasIngresos,
        costoInsumosTotal,
        costoMaquinariasTotal,
        costoManutencionTotal,
        costoFletesTotal,
        costoEnergiaElectricaTotal,
        totalCostosEgresos,
        costosPromedioHa,
        gananciaNetaArea,
        impuestosIrragro,
        impuestoRentaIRP,
        impuestoTotal,
        gananciaLiquidaFinalArea,
        rentabilidadSobreFacturacion,
        gananciaPorHectarea,
        produccionHa,
      };
    };