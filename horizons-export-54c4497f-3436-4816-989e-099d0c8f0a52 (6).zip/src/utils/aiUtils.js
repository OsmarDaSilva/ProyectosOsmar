import { supabase } from "@/lib/customSupabaseClient";

    export async function genericResolver({ query }) {
      return {
        answer: "No he podido encontrar una respuesta específica para tu consulta. Intenta reformular tu pregunta o busca en la Base de Conocimiento.",
        sources: [],
        actions: [{ type: 'navigate', label: 'Buscar en Base de Conocimiento', payload: { path: '/knowledge-base' } }],
        debug: { resolver: 'genericResolver', query },
      };
    }