import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import AlertDetailDialog from '@/components/notifications/AlertDetailDialog';

const CriticalAlerts = () => {
    const { user } = useAuth();
    const [selectedAlert, setSelectedAlert] = useState(null);

    const { data: alerts, isLoading, isError, error } = useQuery({
        queryKey: ['allCriticalAlerts', user?.id],
        queryFn: async () => {
            if (!user) return [];
            const { data, error } = await supabase
                .from('alerts')
                .select('*, client:clients(name)')
                .eq('is_resolved', false)
                .order('created_at', { ascending: false });
            if (error) throw error;
            return data;
        },
        enabled: !!user,
    });

    const handleAlertClick = (alert) => {
        setSelectedAlert(alert);
    };

    const handleDialogClose = () => {
        setSelectedAlert(null);
    };

    const getAlertVariant = (severity) => {
        switch (severity) {
            case 'critical': return 'destructive';
            case 'high': return 'default';
            default: return 'default';
        }
    };
    
    const getAlertClass = (severity) => {
        switch (severity) {
            case 'critical': return 'bg-red-50 border-red-200 text-red-800 dark:bg-red-900/20 dark:border-red-700/40 dark:text-red-400';
            case 'high': return 'bg-yellow-50 border-yellow-200 text-yellow-800 dark:bg-yellow-900/20 dark:border-yellow-700/40 dark:text-yellow-400';
            default: return 'bg-blue-50 border-blue-200 text-blue-800 dark:bg-blue-900/20 dark:border-blue-700/40 dark:text-blue-400';
        }
    };

    if (isLoading) {
        return <Skeleton className="h-24 w-full" />;
    }

    if (isError) {
        return (
            <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>No se pudieron cargar las alertas: {error.message}</AlertDescription>
            </Alert>
        );
    }

    if (!alerts || alerts.length === 0) {
        return (
            <Alert variant="default" className="bg-green-50 border-green-200 text-green-800">
                <div className="flex items-start">
                    <CheckCircle className="h-4 w-4 mt-0.5 text-green-600" />
                    <div className="ml-3">
                        <AlertTitle>Todo en Orden</AlertTitle>
                        <AlertDescription>
                            No hay alertas activas en este momento. ¡Buen trabajo!
                        </AlertDescription>
                    </div>
                </div>
            </Alert>
        );
    }
    
    return (
        <>
            <div className="space-y-4">
                {alerts.map(alert => (
                    <Alert key={alert.id} variant={getAlertVariant(alert.severity)} className={getAlertClass(alert.severity)} onClick={() => handleAlertClick(alert)} style={{cursor: 'pointer'}}>
                        <div className="flex items-start">
                            <div className="pt-0.5"><AlertCircle className="h-4 w-4" /></div>
                            <div className="ml-4">
                                <AlertTitle className="font-bold">{alert.type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</AlertTitle>
                                <AlertDescription>
                                    {alert.description} {alert.client ? `(Cliente: ${alert.client.name})` : ''}
                                </AlertDescription>
                            </div>
                        </div>
                    </Alert>
                ))}
            </div>
            <AlertDetailDialog
                alert={selectedAlert}
                isOpen={!!selectedAlert}
                onOpenChange={handleDialogClose}
            />
        </>
    );
};

export default CriticalAlerts;