import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/lib/customSupabaseClient';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

const ResolvedAlertsWidget = () => {
  const fetchResolvedAlerts = async () => {
    const { data, error } = await supabase
      .from('alerts')
      .select('*, client:clients(name), resolved_by_user:profiles!resolved_by(full_name)')
      .eq('is_resolved', true)
      .order('resolved_at', { ascending: false })
      .limit(5);
      
    if (error) {
      console.error("Error fetching resolved alerts:", error.message);
      throw new Error(error.message);
    }
    return data;
  };

  const { data: alerts, isLoading, isError, error } = useQuery({
    queryKey: ['resolvedAlerts'],
    queryFn: fetchResolvedAlerts,
    retry: 1,
  });

  const getSeverityBadge = (severity) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <Card className="h-full bg-white shadow-md rounded-lg overflow-hidden">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold text-gray-700">
          <CheckCircle2 className="h-6 w-6 text-green-500" />
          Alertas Resueltas Recientemente
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
          </div>
        )}
        {isError && <p className="text-red-500 flex items-center gap-2"><AlertCircle className="h-4 w-4" /> No se pudieron cargar las alertas resueltas. {error?.message}</p>}
        {alerts && alerts.length > 0 && (
          <ul className="space-y-3">
            {alerts.map((alert, index) => (
              <motion.li
                key={alert.id}
                className="p-3 bg-gray-50 rounded-md border border-gray-200"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="font-medium text-gray-800">{alert.description}</p>
                    <p className="text-sm text-gray-500">
                      Cliente: {alert.client?.name || 'N/A'}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Resuelta por: {alert.resolved_by_user?.full_name || 'Sistema'} el {new Date(alert.resolved_at).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant={getSeverityBadge(alert.severity)} className="capitalize ml-2 whitespace-nowrap">
                    {alert.severity}
                  </Badge>
                </div>
              </motion.li>
            ))}
          </ul>
        )}
        {alerts && alerts.length === 0 && (
            <div className="text-center text-gray-500 py-8">
                <CheckCircle2 className="h-12 w-12 mx-auto text-gray-300" />
                <p className="mt-2">No hay alertas resueltas recientemente.</p>
            </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ResolvedAlertsWidget;