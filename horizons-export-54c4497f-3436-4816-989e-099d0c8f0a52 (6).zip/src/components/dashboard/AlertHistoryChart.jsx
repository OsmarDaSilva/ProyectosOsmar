import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { subDays, format, startOfDay } from 'date-fns';
import { es } from 'date-fns/locale';

const fetchAlertHistory = async () => {
    const thirtyDaysAgo = subDays(new Date(), 30);
    const { data, error } = await supabase
        .from('alerts')
        .select('created_at, module')
        .gte('created_at', thirtyDaysAgo.toISOString());

    if (error) throw new Error(error.message);
    return data;
};

const AlertHistoryChart = () => {
    const { data: alerts, isLoading, isError } = useQuery({
        queryKey: ['alertHistory'],
        queryFn: fetchAlertHistory
    });

    const chartData = React.useMemo(() => {
        if (!alerts) return [];

        const dailyData = {};

        // Initialize last 30 days
        for (let i = 29; i >= 0; i--) {
            const date = format(subDays(new Date(), i), 'dd/MM', { locale: es });
            dailyData[date] = { date, Forraje: 0, Agricultura: 0, Ganadería: 0, Finanzas: 0 };
        }

        alerts.forEach(alert => {
            const date = format(startOfDay(new Date(alert.created_at)), 'dd/MM', { locale: es });
            if (dailyData[date]) {
                if (alert.module === 'forage') dailyData[date].Forraje += 1;
                else if (alert.module === 'agriculture') dailyData[date].Agricultura += 1;
                else if (alert.module === 'livestock') dailyData[date].Ganadería += 1;
                else if (alert.module === 'finance') dailyData[date].Finanzas += 1;
            }
        });

        return Object.values(dailyData);
    }, [alerts]);

    if (isLoading) return <div>Cargando historial de alertas...</div>;
    if (isError) return <div>Error al cargar el historial.</div>;

    return (
        <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Legend />
                <Bar dataKey="Forraje" stackId="a" fill="#ea580c" />
                <Bar dataKey="Agricultura" stackId="a" fill="#16a34a" />
                <Bar dataKey="Ganadería" stackId="a" fill="#2563eb" />
                <Bar dataKey="Finanzas" stackId="a" fill="#ca8a04" />
            </BarChart>
        </ResponsiveContainer>
    );
};

export default AlertHistoryChart;