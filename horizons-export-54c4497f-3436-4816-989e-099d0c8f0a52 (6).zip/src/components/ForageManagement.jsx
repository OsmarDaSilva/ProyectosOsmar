import React from 'react';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { useGanaderiaForageAnalysis } from '@/hooks/useGanaderiaForageAnalysis';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ForageBalanceTable } from '@/components/intensive-pasture/ForageBalanceTable';
import { ForageBalanceChart } from '@/components/intensive-pasture/ForageBalanceChart';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Leaf, AlertCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useForageData } from '@/hooks/useForageData';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { normalizeText } from '@/lib/utils';

const ForageManagement = () => {
    const { t } = useTranslation(['forageBalance', 'common']);
    const { ganaderiaData } = useProjectData();
    const { user } = useAuth();
    const { data: forageProfiles, isLoading, isError } = useForageData(user?.id);

    const intensiveParams = ganaderiaData?.intensivo;
    const selectedPastureName = intensiveParams?.tipoPastura;

    const selectedPasture = React.useMemo(() => {
        if (!forageProfiles || !selectedPastureName) return undefined;
        
        const normalizedSelectedPastureName = normalizeText(selectedPastureName);

        return forageProfiles.find(p => {
            const pastureFullName = p.method ? `${p.pasture_type} (${p.method})` : p.pasture_type;
            return normalizeText(pastureFullName) === normalizedSelectedPastureName;
        });
    }, [forageProfiles, selectedPastureName]);

    const { forageBalance } = useGanaderiaForageAnalysis({ ganaderiaData, selectedPasture });

    if (isLoading) {
        return <div>{t('common:loading.data')}</div>;
    }

    if (isError || !ganaderiaData || !intensiveParams) {
        return (
            <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>{t('error.title')}</AlertTitle>
                <AlertDescription>{t('error.noData')}</AlertDescription>
            </Alert>
        );
    }
    
    if (!selectedPasture) {
         return (
            <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>{t('error.pastureNotFoundTitle')}</AlertTitle>
                <AlertDescription>
                    {t('error.pastureNotFoundDescription', { pastureName: selectedPastureName || 'N/A' })}
                </AlertDescription>
            </Alert>
        );
    }

    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Leaf className="text-green-600" />
                        {t('monthlyBalanceDetail')}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <ForageBalanceTable forageBalance={forageBalance} />
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Leaf className="text-green-600" />
                        {t('annualBalanceChart')}
                    </CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                    <ForageBalanceChart data={forageBalance.map(d => ({
                        month: d.month,
                        oferta: d.forageProduction / 1000,
                        demanda: d.animalConsumption / 1000,
                        balanceTon: d.balance / 1000,
                        balancePercentage: d.animalConsumption > 0 ? (d.balance / d.animalConsumption) * 100 : 0
                    }))} />
                </CardContent>
            </Card>
        </div>
    );
};

export default ForageManagement;