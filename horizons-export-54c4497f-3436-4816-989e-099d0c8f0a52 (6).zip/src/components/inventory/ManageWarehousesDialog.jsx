import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useForm, useFieldArray } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Trash2, PlusCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { v4 as uuidv4 } from 'uuid';

const ManageWarehousesDialog = ({ isOpen, onOpenChange }) => {
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();

    const { data: deposits, isLoading } = useQuery({
        queryKey: ['deposits'],
        queryFn: async () => {
            const { data, error } = await supabase.from('deposits').select('*').order('created_at');
            if (error) throw error;
            return data;
        },
        enabled: isOpen,
    });

    const { register, control, handleSubmit, watch, setValue, reset } = useForm({
        defaultValues: { deposits: [] }
    });

    const { fields, append, remove } = useFieldArray({
        control,
        name: "deposits"
    });

    React.useEffect(() => {
        if (deposits) {
            reset({ deposits });
        }
    }, [deposits, reset]);

    const watchedDeposits = watch('deposits');

    const mutation = useMutation({
        mutationFn: async (formData) => {
            const upserts = formData.deposits.map(w => ({
                id: w.id,
                user_id: user.id,
                name: w.name,
                is_default: w.is_default
            }));
            const { error } = await supabase.from('deposits').upsert(upserts);
            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['deposits'] });
            toast({ title: "Éxito", description: "Depósitos actualizados." });
            onOpenChange(false);
        },
        onError: (error) => {
            toast({ variant: "destructive", title: "Error", description: error.message });
        }
    });

    const handleSetDefault = (index) => {
        watchedDeposits.forEach((_, i) => {
            setValue(`deposits.${i}.is_default`, i === index);
        });
    };

    const onSubmit = (data) => {
        mutation.mutate(data);
    };

    const handleAddNewDeposit = () => {
        append({ 
            id: uuidv4(), 
            user_id: user.id, 
            name: '', 
            is_default: fields.length === 0,
            created_at: new Date().toISOString()
        });
    };

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Gestionar Depósitos</DialogTitle>
                    <DialogDescription>Añada, edite o elimine sus depósitos. Solo uno puede ser el predeterminado.</DialogDescription>
                </DialogHeader>
                <form id="deposits-form" onSubmit={handleSubmit(onSubmit)}>
                    <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                        {isLoading ? (
                            <div className="space-y-2">
                                <Skeleton className="h-10 w-full" />
                                <Skeleton className="h-10 w-full" />
                            </div>
                        ) : fields.map((field, index) => (
                            <div key={field.id} className="flex items-center gap-2">
                                <Input {...register(`deposits.${index}.name`, { required: true })} placeholder="Nombre del depósito" />
                                <div className="flex items-center space-x-2">
                                    <Switch
                                        checked={watchedDeposits[index]?.is_default}
                                        onCheckedChange={() => handleSetDefault(index)}
                                    />
                                    <Label className="text-xs">Default</Label>
                                </div>
                                <Button type="button" variant="ghost" size="icon" onClick={() => remove(index)}>
                                    <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                            </div>
                        ))}
                         <Button type="button" variant="outline" onClick={handleAddNewDeposit}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Añadir Depósito
                        </Button>
                    </div>
                </form>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                    <Button type="submit" form="deposits-form" disabled={mutation.isPending}>
                        {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Guardar Cambios
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default ManageWarehousesDialog;