import React, { useState, useEffect, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import { useDebounce } from '@/hooks/useDebounce';
import { useToast } from "@/components/ui/use-toast";

const FlowVerificationPanel = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [sku, setSku] = useState('');
    const [depositId, setDepositId] = useState('');
    const debouncedSku = useDebounce(sku, 500);

    const { data: warehouses, isLoading: isLoadingWarehouses } = useQuery({
        queryKey: ['warehouses', user?.id],
        queryFn: async () => {
            if (!user) return [];
            const { data, error } = await supabase.from('deposits').select('*').eq('user_id', user.id);
            if (error) throw error;
            return data;
        },
        enabled: !!user,
        initialData: [],
    });
    
    const queryKey = ['stockProof', user?.id, debouncedSku, depositId];
    
    const { data: stockData, isLoading: isLoadingStock, refetch, isRefetching } = useQuery({
        queryKey,
        queryFn: async () => {
            if (!user || !debouncedSku || !depositId) return null;
            
            const { data, error } = await supabase
                .from('v_stock_per_deposit')
                .select('qty_on_hand, qty_reserved, qty_available')
                .eq('user_id', user.id)
                .eq('sku', debouncedSku)
                .eq('deposit_id', depositId)
                .maybeSingle();

            if (error) throw error;
            return data;
        },
        enabled: false, // Only fetch on manual trigger
    });

    useEffect(() => {
        if (debouncedSku && depositId) {
            refetch();
        }
    }, [debouncedSku, depositId, refetch]);
    
    const handleRefresh = useCallback(() => {
        if (!sku || !depositId) {
            toast({
                variant: "destructive",
                title: "Campos Requeridos",
                description: "Por favor ingrese un SKU y seleccione un depósito.",
            });
            return;
        }
        refetch();
    }, [sku, depositId, refetch, toast]);

    const isFetching = isLoadingStock || isRefetching;

    return (
        <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
                <CardTitle>Panel de Verificación de Flujo de Inventario</CardTitle>
                <CardDescription>Use esta herramienta para probar y confirmar el flujo de stock por depósito.</CardDescription>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-6">
                <div>
                    <div className="flex items-end gap-4 mb-4">
                        <div className="flex-grow">
                            <label htmlFor="sku-check" className="text-sm font-medium">Ingrese el SKU</label>
                            <Input id="sku-check" value={sku} onChange={(e) => setSku(e.target.value)} placeholder="Ej: 112383" />
                        </div>
                        <div className="flex-grow">
                            <label htmlFor="deposit-check" className="text-sm font-medium">Seleccione el Depósito</label>
                            <Select value={depositId} onValueChange={setDepositId} disabled={isLoadingWarehouses}>
                                <SelectTrigger id="deposit-check">
                                    <SelectValue placeholder="Seleccione un depósito..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {warehouses?.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <Button onClick={handleRefresh} disabled={isFetching || !sku || !depositId}>
                            {isFetching ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Refrescar Datos'}
                        </Button>
                    </div>
                    <div className="p-4 rounded-lg bg-white border min-h-[80px] flex items-center">
                        {isFetching ? (
                           <div className="flex items-center text-muted-foreground w-full"><Loader2 className="mr-2 h-4 w-4 animate-spin" />Buscando stock...</div>
                        ) : !stockData && debouncedSku && depositId ? (
                            <div className="flex items-center text-orange-600"><AlertCircle className="mr-2 h-4 w-4"/>No se encontró stock para este producto en el depósito seleccionado.</div>
                        ) : !sku || !depositId ? (
                            <p className="text-sm text-muted-foreground">Ingrese un SKU y seleccione un depósito para ver el stock.</p>
                        ) : stockData ? (
                            <div className="flex items-center gap-6 text-lg">
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="h-6 w-6 text-green-500" />
                                    <span>Disponible: <strong className="font-bold">{formatCurrency(stockData.qty_available, 2)}</strong></span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="h-6 w-6 text-yellow-500" />
                                    <span>Reservado: <strong className="font-bold">{formatCurrency(stockData.qty_reserved, 2)}</strong></span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="h-6 w-6 text-blue-500" />
                                    <span>En Mano: <strong className="font-bold">{formatCurrency(stockData.qty_on_hand, 2)}</strong></span>
                                </div>
                            </div>
                        ) : null}
                    </div>
                </div>
                <div className="text-sm text-gray-600 space-y-2 p-4 rounded-lg bg-blue-100/50">
                    <h4 className="font-semibold text-gray-800">Guía de Prueba Rápida:</h4>
                    <ol className="list-decimal list-inside space-y-1">
                        <li>Vaya a <strong className="text-blue-700">Atención al Cliente</strong> y cree una OS o apruebe un Presupuesto con el SKU de arriba, seleccionando el depósito o usando "Auto".</li>
                        <li>Vuelva aquí y presione "Refrescar Datos". Verá que "Reservado" aumenta.</li>
                        <li>Vuelva a la OS y márquela como "Cerrada".</li>
                        <li>Regrese y refresque de nuevo. Verá que "En Mano" y "Reservado" disminuyen.</li>
                        <li>Revise el <strong className="text-blue-700">Kardex</strong> del producto para ver el movimiento de salida.</li>
                    </ol>
                </div>
            </CardContent>
        </Card>
    );
};

export default FlowVerificationPanel;