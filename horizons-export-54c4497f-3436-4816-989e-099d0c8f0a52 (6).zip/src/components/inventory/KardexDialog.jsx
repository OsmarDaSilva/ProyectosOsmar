import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';
import { formatCurrency } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const KardexDialog = ({ isOpen, onOpenChange, sku }) => {
    const [selectedDeposit, setSelectedDeposit] = React.useState('all');

    const { data: deposits, isLoading: isLoadingDeposits } = useQuery({
        queryKey: ['depositsForKardex'],
        queryFn: async () => {
            const { data, error } = await supabase.from('deposits').select('id, name');
            if (error) throw error;
            return data;
        },
        enabled: isOpen,
    });
    
    const { data, isLoading } = useQuery({
        queryKey: ['kardex', sku, selectedDeposit],
        queryFn: async () => {
            if (!sku) return null;
            
            let query = supabase
                .from('v_kardex')
                .select('*')
                .eq('sku', sku)
                .order('ts', { ascending: false });

            if (selectedDeposit !== 'all') {
                query = query.or(`warehouse_from.eq.${selectedDeposit},warehouse_to.eq.${selectedDeposit}`);
            }

            const { data: moves, error } = await query;
            if (error) throw error;

            let balance = 0;
            // Balance calculation needs to be smarter for filtered views.
            // For now, it will show a running total of the visible items, which might not be the true balance.
            // A more complex query would be needed for a true running balance on a filtered set.
            const processedMoves = moves.reverse().map(move => {
                if (move.reason === 'IN' && (selectedDeposit === 'all' || move.warehouse_to === selectedDeposit)) {
                    balance += move.qty;
                } else if (move.reason !== 'IN' && (selectedDeposit === 'all' || move.warehouse_from === selectedDeposit)) {
                    balance -= move.qty;
                }
                return { ...move, balance };
            }).reverse();

            return {
                product_name: moves[0]?.product_name || `Producto ${sku}`,
                moves: processedMoves
            };
        },
        enabled: !!sku && isOpen && !isLoadingDeposits,
    });

    const getMoveDescription = (move) => {
        switch (move.reason) {
            case 'IN':
                return `Entrada ${move.ref_type === 'PURCHASE_ORDER' ? '(Compra)' : '(Manual)'} a ${move.warehouse_to_name}`;
            case 'OUT':
                 return `Salida desde ${move.warehouse_from_name} (${move.ref_type || 'Venta/Servicio'})`;
            case 'TRANSFER':
                return `Transferencia de ${move.warehouse_from_name} a ${move.warehouse_to_name}`;
            case 'ADJUST':
                return `Ajuste en ${move.warehouse_from_name || move.warehouse_to_name}`;
            default:
                return move.ref_type || move.reason;
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl">
                <DialogHeader>
                    <DialogTitle>Kardex del Producto: {data?.product_name || `SKU ${sku}`}</DialogTitle>
                    <DialogDescription>Historial de todos los movimientos de inventario para este producto.</DialogDescription>
                </DialogHeader>
                
                <div className="flex justify-end">
                    <Select onValueChange={setSelectedDeposit} value={selectedDeposit}>
                        <SelectTrigger className="w-[250px]">
                            <SelectValue placeholder="Filtrar por depósito" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">Todos los Depósitos</SelectItem>
                            {deposits?.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                
                <ScrollArea className="h-[60vh]">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Fecha</TableHead>
                                <TableHead>Descripción</TableHead>
                                <TableHead className="text-right">Entrada</TableHead>
                                <TableHead className="text-right">Salida</TableHead>
                                <TableHead className="text-right">Saldo</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {isLoading ? (
                                [...Array(5)].map((_, i) => (
                                    <TableRow key={i}><TableCell colSpan={5}><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                                ))
                            ) : data?.moves?.length > 0 ? (
                                data.moves.map(move => (
                                    <TableRow key={move.id}>
                                        <TableCell>{format(new Date(move.ts), 'dd/MM/yyyy HH:mm')}</TableCell>
                                        <TableCell>{getMoveDescription(move)}</TableCell>
                                        <TableCell className="text-right text-green-600">{move.reason === 'IN' ? formatCurrency(move.qty, 2) : '-'}</TableCell>
                                        <TableCell className="text-right text-red-600">{move.reason !== 'IN' ? formatCurrency(move.qty, 2) : '-'}</TableCell>
                                        <TableCell className="text-right font-bold">{formatCurrency(move.balance, 2)}</TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow><TableCell colSpan={5} className="h-24 text-center">No hay movimientos para este producto.</TableCell></TableRow>
                            )}
                        </TableBody>
                    </Table>
                </ScrollArea>
            </DialogContent>
        </Dialog>
    );
};

export default KardexDialog;