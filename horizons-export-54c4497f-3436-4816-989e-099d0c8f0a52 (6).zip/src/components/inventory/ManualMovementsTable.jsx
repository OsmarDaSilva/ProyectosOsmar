import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase-helpers';
import { format } from 'date-fns';
import { formatCurrency, formatNumber } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { MoreHorizontal, Trash2, Loader2 } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';

const ManualMovementsTable = () => {
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [moveToCancel, setMoveToCancel] = useState(null);

    const { data: moves, isLoading, error } = useQuery({
        queryKey: ['inventory', 'kardex'],
        queryFn: async () => {
            try {
                const { data, error: fetchError } = await supabase
                    .from('inventory_kardex')
                    .select('id, created_at, tipo, sku, producto, deposito_origen, deposito_destino, cantidad, costo_unitario, observacion')
                    .order('created_at', { ascending: false })
                    .limit(200);

                if (fetchError) throw fetchError;

                return (data ?? []).map(r => ({
                    id: r.id,
                    fecha: r.created_at ?? '-',
                    tipo: r.tipo ?? '-',
                    sku: r.sku ?? '-',
                    producto: r.producto ?? '-',
                    origen: r.deposito_origen ?? '-',
                    destino: r.deposito_destino ?? '',
                    cantidad: Number(r.cantidad ?? 0),
                    costo: Number(r.costo_unitario ?? 0),
                    obs: r.observacion ?? ''
                }));
            } catch (e) {
                toast({ variant: 'destructive', title: 'Error', description: e.message || 'Error al cargar movimientos' });
                return [];
            }
        },
    });

    const cancelMutation = useMutation({
        mutationFn: (moveId) => supabase.rpc('cancel_stock_move', { p_move_id: moveId }),
        onSuccess: () => {
            toast({ title: 'Éxito', description: 'El movimiento ha sido anulado correctamente.' });
            queryClient.invalidateQueries({ queryKey: ['inventory', 'kardex'] });
            queryClient.invalidateQueries({ queryKey: ['inventory_stock'] });
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        },
        onSettled: () => setMoveToCancel(null)
    });

    const handleCancelMove = (move) => {
        setMoveToCancel(move);
    };

    const confirmCancel = () => {
        if (moveToCancel) {
            cancelMutation.mutate(moveToCancel.id);
        }
    };
    
    const getBadgeVariant = (type) => {
        switch (type) {
            case 'IN': return 'success';
            case 'OUT': return 'destructive';
            case 'TRANSFER': return 'default';
            case 'ADJUST': return 'secondary';
            default: return 'outline';
        }
    }
    
    return (
        <Card>
            <CardHeader>
                <CardTitle>Historial de Movimientos</CardTitle>
                <CardDescription>Aquí puede ver el historial completo de movimientos de inventario (Kardex).</CardDescription>
            </CardHeader>
            <CardContent>
                <ScrollArea className="h-[60vh] w-full">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Fecha</TableHead>
                                <TableHead>Tipo</TableHead>
                                <TableHead>SKU/Producto</TableHead>
                                <TableHead>Origen</TableHead>
                                <TableHead>Destino</TableHead>
                                <TableHead>Observación</TableHead>
                                <TableHead className="text-right">Cantidad</TableHead>
                                <TableHead></TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {isLoading ? (
                                 [...Array(10)].map((_, i) => (
                                    <TableRow key={i}><TableCell colSpan={8}><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                                ))
                            ) : error ? (
                                <TableRow><TableCell colSpan={8} className="h-24 text-center text-red-500">Error al cargar datos: {error.message}</TableCell></TableRow>
                            ) : moves?.length > 0 ? moves.map(move => (
                                <TableRow key={move.id}>
                                    <TableCell>{format(new Date(move.fecha), 'dd/MM/yy HH:mm')}</TableCell>
                                    <TableCell><Badge variant={getBadgeVariant(move.tipo)}>{move.tipo}</Badge></TableCell>
                                    <TableCell>
                                        <div className="font-medium">{move.producto}</div>
                                        <div className="text-xs text-muted-foreground">{move.sku}</div>
                                    </TableCell>
                                    <TableCell>{move.origen}</TableCell>
                                    <TableCell>{move.destino}</TableCell>
                                    <TableCell className="max-w-[200px] truncate">{move.obs}</TableCell>
                                    <TableCell className="text-right font-semibold">{formatNumber(move.cantidad, 2)}</TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent>
                                                <DropdownMenuItem onClick={() => handleCancelMove(move)} className="text-red-500">
                                                    <Trash2 className="mr-2 h-4 w-4" /> Anular
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            )) : (
                                <TableRow><TableCell colSpan={8} className="h-24 text-center">No hay movimientos registrados.</TableCell></TableRow>
                            )}
                        </TableBody>
                    </Table>
                </ScrollArea>
                <AlertDialog open={!!moveToCancel} onOpenChange={() => setMoveToCancel(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>¿Está seguro de anular este movimiento?</AlertDialogTitle>
                            <AlertDialogDescription>
                                Esta acción no se puede deshacer. Se creará un movimiento inverso para contrarrestar este registro.
                                El movimiento original y su anulación aparecerán en el Kardex.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmCancel} disabled={cancelMutation.isPending} className="bg-red-600 hover:bg-red-700">
                                {cancelMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                                Confirmar Anulación
                            </AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </CardContent>
        </Card>
    );
};

export default ManualMovementsTable;