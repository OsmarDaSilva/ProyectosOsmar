import React, { useState, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from 'lucide-react';
import StockProductSelector from './StockProductSelector';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

const TransferStockDialog = ({ isOpen, onOpenChange, warehouses, mutation }) => {
    const { user } = useAuth();
    const { toast } = useToast();
    const { register, handleSubmit, control, setValue, reset, formState: { errors } } = useForm();
    const [selectedProduct, setSelectedProduct] = useState(null);

    useEffect(() => {
        if (!isOpen) {
            reset();
            setSelectedProduct(null);
        }
    }, [isOpen, reset]);

    const onSubmit = (data) => {
        if (!selectedProduct || !user) {
            toast({ variant: 'destructive', title: 'Error', description: 'Por favor, seleccione un producto y asegúrese de estar autenticado.'});
            return;
        }

        const moveData = {
            user_id: user.id,
            sku: selectedProduct.sku,
            qty: parseFloat(data.quantity),
            reason: 'TRANSFER',
            warehouse_from: data.warehouse_from,
            warehouse_to: data.warehouse_to,
        };
        mutation.mutate(moveData);
    };

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Transferencia entre Depósitos</DialogTitle>
                    <DialogDescription>Mueva stock de un depósito a otro.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                        <Label>Producto</Label>
                        <StockProductSelector onProductSelect={(product) => {
                            setSelectedProduct(product);
                            setValue('sku', product.sku);
                        }} />
                        <Input type="hidden" {...register('sku', { required: 'El producto es requerido' })}/>
                        {errors.sku && <p className="text-red-500 text-xs">{errors.sku.message}</p>}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="warehouse_from">Desde Depósito</Label>
                            <Controller
                                name="warehouse_from"
                                control={control}
                                rules={{ required: "Depósito de origen es requerido" }}
                                render={({ field }) => (
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <SelectTrigger id="warehouse_from">
                                            <SelectValue placeholder="Seleccione origen..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {warehouses?.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                )}
                            />
                            {errors.warehouse_from && <p className="text-red-500 text-xs">{errors.warehouse_from.message}</p>}
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="warehouse_to">Hacia Depósito</Label>
                             <Controller
                                name="warehouse_to"
                                control={control}
                                rules={{ required: "Depósito de destino es requerido" }}
                                render={({ field }) => (
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <SelectTrigger id="warehouse_to">
                                            <SelectValue placeholder="Seleccione destino..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {warehouses?.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                )}
                            />
                            {errors.warehouse_to && <p className="text-red-500 text-xs">{errors.warehouse_to.message}</p>}
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="quantity">Cantidad</Label>
                        <Input id="quantity" type="number" step="any" {...register('quantity', { required: 'La cantidad es requerida', valueAsNumber: true, min: { value: 0.01, message: 'La cantidad debe ser mayor a cero' } })} />
                        {errors.quantity && <p className="text-red-500 text-xs">{errors.quantity.message}</p>}
                    </div>
                    
                    <DialogFooter>
                        <DialogClose asChild><Button type="button" variant="outline">Cancelar</Button></DialogClose>
                        <Button type="submit" disabled={mutation.isPending}>
                            {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Confirmar Transferencia
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default TransferStockDialog;