import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDebounce } from '@/hooks/useDebounce';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { PackageSearch, Loader2 } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const StockProductSelector = ({ onProductSelect, disabled }) => {
    const { user } = useAuth();
    const [searchTerm, setSearchTerm] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);
    const wrapperRef = useRef(null);
    const debouncedSearchTerm = useDebounce(searchTerm, 300);

    const { data: searchResult, isLoading, isError, refetch } = useQuery({
        queryKey: ['stock_and_product_search', debouncedSearchTerm, user?.id],
        queryFn: async () => {
            if (!user || !debouncedSearchTerm) return { products: [], stock: {} };
            
            const [productsRes, stockRes] = await Promise.all([
                supabase.rpc('search_products', {
                    p_user_id: user.id,
                    p_term: debouncedSearchTerm,
                    p_limit: 20
                }),
                supabase.from('v_stock_per_deposit').select('sku, deposit_name, qty_available').ilike('sku', `%${debouncedSearchTerm}%`)
            ]);
            
            if (productsRes.error) throw productsRes.error;
            if (stockRes.error) throw stockRes.error;

            const stockMap = stockRes.data.reduce((acc, item) => {
                if (!acc[item.sku]) {
                    acc[item.sku] = [];
                }
                if (item.qty_available > 0) {
                   acc[item.sku].push({ deposit: item.deposit_name, qty: item.qty_available });
                }
                return acc;
            }, {});

            return { products: productsRes.data || [], stock: stockMap };
        },
        enabled: !!user && !!debouncedSearchTerm,
        staleTime: 1000 * 60, // 1 minute
    });
    
    const handleSelect = (product) => {
        if (typeof onProductSelect === 'function') {
            onProductSelect(product);
        }
        setSearchTerm(product.product_name);
        setShowSuggestions(false);
    };
    
    const handleFocus = useCallback(() => {
        setShowSuggestions(true);
        if (debouncedSearchTerm) {
            refetch();
        }
    }, [debouncedSearchTerm, refetch]);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);
    
    return (
        <div className="relative" ref={wrapperRef}>
            <div className="relative">
                {isLoading ? (
                    <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 animate-spin text-muted-foreground" />
                ) : (
                    <PackageSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                )}
                <Input
                    type="text"
                    placeholder="Buscar por Código, Nombre o Marca..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onFocus={handleFocus}
                    disabled={disabled}
                    className="pl-10"
                />
            </div>
            {showSuggestions && debouncedSearchTerm && (
                <Card className="absolute z-10 w-full mt-1 shadow-lg">
                    <CardContent className="p-2 max-h-80 overflow-y-auto">
                        {isLoading ? (
                            <div className="flex justify-center items-center p-4">
                                <Loader2 className="h-5 w-5 animate-spin" />
                            </div>
                        ) : isError ? (
                            <p className="p-4 text-center text-red-500">Error en la búsqueda.</p>
                        ) : searchResult?.products?.length > 0 ? (
                            searchResult.products.map(product => (
                                <div
                                    key={product.sku}
                                    className="p-2 hover:bg-accent rounded-md cursor-pointer"
                                    onMouseDown={(e) => { e.preventDefault(); handleSelect(product); }}
                                >
                                    <p className="font-medium">{product.product_name}</p>
                                    <p className="text-xs text-muted-foreground">
                                        {product.sku} {product.brand ? `– ${product.brand}` : ''} | Costo: {formatCurrency(product.purchase_price)}
                                    </p>
                                    <div className="flex flex-wrap gap-1 mt-1">
                                        {searchResult.stock[product.sku] && searchResult.stock[product.sku].length > 0 ? (
                                            searchResult.stock[product.sku].map(s => (
                                                <Badge key={s.deposit} variant="secondary" className="text-xs">{s.deposit}: {s.qty}</Badge>
                                            ))
                                        ) : (
                                            <Badge variant="destructive" className="text-xs">Sin stock</Badge>
                                        )}
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="p-4 text-center text-sm text-muted-foreground space-y-2">
                                <p>Producto no encontrado</p>
                                <Button size="sm" onClick={() => { /* Lógica para crear pedido a proveedor */ }}>Crear Pedido a Proveedor</Button>
                            </div>
                        )}
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default StockProductSelector;