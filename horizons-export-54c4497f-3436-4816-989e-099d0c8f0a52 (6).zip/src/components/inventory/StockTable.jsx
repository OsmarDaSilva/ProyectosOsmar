import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase-helpers';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDebounce } from '@/hooks/useDebounce';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PackageSearch, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import KardexDialog from '@/components/inventory/KardexDialog';
import { formatNumber } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';

const StockTable = () => {
    const { user } = useAuth();
    const [searchTerm, setSearchTerm] = useState('');
    const [warehouseFilter, setWarehouseFilter] = useState('all');
    const [selectedSkuForKardex, setSelectedSkuForKardex] = useState(null);
    const debouncedSearchTerm = useDebounce(searchTerm, 300);

    const { data: stockData, isLoading: isLoadingStock } = useQuery({
        queryKey: ['inventory_stock', user?.id],
        queryFn: async () => {
            if (!user) return { stockItems: [], warehouses: [] };
            
            const { data, error } = await supabase
                .from('v_stock_per_deposit')
                .select(`
                    sku,
                    product_name,
                    brand,
                    deposit_id,
                    deposit_name,
                    qty_on_hand,
                    qty_reserved,
                    qty_available
                `);

            if (error) {
                console.error("Error fetching stock data:", error);
                throw new Error(error.message);
            }

            const stockBySku = data.reduce((acc, item) => {
                if (!acc[item.sku]) {
                    acc[item.sku] = {
                        sku: item.sku,
                        product_name: item.product_name,
                        brand: item.brand,
                        total_on_hand: 0,
                        total_reserved: 0,
                        total_available: 0,
                        deposits: []
                    };
                }
                acc[item.sku].total_on_hand += item.qty_on_hand || 0;
                acc[item.sku].total_reserved += item.qty_reserved || 0;
                acc[item.sku].total_available += item.qty_available || 0;
                acc[item.sku].deposits.push({
                    id: item.deposit_id,
                    name: item.deposit_name,
                    on_hand: item.qty_on_hand || 0,
                    reserved: item.qty_reserved || 0,
                    available: item.qty_available || 0,
                });
                return acc;
            }, {});

            const uniqueDeposits = new Map();
            data.forEach(item => {
                if (item.deposit_id && !uniqueDeposits.has(item.deposit_id)) {
                    uniqueDeposits.set(item.deposit_id, item.deposit_name);
                }
            });

            return {
                stockItems: Object.values(stockBySku),
                warehouses: Array.from(uniqueDeposits, ([id, name]) => ({ id, name }))
            };
        },
        enabled: !!user,
    });
    
    const { stockItems = [], warehouses = [] } = stockData || {};

    const filteredStock = useMemo(() => {
        if (!stockItems) return [];
        return stockItems.filter(item => {
            const warehouseMatch = warehouseFilter === 'all' || item.deposits.some(d => d.id === warehouseFilter && (d.on_hand > 0 || d.reserved > 0));
            const searchMatch = debouncedSearchTerm === '' ||
                item.product_name?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                item.sku?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                item.brand?.toLowerCase().includes(debouncedSearchTerm.toLowerCase());
            return warehouseMatch && searchMatch;
        });
    }, [stockItems, debouncedSearchTerm, warehouseFilter]);

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-4">
                <div className="relative flex-grow max-w-sm">
                    <PackageSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                    <Input
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        placeholder="Buscar por SKU, nombre, marca..."
                        className="pl-10"
                    />
                </div>
                <Select onValueChange={setWarehouseFilter} value={warehouseFilter}>
                    <SelectTrigger className="w-full sm:w-[200px]">
                        <SelectValue placeholder="Filtrar por depósito" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">Todos los Depósitos</SelectItem>
                        {warehouses.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
            <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>SKU</TableHead>
                            <TableHead>Producto</TableHead>
                            <TableHead>Disp. Total</TableHead>
                            <TableHead>Reservado Total</TableHead>
                            <TableHead>Stock por Depósito (Disp./Reserv.)</TableHead>
                            <TableHead className="text-center">Kardex</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoadingStock ? (
                            [...Array(5)].map((_, i) => (
                                <TableRow key={i}><TableCell colSpan={6}><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                            ))
                        ) : filteredStock.length > 0 ? (
                            filteredStock.map(item => (
                                <TableRow key={item.sku}>
                                    <TableCell>{item.sku}</TableCell>
                                    <TableCell className="font-medium">{item.product_name || 'N/A'}</TableCell>
                                    <TableCell className="font-bold text-green-700">{formatNumber(item.total_available, 2)}</TableCell>
                                    <TableCell className="font-bold text-orange-600">{formatNumber(item.total_reserved, 2)}</TableCell>
                                    <TableCell>
                                        <div className="flex flex-wrap gap-1">
                                            {item.deposits.filter(d => d.on_hand > 0 || d.reserved > 0).map(d => (
                                                <Badge key={d.id} variant="secondary">{d.name}: {formatNumber(d.available, 2)} / <span className="text-orange-600">{formatNumber(d.reserved, 2)}</span></Badge>
                                            ))}
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-center">
                                        <Button variant="ghost" size="icon" onClick={() => setSelectedSkuForKardex(item.sku)}><Eye className="h-4 w-4" /></Button>
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={6} className="text-center h-24">No se encontraron resultados.</TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
            {selectedSkuForKardex && (
                <KardexDialog
                    isOpen={!!selectedSkuForKardex}
                    onOpenChange={() => setSelectedSkuForKardex(null)}
                    sku={selectedSkuForKardex}
                />
            )}
        </div>
    );
};

export default StockTable;