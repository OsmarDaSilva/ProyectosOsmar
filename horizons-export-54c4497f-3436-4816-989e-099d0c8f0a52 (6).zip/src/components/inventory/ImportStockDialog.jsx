import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { UploadCloud, Loader2, FileUp, Download } from 'lucide-react';
import * as XLSX from 'xlsx';

const ImportStockDialog = ({ isOpen, onOpenChange, warehouses }) => {
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [file, setFile] = useState(null);
    const [fileData, setFileData] = useState([]);
    
    const warehouseNameMap = warehouses?.reduce((acc, w) => {
        acc[w.name.toLowerCase()] = w.id;
        return acc;
    }, {});

    const onDrop = useCallback(acceptedFiles => {
        const selectedFile = acceptedFiles[0];
        setFile(selectedFile);
        
        const reader = new FileReader();
        reader.onload = (event) => {
            const data = new Uint8Array(event.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const json = XLSX.utils.sheet_to_json(worksheet);
            setFileData(json);
        };
        reader.readAsArrayBuffer(selectedFile);
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] }});

    const mutation = useMutation({
        mutationFn: async () => {
            if (fileData.length === 0) throw new Error("No hay datos para importar.");

            const { data: catalogData, error: catalogError } = await supabase
                .from('product_catalog')
                .select('sku')
                .eq('user_id', user.id);
            
            if(catalogError) throw catalogError;
            const existingSkus = new Set(catalogData.map(p => p.sku));

            const moves = [];
            const errors = [];

            fileData.forEach((row, index) => {
                const sku = row.sku?.toString().trim();
                const warehouseName = row.deposito?.toString().trim().toLowerCase();
                const qty = parseFloat(row.cantidad);
                const cost = parseFloat(row.costo_unitario);
                
                if (!sku || !warehouseName || isNaN(qty) || isNaN(cost)) {
                    errors.push(`Fila ${index + 2}: Faltan datos requeridos (SKU, Depósito, Cantidad, Costo).`);
                    return;
                }
                if (!existingSkus.has(sku)) {
                    errors.push(`Fila ${index + 2}: El SKU '${sku}' no existe en el catálogo.`);
                    return;
                }
                const warehouseId = warehouseNameMap[warehouseName];
                if (!warehouseId) {
                    errors.push(`Fila ${index + 2}: El depósito '${row.deposito}' no existe.`);
                    return;
                }

                moves.push({
                    user_id: user.id,
                    sku,
                    warehouse_to: warehouseId,
                    qty,
                    unit_cost: cost,
                    supplier: row.proveedor?.toString().trim() || null,
                    reason: 'IN',
                    ref_type: 'IMPORT'
                });
            });

            if(errors.length > 0) {
                throw new Error("Errores de validación encontrados:\n" + errors.join('\n'));
            }

            const { error: insertError } = await supabase.from('stock_moves').insert(moves);
            if(insertError) throw insertError;
        },
        onSuccess: () => {
            toast({ title: 'Éxito', description: 'Importación de stock inicial completada.' });
            queryClient.invalidateQueries({ queryKey: ['v_stock_by_warehouse'] });
            onOpenChange(false);
            setFile(null);
            setFileData([]);
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error en la importación', description: error.message, duration: 10000 });
        }
    });

    const handleDownloadTemplate = () => {
        const templateData = [{
            deposito: 'Principal',
            sku: 'SKU-001',
            cantidad: 10,
            costo_unitario: 150.50,
            proveedor: 'Proveedor Ejemplo'
        }];
        const ws = XLSX.utils.json_to_sheet(templateData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Plantilla Stock");
        XLSX.writeFile(wb, "plantilla_importacion_stock.xlsx");
    };


    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Importar Stock Inicial</DialogTitle>
                    <DialogDescription>Cargue el saldo inicial de su inventario desde un archivo Excel (.xlsx).</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                    <Button variant="outline" onClick={handleDownloadTemplate} className="w-full">
                        <Download className="mr-2 h-4 w-4" />
                        Descargar Plantilla
                    </Button>
                    <div {...getRootProps()} className={`p-8 border-2 border-dashed rounded-lg text-center cursor-pointer ${isDragActive ? 'border-primary bg-primary/10' : 'border-input'}`}>
                        <input {...getInputProps()} />
                        <UploadCloud className="mx-auto h-12 w-12 text-muted-foreground" />
                        {file ? (
                            <p className="mt-2 text-sm font-medium">{file.name}</p>
                        ) : (
                            <p className="mt-2 text-sm text-muted-foreground">Arrastre y suelte el archivo aquí, o haga clic para seleccionar</p>
                        )}
                    </div>
                    {fileData.length > 0 && <p className="text-sm text-center text-muted-foreground">{fileData.length} filas detectadas para importar.</p>}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)} disabled={mutation.isPending}>Cancelar</Button>
                    <Button onClick={() => mutation.mutate()} disabled={!file || mutation.isPending}>
                        {mutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileUp className="mr-2 h-4 w-4" />}
                        Importar y Procesar
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default ImportStockDialog;