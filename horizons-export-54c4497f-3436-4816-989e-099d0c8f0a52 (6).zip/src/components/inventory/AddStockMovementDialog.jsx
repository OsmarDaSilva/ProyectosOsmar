import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import StockProductSelector from './StockProductSelector';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase-helpers';
import { toNumber } from '@/lib/utils';

const createEntry = async (payload) => {
  const { data, error } = await supabase.rpc('create_inventory_entry', payload);
  if (error) throw new Error(error.message);
  return data;
};

const AddStockMovementDialog = ({ isOpen, onOpenChange, movementType, warehouses, onSuccess: onParentSuccess }) => {
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();

    const [formState, setFormState] = useState({
        product: null,
        quantity: '1',
        deposit_name: '',
        unit_cost: '0',
        supplier: '',
        reason: 'OUT',
        ref_type: '',
    });

    const mutation = useMutation({
        mutationFn: createEntry,
        onSuccess: (data) => {
            toast({ title: 'Éxito', description: 'Movimiento registrado' });
            queryClient.invalidateQueries({ queryKey: ['inventory_stock'] });
            queryClient.invalidateQueries({ queryKey: ['inventory_kardex'] });
            onParentSuccess?.(data);
            onOpenChange(false);
        },
        onError: (err) => {
            toast({ variant: 'destructive', title: 'Error al registrar', description: err.message ?? 'Error desconocido' });
        },
    });

    const handleFormChange = (field, value) => {
        setFormState(prev => ({ ...prev, [field]: value }));
    };

    useEffect(() => {
        if (!isOpen) {
            setFormState({
                product: null,
                quantity: '1',
                deposit_name: '',
                unit_cost: '0',
                supplier: '',
                reason: 'OUT',
                ref_type: '',
            });
            mutation.reset();
        } else {
            if (warehouses && warehouses.length > 0) {
                const defaultWarehouse = warehouses.find(w => w.is_default) || warehouses[0];
                handleFormChange('deposit_name', defaultWarehouse.name);
            }
        }
    }, [isOpen, warehouses]);
    
    useEffect(() => {
        if (formState.product) {
            handleFormChange('unit_cost', String(formState.product.purchase_price || 0).replace('.',','));
        }
    }, [formState.product]);

    const handleSubmit = async (e) => {
        e?.preventDefault();
        const { product, deposit_name, ref_type } = formState;
        const quantity = toNumber(formState.quantity);

        if (!product || !deposit_name || !quantity || quantity <= 0) {
            toast({ variant: 'destructive', title: 'Error de validación', description: 'Complete SKU, Depósito y Cantidad > 0' });
            return;
        }

        if (movementType === 'IN') {
             await mutation.mutateAsync({
                p_user_id: user.id,
                p_sku: product.sku,
                p_deposito: deposit_name,
                p_cantidad: quantity,
                p_observacion: ref_type || 'Entrada Manual',
            });
        } else {
            toast({ variant: 'destructive', title: 'Funcionalidad no implementada', description: 'Las salidas de stock aún no están implementadas.' });
        }
    };

    const dialogTitle = movementType === 'IN' ? 'Registrar Entrada de Stock' : 'Registrar Salida/Ajuste de Stock';
    const dialogDescription = movementType === 'IN' 
        ? 'Añada productos al inventario desde una compra u otro motivo.'
        : 'Descuente productos del inventario por venta, servicio o ajuste.';
    
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent>
                <form id="stock-movement-form" onSubmit={handleSubmit}>
                    <DialogHeader>
                        <DialogTitle>{dialogTitle}</DialogTitle>
                        <DialogDescription>{dialogDescription}</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="space-y-2">
                            <Label>Producto</Label>
                            <StockProductSelector onProductSelect={(p) => handleFormChange('product', p)} />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="quantity">Cantidad</Label>
                                <Input id="quantity" type="text" value={formState.quantity} onChange={e => handleFormChange('quantity', e.target.value)} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="unit_cost">Costo Unitario</Label>
                                <Input id="unit_cost" type="text" value={formState.unit_cost} onChange={e => handleFormChange('unit_cost', e.target.value)} />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label>Depósito</Label>
                             <Select onValueChange={(v) => handleFormChange('deposit_name', v)} value={formState.deposit_name}>
                                <SelectTrigger><SelectValue placeholder="Seleccione un depósito..." /></SelectTrigger>
                                <SelectContent>
                                    {warehouses?.map(w => <SelectItem key={w.id} value={w.name}>{w.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                       
                        {movementType === 'IN' && (
                            <>
                                <div className="space-y-2">
                                    <Label htmlFor="supplier">Proveedor (Opcional)</Label>
                                    <Input id="supplier" value={formState.supplier} onChange={e => handleFormChange('supplier', e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="ref_type">Razón / Referencia (Opcional)</Label>
                                    <Input id="ref_type" value={formState.ref_type} onChange={e => handleFormChange('ref_type', e.target.value)} placeholder="Ej: Compra inicial, Devolución" />
                                </div>
                            </>
                        )}
                        
                        {movementType !== 'IN' && (
                            <>
                                <div className="space-y-2">
                                    <Label>Motivo</Label>
                                    <Select onValueChange={(v) => handleFormChange('reason', v)} value={formState.reason}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="OUT">Salida (Venta/Servicio)</SelectItem>
                                            <SelectItem value="ADJUST">Ajuste de Inventario</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="ref_type">Razón / Referencia (Opcional)</Label>
                                    <Input id="ref_type" value={formState.ref_type} onChange={e => handleFormChange('ref_type', e.target.value)} placeholder="Ej: Venta a cliente X, Ajuste por rotura" />
                                </div>
                            </>
                        )}

                    </div>
                    <DialogFooter>
                        <Button variant="outline" type="button" onClick={() => onOpenChange(false)} disabled={mutation.isPending}>Cancelar</Button>
                        <Button type="submit" disabled={mutation.isPending || !formState.product || !formState.deposit_name}>
                            {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {mutation.isPending ? 'Guardando…' : 'Registrar Movimiento'}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default AddStockMovementDialog;