import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { ArrowDown, ArrowUp, Leaf, DollarSign } from 'lucide-react';
import { formatNumber, formatCurrency } from '@/lib/utils';
import { useTranslation } from 'react-i18next';


const CarbonBalanceSection = ({ carbonCalculations, projectData }) => {
    const { t } = useTranslation(['calculator', 'viability', 'common', 'carbonBalance']);
    const { traditional, tech, comparison } = carbonCalculations;

    const chartData = [
        {
            name: t('calculator:models.traditional'),
            [t('carbonBalance:emissions')]: traditional.totalEmissions,
            [t('carbonBalance:sequestration')]: -traditional.totalSequestration,
            [t('carbonBalance:balance')]: traditional.netBalance,
        },
        {
            name: t('calculator:models.technified'),
            [t('carbonBalance:emissions')]: tech.totalEmissions,
            [t('carbonBalance:sequestration')]: -tech.totalSequestration,
            [t('carbonBalance:balance')]: tech.netBalance,
        },
    ];

    const CustomTooltip = ({ active, payload, label }) => {
        if (active && payload && payload.length) {
            return (
                <div className="p-4 bg-white/90 backdrop-blur-sm rounded-lg shadow-lg border border-gray-200">
                    <p className="font-bold text-gray-800">{label}</p>
                    {payload.map(pld => {
                       const value = pld.dataKey === t('carbonBalance:sequestration') ? -pld.value : pld.value;
                       return (
                         <p key={pld.dataKey} style={{ color: pld.fill }}>
                            {`${pld.name}: ${formatNumber(value)} tCO2e`}
                        </p>
                       )
                    })}
                </div>
            );
        }
        return null;
    };
    
    const MetricCard = ({ title, value, change, unit, icon, positiveIsGood = true }) => {
        const Icon = icon;
        const isPositive = change > 0;
        const changeColor = (isPositive && positiveIsGood) || (!isPositive && !positiveIsGood) ? 'text-green-600' : 'text-red-600';
        const ChangeIcon = isPositive ? ArrowUp : ArrowDown;

        return (
            <Card className="metric-card">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{title}</CardTitle>
                    <Icon className="h-5 w-5 text-gray-400" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{value} <span className="text-sm font-normal text-gray-500">{unit}</span></div>
                    {change !== null && typeof change === 'number' && isFinite(change) && (
                        <p className={`text-xs ${changeColor} flex items-center`}>
                            <ChangeIcon className="h-4 w-4 mr-1" />
                            {`${formatNumber(change * 100, 1)}% ${t('carbonBalance:vsTraditional')}`}
                        </p>
                    )}
                </CardContent>
            </Card>
        );
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <MetricCard 
                    title={t('carbonBalance:netBalanceTech')}
                    value={formatNumber(tech.netBalance, 0)}
                    unit="tCO2e/año"
                    change={comparison.netBalancePct}
                    icon={Leaf}
                    positiveIsGood={false}
                />
                <MetricCard 
                    title={t('carbonBalance:emissionsReduction')}
                    value={`${formatNumber(comparison.emissionsReductionPct * 100, 1)}%`}
                    unit=""
                    change={null}
                    icon={ArrowDown}
                    positiveIsGood={true}
                />
                <MetricCard 
                    title={t('carbonBalance:sequestrationIncrease')}
                    value={`${formatNumber(comparison.sequestrationIncreasePct * 100, 1)}%`}
                    unit=""
                    change={null}
                    icon={ArrowUp}
                    positiveIsGood={true}
                />
                <Card className="col-span-1 lg:col-span-1 bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-lg">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-green-100">{t('carbonBalance:revenuePotential')}</CardTitle>
                        <DollarSign className="h-5 w-5 text-green-200" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-3xl font-bold">{formatCurrency(tech.potentialRevenue)}</div>
                        <p className="text-xs text-green-200 mt-1">{t('carbonBalance:revenueNote', { years: projectData?.projectYears || 10 })}</p>
                    </CardContent>
                </Card>
            </div>
            
             <Card>
                <CardHeader>
                    <CardTitle>{t('carbonBalance:annualComparisonTitle')}</CardTitle>
                    <CardDescription>{t('carbonBalance:annualComparisonDesc')}</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="h-96">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis tickFormatter={(tick) => `${formatNumber(tick)}`} label={{ value: `tCO2e / ${t('common:year')}`, angle: -90, position: 'insideLeft' }} />
                                <Tooltip content={<CustomTooltip />} />
                                <Legend />
                                <ReferenceLine y={0} stroke="#000" strokeWidth={2} />
                                <Bar dataKey={t('carbonBalance:emissions')} fill="#ef4444" name={t('carbonBalance:emissions')} stackId="a" />
                                <Bar dataKey={t('carbonBalance:sequestration')} fill="#22c55e" name={t('carbonBalance:sequestration')} stackId="a" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>{t('carbonBalance:detailedSummaryTitle')}</CardTitle>
                    <CardDescription>{t('carbonBalance:detailedSummaryDesc')}</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="font-bold">{t('carbonBalance:metric')} (tCO2e/{t('common:year')})</TableHead>
                                <TableHead className="text-right font-bold">{t('calculator:models.traditional')}</TableHead>
                                <TableHead className="text-right font-bold">{t('calculator:models.technified')}</TableHead>
                                <TableHead className="text-right font-bold">{t('carbonBalance:improvement')}</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            <TableRow>
                                <TableCell>{t('carbonBalance:totalEmissions')}</TableCell>
                                <TableCell className="text-right text-red-600">{formatNumber(traditional.totalEmissions)}</TableCell>
                                <TableCell className="text-right text-red-600">{formatNumber(tech.totalEmissions)}</TableCell>
                                <TableCell className="text-right text-green-600">
                                    <div className="flex items-center justify-end">
                                        <ArrowDown className="h-4 w-4 mr-1"/>
                                        {formatNumber(comparison.emissionsReduction, 0)} ({formatNumber(comparison.emissionsReductionPct * 100, 1)}%)
                                    </div>
                                </TableCell>
                            </TableRow>
                            <TableRow>
                                <TableCell>{t('carbonBalance:totalSequestration')}</TableCell>
                                <TableCell className="text-right text-green-600">{formatNumber(traditional.totalSequestration)}</TableCell>
                                <TableCell className="text-right text-green-600">{formatNumber(tech.totalSequestration)}</TableCell>
                                <TableCell className="text-right text-green-600">
                                    <div className="flex items-center justify-end">
                                        <ArrowUp className="h-4 w-4 mr-1"/>
                                        {formatNumber(comparison.sequestrationIncrease, 0)} ({formatNumber(comparison.sequestrationIncreasePct * 100, 1)}%)
                                    </div>
                                </TableCell>
                            </TableRow>
                            <TableRow className="bg-gray-100 font-bold">
                                <TableCell>{t('carbonBalance:netBalance')}</TableCell>
                                <TableCell className={`text-right ${traditional.netBalance >= 0 ? 'text-red-700' : 'text-green-700'}`}>{formatNumber(traditional.netBalance)}</TableCell>
                                <TableCell className={`text-right ${tech.netBalance >= 0 ? 'text-red-700' : 'text-green-700'}`}>{formatNumber(tech.netBalance)}</TableCell>
                                <TableCell className={`text-right ${comparison.netBalanceChange >= 0 ? 'text-red-700' : 'text-green-700'}`}>
                                    <div className="flex items-center justify-end">
                                        {comparison.netBalanceChange < 0 ? <ArrowDown className="h-4 w-4 mr-1"/> : <ArrowUp className="h-4 w-4 mr-1"/>}
                                        {formatNumber(comparison.netBalanceChange, 0)} ({formatNumber(comparison.netBalancePct * 100, 1)}%)
                                    </div>
                                </TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
};

export default CarbonBalanceSection;