import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { TrendingUp, DollarSign, Percent, Calendar } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const KeyMetricsCards = ({ metrics, formatCurrency }) => {
    const { t } = useTranslation(['viability', 'common']);

    const { irr, npv, roi, paybackPeriod } = metrics;

    const metricItems = [
        {
            title: t('keyMetrics.irrShort'),
            value: typeof irr === 'number' ? `${(irr * 100).toFixed(2)}%` : irr,
            subtext: t('keyMetrics.irrSubtext'),
            icon: TrendingUp,
            colors: "from-green-100 to-green-200 text-green-800"
        },
        {
            title: t('keyMetrics.npvShort'),
            value: formatCurrency(npv),
            subtext: t('keyMetrics.npvSubtext'),
            icon: DollarSign,
            colors: "from-blue-100 to-blue-200 text-blue-800"
        },
        {
            title: t('keyMetrics.roiShort'),
            value: typeof roi === 'number' ? `${(roi * 100).toFixed(2)}%` : 'N/A',
            subtext: t('keyMetrics.roiSubtext'),
            icon: Percent,
            colors: "from-purple-100 to-purple-200 text-purple-800"
        },
        {
            title: t('keyMetrics.paybackShort'),
            value: `${paybackPeriod} ${t('common:years')}`,
            subtext: t('keyMetrics.paybackSubtext'),
            icon: Calendar,
            colors: "from-orange-100 to-orange-200 text-orange-800"
        }
    ];

    return (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {metricItems.map((item) => (
                <Card key={item.title} className={`text-center bg-gradient-to-br ${item.colors}`}>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium flex items-center justify-center">
                            <item.icon className="mr-2 h-4 w-4" />
                            <span className="notranslate" translate="no">{item.title}</span>
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-lg sm:text-2xl font-bold">{item.value}</p>
                        <p className="text-xs mt-1">{item.subtext}</p>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
};

export default KeyMetricsCards;