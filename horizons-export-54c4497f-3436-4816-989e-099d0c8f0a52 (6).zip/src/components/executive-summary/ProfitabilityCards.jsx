import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Tractor, Wheat, Beef, Droplets } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const ProfitabilityCards = ({ traditional, tech, profitDifference, formatCurrency }) => {
    const { t } = useTranslation(['viability', 'calculator']);

    return (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-orange-200 shadow-sm">
                    <CardHeader className="bg-orange-50 pb-2">
                        <CardTitle className="flex items-center justify-center text-orange-700 text-base sm:text-lg">
                            <Tractor className="mr-2 h-5 w-5" /> {t('calculator:models.traditional')}
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 space-y-2">
                        <div className="flex justify-between items-center text-sm">
                            <span className="flex items-center text-gray-600"><Wheat className="mr-2 h-4 w-4"/> {t('executiveSummary.agriculture')}:</span>
                            <span className="font-semibold text-gray-800">{formatCurrency(traditional.agricultura)}</span>
                        </div>
                         <div className="flex justify-between items-center text-sm">
                            <span className="flex items-center text-gray-600"><Beef className="mr-2 h-4 w-4"/> {t('executiveSummary.livestock')}:</span>
                            <span className="font-semibold text-gray-800">{formatCurrency(traditional.ganaderia)}</span>
                        </div>
                        <div className="flex justify-between items-center text-base font-bold pt-2 border-t mt-2">
                            <span>{t('executiveSummary.annualTotal')}:</span>
                            <span className="text-orange-700">{formatCurrency(traditional.revenue)}</span>
                        </div>
                    </CardContent>
                </Card>
                <Card className="border-green-200 shadow-sm">
                    <CardHeader className="bg-green-50 pb-2">
                        <CardTitle className="flex items-center justify-center text-green-700 text-base sm:text-lg">
                            <Droplets className="mr-2 h-5 w-5" /> {t('calculator:models.technified')}
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 space-y-2">
                        <div className="flex justify-between items-center text-sm">
                            <span className="flex items-center text-gray-600"><Tractor className="mr-2 h-4 w-4"/> {t('executiveSummary.agriculture')}:</span>
                            <span className="font-semibold text-gray-800">{formatCurrency(tech.agricultura)}</span>
                        </div>
                         <div className="flex justify-between items-center text-sm">
                            <span className="flex items-center text-gray-600"><Beef className="mr-2 h-4 w-4"/> {t('executiveSummary.livestock')}:</span>
                            <span className="font-semibold text-gray-800">{formatCurrency(tech.ganaderia)}</span>
                        </div>
                        <div className="flex justify-between items-center text-base font-bold pt-2 border-t mt-2">
                            <span>{t('executiveSummary.annualTotal')}:</span>
                            <span className="text-green-700">{formatCurrency(tech.revenue)}</span>
                        </div>
                    </CardContent>
                </Card>
            </div>
             <div className="mt-6 p-6 bg-blue-50 rounded-lg text-center">
                <h4 className="text-md sm:text-lg font-semibold text-blue-800">{t('executiveSummary.annualProfitDifference')}</h4>
                <p className="text-3xl sm:text-4xl font-extrabold text-blue-900 mt-2">{formatCurrency(profitDifference)}</p>
                <p className="text-sm sm:text-md text-gray-600 mt-1">{t('executiveSummary.inFavorOfTech')}</p>
            </div>
        </>
    );
};

export default ProfitabilityCards;