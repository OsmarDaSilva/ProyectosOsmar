import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Leaf, DollarSign, ArrowDown, ArrowUp } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { formatNumber } from '@/lib/utils';

const CarbonMetricsCards = ({ carbonCalculations, projectYears, formatCurrency }) => {
    const { t } = useTranslation(['calculator']);
    const { tech, comparison } = carbonCalculations;

    const metricItems = [
        {
            title: t('executiveSummary.carbonMetrics.netBalance'),
            value: formatNumber(tech.netBalance, 0),
            unit: 'tCO2e/año',
            icon: Leaf,
            colors: tech.netBalance < 0 ? "from-emerald-100 to-emerald-200 text-emerald-800" : "from-amber-100 to-amber-200 text-amber-800"
        },
        {
            title: t('executiveSummary.carbonMetrics.emissionsReduction'),
            value: `${formatNumber(comparison.emissionsReductionPct * 100, 1)}%`,
            unit: t('executiveSummary.carbonMetrics.vsTraditional'),
            icon: ArrowDown,
            colors: "from-blue-100 to-blue-200 text-blue-800"
        },
        {
            title: t('executiveSummary.carbonMetrics.sequestrationIncrease'),
            value: `${formatNumber(comparison.sequestrationIncreasePct * 100, 1)}%`,
            unit: t('executiveSummary.carbonMetrics.vsTraditional'),
            icon: ArrowUp,
            colors: "from-teal-100 to-teal-200 text-teal-800"
        },
        {
            title: t('executiveSummary.carbonMetrics.revenuePotential'),
            value: formatCurrency(tech.potentialRevenue),
            unit: t('executiveSummary.carbonMetrics.inYears', { years: projectYears || 10 }),
            icon: DollarSign,
            colors: "from-green-100 to-green-200 text-green-800"
        }
    ];

    return (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {metricItems.map((item) => (
                <Card key={item.title} className={`text-center bg-gradient-to-br ${item.colors}`}>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium flex items-center justify-center">
                            <item.icon className="mr-2 h-4 w-4" />{item.title}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-lg sm:text-2xl font-bold">{item.value}</p>
                        <p className="text-xs mt-1">{item.unit}</p>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
};

export default CarbonMetricsCards;