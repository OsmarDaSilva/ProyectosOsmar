import React from 'react';
import { useTranslation } from 'react-i18next';
import { User, Hash, MapPin, Globe, Map, Droplets } from 'lucide-react';

const SummarySection = ({
    title,
    number,
    children,
    pageBreakAfter = true,
}) => (
    <section className={`mb-8 ${pageBreakAfter ? 'page-break-after' : ''}`}>
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 border-b border-gray-300 pb-2 mb-4">
            {title}
        </h3>
        {children}
    </section>
);

const GeneralData = ({ projectData }) => {
    const { t } = useTranslation(['viability']);
    
    const irrigationInvestment = projectData.investments?.find(inv => inv.id === 'riego');
    const irrigationHa = irrigationInvestment?.cantidad || 0;
    
    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-4">
            <div className="flex items-center">
                <User className="h-5 w-5 mr-3 text-gray-500 flex-shrink-0" />
                <div>
                    <p className="text-sm text-gray-600">{t('executiveSummary.clientName')}</p>
                    <p className="font-semibold text-gray-800 break-words">{projectData.ownerName || 'N/A'}</p>
                </div>
            </div>
            <div className="flex items-center">
                <Globe className="h-5 w-5 mr-3 text-gray-500 flex-shrink-0" />
                <div>
                    <p className="text-sm text-gray-600">{t('executiveSummary.country')}</p>
                    <p className="font-semibold text-gray-800 break-words">{projectData.country || 'N/A'}</p>
                </div>
            </div>
             <div className="flex items-center">
                <Map className="h-5 w-5 mr-3 text-gray-500 flex-shrink-0" />
                <div>
                    <p className="text-sm text-gray-600">{t('executiveSummary.department')}</p>
                    <p className="font-semibold text-gray-800 break-words">{projectData.department || 'N/A'}</p>
                </div>
            </div>
            <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-3 text-gray-500 flex-shrink-0" />
                <div>
                    <p className="text-sm text-gray-600">{t('executiveSummary.location')}</p>
                    <p className="font-semibold text-gray-800 break-words">{projectData.location || 'N/A'}</p>
                </div>
            </div>
            <div className="flex items-center">
                <Droplets className="h-5 w-5 mr-3 text-gray-500 flex-shrink-0" />
                <div>
                    <p className="text-sm text-gray-600">{t('executiveSummary.irrigationHa')}</p>
                    <p className="font-semibold text-gray-800 break-words">{irrigationHa} ha</p>
                </div>
            </div>
             <div className="flex items-center">
                <Hash className="h-5 w-5 mr-3 text-gray-500 flex-shrink-0" />
                <div>
                    <p className="text-sm text-gray-600">{t('executiveSummary.clientRuc')}</p>
                    <p className="font-semibold text-gray-800 break-words">{projectData.rucCi || 'N/A'}</p>
                </div>
            </div>
        </div>
    );
};

const CashFlowTable = ({ projectedCashFlow, formatCurrency }) => {
    const { t } = useTranslation(['viability', 'common']);
    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm">
                <thead className="bg-gray-50">
                    <tr>
                        <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase">{t('common:year')}</th>
                        <th className="px-2 py-2 text-right text-xs font-medium text-gray-500 uppercase">{t('executiveSummary.annualFlow')}</th>
                        <th className="px-2 py-2 text-right text-xs font-medium text-gray-500 uppercase">{t('executiveSummary.cumulativeFlow')}</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    {projectedCashFlow.map((flow) => (
                        <tr key={flow.year}>
                            <td className="px-2 py-2 whitespace-nowrap text-sm font-medium text-gray-900">{flow.year === 0 ? t('executiveSummary.investment') : `${t('common:year')} ${flow.year}`}</td>
                            <td className={`px-2 py-2 whitespace-nowrap text-sm text-right font-semibold ${flow.annualFlow >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(flow.annualFlow)}</td>
                            <td className={`px-2 py-2 whitespace-nowrap text-sm text-right font-semibold ${flow.cumulativeFlow >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(flow.cumulativeFlow)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export { SummarySection, GeneralData, CashFlowTable };