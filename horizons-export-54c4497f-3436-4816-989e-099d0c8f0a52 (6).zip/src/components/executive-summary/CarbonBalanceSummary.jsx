import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowDown, Leaf, DollarSign } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const CarbonBalanceSummary = ({ carbonCalculations, projectData }) => {
    const { t } = useTranslation(['calculator', 'carbonBalance']);
    const { tech, comparison } = carbonCalculations;

    const formatNumber = (num, decimals = 0) => {
        if (typeof num !== 'number' || isNaN(num)) return '0';
        return num.toLocaleString('de-DE', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
    };

    const formatCurrency = (num) => {
        if (typeof num !== 'number' || isNaN(num)) return 'U$ 0';
        return `U$ ${formatNumber(num, 0)}`;
    };

    const isCarbonNegative = tech.netBalance < 0;

    const metrics = [
        {
            title: t('carbonBalance:netBalanceTech'),
            value: formatNumber(tech.netBalance, 0),
            unit: 'tCO2e/año',
            icon: Leaf,
            color: isCarbonNegative ? 'text-green-600' : 'text-red-600',
            bgColor: isCarbonNegative ? 'bg-green-50' : 'bg-red-50'
        },
        {
            title: t('carbonBalance:emissionsReduction'),
            value: `${formatNumber(comparison.emissionsReductionPct * 100, 1)}%`,
            unit: t('carbonBalance:vsTraditional'),
            icon: ArrowDown,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
        },
        {
            title: t('carbonBalance:revenuePotential'),
            value: formatCurrency(tech.potentialRevenue),
            unit: t('carbonBalance:revenueNote', { years: projectData?.projectYears || 10 }),
            icon: DollarSign,
            color: 'text-emerald-600',
            bgColor: 'bg-emerald-50'
        }
    ];

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {metrics.map((metric, index) => (
                <Card key={index} className={`${metric.bgColor} border-0 shadow-sm hover:shadow-md transition-shadow`}>
                    <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-gray-700">{metric.title}</CardTitle>
                        <metric.icon className={`h-5 w-5 ${metric.color}`} />
                    </CardHeader>
                    <CardContent>
                        <div className={`text-3xl font-bold ${metric.color}`}>
                            {metric.value}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">{metric.unit}</p>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
};

export default CarbonBalanceSummary;