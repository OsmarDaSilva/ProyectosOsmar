import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const AssetDescriptionCards = ({ assets, t }) => {
    if (!assets || assets.length === 0) {
        return (
            <div className="text-center text-gray-500 py-4">
                {t('executiveSummary.assetDescription.noAssets')}
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {assets.map(asset => {
                const labelKey = `executiveSummary.assetLabel.${asset.id}`;
                let descriptionText;

                if (asset.id === 'tierra') {
                    descriptionText = "La inversión en tierra representa la base estratégica de cualquier proyecto agrícola o ganadero. Garantiza la disponibilidad de superficie productiva, genera seguridad patrimonial y asegura estabilidad a largo plazo. La tierra es un activo que se valoriza con el tiempo y sobre el cual se sostienen todas las demás actividades productivas. Es el pilar central del desarrollo sostenible del proyecto.";
                } else if (asset.id === 'riego') {
                    descriptionText = "La tecnología de riego es fundamental para intensificar la producción agrícola y ganadera. Permite un uso eficiente del agua, garantiza la disponibilidad de forraje y reduce los riesgos climáticos como sequías o variabilidad estacional. Es una inversión estratégica que aumenta la productividad, estabiliza los rendimientos y asegura la resiliencia del sistema productivo frente a condiciones adversas.";
                } else if (asset.id === 'infraestructura') {
                    descriptionText = "La infraestructura productiva incluye corrales, caminos, galpones, instalaciones de manejo y otras obras que permiten operar de manera eficiente. Estos activos son esenciales para reducir costos logísticos, optimizar el manejo del ganado y garantizar la seguridad de las operaciones. Una infraestructura sólida asegura fluidez en los procesos, mejora la eficiencia del trabajo diario y agrega valor al sistema productivo en el largo plazo.";
                } else if (asset.id === 'mecanizacion') {
                    descriptionText = "La mecanización incorpora tractores, implementos y equipos agrícolas que permiten realizar las labores de campo con mayor rapidez, precisión y menor esfuerzo humano. Estos activos aumentan la productividad, reducen tiempos de trabajo y aseguran un uso más eficiente de los recursos. Además, la mecanización facilita la adopción de tecnologías modernas, disminuye riesgos operativos y contribuye a una producción más estable y competitiva.";
                } else if (asset.id === 'fotovoltaica') {
                    descriptionText = "La inversión en energía solar fotovoltaica dota al proyecto de una fuente de energía limpia y sostenible, reduciendo la dependencia de combustibles fósiles y los costos operativos a largo plazo. Este sistema no solo disminuye la huella de carbono del proyecto, sino que también garantiza autonomía energética y seguridad en el suministro eléctrico para las operaciones críticas, contribuyendo directamente a la sostenibilidad ambiental.";
                } else if (asset.id === 'otros') {
                    descriptionText = "Esta categoría incluye inversiones estratégicas que complementan las operaciones principales del proyecto, como sistemas de monitoreo avanzado, software de gestión agrícola, vehículos de apoyo o equipos especializados. Son fundamentales para mejorar la eficiencia, optimizar la toma de decisiones y reforzar la capacidad del proyecto de adaptarse a nuevas tecnologías y desafíos del mercado.";
                }
                else {
                    const descriptionKey = asset.hasInvestment
                        ? `executiveSummary.assetDescription.${asset.id}_investment`
                        : `executiveSummary.assetDescription.${asset.id}_no_investment`;
                    descriptionText = t(descriptionKey);
                }

                return (
                    <Card key={asset.key} className="bg-gray-50 border-gray-200">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-base font-semibold text-gray-800">{t(labelKey)}</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-gray-700 leading-relaxed">{descriptionText}</p>
                        </CardContent>
                    </Card>
                );
            })}
        </div>
    );
};

export default AssetDescriptionCards;