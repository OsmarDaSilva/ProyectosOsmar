import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Upload, AlertTriangle } from 'lucide-react';
import * as XLSX from 'xlsx';

export const ExcelImporter = ({ onDataImported }) => {
  const { toast } = useToast();

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target.result;
        const workbook = XLSX.read(data, { type: 'binary', cellDates: true });
        
        const importedData = {};
        const validSheets = ['Inicial', 'Agricultura', 'Ganaderia'];

        workbook.SheetNames.forEach(sheetName => {
            const normalizedSheetName = sheetName.trim();
            const matchingValidSheet = validSheets.find(valid => valid.toLowerCase() === normalizedSheetName.toLowerCase());

            if (matchingValidSheet) {
                const worksheet = workbook.Sheets[sheetName];
                const json = XLSX.utils.sheet_to_json(worksheet);
                importedData[matchingValidSheet] = json;
            }
        });

        if (Object.keys(importedData).length === 0) {
          throw new Error("El archivo no contiene las pestañas requeridas ('Inicial', 'Agricultura', 'Ganaderia').");
        }

        onDataImported(importedData);

      } catch (error) {
        console.error("Error al procesar el archivo Excel:", error);
        toast({
          title: (
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
              <span>Error de importación</span>
            </div>
          ),
          description: error.message || "Hubo un problema al leer el archivo. Asegúrate de que el formato y las pestañas sean correctos.",
          variant: "destructive",
        });
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  return (
    <>
      <Label htmlFor="excel-upload" className="btn-primary cursor-pointer flex items-center">
        <Upload className="h-4 w-4 mr-2" />
        Importar Excel
      </Label>
      <Input
        id="excel-upload"
        type="file"
        className="hidden"
        accept=".xlsx, .xls, .xlsb, .xlsm"
        onChange={handleFileChange}
      />
    </>
  );
};