import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { logError } from '@/lib/error-logger';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
    console.error("Error de renderizado capturado por ErrorBoundary:", error, errorInfo);
    logError(error, {
      componentStack: errorInfo.componentStack,
      context: 'ErrorBoundary',
      module: 'app_shell'
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-background p-4 text-center">
          <AlertTriangle className="h-16 w-16 text-destructive mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">¡Ups! Algo salió mal.</h1>
          <p className="text-muted-foreground mb-6 max-w-md">
            Ocurrió un error inesperado en la aplicación. Nuestro equipo ha sido notificado. Por favor, intenta refrescar la página.
          </p>
          <Button onClick={() => window.location.reload()}>
            Refrescar Página
          </Button>
          {process.env.NODE_ENV === 'development' && (
            <details className="mt-6 text-left bg-muted p-4 rounded-lg max-w-2xl overflow-auto">
              <summary className="cursor-pointer font-semibold">Detalles del Error (Modo Desarrollo)</summary>
              <pre className="mt-2 text-sm whitespace-pre-wrap">
                {this.state.error && this.state.error.toString()}
                <br />
                {this.state.errorInfo && this.state.errorInfo.componentStack}
              </pre>
            </details>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;