import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, UploadCloud, Image as ImageIcon } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

const CompanySettings = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [companyData, setCompanyData] = useState({ name: '', country: '', address: '', phone: '', email: '', website: '', logo_url: '' });
  const [companyId, setCompanyId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const { data, isLoading: isLoadingData } = useQuery({
    queryKey: ['companyData', user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('user_id', user.id)
        .single();
      if (error && error.code !== 'PGRST116') {
        throw new Error(error.message);
      }
      return data;
    },
    enabled: !!user,
  });

  useEffect(() => {
    if (data) {
      setCompanyData({
        name: data.name || '',
        country: data.country || '',
        address: data.address || '',
        phone: data.phone || '',
        email: data.email || '',
        website: data.website || '',
        logo_url: data.logo_url || '',
      });
      setCompanyId(data.id);
    }
  }, [data]);

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploading(true);
    const fileExt = file.name.split('.').pop();
    const fileName = `${uuidv4()}.${fileExt}`;
    const filePath = `${user.id}/${fileName}`;

    try {
      const { error: uploadError } = await supabase.storage
        .from('company_logos')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      const { data: urlData } = supabase.storage
        .from('company_logos')
        .getPublicUrl(filePath);

      setCompanyData(prev => ({ ...prev, logo_url: urlData.publicUrl }));
      toast({
        title: '¡Logo subido!',
        description: 'El logo se ha subido correctamente. No olvide guardar los cambios.',
        className: 'bg-green-100 border-green-400',
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error al subir el logo',
        description: error.message,
      });
    } finally {
      setUploading(false);
    }
  };

  const mutation = useMutation({
    mutationFn: async (updatedData) => {
      const dataToSave = {
        ...updatedData,
        user_id: user.id,
      };

      if (companyId) {
        const { error } = await supabase.from('companies').update(dataToSave).eq('id', companyId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('companies').insert(dataToSave);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companyData', user.id] });
      queryClient.invalidateQueries({ queryKey: ['companyDataForPrint', user.id] });
      toast({
        title: '¡Éxito!',
        description: 'Los datos de la empresa se han guardado correctamente.',
        className: 'bg-green-100 border-green-400',
      });
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Error al guardar',
        description: error.message,
      });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(companyData);
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setCompanyData(prev => ({ ...prev, [id]: value }));
  };

  if (isLoadingData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Datos de la Empresa</CardTitle>
          <CardDescription>Cargando datos de la empresa...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center p-10">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <form onSubmit={handleSubmit}>
        <CardHeader>
          <CardTitle>Datos de la Empresa</CardTitle>
          <CardDescription>
            Esta información aparecerá en sus documentos, como presupuestos y facturas.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre de la Empresa</Label>
              <Input id="name" value={companyData.name} onChange={handleInputChange} placeholder="Ej: AGROinvest S.A." required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="country">País</Label>
              <Input id="country" value={companyData.country} onChange={handleInputChange} placeholder="Ej: Paraguay" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Dirección</Label>
              <Input id="address" value={companyData.address} onChange={handleInputChange} placeholder="Ej: Av. Principal 123" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Teléfono</Label>
              <Input id="phone" value={companyData.phone} onChange={handleInputChange} placeholder="Ej: +595 21 123 456" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Correo Electrónico</Label>
              <Input id="email" type="email" value={companyData.email} onChange={handleInputChange} placeholder="Ej: contacto@agroinvest.com" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="website">Página Web</Label>
              <Input id="website" value={companyData.website} onChange={handleInputChange} placeholder="Ej: https://www.agroinvest.com" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Logo de la Empresa</Label>
            <div className="flex items-center gap-4">
              <div className="w-24 h-24 rounded-md border border-dashed flex items-center justify-center bg-muted">
                {companyData.logo_url ? (
                  <img src={companyData.logo_url} alt="Logo actual" className="max-w-full max-h-full object-contain" />
                ) : (
                  <ImageIcon className="h-10 w-10 text-muted-foreground" />
                )}
              </div>
              <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                {uploading ? 'Subiendo...' : 'Subir Logo'}
              </Button>
              <Input
                type="file"
                ref={fileInputRef}
                onChange={handleLogoUpload}
                className="hidden"
                accept="image/png, image/jpeg, image/svg+xml"
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Suba el logo de su empresa. Recomendado: PNG, JPG o SVG.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={mutation.isPending || uploading}>
            {(mutation.isPending || uploading) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Guardar Cambios
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default CompanySettings;