import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2, Save } from 'lucide-react';

const MODULES = [
    { id: 'forage', name: 'Forraje' },
    { id: 'agriculture', name: 'Agricultura' },
    { id: 'livestock', name: 'Ganadería' },
    { id: 'finance', name: 'Finanzas' },
];

const ROLES = ['agronomist', 'financial', 'commercial', 'admin', 'collaborator'];

const AlertAssignmentRules = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [localRules, setLocalRules] = useState([]);

    const { data: rules, isLoading: isLoadingRules } = useQuery({
        queryKey: ['alertAssignmentRules', user?.id],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('alert_assignment_rules')
                .select('*')
                .eq('user_id', user.id);
            if (error) throw error;
            
            const rulesMap = new Map(data.map(rule => [rule.module, rule]));
            return MODULES.map(module => rulesMap.get(module.id) || { module: module.id, assigned_role: 'none' });
        },
        enabled: !!user,
    });

    useEffect(() => {
        if (rules) {
            setLocalRules(rules);
        }
    }, [rules]);

    const mutation = useMutation({
        mutationFn: async (updatedRules) => {
            const rulesToUpsert = updatedRules
                .filter(rule => rule.assigned_role && rule.assigned_role !== 'none')
                .map(({ module, assigned_role }) => ({
                    user_id: user.id,
                    module,
                    assigned_role,
                }));

            const { error } = await supabase
                .from('alert_assignment_rules')
                .upsert(rulesToUpsert, { onConflict: ['user_id', 'module'] });

            if (error) throw error;
        },
        onSuccess: () => {
            toast({ title: 'Reglas guardadas', description: 'Las reglas de asignación de alertas se han actualizado.' });
            queryClient.invalidateQueries({ queryKey: ['alertAssignmentRules', user?.id] });
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error al guardar', description: error.message });
        },
    });

    const handleRoleChange = (module, assigned_role) => {
        setLocalRules(prevRules => prevRules.map(rule => 
            rule.module === module ? { ...rule, assigned_role } : rule
        ));
    };

    const handleSaveChanges = () => {
        mutation.mutate(localRules);
    };

    if (isLoadingRules) {
        return <div className="flex justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    return (
        <Card>
            <CardHeader>
                <CardTitle>Reglas de Asignación Automática de Alertas</CardTitle>
                <CardDescription>
                    Define qué rol de usuario recibirá automáticamente las alertas generadas por cada módulo.
                    El sistema asignará la alerta al primer usuario disponible con el rol seleccionado.
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                {localRules?.map(rule => (
                    <div key={rule.module} className="flex items-center justify-between p-3 border rounded-lg">
                        <span className="font-medium">{MODULES.find(m => m.id === rule.module)?.name}</span>
                        <Select value={rule.assigned_role || 'none'} onValueChange={(value) => handleRoleChange(rule.module, value)}>
                            <SelectTrigger className="w-[250px]">
                                <SelectValue placeholder="Seleccionar un rol..." />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="none">Sin asignación automática</SelectItem>
                                {ROLES.map(role => (
                                    <SelectItem key={role} value={role} className="capitalize">{role}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                ))}
                <div className="flex justify-end pt-4">
                    <Button onClick={handleSaveChanges} disabled={mutation.isPending}>
                        {mutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                        Guardar Cambios
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
};

export default AlertAssignmentRules;