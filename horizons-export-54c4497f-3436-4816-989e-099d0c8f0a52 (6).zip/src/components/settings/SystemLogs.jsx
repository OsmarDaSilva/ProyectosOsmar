import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Skeleton } from '@/components/ui/skeleton';
import { useDebounce } from '@/hooks/useDebounce';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

const PAGE_SIZE = 20;

const fetchLogs = async ({ queryKey }) => {
  const [_key, { page, level, module, userQuery }] = queryKey;
  
  let query = supabase
    .from('app_logs')
    .select('*, profile:profiles(full_name, email)', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
    
  if (level) query = query.eq('level', level);
  if (module) query = query.ilike('module', `%${module}%`);
  if (userQuery) {
    query = query.or(`message.ilike.%${userQuery}%,details->>stack.ilike.%${userQuery}%,profile.email.ilike.%${userQuery}%,profile.full_name.ilike.%${userQuery}%`);
  }

  const { data, error, count } = await query;

  if (error) throw error;
  return { data, count };
};

const SystemLogs = () => {
  const { profile } = useAuth();
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState({ level: '', module: '', userQuery: '' });
  const debouncedUserQuery = useDebounce(filters.userQuery, 500);

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ['systemLogs', { page, level: filters.level, module: filters.module, userQuery: debouncedUserQuery }],
    queryFn: fetchLogs,
    keepPreviousData: true,
    enabled: profile?.role === 'admin' || profile?.role === 'owner',
  });

  const logs = data?.data || [];
  const count = data?.count || 0;
  const totalPages = Math.ceil(count / PAGE_SIZE);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPage(1);
  };
  
  const getLevelBadge = (level) => {
    switch (level) {
      case 'error': return 'destructive';
      case 'warn': return 'secondary';
      default: return 'outline';
    }
  };

  if (profile?.role !== 'admin' && profile?.role !== 'owner') {
    return <p>No tienes permiso para ver esta sección.</p>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Logs del Sistema</CardTitle>
        <CardDescription>Registro de eventos y errores de la aplicación.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <Input
            placeholder="Buscar por mensaje, usuario, stack..."
            value={filters.userQuery}
            onChange={(e) => handleFilterChange('userQuery', e.target.value)}
            className="flex-grow"
          />
          <Select value={filters.level} onValueChange={(v) => handleFilterChange('level', v)}>
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder="Nivel" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Todos los niveles</SelectItem>
              <SelectItem value="error">Error</SelectItem>
              <SelectItem value="warn">Warning</SelectItem>
              <SelectItem value="info">Info</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Filtrar por módulo..."
            value={filters.module}
            onChange={(e) => handleFilterChange('module', e.target.value)}
            className="w-full md:w-[200px]"
          />
        </div>
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha</TableHead>
                <TableHead>Nivel</TableHead>
                <TableHead>Módulo</TableHead>
                <TableHead>Usuario</TableHead>
                <TableHead>Mensaje</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: PAGE_SIZE }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell colSpan={6}><Skeleton className="h-6 w-full" /></TableCell>
                  </TableRow>
                ))
              ) : isError ? (
                <TableRow><TableCell colSpan={6} className="text-center text-red-500 py-8">Error: {error.message}</TableCell></TableRow>
              ) : logs.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8">No se encontraron logs con los filtros actuales.</TableCell></TableRow>
              ) : (
                logs.map(log => (
                  <TableRow key={log.id}>
                    <TableCell className="text-xs whitespace-nowrap">{format(new Date(log.created_at), 'dd/MM/yy HH:mm:ss', { locale: es })}</TableCell>
                    <TableCell><Badge variant={getLevelBadge(log.level)}>{log.level}</Badge></TableCell>
                    <TableCell className="font-mono text-xs">{log.module}</TableCell>
                    <TableCell className="text-xs">{log.profile?.email || 'Sistema'}</TableCell>
                    <TableCell className="text-sm truncate max-w-xs">{log.message}</TableCell>
                    <TableCell className="text-right">
                      <Dialog>
                        <DialogTrigger asChild><Button variant="ghost" size="sm">Ver Detalles</Button></DialogTrigger>
                        <DialogContent className="max-w-3xl">
                          <DialogHeader>
                            <DialogTitle>Detalles del Log</DialogTitle>
                          </DialogHeader>
                          <pre className="mt-2 w-full rounded-md bg-slate-950 p-4 overflow-auto max-h-[60vh]">
                            <code className="text-white">{JSON.stringify(log.details, null, 2)}</code>
                          </pre>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <div className="flex items-center justify-between mt-4">
          <p className="text-sm text-muted-foreground">Página {page} de {totalPages}. Total de {count} registros.</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}>Anterior</Button>
            <Button variant="outline" size="sm" onClick={() => setPage(p => p + 1)} disabled={page >= totalPages}>Siguiente</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SystemLogs;