import React from 'react';
    import { cva } from 'class-variance-authority';
    import { cn } from '@/lib/utils';

    const badgeVariants = cva(
      'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2',
      {
        variants: {
          variant: {
            default: 'border-transparent bg-blue-500 text-primary-foreground hover:bg-blue-500/80',
            secondary: 'border-transparent bg-gray-500 text-secondary-foreground hover:bg-gray-500/80',
            destructive: 'border-transparent bg-red-500 text-destructive-foreground hover:bg-red-500/80',
            outline: 'text-foreground',
            success: 'border-transparent bg-green-500 text-white hover:bg-green-500/80'
          },
        },
        defaultVariants: {
          variant: 'default',
        },
      }
    );

    function Badge({ className, variant, ...props }) {
      return (
        <div className={cn(badgeVariants({ variant }), className)} {...props} />
      );
    }

    export { Badge, badgeVariants };