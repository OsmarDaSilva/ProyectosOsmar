import React, { useState } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { useToast } from "@/components/ui/use-toast";
    import { UserPlus } from 'lucide-react';
    import UserTable from '@/components/users/UserTable';
    import InviteUserDialog from '@/components/users/InviteUserDialog';
    import EditUserDialog from '@/components/users/EditUserDialog';
    import DeleteUserDialog from '@/components/users/DeleteUserDialog';
    import ResetPasswordDialog from '@/components/users/ResetPasswordDialog';

    const UserManagement = () => {
      const { toast } = useToast();
      const queryClient = useQueryClient();
      const { user: currentUser } = useAuth();
      const isOwner = currentUser?.role === 'owner';
      
      const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
      const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
      const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
      const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] = useState(false);
      
      const [userToEdit, setUserToEdit] = useState(null);
      const [userToDelete, setUserToDelete] = useState(null);
      const [userToResetPassword, setUserToResetPassword] = useState(null);

      const { data: users, isLoading: isLoadingUsers } = useQuery({
        queryKey: ['users'],
        queryFn: async () => {
          const { data, error } = await supabase.rpc('get_all_users');
          if (error) throw error;
          return data;
        },
      });

      const updateMutation = useMutation({
        mutationFn: async (userData) => {
          if (userData.role) {
            const { error } = await supabase.rpc('set_user_role', {
              p_target_user_id: userData.id,
              p_new_role: userData.role
            });
            if (error) throw error;
          } else {
            const { error } = await supabase.functions.invoke('update-user-profile', {
              body: { userId: userData.id, fullName: userData.full_name, phone: userData.phone },
            });
            if (error) throw error;
          }
        },
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['users'] });
          setIsEditDialogOpen(false);
          toast({
            title: "Usuario actualizado",
            description: "La información del usuario se ha actualizado correctamente.",
          });
        },
        onError: (error) => {
          toast({
            variant: "destructive",
            title: "Error al actualizar",
            description: error.message,
          });
        },
      });

      const deleteMutation = useMutation({
        mutationFn: async (userId) => {
          const { error } = await supabase.functions.invoke('delete-user', {
            body: { userId },
          });
          if (error) throw error;
        },
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['users'] });
          setIsDeleteDialogOpen(false);
          toast({
            title: "Usuario eliminado",
            description: "El usuario ha sido eliminado permanentemente.",
          });
        },
        onError: (error) => {
          toast({
            variant: "destructive",
            title: "Error al eliminar",
            description: error.message,
          });
        },
      });
      
      const handleEditUser = (user) => {
        setUserToEdit({ ...user });
        setIsEditDialogOpen(true);
      };

      const handleDeleteUser = (user) => {
        setUserToDelete(user);
        setIsDeleteDialogOpen(true);
      };

      const handleResetPassword = (user) => {
        setUserToResetPassword(user);
        setIsResetPasswordDialogOpen(true);
      };

      return (
        <>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Gestión de Usuarios</CardTitle>
                <CardDescription>Invite, edite y gestione los roles de su equipo.</CardDescription>
              </div>
              {isOwner && (
                <Button onClick={() => setIsInviteDialogOpen(true)}>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Invitar Usuario
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <UserTable 
                users={users}
                isLoading={isLoadingUsers}
                currentUser={currentUser}
                onEditUser={handleEditUser}
                onDeleteUser={handleDeleteUser}
                onResetPassword={handleResetPassword}
                updateMutation={updateMutation}
              />
            </CardContent>
          </Card>

          <InviteUserDialog
            isOpen={isInviteDialogOpen}
            onOpenChange={setIsInviteDialogOpen}
          />
          
          <EditUserDialog
            isOpen={isEditDialogOpen}
            onOpenChange={setIsEditDialogOpen}
            userToEdit={userToEdit}
            setUserToEdit={setUserToEdit}
            updateMutation={updateMutation}
            currentUser={currentUser}
          />

          <DeleteUserDialog
            isOpen={isDeleteDialogOpen}
            onOpenChange={setIsDeleteDialogOpen}
            userToDelete={userToDelete}
            deleteMutation={deleteMutation}
          />
          
          <ResetPasswordDialog
            isOpen={isResetPasswordDialogOpen}
            onOpenChange={setIsResetPasswordDialogOpen}
            userToResetPassword={userToResetPassword}
          />
        </>
      );
    };

    export default UserManagement;