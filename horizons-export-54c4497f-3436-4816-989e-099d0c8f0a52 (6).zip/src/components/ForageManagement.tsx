import React, { useState, FC } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from "@/components/ui/use-toast";
import { Trash2, Sprout, PlusCircle, Save, XCircle, FileText } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';
import PastureTechnicalSheetUploader from '@/components/pasture/PastureTechnicalSheetUploader';

interface ForageRow {
    id: string;
    user_id: string;
    pasture_type: string;
    monthly_production: number[];
}

interface ForageManagementProps {
    userId: string;
}

const ForageLoader: FC = () => (
    <div className="space-y-2">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-10 w-full" />
    </div>
);

const fetchForageData = async (userId: string): Promise<ForageRow[]> => {
    if (!userId) return [];
    const { data, error } = await supabase.from('forage_production').select('*').eq('user_id', userId);
    if (error) throw new Error(error.message);
    return data as ForageRow[];
};

const ForageManagement: FC<ForageManagementProps> = ({ userId }) => {
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [editingRowId, setEditingRowId] = useState<string | null>(null);
    const [sheetUploaderOpen, setSheetUploaderOpen] = useState(false);
    const [selectedForageRow, setSelectedForageRow] = useState<ForageRow | null>(null);

    const { data: forageData, isLoading, isError, error, refetch } = useQuery({
        queryKey: ['forageProduction', userId],
        queryFn: () => fetchForageData(userId),
        enabled: !!userId,
    });

    const upsertMutation = useMutation({
        mutationFn: async (rowsToUpsert: ForageRow[]) => {
            const { error } = await supabase.from('forage_production').upsert(rowsToUpsert);
            if (error) throw new Error(error.message);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['forageProduction', userId] });
            toast({ title: 'Guardado', description: 'Los cambios en las pasturas se han guardado.' });
            setEditingRowId(null);
        },
        onError: (e: Error) => {
            toast({ variant: 'destructive', title: 'Error al guardar', description: e.message });
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (rowId: string) => {
            const { error } = await supabase.from('forage_production').delete().eq('id', rowId);
            if (error) throw new Error(error.message);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['forageProduction', userId] });
            toast({ title: 'Fila Eliminada', description: 'La fila ha sido eliminada correctamente.' });
        },
        onError: (e: Error) => {
            toast({ variant: 'destructive', title: 'Error al eliminar', description: e.message });
        },
    });

    const handleAddNew = () => {
        const newRow: ForageRow = {
            id: uuidv4(),
            user_id: userId,
            pasture_type: 'Nueva Pastura',
            monthly_production: Array(12).fill(0),
        };
        queryClient.setQueryData(['forageProduction', userId], (old: ForageRow[] | undefined) => [newRow, ...(old || [])]);
        setEditingRowId(newRow.id);
    };

    const handleSave = (rowData: ForageRow) => {
        const currentData = queryClient.getQueryData<ForageRow[]>(['forageProduction', userId]) || [];
        const updatedData = currentData.map(row => (row.id === rowData.id ? rowData : row));
        upsertMutation.mutate(updatedData);
    };

    const handleDeleteRow = (idToDelete: string) => {
        deleteMutation.mutate(idToDelete);
    };

    const handleCancelEdit = () => {
        setEditingRowId(null);
        refetch();
    };

    const handleOpenSheetUploader = (row: ForageRow) => {
        setSelectedForageRow(row);
        setSheetUploaderOpen(true);
    };

    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

    const EditableRow: FC<{ row: ForageRow, onSave: (row: ForageRow) => void, onCancel: () => void }> = ({ row, onSave, onCancel }) => {
        const [editedRow, setEditedRow] = useState(row);
        const handleMonthChange = (index: number, value: string) => {
            const newMonthlyProduction = [...editedRow.monthly_production];
            newMonthlyProduction[index] = parseFloat(String(value).replace(',', '.')) || 0;
            setEditedRow({ ...editedRow, monthly_production: newMonthlyProduction });
        };
        return (
            <TableRow className="bg-blue-50">
                <TableCell>
                    <Input value={editedRow.pasture_type} onChange={(e) => setEditedRow({...editedRow, pasture_type: e.target.value})} className="min-w-[150px]" />
                </TableCell>
                {months.map((_, index) => (
                    <TableCell key={index}>
                        <Input type="number" step="0.001" value={editedRow.monthly_production[index]} onChange={(e) => handleMonthChange(index, e.target.value)} className="w-24 text-center" />
                    </TableCell>
                ))}
                <TableCell className="text-right">
                    <div className="flex gap-2">
                        <Button size="sm" onClick={() => onSave(editedRow)} disabled={upsertMutation.isPending}><Save className="h-4 w-4" /></Button>
                        <Button size="sm" variant="outline" onClick={onCancel} disabled={upsertMutation.isPending}><XCircle className="h-4 w-4" /></Button>
                    </div>
                </TableCell>
            </TableRow>
        );
    };

    return (
        <>
            <Card>
                <CardHeader>
                    <div className="flex items-center gap-3">
                        <Sprout className="h-6 w-6 text-green-600" />
                        <CardTitle>Balance Forrajero - Gestión de Pasturas</CardTitle>
                    </div>
                    <CardDescription>
                        Edite los perfiles de producción de sus pasturas. Los cambios se guardan automáticamente.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <QueryStateWrapper isLoading={isLoading} isError={isError} error={error as Error} data={forageData} loader={<ForageLoader />} onRetry={refetch}>
                        {(data) => (
                            <>
                                <div className="overflow-x-auto">
                                    <Table>
                                        <TableHeader>
                                            <TableRow>
                                                <TableHead>Tipo de Pastura</TableHead>
                                                {months.map((m) => <TableHead key={m} className="text-center">{m}</TableHead>)}
                                                <TableHead className="text-right">Acciones</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                            {data.map((row) => (
                                                editingRowId === row.id ? (
                                                    <EditableRow key={row.id} row={row} onSave={handleSave} onCancel={handleCancelEdit} />
                                                ) : (
                                                    <TableRow key={row.id}>
                                                        <TableCell className="font-medium">{row.pasture_type}</TableCell>
                                                        {row.monthly_production.map((prod, index) => (
                                                            <TableCell key={index} className="text-center">{new Intl.NumberFormat('es-PY', { minimumFractionDigits: 3, maximumFractionDigits: 3 }).format(prod)}</TableCell>
                                                        ))}
                                                        <TableCell className="text-right">
                                                            <div className="flex gap-2">
                                                                <Button size="sm" variant="outline" onClick={() => handleOpenSheetUploader(row)}><FileText className="h-4 w-4" /></Button>
                                                                <Button size="sm" variant="ghost" onClick={() => handleDeleteRow(row.id)}><Trash2 className="h-4 w-4 text-red-500" /></Button>
                                                            </div>
                                                        </TableCell>
                                                    </TableRow>
                                                )
                                            ))}
                                        </TableBody>
                                    </Table>
                                </div>
                                <Button onClick={handleAddNew} className="mt-4">
                                    <PlusCircle className="mr-2 h-4 w-4" />
                                    Añadir Nueva Pastura
                                </Button>
                            </>
                        )}
                    </QueryStateWrapper>
                </CardContent>
            </Card>
            {selectedForageRow && (
                <PastureTechnicalSheetUploader
                    isOpen={sheetUploaderOpen}
                    setIsOpen={setSheetUploaderOpen}
                    forageRow={selectedForageRow}
                    userId={userId}
                />
            )}
        </>
    );
};

export default ForageManagement;