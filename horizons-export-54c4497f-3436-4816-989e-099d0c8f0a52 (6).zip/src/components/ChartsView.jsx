import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, DollarSign, LineChart as LineChartIcon, Target, LandPlot, Printer } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { Button } from '@/components/ui/button';
import { exportToPdf } from '@/lib/pdfUtils';
import BreakEvenChart from '@/components/BreakEvenChart';
import useFinancialCalculations from '@/hooks/useFinancialCalculations';
import { useTirVanRoyPayback } from '@/hooks/useTirVanRoyPayback';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { useTranslation } from 'react-i18next';

const ChartsView = () => {
  const { t } = useTranslation(['calculator', 'common', 'viability']);
  const { projectData, agricultureData, ganaderiaData } = useProjectData();
  const tirVanCalculations = useTirVanRoyPayback({ projectData, agricultureData, ganaderiaData });
  const financialCalculations = useFinancialCalculations(projectData, agricultureData, ganaderiaData, tirVanCalculations);
  
  const printableRef = useRef();
  const footerText = t('generatedBy', { ns: 'common' });

  const handlePrint = () => {
    const fileName = `${t('charts.pdfFilename')}_${projectData?.projectName?.replace(/\s+/g, '_') || 'proyecto'}`;
    exportToPdf(printableRef.current, fileName, 'portrait', true, footerText);
  };

  if (!financialCalculations || !projectData || !tirVanCalculations || tirVanCalculations.tableData.length === 0) {
    return (
      <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
        <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800">{t('charts.insufficientDataTitle')}</h2>
        <p className="text-gray-600 text-lg mt-2">
          {t('charts.insufficientDataSubtitle')}
        </p>
        <p className="text-gray-500 mt-1">
          {t('charts.insufficientDataSuggestion')}
        </p>
      </div>
    );
  }

  const { traditional, tech, paybackPeriod, projectHectares } = financialCalculations;
  const { tableData } = tirVanCalculations;
  
  const comparisonData = [
    { name: t('charts.revenue'), [t('models.traditional')]: traditional.revenue, [t('models.technified')]: tech.revenue },
    { name: t('charts.costs'), [t('models.traditional')]: traditional.totalCosts, [t('models.technified')]: tech.totalCosts },
    { name: t('charts.profit'), [t('models.traditional')]: traditional.grossProfit, [t('models.technified')]: tech.grossProfit },
  ];

  const profitabilityPerHectareData = [
    { 
      name: t('charts.profitabilityPerHaTitle'), 
      [t('charts.techRevenue')]: projectHectares > 0 ? (tech.revenue / projectHectares) : 0,
      [t('charts.techCosts')]: projectHectares > 0 ? (tech.totalCosts / projectHectares) : 0,
      [t('charts.tradRevenue')]: projectHectares > 0 ? (traditional.revenue / projectHectares) : 0,
      [t('charts.tradCosts')]: projectHectares > 0 ? (traditional.totalCosts / projectHectares) : 0,
    }
  ];

  const yAxisFormatter = (value) => {
    if (Math.abs(value) >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
    if (Math.abs(value) >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
    if (Math.abs(value) >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
    return value;
  };
  
  const formatCurrencyForTooltip = (value) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2,
    }).format(value);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-4 bg-white/80 backdrop-blur-sm rounded-lg shadow-lg border border-gray-200">
          <p className="font-bold text-gray-800">{label}</p>
          <p className="text-sm text-orange-600">{`${t('models.traditional')}: ${formatCurrencyForTooltip(payload[0]?.value || 0)}`}</p>
          <p className="text-sm text-green-600">{`${t('models.technified')}: ${formatCurrencyForTooltip(payload[1]?.value || 0)}`}</p>
        </div>
      );
    }
    return null;
  };
  
   const projectedCashFlow = tableData.map(d => ({ year: d.year, annualFlow: d.flujoCajaNeto, cumulativeFlow: d.flujoCajaAcumulado }));

   const cumulativeCashFlowData = tableData.map(d => ({
      year: d.year,
      name: d.year === 0 ? t('charts.initial') : `${t('common:year')} ${d.year}`,
      [t('charts.cumulativeCashFlow')]: d.flujoCajaAcumulado
   }));

   const gradientOffset = () => {
    const dataMax = Math.max(...cumulativeCashFlowData.map((i) => i[t('charts.cumulativeCashFlow')]));
    const dataMin = Math.min(...cumulativeCashFlowData.map((i) => i[t('charts.cumulativeCashFlow')]));
    if (dataMax <= 0) return 0;
    if (dataMin >= 0) return 1;
    return dataMax / (dataMax - dataMin);
  };
  const off = gradientOffset();

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-center gap-4"
      >
        <div className="text-center space-y-2 flex-grow">
            <h1 className="text-2xl sm:text-4xl font-bold gradient-text">{t('charts.title')}: {projectData?.projectName || ''}</h1>
            <p className="text-sm sm:text-base text-gray-600">{t('charts.subtitle')}</p>
        </div>
        <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700 flex-shrink-0">
          <Printer className="mr-2 h-4 w-4" />
          {t('common:exportPdf')}
        </Button>
      </motion.div>

      <div ref={printableRef} className="p-2 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center text-base sm:text-lg"><DollarSign className="mr-2 h-5 w-5 text-blue-500" />{t('charts.annualComparison')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={comparisonData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" fontSize={12} />
                      <YAxis tickFormatter={yAxisFormatter} fontSize={12} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: '12px' }} />
                      <Bar dataKey={t('models.traditional')} fill="#f97316" />
                      <Bar dataKey={t('models.technified')} fill="#16a34a" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center text-base sm:text-lg"><LineChartIcon className="mr-2 h-5 w-5 text-purple-500" />{t('charts.cumulativeCashFlowTitle')}</CardTitle>
              </CardHeader>
              <CardContent>
                 <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                          data={cumulativeCashFlowData}
                          margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
                      >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" fontSize={12} />
                          <YAxis tickFormatter={yAxisFormatter} fontSize={12} />
                          <Tooltip formatter={(value) => formatCurrencyForTooltip(value)} />
                          <Legend wrapperStyle={{ fontSize: '12px' }} />
                           <defs>
                              <linearGradient id="splitColor" x1="0" y1="0" x2="0" y2="1">
                                <stop offset={off} stopColor="#16a34a" stopOpacity={1} />
                                <stop offset={off} stopColor="#ef4444" stopOpacity={1} />
                              </linearGradient>
                          </defs>
                          <Line
                              type="monotone"
                              dataKey={t('charts.cumulativeCashFlow')}
                              stroke="url(#splitColor)"
                              strokeWidth={3}
                              dot={{ r: 4 }}
                              activeDot={{ r: 8 }}
                          />
                      </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
        
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-base sm:text-lg"><Target className="mr-2 h-5 w-5 text-red-500" />{t('charts.breakEvenTitle')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full">
                <BreakEvenChart cashFlow={projectedCashFlow} paybackPeriod={paybackPeriod} />
              </div>
               <div className="text-center mt-4 text-sm text-gray-600">
                  <p>{t('charts.breakEvenNote', { paybackPeriod: paybackPeriod })}</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

         <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-base sm:text-lg"><LandPlot className="mr-2 h-5 w-5 text-teal-500" />{t('charts.profitabilityPerHaTitle')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={profitabilityPerHectareData} layout="vertical" margin={{ top: 20, right: 20, left: 20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" tickFormatter={yAxisFormatter} fontSize={12} />
                          <YAxis type="category" dataKey="name" width={120} fontSize={12} />
                          <Tooltip formatter={(value) => formatCurrencyForTooltip(value)} />
                          <Legend wrapperStyle={{ fontSize: '12px' }} />
                          <Bar dataKey={t('charts.techRevenue')} stackId="tecnificado" fill="#2dd4bf" name={t('charts.techRevenue')} />
                          <Bar dataKey={t('charts.techCosts')} stackId="tecnificado" fill="#f43f5e" name={t('charts.techCosts')} />
                          <Bar dataKey={t('charts.tradRevenue')} stackId="tradicional" fill="#facc15" name={t('charts.tradRevenue')} />
                          <Bar dataKey={t('charts.tradCosts')} stackId="tradicional" fill="#f97316" name={t('charts.tradCosts')} />
                      </BarChart>
                  </ResponsiveContainer>
              </div>
              <div className="text-center mt-4 text-sm text-gray-600">
                  <p>{t('charts.profitabilityPerHaNote')}</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default ChartsView;