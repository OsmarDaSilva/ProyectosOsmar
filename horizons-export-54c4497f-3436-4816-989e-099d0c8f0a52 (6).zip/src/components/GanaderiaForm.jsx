import React, { useRef } from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Switch } from '@/components/ui/switch';
    import { useGanaderiaCalculations } from '@/hooks/useGanaderiaCalculations';
    import { cn } from '@/lib/utils';
    import { Button } from '@/components/ui/button';
    import { Printer, Info, CheckCircle, AlertTriangle } from 'lucide-react';
    import { Alert, AlertDescription } from '@/components/ui/alert';
    import { exportToPdf } from '@/lib/pdfUtils';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Tooltip, TooltipProvider, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
    import { useTranslation } from 'react-i18next';

    const formatCurrency = (value, decimals = 2) => {
      const num = Number(value) || 0;
      const options = {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      };
      return new Intl.NumberFormat('es-PY', options).format(num);
    };

    const formatPercentage = (value) => {
      const num = Number(value) || 0;
      return `${(num * 100).toFixed(2)}%`.replace('.', ',');
    };

    const FormattedInput = ({ label, value, unit, className }) => (
        <div className="grid grid-cols-2 items-center">
            <Label className="text-sm">{label}</Label>
            <div className="flex items-center space-x-2">
                <Input disabled value={value} className={cn("h-8 text-right text-sm font-semibold border-none bg-transparent shadow-none px-1", className)} />
                {unit && <span className="text-xs text-gray-500 w-8 text-left">{unit}</span>}
            </div>
        </div>
    );

    const DataInput = ({ label, value, onChange, unit, isSelect = false, options = [] }) => {
        const { t } = useTranslation('common');
        return (
            <div className="grid grid-cols-2 items-center">
                <Label className="text-sm">{label}</Label>
                <div className="flex items-center space-x-2">
                    {isSelect ? (
                        <Select onValueChange={onChange} value={value}>
                            <SelectTrigger className="h-8 text-right text-sm">
                                <SelectValue placeholder={t('selectType')} />
                            </SelectTrigger>
                            <SelectContent>
                                {options.map(option => (
                                    <SelectItem key={option} value={option}>
                                        {option}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    ) : (
                        <Input
                            type={'text'}
                            value={value}
                            onChange={onChange}
                            className="h-8 text-right text-sm"
                        />
                    )}
                     {unit && <span className="text-xs text-gray-500 w-8 text-left">{unit}</span>}
                </div>
            </div>
        );
    };

    const ModelSection = ({ title, data, calculations, onChange, section, headerClass, formatDateForInput, isEnabled, onToggle }) => {
      const { t } = useTranslation(['simulations', 'common']);
      return (
      <Card className={cn("page-break-inside-avoid transition-opacity", !isEnabled && "opacity-50")}>
        <CardHeader className={cn("p-3 flex flex-row items-center justify-between", headerClass)}>
          <CardTitle className="text-base text-center font-bold text-white">{title}</CardTitle>
          <div className="flex items-center space-x-2 no-print">
            <Label htmlFor={`${section}-enabled`} className="text-white text-xs sr-only">{t('livestock.enableModel')}</Label>
            <Switch
              id={`${section}-enabled`}
              checked={isEnabled}
              onCheckedChange={onToggle}
              className="data-[state=checked]:bg-green-500"
            />
          </div>
        </CardHeader>
        <CardContent className={cn("p-4 space-y-1", !isEnabled && "pointer-events-none")}>
            <div className="grid grid-cols-3 items-center">
                <Label className="text-sm col-span-1">{t('livestock.headsPerHa')}</Label>
                <Input type="text" value={data.cantidad} onChange={(e) => onChange(section, 'cantidad', e.target.value)} className="h-8 text-right text-sm col-span-1"/>
                <FormattedInput value={formatCurrency(calculations.totalCabezas, 0)} unit={t('common:heads')} />
            </div>
            <div className="grid grid-cols-3 items-center">
                <Label className="text-sm col-span-1">{t('livestock.entryExitDate')}:</Label>
                <Input type="date" value={formatDateForInput(data.fechaEntrada)} onChange={(e) => onChange(section, 'fechaEntrada', e.target.value)} className="h-8 text-center text-sm" />
                <Input type="date" value={formatDateForInput(data.fechaSalida)} onChange={(e) => onChange(section, 'fechaSalida', e.target.value)} className="h-8 text-center text-sm" />
            </div>
            <div className="grid grid-cols-2 items-center">
              <FormattedInput label={t('livestock.fatteningDays')} value={formatCurrency(calculations.diasEngorde,0)} unit={t('common:days')} />
              <FormattedInput value={formatCurrency(calculations.duracionAnos, 1)} unit={t('common:years')} />
            </div>
            <div className="grid grid-cols-3 items-center">
                <Label className="text-sm col-span-1">{t('livestock.entryFreight')}:</Label>
                <Input value={data.fleteEntrada} onChange={(e) => onChange(section, 'fleteEntrada', e.target.value)} className="h-8 text-right text-sm"/>
                <FormattedInput value={formatCurrency(calculations.fleteTotal)} unit="U$" />
            </div>
             <div className="grid grid-cols-3 items-center">
                <Label className="text-sm col-span-1">{t('livestock.sellerCommission')}:</Label>
                <Input value={data.comisionVendedor} onChange={(e) => onChange(section, 'comisionVendedor', e.target.value)} className="h-8 text-right text-sm"/>
                <FormattedInput value={formatCurrency(calculations.comisionTotal)} unit="U$" />
            </div>
          <FormattedInput label={t('livestock.purchaseCostPerAnimal')} value={formatCurrency(calculations.costoCompraAnimal)} unit="U$" />
          <FormattedInput label={t('livestock.totalInterestPeriod')} value={formatCurrency(calculations.totalInteresesPeriodo)} unit="U$" />
          <FormattedInput label={t('livestock.totalHerdValue')} value={formatCurrency(calculations.valorRebano)} unit="U$" className="font-bold"/>
          
          <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.supplementationCost')}</Label>
            <Input value={data.costoSuplementacion} onChange={(e) => onChange(section, 'costoSuplementacion', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalSuplementacion)} unit="U$" />
          </div>
          <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.adminCost')}</Label>
            <Input value={data.costoAdministrativo} onChange={(e) => onChange(section, 'costoAdministrativo', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalAdministrativo)} unit="U$" />
          </div>
           <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.vaccinationCost')}</Label>
            <Input value={data.costoVacunacion} onChange={(e) => onChange(section, 'costoVacunacion', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalVacunacion)} unit="U$" />
          </div>
           <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.fertilizationCost')}</Label>
            <Input value={data.costoFertilizacion} onChange={(e) => onChange(section, 'costoFertilizacion', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalFertilizacion)} unit="U$" />
          </div>
           <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.energyCost')}</Label>
            <Input value={data.costoEnergia} onChange={(e) => onChange(section, 'costoEnergia', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalEnergia)} unit="U$" />
          </div>
           <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.maintenanceCost')}</Label>
            <Input value={data.costoManutencion} onChange={(e) => onChange(section, 'costoManutencion', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalManutencion)} unit="U$" />
          </div>
          <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.fuelCost')}</Label>
            <Input value={data.combustibleGasoil} onChange={(e) => onChange(section, 'combustibleGasoil', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalCombustible)} unit="U$" />
          </div>
          <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.otherCosts')}</Label>
            <Input value={data.otrosCostos} onChange={(e) => onChange(section, 'otrosCostos', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalOtrosCostos)} unit="U$" />
          </div>
          <div className="grid grid-cols-4 items-center">
            <Label className="text-sm col-span-1">{t('livestock.mortality')}</Label>
            <Input value={data.mortandad} onChange={(e) => onChange(section, 'mortandad', e.target.value)} className="h-8 text-right text-sm col-span-1" />
            <FormattedInput value={formatCurrency(calculations.cabezasMuertas, 2)} unit={t('common:heads')} />
            <FormattedInput value={formatCurrency(calculations.totalMortandad)} unit="U$" />
          </div>

          <FormattedInput label={t('livestock.interestOnOperatingCost')} value={formatCurrency(calculations.interesCostoOperativo)} unit="U$" />
          <FormattedInput label={t('livestock.totalAreaCosts')} value={formatCurrency(calculations.totalCostosArea)} unit="U$" className="font-bold"/>
          <FormattedInput label={t('livestock.productionCostPerAnimal')} value={formatCurrency(calculations.costoProduccionAnimal)} unit="U$" />
          <FormattedInput label={t('livestock.totalPurchaseAndOperatingCosts')} value={formatCurrency(calculations.totalCompraCostosOp)} unit="U$" className="font-bold"/>
          <FormattedInput label={t('livestock.totalCostPerAnimal')} value={formatCurrency(calculations.costoTotalAnimal)} unit="U$" />
          <FormattedInput label={t('livestock.herdSaleValue')} value={formatCurrency(calculations.valorVentaRebano)} unit="U$" className="font-bold text-green-700"/>
          <FormattedInput label={t('livestock.herdGrossMargin')} value={formatCurrency(calculations.margenNeto)} unit="U$" className="font-bold text-blue-700"/>
          
          <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.iragroTax')}</Label>
            <Input value={data.impuestoIragro} onChange={(e) => onChange(section, 'impuestoIragro', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalIragro)} unit="U$" />
          </div>
          <div className="grid grid-cols-3 items-center">
            <Label className="text-sm">{t('livestock.irpTax')}</Label>
            <Input value={data.impuestoIrp} onChange={(e) => onChange(section, 'impuestoIrp', e.target.value)} className="h-8 text-right text-sm" />
            <FormattedInput value={formatCurrency(calculations.totalIrp)} unit="U$" />
          </div>

          <FormattedInput label={t('livestock.finalHerdProfit')} value={formatCurrency(calculations.gananciaFinalRebano)} unit="U$" className="font-bold text-lg text-green-800"/>
          <FormattedInput label={t('livestock.finalProfitPerAnimal')} value={formatCurrency(calculations.gananciaFinalAnimal)} unit="U$" />
          <FormattedInput label={t('livestock.finalProfitPerHectare')} value={formatCurrency(calculations.gananciaFinalHectarea)} unit="U$" />
        </CardContent>
      </Card>
      );
    };

    const GanaderiaForm = ({ initialData, onUpdate, projectData }) => {
      const { t } = useTranslation(['simulations', 'common']);
      const { formData, setFormData, calculations } = useGanaderiaCalculations(initialData);
      const printableRef = useRef();
      const footerText = t('common:generatedBy');

      const animalTypeOptions = [
        "Novillo Toro",
        "Novillo Capon",
        "Vaquilla",
        "Vaca de cria",
        "Vaca descarte"
      ];

      const handlePrint = () => {
        const fileName = `${t('livestock.pdfFilename')}_${projectData?.projectName?.replace(/\s+/g, '_') || 'proyecto'}`;
        exportToPdf(printableRef.current, fileName, 'landscape', true, footerText);
      };

      const handleInputChange = (section, field, value) => {
        const newFormData = {
          ...formData,
          [section]: { ...formData[section], [field]: value }
        };
        setFormData(newFormData);
        if (onUpdate) {
          onUpdate(newFormData);
        }
      };

      const handleToggleEnabled = (module) => {
        const newFormData = {
          ...formData,
          [module]: !formData[module]
        };
        setFormData(newFormData);
        if (onUpdate) {
          onUpdate(newFormData);
        }
      };

      const bothModelsDisabled = !formData.use_traditional && !formData.use_intensive;

      return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
          <div id="ganaderia-printable" ref={printableRef} className="p-2 bg-white printable-area">
            <div className="space-y-6">
                <Card className="page-break-inside-avoid">
                <CardHeader className="bg-gray-800 text-white p-3 flex flex-row items-center justify-between">
                    <div className="flex items-center gap-3">
                        <CardTitle className="text-lg text-center">{t('livestock.title')}: {projectData?.projectName || ''}</CardTitle>
                        <div className="flex items-center bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                            <CheckCircle className="w-4 h-4 mr-2" />
                            <span>{t('common:validated')}</span>
                        </div>
                    </div>
                    <div className="flex items-center space-x-2 no-print">
                    <Label htmlFor="ganaderia-enabled" className="text-white">{t('livestock.enableModule')}</Label>
                    <Switch
                        id="ganaderia-enabled"
                        checked={formData.isEnabled}
                        onCheckedChange={() => handleToggleEnabled('isEnabled')}
                    />
                    </div>
                </CardHeader>
                <CardContent className={cn("p-6 transition-opacity", !formData.isEnabled && "opacity-50 pointer-events-none")}>
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="font-bold text-xl text-gray-700">{t('livestock.parameters')}</h3>
                        <Button onClick={handlePrint} disabled={bothModelsDisabled} className="bg-green-600 hover:bg-green-700 no-print">
                        <Printer className="mr-2 h-4 w-4" />
                        {t('common:exportPdf')}
                        </Button>
                    </div>
                    {bothModelsDisabled && (
                        <Alert variant="destructive" className="mb-4">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                                {t('livestock.activateModelWarning')}
                            </AlertDescription>
                        </Alert>
                    )}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-2 items-start">
                    <div className="space-y-2">
                        <DataInput label={`${t('livestock.animalType')}:`} value={formData.params.tipoAnimal} onChange={(value) => handleInputChange('params', 'tipoAnimal', value)} isSelect options={animalTypeOptions} />
                        <DataInput label={t('livestock.entryWeight')} value={formData.params.pesoVivoEntrada} onChange={(e) => handleInputChange('params', 'pesoVivoEntrada', e.target.value)} />
                        <DataInput label={t('livestock.purchasePriceKg')} value={formData.params.precioCompraKgVivo} onChange={(e) => handleInputChange('params', 'precioCompraKgVivo', e.target.value)} />
                        <DataInput label={t('livestock.haTraditional')} value={formData.params.hectareasTradicional} onChange={(e) => handleInputChange('params', 'hectareasTradicional', e.target.value)} />
                        <DataInput label={t('livestock.forageUtilization')} value={formData.params.aprovechamientoForraje} onChange={(e) => handleInputChange('params', 'aprovechamientoForraje', e.target.value)} />
                        <div className="flex items-center justify-between p-1 bg-green-100 rounded-md mt-2">
                        <Label className="text-sm">{t('livestock.avgDailyGainTrad')}</Label>
                        <span className="text-sm font-bold text-green-800">{formatCurrency(calculations.tradicional.engordeDiario, 0)} g/{t('common:day')}</span>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <DataInput label={t('livestock.exitWeight')} value={formData.params.pesoVivoSalida} onChange={(e) => handleInputChange('params', 'pesoVivoSalida', e.target.value)} />
                        <DataInput label={t('livestock.shrinkage')} value={formData.params.desbaste} onChange={(e) => handleInputChange('params', 'desbaste', e.target.value)} />
                        <DataInput label={t('livestock.salePriceHook')} value={formData.params.precioVentaKgGancho} onChange={(e) => handleInputChange('params', 'precioVentaKgGancho', e.target.value)} />
                        <DataInput label={t('livestock.carcassYield')} value={formData.params.rendimientoCarcaza} onChange={(e) => handleInputChange('params', 'rendimientoCarcaza', e.target.value)} />
                        <DataInput label={t('livestock.dailyConsumptionMS')} value={formData.params.consumoDiarioMS} onChange={(e) => handleInputChange('params', 'consumoDiarioMS', e.target.value)} />
                        <div className="grid grid-cols-2 gap-2">
                            <DataInput label={t('livestock.annualInterestRate')} value={formData.params.tasaInteresAnual} onChange={(e) => handleInputChange('params', 'tasaInteresAnual', e.target.value)} />
                            <FormattedInput label={t('livestock.monthlyInterestRate')} value={calculations.params.tasaInteresMensual ? formatPercentage(calculations.params.tasaInteresMensual) : '0,00%'} />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <FormattedInput label={t('livestock.weightGained')} value={formatCurrency(calculations.params.kilosEngordado, 2)} />
                        <FormattedInput label={t('livestock.finalWeightWithShrinkage')} value={formatCurrency(calculations.params.pesoFinalDesbaste, 2)} unit="kg" />
                        <FormattedInput label={t('livestock.salePriceKgLive')} value={formatCurrency(calculations.params.precioVentaKgVivo)} />
                        <FormattedInput label={`${t('livestock.kgHookWeight')}:`} value={formatCurrency(calculations.params.kgCarneGancho, 2)} />
                        <DataInput label={t('livestock.haIntensive')} value={formData.params.hectareasIntensivo} onChange={(e) => handleInputChange('params', 'hectareasIntensivo', e.target.value)} />
                        <div className="flex items-center justify-between p-1 bg-blue-100 rounded-md mt-2">
                        <Label className="text-sm">{t('livestock.avgDailyGainInt')}</Label>
                        <span className="text-sm font-bold text-blue-800">{formatCurrency(calculations.intensivo.engordeDiario, 0)} g/{t('common:day')}</span>
                        </div>
                    </div>
                    </div>
                </CardContent>
                </Card>

                <div className={cn("grid grid-cols-1 lg:grid-cols-2 gap-6 transition-opacity page-break-after", !formData.isEnabled && "opacity-50 pointer-events-none")}>
                <ModelSection title={t('livestock.traditionalModelTitle')} data={formData.tradicional} calculations={calculations.tradicional} onChange={handleInputChange} section="tradicional" headerClass="bg-orange-500" formatDateForInput={calculations.formatDateForInput} isEnabled={formData.use_traditional} onToggle={() => handleToggleEnabled('use_traditional')} />
                <ModelSection title={t('livestock.intensiveModelTitle')} data={formData.intensivo} calculations={calculations.intensivo} onChange={handleInputChange} section="intensivo" headerClass="bg-blue-500" formatDateForInput={calculations.formatDateForInput} isEnabled={formData.use_intensive} onToggle={() => handleToggleEnabled('use_intensive')} />
                </div>

                <Card className={cn("transition-opacity mt-6", (!formData.isEnabled || bothModelsDisabled) && "opacity-50 pointer-events-none")}>
                <CardHeader className="p-3 bg-gray-100 border-b">
                    <CardTitle className="text-base text-center font-semibold">{t('livestock.differencesTitle')}</CardTitle>
                </CardHeader>
                <CardContent className="p-4 grid grid-cols-3 gap-4 text-center">
                    <div>
                        <div className="flex justify-center items-center gap-2">
                            <p className="text-sm text-gray-600">{t('livestock.animalsPlusIrrigation')}</p>
                            <TooltipProvider>
                            <Tooltip>
                                <TooltipTrigger asChild>
                                <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                                </TooltipTrigger>
                                <TooltipContent>
                                <p className="max-w-xs">{t('livestock.animalsPlusTooltip')}</p>
                                </TooltipContent>
                            </Tooltip>
                            </TooltipProvider>
                        </div>
                        <p className="font-bold text-lg">{formatCurrency(calculations.comparativos.animales, 0)}</p>
                        <p className="font-bold text-lg text-green-600">{formatPercentage(calculations.comparativos.animalesPct)}</p>
                    </div>
                    <div>
                        <div className="flex justify-center items-center gap-2">
                            <p className="text-sm text-gray-600">{t('livestock.marginPerHaPlusIrrigation')}</p>
                            <TooltipProvider>
                                <Tooltip>
                                <TooltipTrigger asChild>
                                    <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                                </TooltipTrigger>
                                <TooltipContent>
                                    <p className="max-w-xs">{t('livestock.marginPerHaTooltip')}</p>
                                </TooltipContent>
                                </Tooltip>
                            </TooltipProvider>
                        </div>
                        <p className="font-bold text-lg">{formatCurrency(calculations.comparativos.margenPorHa)}</p>
                        <p className="font-bold text-lg text-green-600">{isFinite(calculations.comparativos.margenPorHaPct) ? formatPercentage(calculations.comparativos.margenPorHaPct) : 'N/A'}</p>
                    </div>
                    <div>
                        <div className="flex justify-center items-center gap-2">
                            <p className="text-sm text-gray-600">{t('livestock.timeMinusIrrigation')}</p>
                            <TooltipProvider>
                                <Tooltip>
                                <TooltipTrigger asChild>
                                    <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                                </TooltipTrigger>
                                <TooltipContent>
                                    <p className="max-w-xs">{t('livestock.timeMinusTooltip')}</p>
                                </TooltipContent>
                                </Tooltip>
                            </TooltipProvider>
                        </div>
                        <p className="font-bold text-lg">{formatCurrency(calculations.comparativos.tiempo, 2)} {t('common:years')}</p>
                        <p className={`font-bold text-lg ${calculations.comparativos.tiempoPct >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatPercentage(calculations.comparativos.tiempoPct)}</p>
                    </div>
                </CardContent>
                </Card>
            </div>
          </div>
        </motion.div>
      );
    };

    export default GanaderiaForm;