import React from 'react';
import { ResponsiveContainer, ComposedChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ReferenceLine, Bar, Line, Cell } from 'recharts';

const BreakEvenChart = ({ cashFlow, paybackPeriod }) => {
  const formatCurrencyForTooltip = (value) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0,
    }).format(value);

  const yAxisFormatter = (value) => {
    if (Math.abs(value) >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
    if (Math.abs(value) >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
    if (Math.abs(value) >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
    return value;
  };

  const breakEvenChartData = cashFlow.map(item => ({
      name: item.year === 0 ? 'Inicial' : `Año ${item.year}`,
      year: item.year,
      "Flujo de Caja Anual": item.annualFlow,
      "Flujo de Caja Acumulado": item.cumulativeFlow,
  }));
  
  const numericPayback = parseFloat(String(paybackPeriod).replace('>', '').trim());
  const projectYears = breakEvenChartData.length - 1;

  const gradientOffset = () => {
    const dataMax = Math.max(...breakEvenChartData.map((i) => i['Flujo de Caja Acumulado']));
    const dataMin = Math.min(...breakEvenChartData.map((i) => i['Flujo de Caja Acumulado']));
  
    if (dataMax <= 0) return 0;
    if (dataMin >= 0) return 1;
  
    return dataMax / (dataMax - dataMin);
  };
  const off = gradientOffset();
  
  const paybackLabel = paybackPeriod === 'N/A' || String(paybackPeriod).startsWith('>')
    ? { value: `Payback: ${paybackPeriod}`, position: 'insideTopRight', fill: '#ef4444' }
    : { value: `Payback: ${paybackPeriod} años`, position: 'insideTopRight', fill: '#16a34a' };


  return (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart
          data={breakEvenChartData}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
      >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis tickFormatter={yAxisFormatter} />
          <Tooltip formatter={(value) => formatCurrencyForTooltip(value)} />
          <Legend />
          <ReferenceLine y={0} stroke="#000" strokeWidth={2} />
          <defs>
            <linearGradient id="splitColorBreakEven" x1="0" y1="0" x2="0" y2="1">
              <stop offset={off} stopColor="#3b82f6" stopOpacity={1} />
              <stop offset={off} stopColor="#ef4444" stopOpacity={1} />
            </linearGradient>
          </defs>
          <Bar dataKey="Flujo de Caja Anual">
            {breakEvenChartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry['Flujo de Caja Anual'] < 0 ? '#ef4444' : '#16a34a'} />
            ))}
          </Bar>
          <Line type="linear" dataKey="Flujo de Caja Acumulado" stroke="url(#splitColorBreakEven)" strokeWidth={3} dot={{ r: 4 }} />
          {!isNaN(numericPayback) && numericPayback > 0 && numericPayback <= projectYears && (
              <ReferenceLine 
                x={`Año ${Math.floor(numericPayback)}`} 
                strokeDasharray="3 3" 
                stroke={paybackLabel.fill}
                label={paybackLabel} 
              />
          )}
      </ComposedChart>
    </ResponsiveContainer>
  );
};

export default BreakEvenChart;