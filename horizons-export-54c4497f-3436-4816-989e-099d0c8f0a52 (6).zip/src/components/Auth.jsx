import React, { useEffect, useState } from 'react';
    import { useLocation, useNavigate } from 'react-router-dom';
    import { Auth as SupabaseAuthUI } from '@supabase/auth-ui-react';
    import { ThemeSupa } from '@supabase/auth-ui-shared';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { LogIn, ShieldAlert, Loader2 } from 'lucide-react';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useLanguage } from '@/contexts/LanguageContext';
    import LanguageSelector from '@/components/LanguageSelector';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { useTranslation } from 'react-i18next';

    const EmergencyRecovery = ({ onBack }) => {
        const { t } = useTranslation('auth');
        const { toast } = useToast();
        const [email, setEmail] = useState('');
        const [password, setPassword] = useState('');
        const [loading, setLoading] = useState(false);

        const handleReset = async (e) => {
            e.preventDefault();
            setLoading(true);
            try {
                const { data, error } = await supabase.functions.invoke('reset-password-emergency', {
                    body: { email, password },
                });

                if (error) throw error;
                if (data.error) throw new Error(data.error);

                toast({
                    title: "Éxito",
                    description: data.message || "Contraseña restablecida. Ahora puedes iniciar sesión.",
                    className: "bg-green-100 border-green-400",
                });
                onBack();
            } catch (error) {
                toast({
                    variant: "destructive",
                    title: "Error en la recuperación",
                    description: error.message || "No se pudo restablecer la contraseña.",
                });
            } finally {
                setLoading(false);
            }
        };

        return (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                <div className="text-center">
                    <ShieldAlert className="mx-auto h-10 w-10 text-orange-500" />
                    <h3 className="text-lg font-semibold mt-2">{t('emergencyRecoveryTitle')}</h3>
                    <p className="text-sm text-muted-foreground">{t('emergencyRecoveryDesc')}</p>
                </div>
                <form onSubmit={handleReset} className="space-y-4">
                    <div>
                        <Label htmlFor="emergency-email">{t('emailLabel')}</Label>
                        <Input id="emergency-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    </div>
                    <div>
                        <Label htmlFor="emergency-password">{t('newPasswordLabel')}</Label>
                        <Input id="emergency-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : t('resetPasswordButton')}
                    </Button>
                </form>
                <Button variant="link" onClick={onBack} className="w-full">{t('backToLogin')}</Button>
            </motion.div>
        );
    };

    const AuthComponent = () => {
        const { session } = useAuth();
        const location = useLocation();
        const navigate = useNavigate();
        const { t, i18n } = useTranslation('auth');
        const [view, setView] = useState('login');

        useEffect(() => {
            if (session) {
                const from = location.state?.from?.pathname || "/my-projects";
                navigate(from, { replace: true });
            }
        }, [session, navigate, location.state]);

        return (
            <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center p-4">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="w-full max-w-md"
                >
                    <Card className="shadow-2xl">
                        <CardHeader className="text-center relative">
                            <div className="absolute top-4 right-4">
                                <LanguageSelector />
                            </div>
                            <div className="mx-auto bg-green-600 text-white rounded-full p-3 w-fit mt-8">
                               <LogIn className="h-8 w-8" />
                            </div>
                            <CardTitle className="mt-4 text-2xl font-bold">
                                {t('title')}
                            </CardTitle>
                            <CardDescription>
                                {t('description')}
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            {view === 'login' ? (
                                <>
                                    <SupabaseAuthUI
                                        supabaseClient={supabase}
                                        appearance={{ theme: ThemeSupa }}
                                        providers={[]}
                                        view='sign_in'
                                        key={`sign_in-${i18n.language}`}
                                        localization={{
                                            variables: {
                                                sign_in: { 
                                                    email_label: t('emailLabel'),
                                                    password_label: t('passwordLabel'),
                                                    button_label: t('signInButton'),
                                                    link_text: t('alreadyHaveAccount')
                                                },
                                                forgotten_password: { 
                                                    email_label: t('emailLabel'),
                                                    button_label: t('sendInstructions'),
                                                    link_text: t('forgotPassword') 
                                                }
                                            }
                                        }}
                                    />
                                    <div className="text-center mt-4">
                                        <Button variant="link" onClick={() => setView('emergency')}>
                                            {t('emergencyRecoveryLink')}
                                        </Button>
                                    </div>
                                </>
                            ) : (
                                <EmergencyRecovery onBack={() => setView('login')} />
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        );
    };

    export default AuthComponent;