import React, { useEffect, useState } from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
    import { Label } from '@/components/ui/label';
    import { Input } from '@/components/ui/input';
    import { Switch } from '@/components/ui/switch';
    import { DollarSign, Percent, CalendarClock, Save, Droplet, Leaf, CheckCircle } from 'lucide-react';
    import { useProjectData } from '@/contexts/ProjectDataContext';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';
    import { useInitialCalculations } from '@/hooks/useInitialCalculations';
    import { useTirVanRoyPayback } from '@/hooks/useTirVanRoyPayback';

    const p = (value) => {
      if (typeof value === 'number') return value;
      if (typeof value === 'string') {
        const strValue = value.replace(/\./g, '').replace(/,/g, '.');
        return parseFloat(strValue) || 0;
      }
      return 0;
    };

    const formatCurrency = (value) => {
      const numValue = p(value);
      if (isNaN(numValue)) return 'U$ 0';
      return new Intl.NumberFormat('es-PY', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(numValue);
    };

    const defaultInvestments = [
        { id: 'tierra', descripcion: 'Compra de propiedad / tierra', cantidad: 0, valorUnitario: 0, vidaUtil: 100, valorResidualPct: 100, year: 0 },
        { id: 'riego', descripcion: 'Sistemas de riego', cantidad: 100, valorUnitario: 3000, vidaUtil: 25, valorResidualPct: 10, year: 0 },
        { id: 'infraestructura', descripcion: 'Infraestructura general', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 20, year: 0 },
        { id: 'mecanizacion', descripcion: 'Mecanización y preparación de suelo, pasturas, alambrados y bebederos', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 10, year: 0 },
        { id: 'fotovoltaica', descripcion: 'Energia Fotovoltaica / Otras', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 10, year: 0 },
        { id: 'otros', descripcion: 'Otros / Varios', cantidad: 0, valorUnitario: 0, vidaUtil: 25, valorResidualPct: 0, year: 0 },
    ];


    const ProjectForm = ({ formData, onUpdate, calculations }) => {
      const { saveToClientProject, activeClientProject, isSaving } = useProjectData();
      const { toast } = useToast();
      const [investments, setInvestments] = useState(formData.investments || []);

      useEffect(() => {
        // Ensure all default investment types are present
        const updatedInvestments = defaultInvestments.map(defaultItem => {
          const existingItem = formData.investments?.find(item => item.id === defaultItem.id);
          return existingItem ? existingItem : defaultItem;
        });
        setInvestments(updatedInvestments);
      }, [formData.investments]);
      
      const handleSaveChanges = async () => {
        if (!activeClientProject) {
          toast({
            variant: 'destructive',
            title: 'Acción requerida',
            description: 'Ningún proyecto activo para guardar.'
          });
          return;
        }
        await saveToClientProject(activeClientProject.project.id);
      };
      
      const handleChange = (e) => {
        const { id, value } = e.target;
        onUpdate({ ...formData, [id]: value });
      };
      
      const handleInvestmentChange = (index, field, value) => {
        const newInvestments = [...investments];
        newInvestments[index] = { ...newInvestments[index], [field]: value };
        setInvestments(newInvestments);
        onUpdate({ ...formData, investments: newInvestments });
      };

      const handleModuleChange = (moduleName) => {
        if (typeof onUpdate === 'function') {
          onUpdate({
            ...formData,
            modules: {
              ...formData.modules,
              [moduleName]: !formData.modules[moduleName],
            },
          });
        }
      };
      
      const totalInvestment = investments.reduce((acc, item) => acc + (p(item.cantidad) * p(item.valorUnitario)), 0) || 0;
      
      return (
        <div className="space-y-6">
          <Card>
             <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Configuración de Módulos y Guardado</CardTitle>
                    <CardDescription>Habilite los módulos y guarde su progreso en la nube.</CardDescription>
                </div>
                <div className="flex items-center gap-4">
                    <div className="flex items-center space-x-2">
                        <Switch
                          id="ganaderia-module"
                          checked={formData?.modules?.ganaderia || false}
                          onCheckedChange={() => handleModuleChange('ganaderia')}
                        />
                        <Label htmlFor="ganaderia-module">Ganadería</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch
                          id="agricultura-module"
                          checked={formData?.modules?.agricultura || false}
                          onCheckedChange={() => handleModuleChange('agricultura')}
                        />
                        <Label htmlFor="agricultura-module">Agricultura</Label>
                    </div>
                    <Button onClick={handleSaveChanges} disabled={isSaving || !activeClientProject} className="bg-green-600 hover:bg-green-700 text-white">
                      <Save className="mr-2 h-4 w-4" />
                      {isSaving ? 'Guardando...' : 'Guardar Cambios en el Proyecto'}
                    </Button>
                </div>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                  <CardTitle>Datos del Proyecto</CardTitle>
                  <div className="flex items-center bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      <span>Validado</span>
                  </div>
              </div>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="ownerName">Nombre del Cliente</Label>
                <div id="ownerName" className="p-2 bg-gray-100 rounded-md border">{formData?.ownerName || 'N/A'}</div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="rucCi">RUC/CI del Cliente</Label>
                <div id="rucCi" className="p-2 bg-gray-100 rounded-md border">{formData?.rucCi || 'N/A'}</div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="projectName">Nombre del Proyecto</Label>
                <div id="projectName" className="p-2 bg-gray-100 rounded-md border">{formData?.projectName || 'N/A'}</div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Localización/Establecimiento</Label>
                <Input id="location" value={formData?.location || ''} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="projectYears">Duración del Proyecto (años)</Label>
                <Input id="projectYears" type="number" value={formData?.projectYears || ''} onChange={handleChange} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Parámetros de Sostenibilidad</CardTitle>
              <CardDescription>Valores clave para el cálculo del Balance de Carbono.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <Label htmlFor="precioTonCO2" className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-gray-500" /> Precio por Tonelada de CO₂ (USD)</Label>
                <Input id="precioTonCO2" type="number" value={formData?.precioTonCO2 || ''} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="consumoDieselAnual" className="flex items-center gap-2"><Droplet className="w-4 h-4 text-gray-500" /> Consumo Anual de Gasoil (Litros)</Label>
                <Input id="consumoDieselAnual" type="number" value={formData?.consumoDieselAnual || ''} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hectareasConservacion" className="flex items-center gap-2"><Leaf className="w-4 h-4 text-gray-500" /> Hectáreas de Conservación</Label>
                <Input id="hectareasConservacion" type="number" value={formData?.hectareasConservacion || ''} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hectareasReforestacion" className="flex items-center gap-2"><Leaf className="w-4 h-4 text-gray-500" /> Hectáreas de Reforestación</Label>
                <Input id="hectareasReforestacion" type="number" value={formData?.hectareasReforestacion || ''} onChange={handleChange} />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Inversiones en Activos</CardTitle>
              <CardDescription>Detalle las inversiones necesarias para el proyecto tecnificado.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Descripción</TableHead>
                    <TableHead className="text-right">Cantidad (ha o und)</TableHead>
                    <TableHead className="text-right">Valor Unitario (USD)</TableHead>
                    <TableHead className="text-right">Año</TableHead>
                    <TableHead className="text-right">Inversión Total (USD)</TableHead>
                    <TableHead className="text-right">Vida Útil (años)</TableHead>
                    <TableHead className="text-right">Depreciación Anual (USD)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {investments.map((item, index) => {
                    const inversionTotalItem = p(item.cantidad) * p(item.valorUnitario);
                    const depreciacionAnual = p(item.vidaUtil) > 0 ? (inversionTotalItem * (1 - (p(item.valorResidualPct)/100))) / p(item.vidaUtil) : 0;
                    return (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.descripcion}</TableCell>
                        <TableCell>
                          <Input
                            type="text"
                            value={item.cantidad}
                            onChange={(e) => handleInvestmentChange(index, 'cantidad', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                        <TableCell>
                           <Input
                            type="text"
                            value={item.valorUnitario}
                            onChange={(e) => handleInvestmentChange(index, 'valorUnitario', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                        <TableCell>
                           <Input
                            type="number"
                            value={item.year || 0}
                            onChange={(e) => handleInvestmentChange(index, 'year', e.target.value)}
                            className="text-right w-20"
                          />
                        </TableCell>
                        <TableCell className="text-right">{formatCurrency(inversionTotalItem)}</TableCell>
                         <TableCell>
                           <Input
                            type="number"
                            value={item.vidaUtil}
                            onChange={(e) => handleInvestmentChange(index, 'vidaUtil', e.target.value)}
                            className="text-right"
                          />
                        </TableCell>
                        <TableCell className="text-right">{formatCurrency(depreciacionAnual)}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-end bg-gray-50 p-4">
                <div className="flex items-center gap-4">
                    <p className="text-lg font-semibold">Inversión Total en Activos:</p>
                    <p className="text-2xl font-bold text-green-700">{formatCurrency(totalInvestment)}</p>
                </div>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Parámetros Financieros y de Crédito</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="tasaInteres" className="flex items-center gap-2"><Percent className="w-4 h-4 text-gray-500" /> Tasa de Interés Anual (%)</Label>
                  <Input id="tasaInteres" type="number" value={formData?.tasaInteres || ''} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="plazo" className="flex items-center gap-2"><CalendarClock className="w-4 h-4 text-gray-500" /> Plazo del Préstamo (años)</Label>
                  <Input id="plazo" type="number" value={formData?.plazo || ''} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="discountRate" className="flex items-center gap-2"><Percent className="w-4 h-4 text-gray-500" /> Tasa de Descuento (%)</Label>
                  <Input id="discountRate" type="number" value={formData?.discountRate || ''} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="costoOportunidad" className="flex items-center gap-2"><DollarSign className="w-4 h-4 text-gray-500" /> Costo de Oportunidad (%)</Label>
                  <Input id="costoOportunidad" type="number" value={formData?.costoOportunidad || ''} onChange={handleChange} />
                </div>
            </CardContent>
          </Card>
      
          <Card>
            <CardHeader>
              <CardTitle>Resultados del Cálculo Inicial</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {calculations && Object.entries(calculations).map(([key, value]) => (
                    (typeof value === 'object' && value.label) &&
                    <div key={key} className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-600">{value.label}</p>
                        <p className="text-lg font-bold text-green-700">{value.value}</p>
                    </div>
                ))}
            </CardContent>
          </Card>
        </div>
      );
    };

    export default ProjectForm;