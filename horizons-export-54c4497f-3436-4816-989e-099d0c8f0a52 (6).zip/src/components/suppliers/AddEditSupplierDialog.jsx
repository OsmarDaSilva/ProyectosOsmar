import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from "@/components/ui/use-toast";
import { useTranslation } from 'react-i18next';

const AddEditSupplierDialog = ({ isOpen, setIsOpen, supplier }) => {
    const queryClient = useQueryClient();
    const { toast } = useToast();
    const { t } = useTranslation(['suppliers', 'common']);
    const [formData, setFormData] = useState({});

    useEffect(() => {
        if (isOpen) {
            if (supplier) {
                setFormData(supplier);
            } else {
                setFormData({ name: '', contact_person: '', email: '', phone: '', address: '' });
            }
        }
    }, [supplier, isOpen]);

    const mutation = useMutation({
        mutationFn: async (supplierData) => {
            const { data, error } = await supabase.rpc('save_supplier', {
                p_id: supplierData.id || null,
                p_name: supplierData.name,
                p_contact_person: supplierData.contact_person,
                p_email: supplierData.email,
                p_phone: supplierData.phone,
                p_address: supplierData.address,
            });

            if (error) {
                if (error.message.includes('ORG_NOT_FOUND')) {
                    throw new Error('No se pudo identificar tu organización. Cierra sesión e ingresa de nuevo o contacta al administrador.');
                }
                throw error;
            }
            return { isUpdate: !!supplierData.id };
        },
        onSuccess: ({ isUpdate }) => {
            toast({ title: t('common:success'), description: isUpdate ? t('toasts.updated') : t('toasts.created') });
            queryClient.invalidateQueries({ queryKey: ['suppliers'] });
            setIsOpen(false);
        },
        onError: (error) => {
            toast({ variant: "destructive", title: t('common:error'), description: error.message });
        },
    });

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.name) {
            toast({ variant: "destructive", title: t('dialog.requiredField'), description: t('dialog.nameRequired') });
            return;
        }
        mutation.mutate(formData);
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogContent className="sm:max-w-lg">
                <form id="supplier-form" onSubmit={handleSubmit}>
                    <DialogHeader>
                        <DialogTitle>{supplier ? t('dialog.editTitle') : t('dialog.newTitle')}</DialogTitle>
                        <DialogDescription>{t('dialog.description')}</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="space-y-2">
                            <Label htmlFor="name">{t('dialog.nameLabel')}</Label>
                            <Input id="name" value={formData.name || ''} onChange={handleChange} required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="contact_person">{t('dialog.contactPersonLabel')}</Label>
                            <Input id="contact_person" value={formData.contact_person || ''} onChange={handleChange} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="email">{t('dialog.emailLabel')}</Label>
                            <Input id="email" type="email" value={formData.email || ''} onChange={handleChange} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="phone">{t('dialog.phoneLabel')}</Label>
                            <Input id="phone" value={formData.phone || ''} onChange={handleChange} />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="address">{t('dialog.addressLabel')}</Label>
                            <Textarea id="address" value={formData.address || ''} onChange={handleChange} />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setIsOpen(false)} disabled={mutation.isPending}>{t('dialog.cancelButton')}</Button>
                        <Button type="submit" form="supplier-form" disabled={mutation.isPending}>
                            {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {t('dialog.saveButton')}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default AddEditSupplierDialog;