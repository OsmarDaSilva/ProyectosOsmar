import React, { useState, useMemo } from 'react';
import { useReactTable, getCoreRowModel, getPaginationRowModel, getSortedRowModel, flexRender } from '@tanstack/react-table';
import { useProductCatalog, useDeleteProduct, useDuplicateProduct } from '@/hooks/useProductCatalog';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { MoreHorizontal, ArrowUpDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, FileDown, Copy, Edit, Trash2 } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { formatCurrency, exportToExcel } from '@/lib/utils';
import { useDebounce } from '@/hooks/useDebounce';
import { useTranslation } from 'react-i18next';

const ProductCatalogTable = ({ onEdit }) => {
    const { t } = useTranslation('catalog'); // Using 'catalog' namespace
    const { user } = useAuth();
    const { toast } = useToast();
    const [sorting, setSorting] = useState([{ id: 'sku', desc: false }]);
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearchTerm = useDebounce(searchTerm, 300);
    const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 50 });
    const [deleteConfirmation, setDeleteConfirmation] = useState(null);

    const { data: result, isLoading, isError, error, isFetching } = useProductCatalog({
        searchTerm: debouncedSearchTerm,
        page: pagination.pageIndex + 1,
        pageSize: pagination.pageSize,
        sorting,
    });
    
    const products = result?.data ?? [];
    const pageCount = result?.totalPages ?? 0;
    const totalProducts = result?.count ?? 0;
    
    const deleteMutation = useDeleteProduct();
    const duplicateMutation = useDuplicateProduct();

    const handleDelete = async () => {
        if (!deleteConfirmation) return;
        try {
            await deleteMutation.mutateAsync({ userId: user.id, sku: deleteConfirmation.sku });
            toast({ title: t('common.success'), description: t('productTable.deleteSuccess') });
        } catch (err) {
            toast({ variant: 'destructive', title: t('common.error'), description: err.message });
        } finally {
            setDeleteConfirmation(null);
        }
    };
    
    const handleDuplicate = async (product) => {
        try {
            await duplicateMutation.mutateAsync(product);
            toast({ title: t('common.success'), description: t('productTable.duplicateSuccess') });
        } catch (err) {
            toast({ variant: 'destructive', title: t('common.error'), description: err.message });
        }
    };
    
    const handleExport = () => {
        if (products && products.length > 0) {
            const dataToExport = products.map(p => ({
                SKU: p.sku,
                [t('productTable.product')]: p.product_name,
                [t('productTable.brand')]: p.brand,
                [t('productTable.category')]: p.category,
                [t('productTable.salePrice')]: p.sale_price,
                [t('productTable.purchasePrice')]: p.purchase_price,
                [t('productTable.specs')]: JSON.stringify(p.specifications),
                [t('productTable.updated')]: new Date(p.updated_at).toLocaleString(),
            }));
            exportToExcel(dataToExport, t('productTable.exportFilename'));
        } else {
            toast({ variant: 'destructive', title: t('common.noData'), description: t('productTable.noDataToExport') });
        }
    };

    const columns = useMemo(() => [
        { accessorKey: 'sku', header: ({ column }) => <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')} >SKU <ArrowUpDown className="ml-2 h-4 w-4" /></Button>, cell: info => info.getValue() },
        { accessorKey: 'product_name', header: ({ column }) => <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')} >{t('productTable.product')} <ArrowUpDown className="ml-2 h-4 w-4" /></Button>, cell: info => info.getValue() },
        { accessorKey: 'brand', header: ({ column }) => <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')} >{t('productTable.brand')} <ArrowUpDown className="ml-2 h-4 w-4" /></Button>, cell: info => info.getValue() },
        { accessorKey: 'sale_price', header: ({ column }) => <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')} >{t('productTable.salePriceAbbr')} <ArrowUpDown className="ml-2 h-4 w-4" /></Button>, cell: info => formatCurrency(info.getValue()) },
        { accessorKey: 'purchase_price', header: ({ column }) => <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')} >{t('productTable.purchasePriceAbbr')} <ArrowUpDown className="ml-2 h-4 w-4" /></Button>, cell: info => formatCurrency(info.getValue()) },
        { accessorKey: 'updated_at', header: ({ column }) => <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')} >{t('productTable.updated')} <ArrowUpDown className="ml-2 h-4 w-4" /></Button>, cell: info => new Date(info.getValue()).toLocaleDateString() },
        { id: 'actions', cell: ({ row }) => (
            <DropdownMenu>
                <DropdownMenuTrigger asChild><Button variant="ghost" className="h-8 w-8 p-0"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEdit(row.original)}><Edit className="mr-2 h-4 w-4" /> {t('common.viewEdit')}</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDuplicate(row.original)}><Copy className="mr-2 h-4 w-4" /> {t('common.duplicate')}</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-red-600" onClick={() => setDeleteConfirmation(row.original)}><Trash2 className="mr-2 h-4 w-4" /> {t('common.delete')}</DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        )},
    ], [onEdit, t]);

    const table = useReactTable({
        data: products,
        columns,
        pageCount,
        state: { sorting, pagination },
        onSortingChange: setSorting,
        onPaginationChange: setPagination,
        getCoreRowModel: getCoreRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        manualPagination: true,
        manualSorting: true,
    });

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <Input placeholder={t('productTable.searchPlaceholder')} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="max-w-sm" />
                <Button variant="outline" onClick={handleExport}><FileDown className="mr-2 h-4 w-4"/> {t('productTable.exportResults')}</Button>
            </div>
            <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        {table.getHeaderGroups().map(headerGroup => (
                            <TableRow key={headerGroup.id}>
                                {headerGroup.headers.map(header => <TableHead key={header.id}>{header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}</TableHead>)}
                            </TableRow>
                        ))}
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            Array.from({ length: 10 }).map((_, i) => (
                                <TableRow key={i}>
                                    {columns.map(col => <TableCell key={col.accessorKey || col.id}><Skeleton className="h-6 w-full" /></TableCell>)}
                                </TableRow>
                            ))
                        ) : isError ? (
                            <TableRow><TableCell colSpan={columns.length} className="h-24 text-center text-red-500">{t('common.error')}: {error.message}</TableCell></TableRow>
                        ) : table.getRowModel().rows?.length ? (
                            table.getRowModel().rows.map(row => (
                                <TableRow key={row.id} data-state={isFetching ? "fetching" : ""}>
                                    {row.getVisibleCells().map(cell => <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>)}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow><TableCell colSpan={columns.length} className="h-24 text-center">{t('common.noResults')}</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
            <div className="flex items-center justify-between">
                 <div className="text-sm text-muted-foreground">
                    {t('common.page')} {table.getState().pagination.pageIndex + 1} {t('common.of')} {table.getPageCount()}. ({totalProducts.toLocaleString('es-ES')} {t('productTable.totalProducts')})
                 </div>
                 <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => table.setPageIndex(0)} disabled={!table.getCanPreviousPage()}><ChevronsLeft className="h-4 w-4" /></Button>
                    <Button variant="outline" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}><ChevronLeft className="h-4 w-4" /></Button>
                    <Button variant="outline" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}><ChevronRight className="h-4 w-4" /></Button>
                    <Button variant="outline" size="sm" onClick={() => table.setPageIndex(table.getPageCount() - 1)} disabled={!table.getCanNextPage()}><ChevronsRight className="h-4 w-4" /></Button>
                 </div>
            </div>

            <AlertDialog open={!!deleteConfirmation} onOpenChange={() => setDeleteConfirmation(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader><AlertDialogTitle>{t('common.areYouSure')}</AlertDialogTitle><AlertDialogDescription>{t('productTable.deleteConfirmation', { productName: deleteConfirmation?.product_name, sku: deleteConfirmation?.sku })}</AlertDialogDescription></AlertDialogHeader>
                    <AlertDialogFooter><AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel><AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">{t('common.delete')}</AlertDialogAction></AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
};

export default ProductCatalogTable;