import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription, DialogClose
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useUpsertProduct } from '@/hooks/useProductCatalog';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { parseCurrency } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

const AddEditProductDialog = ({ open, onOpenChange, product }) => {
    const { t } = useTranslation('catalog'); // Using 'catalog' namespace
    const { register, handleSubmit, reset, setValue, formState: { errors, isSubmitting } } = useForm();
    const { user } = useAuth();
    const { toast } = useToast();
    const upsertProductMutation = useUpsertProduct();

    useEffect(() => {
        if (product) {
            reset({
                sku: product.sku,
                product_name: product.product_name,
                brand: product.brand,
                category: product.category,
                sale_price: product.sale_price,
                purchase_price: product.purchase_price,
                specifications: JSON.stringify(product.specifications || {}, null, 2),
            });
        } else {
            reset({
                sku: '', product_name: '', brand: '', category: '', sale_price: '', purchase_price: '', specifications: '{}',
            });
        }
    }, [product, open, reset]);
    
    const normalizePrice = (fieldName) => (e) => {
        const value = e.target.value;
        const parsed = parseCurrency(value);
        if(!isNaN(parsed)) {
            setValue(fieldName, parsed);
        }
    };

    const onSubmit = async (data) => {
        if (!user) {
            toast({ variant: 'destructive', title: t('common.error'), description: t('catalog.productDialog.authError') });
            return;
        }

        try {
            let specifications;
            try {
                if (data.specifications.trim() === '') {
                    specifications = {};
                } else {
                    specifications = JSON.parse(data.specifications);
                }
            } catch (e) {
                specifications = { nota: data.specifications };
            }

            const productData = {
                user_id: user.id,
                sku: data.sku,
                product_name: data.product_name,
                brand: data.brand,
                category: data.category,
                sale_price: parseFloat(data.sale_price),
                purchase_price: parseFloat(data.purchase_price),
                specifications,
            };

            await upsertProductMutation.mutateAsync(productData);
            toast({ title: t('common.success'), description: t(product ? 'productDialog.updateSuccess' : 'productDialog.createSuccess') });
            onOpenChange(false);
        } catch (error) {
            toast({ variant: 'destructive', title: t('common.error'), description: error.message });
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>{t(product ? 'productDialog.editTitle' : 'productDialog.createTitle')}</DialogTitle>
                    <DialogDescription>
                        {t(product ? 'productDialog.editDescription' : 'productDialog.createDescription')}
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="sku" className="text-right">SKU</Label>
                        <Input id="sku" {...register('sku', { required: t('productDialog.skuRequired') })} disabled={!!product} className="col-span-3" />
                        {errors.sku && <p className="col-span-4 text-red-500 text-xs text-right">{errors.sku.message}</p>}
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="product_name" className="text-right">{t('productDialog.name')}</Label>
                        <Input id="product_name" {...register('product_name', { required: t('productDialog.nameRequired') })} className="col-span-3" />
                        {errors.product_name && <p className="col-span-4 text-red-500 text-xs text-right">{errors.product_name.message}</p>}
                    </div>
                     <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="sale_price" className="text-right">{t('productDialog.salePrice')}</Label>
                        <Input id="sale_price" type="number" step="0.01" {...register('sale_price', { required: t('productDialog.salePriceRequired'), valueAsNumber: true })} onBlur={normalizePrice('sale_price')} className="col-span-3" />
                        {errors.sale_price && <p className="col-span-4 text-red-500 text-xs text-right">{errors.sale_price.message}</p>}
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="purchase_price" className="text-right">{t('productDialog.purchasePrice')}</Label>
                        <Input id="purchase_price" type="number" step="0.01" {...register('purchase_price', { required: t('productDialog.purchasePriceRequired'), valueAsNumber: true })} onBlur={normalizePrice('purchase_price')} className="col-span-3" />
                        {errors.purchase_price && <p className="col-span-4 text-red-500 text-xs text-right">{errors.purchase_price.message}</p>}
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="brand" className="text-right">{t('productDialog.brand')}</Label>
                        <Input id="brand" {...register('brand')} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="category" className="text-right">{t('productDialog.category')}</Label>
                        <Input id="category" {...register('category')} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-start gap-4">
                        <Label htmlFor="specifications" className="text-right pt-2">{t('productDialog.specs')}</Label>
                        <Textarea id="specifications" {...register('specifications')} className="col-span-3" rows={5} />
                    </div>
                    <DialogFooter>
                        <DialogClose asChild>
                            <Button type="button" variant="secondary">{t('common.cancel')}</Button>
                        </DialogClose>
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? t('common.saving') : t('common.saveChanges')}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default AddEditProductDialog;