import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, CheckCircle, XCircle, AlertCircle, RefreshCw, Ban } from 'lucide-react';
import { useImportJobs } from '@/hooks/useImportJobs';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';

const JobStatusBadge = ({ status }) => {
    const statusConfig = {
        queued: { variant: 'secondary', icon: <Loader2 className="h-3 w-3 animate-spin" />, label: 'En Cola' },
        processing: { variant: 'default', icon: <Loader2 className="h-3 w-3 animate-spin" />, label: 'Procesando' },
        completed: { variant: 'success', icon: <CheckCircle className="h-3 w-3" />, label: 'Completado' },
        completed_with_errors: { variant: 'warning', icon: <AlertCircle className="h-3 w-3" />, label: 'Completado con Errores' },
        failed: { variant: 'destructive', icon: <XCircle className="h-3 w-3" />, label: 'Fallido' },
    };
    const config = statusConfig[status] || { variant: 'outline', label: status };
    return (
        <Badge variant={config.variant} className="flex items-center gap-1.5 text-xs">
            {config.icon}
            <span>{config.label}</span>
        </Badge>
    );
};

const JobsListContent = ({ jobType, title, description, isModal = true }) => {
    const { user } = useAuth();
    const { jobs, isLoading, refetchJobs, cancelJob, resumeJob, isResuming } = useImportJobs(user?.id, jobType);

    const handleCancel = (jobId) => {
        cancelJob(jobId);
    };

    const handleResume = (jobId) => {
        resumeJob({jobId, userId: user?.id, jobType});
    };

    const JobsSkeleton = () => (
        <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
                <div key={i} className="p-4 border rounded-lg space-y-3">
                    <div className="flex justify-between items-start">
                        <div className="space-y-2 flex-grow">
                            <Skeleton className="h-5 w-3/4" />
                            <Skeleton className="h-4 w-1/2" />
                        </div>
                        <Skeleton className="h-6 w-24 rounded-full" />
                    </div>
                </div>
            ))}
        </div>
    );
    
    const content = (
        <div className="py-4">
            <div className="flex justify-end mb-4">
                <Button variant="outline" size="sm" onClick={() => refetchJobs()} disabled={isLoading}>
                    <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                    Actualizar
                </Button>
            </div>
            <QueryStateWrapper
              isLoading={isLoading && !jobs}
              isError={false}
              loader={<JobsSkeleton />}
            >
              {jobs && jobs.length > 0 ? (
                  <ScrollArea className="h-96 pr-4">
                      <div className="space-y-4">
                          {jobs.map(job => (
                              <div key={job.id} className="p-4 border rounded-lg space-y-3">
                                  <div className="flex justify-between items-start">
                                      <div className="flex-grow">
                                          <p className="font-semibold text-sm truncate" title={job.file_path.split('/').pop()}>
                                              {job.file_path.split('/').pop()}
                                          </p>
                                          <p className="text-xs text-muted-foreground">
                                              Iniciado: {format(new Date(job.created_at), "dd MMM yyyy, HH:mm", { locale: es })}
                                          </p>
                                      </div>
                                      <JobStatusBadge status={job.status} />
                                  </div>
                                  {job.summary?.message && (
                                    <p className="text-xs text-muted-foreground">{job.summary.message}</p>
                                  )}
                                  {(job.status === 'processing' || job.status === 'completed' || job.status === 'completed_with_errors' || (job.status === 'failed' && job.processed_rows > 0)) && job.total_rows > 0 && (
                                      <div>
                                          <Progress value={(job.processed_rows / job.total_rows) * 100} className="h-2" />
                                          <p className="text-xs text-muted-foreground mt-1 text-right">
                                              {job.processed_rows} / {job.total_rows} filas procesadas
                                          </p>
                                      </div>
                                  )}
                                  {job.status.startsWith('completed') && job.summary && (
                                      <div className="text-xs flex gap-4">
                                          <span className="text-green-600">Éxito: {job.summary.success || 0}</span>
                                          <span className="text-red-600">Fallos: {job.summary.failed || 0}</span>
                                      </div>
                                  )}
                                  {job.status === 'failed' && job.summary?.error && (
                                      <Alert variant="destructive" className="text-xs">
                                          <AlertTitle>Error</AlertTitle>
                                          <AlertDescription>{job.summary.error}</AlertDescription>
                                      </Alert>
                                  )}
                                  {(job.status === 'queued' || job.status === 'processing') && (
                                      <div className="flex justify-end">
                                          <Button size="sm" variant="destructive" onClick={() => handleCancel(job.id)}>
                                              <Ban className="mr-2 h-4 w-4" /> Cancelar
                                          </Button>
                                      </div>
                                  )}
                                  {job.status === 'failed' && (
                                      <div className="flex justify-end">
                                          <Button size="sm" variant="outline" onClick={() => handleResume(job.id)} disabled={isResuming}>
                                              <RefreshCw className={`mr-2 h-4 w-4 ${isResuming ? 'animate-spin' : ''}`} /> Reintentar
                                          </Button>
                                      </div>
                                  )}
                              </div>
                          ))}
                      </div>
                  </ScrollArea>
              ) : (
                  <div className="text-center py-10 text-muted-foreground">
                      <p>No hay trabajos de importación recientes.</p>
                  </div>
              )}
            </QueryStateWrapper>
        </div>
    );

    if (isModal) {
      return (
          <DialogContent className="sm:max-w-2xl">
              <DialogHeader>
                  <DialogTitle>{title}</DialogTitle>
                  <DialogDescription>{description}</DialogDescription>
              </DialogHeader>
              {content}
          </DialogContent>
      );
    }
    return content;
};

const ImportJobsDialog = ({ isOpen, setIsOpen, ...props }) => {
    if (props.isModal === false) {
        return <JobsListContent {...props} />;
    }
    
    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <JobsListContent {...props} />
        </Dialog>
    );
};

export default ImportJobsDialog;