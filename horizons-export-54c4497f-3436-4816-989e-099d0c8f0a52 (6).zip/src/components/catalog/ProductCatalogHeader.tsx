import React from 'react';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, PlusCircle } from 'lucide-react';

type Props = {
  title?: string;
  onUploadClick?: () => void;
  onNewClick?: () => void;
  rightSlot?: React.ReactNode;
};

const ProductCatalogHeader: React.FC<Props> = ({
  title = 'Catálogo de Productos',
  onUploadClick,
  onNewClick,
  rightSlot,
}) => {
  return (
    <Card className="mb-4">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl font-semibold">{title}</CardTitle>
        <div className="flex items-center gap-2">
          {rightSlot}
          {onUploadClick && (
            <Button variant="outline" onClick={onUploadClick}>
              <Upload className="mr-2 h-4 w-4" /> Importar
            </Button>
          )}
          {onNewClick && (
            <Button onClick={onNewClick}>
              <PlusCircle className="mr-2 h-4 w-4" /> Nuevo
            </Button>
          )}
        </div>
      </CardHeader>
    </Card>
  );
};

export default ProductCatalogHeader;