import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { useReactTable, getCoreRowModel, flexRender } from '@tanstack/react-table';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Save, RefreshCw, Trash2, ArrowLeft } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useUpsertProduct } from '@/hooks/useProductCatalog';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { parseCurrency } from '@/lib/utils';
import { useTranslation } from 'react-i18next'; // Import useTranslation

const EditableCell = ({ getValue, row, column, table }) => {
    const initialValue = getValue();
    const [value, setValue] = useState(initialValue);
  
    const onBlur = () => {
      table.options.meta?.updateData(row.index, column.id, value);
    };
  
    useEffect(() => {
      setValue(initialValue);
    }, [initialValue]);
  
    return (
      <Input
        value={value || ''}
        onChange={(e) => setValue(e.target.value)}
        onBlur={onBlur}
        className="h-8"
      />
    );
  };

const ImportCorrector = ({ job, onBack, onJobCompletion }) => {
    const { t } = useTranslation('catalog'); // Using 'catalog' namespace
    const { toast } = useToast();
    const { user } = useAuth();
    const upsertMutation = useUpsertProduct();
    const [data, setData] = useState(() => 
        job.error_details.rows.map(row => ({...row.data, original_row: row.row, error: row.error}))
    );
    const [isSaving, setIsSaving] = useState(false);

    const columns = useMemo(() => [
        { accessorKey: 'original_row', header: t('importCorrector.excelRow'), enableEditing: false, cell: info => info.getValue() },
        { accessorKey: 'sku', header: 'SKU' },
        { accessorKey: 'product_name', header: t('importCorrector.product') },
        { accessorKey: 'sale_price', header: t('importCorrector.salePrice') },
        { accessorKey: 'purchase_price', header: t('importCorrector.purchasePrice') },
        { accessorKey: 'brand', header: t('importCorrector.brand') },
        { accessorKey: 'category', header: t('importCorrector.category') },
        { accessorKey: 'error', header: t('importCorrector.error'), cell: info => <span className="text-red-500 text-xs">{info.getValue()}</span> },
        {
            id: 'actions',
            header: '',
            cell: ({ row }) => (
                <Button variant="ghost" size="icon" onClick={() => removeRow(row.index)}>
                    <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
            ),
        },
    ], [t]); // Add t to dependency array
    
    const table = useReactTable({
        data,
        columns,
        getCoreRowModel: getCoreRowModel(),
        meta: {
          updateData: (rowIndex, columnId, value) => {
            setData(old =>
              old.map((row, index) => {
                if (index === rowIndex) {
                  return {
                    ...old[rowIndex],
                    [columnId]: value,
                  };
                }
                return row;
              })
            );
          },
        },
        defaultColumn: {
            cell: EditableCell,
        },
    });
    
    const removeRow = (index) => {
        setData(current => current.filter((_, i) => i !== index));
    };

    const handleRetry = async () => {
        setIsSaving(true);
        const productsToUpsert = data.map(row => {
            const { original_row, error, ...productData } = row;
            return {
                ...productData,
                user_id: user.id,
                sale_price: parseCurrency(productData.sale_price),
                purchase_price: parseCurrency(productData.purchase_price),
            };
        });

        try {
            await upsertMutation.mutateAsync(productsToUpsert);
            toast({ title: t('common.success'), description: `${data.length} ${t('importCorrector.productsProcessed')}` });
            onJobCompletion();
        } catch (error) {
            toast({ variant: 'destructive', title: t('common.error'), description: `${t('importCorrector.saveError')}: ${error.message}` });
        } finally {
            setIsSaving(false);
        }
    };
    
    if (!job || !job.error_details?.rows) {
        return (
            <div>
                <p>{t('importCorrector.noErrorDetails')}</p>
                <Button onClick={onBack}><ArrowLeft className="mr-2 h-4 w-4"/> {t('common.back')}</Button>
            </div>
        );
    }
    
    return (
        <div className="space-y-4">
             <div className="flex justify-between items-center">
                <Button onClick={onBack} variant="outline"><ArrowLeft className="mr-2 h-4 w-4"/> {t('importCorrector.backToHistory')}</Button>
                <Button onClick={handleRetry} disabled={isSaving || data.length === 0}>
                    {isSaving ? <RefreshCw className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>}
                    {isSaving ? t('common.saving') : `${t('common.save')} ${data.length} ${t('importCorrector.products')}`}
                </Button>
            </div>
            <p className="text-sm text-muted-foreground">
                {t('importCorrector.instructions')}
            </p>
            <div className="rounded-md border overflow-x-auto">
                <Table>
                    <TableHeader>
                        {table.getHeaderGroups().map(headerGroup => (
                            <TableRow key={headerGroup.id}>
                                {headerGroup.headers.map(header => (
                                    <TableHead key={header.id}>
                                        {flexRender(header.column.columnDef.header, header.getContext())}
                                    </TableHead>
                                ))}
                            </TableRow>
                        ))}
                    </TableHeader>
                    <TableBody>
                        {table.getRowModel().rows.map(row => (
                            <TableRow key={row.id}>
                                {row.getVisibleCells().map(cell => (
                                    <TableCell key={cell.id}>
                                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                    </TableCell>
                                ))}
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
    );
};

export default ImportCorrector;