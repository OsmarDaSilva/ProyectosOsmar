import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  FolderOpen, 
  Trash2, 
  Edit, 
  Plus,
  Calendar,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ProjectList = ({ onProjectSelect, onNewProject }) => {
  const { toast } = useToast();
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = () => {
    const savedProjects = JSON.parse(localStorage.getItem('costoRuralProjects') || '[]');
    setProjects(savedProjects);
  };

  const deleteProject = (projectName) => {
    const savedProjects = JSON.parse(localStorage.getItem('costoRuralProjects') || '[]');
    const filteredProjects = savedProjects.filter(p => p.projectName !== projectName);
    localStorage.setItem('costoRuralProjects', JSON.stringify(filteredProjects));
    setProjects(filteredProjects);
    
    toast({
      title: "Proyecto eliminado",
      description: `El proyecto "${projectName}" ha sido eliminado exitosamente.`
    });
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const calculateQuickMetrics = (project) => {
    const traditionalRevenue = (project.area || 0) * (project.traditionalYield || 0) * (project.traditionalPrice || 0);
    const traditionalCosts = (project.traditionalCosts || 0) + (project.traditionalLabor || 0) + (project.traditionalInputs || 0);
    const traditionalProfit = traditionalRevenue - traditionalCosts;

    const techRevenue = (project.area || 0) * (project.techYield || 0) * (project.techPrice || 0);
    const techCosts = (project.techCosts || 0) + (project.techLabor || 0) + (project.techInputs || 0) + (project.irrigationCost || 0) + (project.technologyCost || 0);
    const techProfit = techRevenue - techCosts;

    return {
      traditionalProfit,
      techProfit,
      profitDifference: techProfit - traditionalProfit,
      isMoreProfitable: techProfit > traditionalProfit
    };
  };

  const getProjectTypeIcon = (type) => {
    switch (type) {
      case 'agricultura': return '🌾';
      case 'ganaderia': return '🐄';
      case 'mixto': return '🌾🐄';
      case 'fruticultura': return '🍎';
      case 'horticultura': return '🥬';
      default: return '📊';
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <h1 className="text-4xl font-bold gradient-text">Mis Proyectos</h1>
        <p className="text-gray-600">Gestiona y analiza todos tus proyectos agrícolas</p>
      </motion.div>

      {/* New Project Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex justify-center"
      >
        <Button onClick={onNewProject} className="btn-primary">
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Proyecto
        </Button>
      </motion.div>

      {/* Projects Grid */}
      {projects.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="glass-effect">
            <CardContent className="text-center py-12">
              <FolderOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">No hay proyectos guardados</h3>
              <p className="text-gray-500 mb-6">Crea tu primer proyecto para comenzar el análisis financiero</p>
              <Button onClick={onNewProject} className="btn-primary">
                <Plus className="h-4 w-4 mr-2" />
                Crear Primer Proyecto
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => {
            const metrics = calculateQuickMetrics(project);
            return (
              <motion.div
                key={project.projectName}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + index * 0.1 }}
              >
                <Card className="metric-card hover:shadow-2xl transition-all duration-300 cursor-pointer group">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{getProjectTypeIcon(project.projectType)}</span>
                        <div>
                          <h3 className="text-lg font-bold text-gray-900 group-hover:text-green-700 transition-colors">
                            {project.projectName}
                          </h3>
                          <p className="text-sm text-gray-500 capitalize">
                            {project.projectType} • {project.area} ha
                          </p>
                        </div>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Quick Metrics */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="text-center">
                        <div className="text-sm text-gray-600 mb-1">Tradicional</div>
                        <div className={`text-lg font-bold ${metrics.traditionalProfit >= 0 ? 'profit-positive' : 'profit-negative'}`}>
                          {formatCurrency(metrics.traditionalProfit)}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm text-gray-600 mb-1">Tecnificado</div>
                        <div className={`text-lg font-bold ${metrics.techProfit >= 0 ? 'profit-positive' : 'profit-negative'}`}>
                          {formatCurrency(metrics.techProfit)}
                        </div>
                      </div>
                    </div>

                    {/* Profit Difference */}
                    <div className="text-center py-2 border-t border-gray-100">
                      <div className="flex items-center justify-center space-x-2">
                        {metrics.profitDifference >= 0 ? 
                          <TrendingUp className="h-4 w-4 text-green-600" /> :
                          <TrendingUp className="h-4 w-4 text-red-600 rotate-180" />
                        }
                        <span className="text-sm text-gray-600">Diferencia:</span>
                        <span className={`font-bold ${metrics.profitDifference >= 0 ? 'profit-positive' : 'profit-negative'}`}>
                          {formatCurrency(metrics.profitDifference)}
                        </span>
                      </div>
                      <div className={`text-xs mt-1 ${metrics.isMoreProfitable ? 'text-green-600' : 'text-red-600'}`}>
                        {metrics.isMoreProfitable ? 'Tecnificado más rentable' : 'Tradicional más rentable'}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex space-x-2 pt-2">
                      <Button
                        onClick={() => onProjectSelect(project)}
                        className="flex-1 btn-primary text-sm"
                      >
                        <FolderOpen className="h-3 w-3 mr-1" />
                        Abrir
                      </Button>
                      <Button
                        onClick={() => deleteProject(project.projectName)}
                        variant="outline"
                        size="sm"
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Summary Stats */}
      {projects.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="chart-container">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span>Resumen de Proyectos</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">{projects.length}</div>
                  <div className="text-sm text-gray-600">Proyectos Totales</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {projects.filter(p => calculateQuickMetrics(p).isMoreProfitable).length}
                  </div>
                  <div className="text-sm text-gray-600">Tecnificado Rentable</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {projects.reduce((sum, p) => sum + (p.area || 0), 0).toFixed(1)}
                  </div>
                  <div className="text-sm text-gray-600">Hectáreas Totales</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {formatCurrency(projects.reduce((sum, p) => {
                      const metrics = calculateQuickMetrics(p);
                      return sum + Math.max(metrics.traditionalProfit, metrics.techProfit);
                    }, 0))}
                  </div>
                  <div className="text-sm text-gray-600">Ganancia Potencial</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
};

export default ProjectList;