import React from 'react';
import AppHeader from '@/components/layout/AppHeader';
import AppNavbar from '@/layout/AppNavbar';
import { useGlobalAssistant } from '@/contexts/GlobalAssistantContext';
import GlobalAssistant from '@/components/assistant/GlobalAssistant';
import { useLocation } from 'react-router-dom';

const DashboardLayout = ({ children }) => {
    const { isOpen, enabled } = useGlobalAssistant();
    const { pathname } = useLocation();

    const hideOnThisRoute = pathname.startsWith("/asistente-ia") || pathname.startsWith("/ai-assistant") || pathname.startsWith("/assistant");

    return (
        <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr]">
            <AppNavbar />
            <div className="flex flex-col relative">
                <AppHeader />
                <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6 bg-muted/20 overflow-auto">
                    {children}
                </main>
                {isOpen && <div className="absolute inset-0 bg-black/30 z-40" />}
                {enabled && !hideOnThisRoute && <GlobalAssistant />}
            </div>
        </div>
    );
};

export default DashboardLayout;