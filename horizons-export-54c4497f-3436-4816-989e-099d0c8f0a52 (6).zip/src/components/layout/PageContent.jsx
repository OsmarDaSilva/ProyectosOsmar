import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calculator } from 'lucide-react';
import ProjectForm from '@/components/ProjectForm';
import FinancialAnalysis from '@/components/FinancialAnalysis';
import AgricultureForm from '@/components/AgricultureForm';
import GanaderiaForm from '@/components/GanaderiaForm';
import TirVanRoyPayback from '@/components/TirVanRoyPayback';
import ChartsView from '@/components/ChartsView';
import ExecutiveSummary from '@/components/ExecutiveSummary';
import CarbonBalancePage from '@/pages/CarbonBalancePage';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { useInitialCalculations } from '@/hooks/useInitialCalculations';
import { useTranslation } from 'react-i18next';

const PlaceholderView = ({ text }) => (
  <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
    <Calculator className="h-16 w-16 text-gray-400 mx-auto mb-4" />
    <p className="text-gray-600 text-lg mb-6">{text}</p>
  </div>
);

const PageContent = ({ currentView }) => {
  const { t } = useTranslation('calculator');
  const { 
    projectData, 
    agricultureData, 
    ganaderiaData, 
    handleProjectUpdate, 
    handleAgricultureUpdate, 
    handleGanaderiaUpdate,
    fullForageData,
    isDataLoaded
  } = useProjectData();
      
  const initialCalculations = useInitialCalculations(projectData);

  const modules = projectData?.modules || { ganaderia: true, agricultura: true };
  const hasDataForAnalysis =
      projectData &&
      (!modules.agricultura || (agricultureData && Array.isArray(agricultureData.cultivos) && agricultureData.cultivos.length > 0)) &&
      (!modules.ganaderia || (ganaderiaData && Object.keys(ganaderiaData).length > 0));

  const renderCurrentView = () => {
    switch (currentView) {
      case 'inicial':
        return <ProjectForm formData={projectData} onUpdate={handleProjectUpdate} calculations={initialCalculations} />;
      case 'resumen':
        return <ExecutiveSummary projectData={projectData} agricultureData={agricultureData} ganaderiaData={ganaderiaData} />;
      case 'agricultura':
        return modules.agricultura ? <AgricultureForm initialData={agricultureData} onUpdate={handleAgricultureUpdate} /> : <PlaceholderView text={t('placeholders.agricultureDisabled')} />;
      case 'ganaderia':
        return modules.ganaderia ? <GanaderiaForm initialData={ganaderiaData} onUpdate={handleGanaderiaUpdate} projectData={projectData} /> : <PlaceholderView text={t('placeholders.livestockDisabled')} />;
      case 'viabilidad':
        if (!modules.ganaderia && !modules.agricultura) {
          return <PlaceholderView text={t('placeholders.viabilityNoModules')} />;
        }
        return hasDataForAnalysis ? <TirVanRoyPayback projectData={projectData} agricultureData={agricultureData} ganaderiaData={ganaderiaData} /> : <PlaceholderView text={t('placeholders.viabilityNoData')} />;
      case 'analisis':
        return hasDataForAnalysis ? <FinancialAnalysis /> : <PlaceholderView text={t('placeholders.viabilityNoData')} />;
      case 'graficos':
        return hasDataForAnalysis ? <ChartsView projectData={projectData} agricultureData={agricultureData} ganaderiaData={ganaderiaData} /> : <PlaceholderView text={t('placeholders.chartsNoData')} />;
      case 'carbono':
        return hasDataForAnalysis ? <CarbonBalancePage /> : <PlaceholderView text={t('placeholders.carbonNoData')} />;
      default:
        return <ProjectForm formData={projectData} onUpdate={handleProjectUpdate} calculations={initialCalculations} />;
    }
  };

  return (
    <main className="container mx-auto p-2 sm:p-6">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentView}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {renderCurrentView()}
        </motion.div>
      </AnimatePresence>
    </main>
  );
};

export default PageContent;