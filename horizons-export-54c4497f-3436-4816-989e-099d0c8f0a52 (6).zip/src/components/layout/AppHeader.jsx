import React, { useState } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { Menu, Bell, User, Settings, LogOut, HelpCircle, Cloud, MonitorCheck as CloudCheck, CloudOff, Bot } from 'lucide-react';
    import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
    import { Button } from '@/components/ui/button';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useProjectData } from '@/contexts/ProjectDataContext';
    import LanguageSelector from '@/components/LanguageSelector';
    import NotificationsPanel from '@/components/notifications/NotificationsPanel';
    import { useQuery } from '@tanstack/react-query';
    import { useTranslation } from 'react-i18next';
    import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
    import { useGlobalAssistant } from '@/contexts/GlobalAssistantContext';

    const SyncStatusIndicator = () => {
        const { t } = useTranslation('nav');
        const { isSyncing, lastSync } = useProjectData();

        let statusIcon;
        let statusText;
        let statusColor;

        if (isSyncing) {
            statusIcon = <Cloud className="h-4 w-4 animate-pulse" />;
            statusText = t('syncStatus.syncing');
            statusColor = 'text-blue-600';
        } else if (lastSync) {
            statusIcon = <CloudCheck className="h-4 w-4" />;
            statusText = `${t('syncStatus.savedAt')} ${new Date(lastSync).toLocaleTimeString()}`;
            statusColor = 'text-green-600';
        } else {
            statusIcon = <CloudOff className="h-4 w-4" />;
            statusText = t('syncStatus.pending');
            statusColor = 'text-gray-500';
        }

        return (
            <div className={`flex items-center gap-2 text-xs font-medium ${statusColor} bg-white/80 backdrop-blur-sm px-3 py-1 rounded-full shadow-sm border`}>
                {statusIcon}
                <span>{statusText}</span>
            </div>
        );
    };

    const AppHeader = ({ toggleSidebar, isSidebarOpen }) => {
        const { user, signOut } = useAuth();
        const { activeClientProject, supabase } = useProjectData();
        const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
        const { t } = useTranslation(['nav', 'assistant']);
        const navigate = useNavigate();
        const { openAssistant } = useGlobalAssistant();
        const isAssistantEnabled = import.meta.env.VITE_ENABLE_GLOBAL_ASSISTANT === 'true';

        const { data: notifications } = useQuery({
            queryKey: ['notifications', user?.id],
            queryFn: async () => {
                if (!user) return [];
                const { data } = await supabase.from('alerts').select('id').eq('is_resolved', false);
                return data;
            },
            enabled: !!user,
            refetchInterval: 60000,
        });


        const handleSignOut = async () => {
            await signOut();
        };

        const handleAssistantClick = () => {
            if (isAssistantEnabled) {
                openAssistant();
            } else {
                navigate('/ai-assistant');
            }
        }

        return (
            <header className="flex items-center justify-between px-6 py-3 bg-white border-b border-gray-200 shadow-sm dark:bg-gray-800 dark:border-gray-700 z-20 relative">
                <div className="flex items-center">
                    <h1 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
                        {activeClientProject ? activeClientProject.project.project_name : 'AGROinvest'}
                    </h1>
                </div>

                <div className="flex items-center space-x-4">
                    <SyncStatusIndicator />
                    <TooltipProvider>
                        <Tooltip>
                            <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" onClick={handleAssistantClick}>
                                    <Bot className="h-6 w-6 text-gray-600 dark:text-gray-300" />
                                </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                                <p>{t('title', {ns: 'assistant'})}</p>
                            </TooltipContent>
                        </Tooltip>
                    </TooltipProvider>
                    <LanguageSelector />
                    
                    <Button variant="ghost" size="icon" onClick={() => setIsNotificationsOpen(true)} className="relative">
                        <Bell className="h-6 w-6 text-gray-600 dark:text-gray-300" />
                        {notifications && notifications.length > 0 && (
                            <span className="absolute top-0 right-0 flex h-3 w-3">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                            </span>
                        )}
                    </Button>
                    <NotificationsPanel isOpen={isNotificationsOpen} onOpenChange={setIsNotificationsOpen} />

                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="rounded-full">
                                <User className="h-6 w-6 text-gray-600 dark:text-gray-300" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56">
                            <DropdownMenuLabel>
                                {user?.full_name || user?.email || t('userMenu.myAccount')}
                            </DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem asChild>
                                <Link to="/user-profile" className="flex items-center">
                                    <User className="mr-2 h-4 w-4" />
                                    {t('userMenu.profile')}
                                </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                                <Link to="/settings" className="flex items-center">
                                    <Settings className="mr-2 h-4 w-4" />
                                    {t('settings')}
                                </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                                <Link to="/help-desk" className="flex items-center">
                                    <HelpCircle className="mr-2 h-4 w-4" />
                                    {t('userMenu.help')}
                                </Link>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={handleSignOut} className="flex items-center text-red-600">
                                <LogOut className="mr-2 h-4 w-4" />
                                {t('logout')}
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </header>
        );
    };

    export default AppHeader;