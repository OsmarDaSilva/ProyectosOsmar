import React from 'react';
    import { NavLink } from 'react-router-dom';
    import { FileText, GanttChartSquare, Beef, Leaf, BarChart, TrendingUp, Home, Scale, Recycle, LandPlot, Calculator } from 'lucide-react';
    import { useProjectData } from '@/contexts/ProjectDataContext';
    import { cn } from '@/lib/utils';
    import { useTranslation } from 'react-i18next';

    const CalculatorNavbar = () => {
      const { t } = useTranslation('calculator');
      const { projectData } = useProjectData();
      const { modules } = projectData || {};

      const navLinks = [
        { to: '.', text: t('nav.home'), icon: Home, end: true },
        { to: 'inversiones', text: t('nav.investments'), icon: LandPlot },
        { to: 'ganaderia', text: t('nav.livestock'), icon: Beef, module: 'ganaderia' },
        { to: 'agricultura', text: t('nav.agriculture'), icon: Leaf, module: 'agricultura' },
        { to: 'resumen-ejecutivo', text: t('nav.executiveSummary'), icon: FileText },
        { to: 'analisis-viabilidad', text: t('nav.viabilityAnalysis'), icon: GanttChartSquare },
        { to: 'graficos', text: t('nav.charts'), icon: BarChart },
        { to: 'analisis-financiero', text: t('nav.financialAnalysis'), icon: TrendingUp },
        { to: 'balance-carbono', text: t('nav.carbonBalance'), icon: Recycle },
      ];

      const activeLinkClass = "bg-white text-green-700 shadow-md";
      const inactiveLinkClass = "text-gray-600 hover:bg-white/60 hover:text-green-800";

      return (
        <div className="bg-gray-100 p-2 rounded-lg shadow-inner-strong mb-6 sticky top-0 z-10 backdrop-blur-sm bg-opacity-80">
          <nav className="flex items-center justify-center space-x-1 sm:space-x-2">
            {navLinks.map(link => {
              if (link.module && modules && !modules[link.module]) {
                return null;
              }
              return (
                <NavLink
                  key={link.text}
                  to={link.to}
                  end={link.end}
                  className={({ isActive }) =>
                    cn(
                      'flex flex-col items-center justify-center px-3 sm:px-4 rounded-md transition-all duration-200 h-16 w-32 sm:w-auto min-w-[120px] text-center',
                      isActive ? activeLinkClass : inactiveLinkClass
                    )
                  }
                >
                  <link.icon className="h-5 w-5 mb-1" />
                  <span className="text-xs sm:text-sm leading-tight">{link.text}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>
      );
    };

    export default CalculatorNavbar;