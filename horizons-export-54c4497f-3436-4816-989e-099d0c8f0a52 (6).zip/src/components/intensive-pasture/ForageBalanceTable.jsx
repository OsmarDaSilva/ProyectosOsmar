import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useTranslation } from 'react-i18next';

const formatNumber = (value) => {
    if (typeof value !== 'number' || isNaN(value)) return '0';
    return value.toLocaleString('es-ES', { maximumFractionDigits: 0 });
};

export const ForageBalanceTable = ({ forageBalance }) => {
    const { t } = useTranslation(['forageBalance', 'forageDatabase', 'common']);
    const totalProduction = forageBalance.reduce((a,b)=>a+b.forageProduction,0);
    const totalConsumption = forageBalance.reduce((a,b)=>a+b.animalConsumption,0);
    const totalBalance = forageBalance.reduce((a,b)=>a+b.balance,0);

    return (
        <div className="overflow-x-auto">
            <Table>
                <TableHeader className="bg-gray-100">
                    <TableRow>
                        <TableHead>{t('forageBalance:month')}</TableHead>
                        <TableHead>{t('forageBalance:forageSupply')} (kg MS)</TableHead>
                        <TableHead>{t('forageBalance:herdDemand')} (kg MS)</TableHead>
                        <TableHead>{t('forageBalance:balanceTon')} (kg MS)</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {forageBalance.map(row => (
                        <TableRow key={row.month}>
                            <TableCell>{row.month}</TableCell>
                            <TableCell>{formatNumber(row.forageProduction)}</TableCell>
                            <TableCell>{formatNumber(row.animalConsumption)}</TableCell>
                            <TableCell className={row.balance < 0 ? 'text-red-500 font-bold' : 'text-green-600'}>
                                {formatNumber(row.balance)}
                            </TableCell>
                        </TableRow>
                    ))}
                    <TableRow className="font-bold bg-gray-50">
                        <TableCell>{t('forageDatabase:table.annualTotal', 'Total Anual')}</TableCell>
                        <TableCell>{formatNumber(totalProduction)}</TableCell>
                        <TableCell>{formatNumber(totalConsumption)}</TableCell>
                        <TableCell className={totalBalance < 0 ? 'text-red-500' : 'text-green-600'}>
                          {formatNumber(totalBalance)}
                        </TableCell>
                    </TableRow>
                </TableBody>
            </Table>
        </div>
    );
};