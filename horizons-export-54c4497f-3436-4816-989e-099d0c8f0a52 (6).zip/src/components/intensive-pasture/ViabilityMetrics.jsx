import React from 'react';
import { formatNumber, formatCurrency } from '@/lib/utils';
import { TrendingUp, DollarSign, Repeat, CalendarCheck2, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const MetricCard = ({ icon, label, value, unit, bgColorClass, textColorClass, isNotViable = false }) => (
    <div className={`p-4 rounded-lg flex items-center gap-4 ${bgColorClass} ${textColorClass}`}>
        <div className="p-3 rounded-full bg-black/10">
            {icon}
        </div>
        <div>
            <p className="text-sm opacity-90">{label}</p>
            <p className="text-2xl font-bold">
                {value} <span className="text-base font-medium">{unit}</span>
            </p>
        </div>
    </div>
);

export const ViabilityMetrics = ({ data }) => {
    const { t } = useTranslation(['viability', 'common']);
    if (!data || Object.keys(data).length === 0) return null;

    const { van, tir, roi, payback } = data;

    const isViable = van?.value >= 0;

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className={`p-6 rounded-lg flex flex-col justify-center items-center text-center ${isViable ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                {isViable ? (
                    <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-3" />
                ) : (
                    <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-3" />
                )}
                <h3 className={`text-xl font-bold ${isViable ? 'text-green-800' : 'text-red-800'}`}>
                    {isViable ? t('viableTitle') : t('notViableTitle')}
                </h3>
                <p className={`text-sm ${isViable ? 'text-green-700' : 'text-red-700'}`}>
                    {isViable ? t('viableSubtitle') : t('notViableSubtitle')}
                </p>
            </div>
            <MetricCard 
                icon={<DollarSign />} 
                label={t('npv')}
                value={formatCurrency(van?.value || 0)} 
                unit="USD" 
                bgColorClass={isViable ? "bg-blue-100" : "bg-red-100"}
                textColorClass={isViable ? "text-blue-800" : "text-red-800"}
            />
             <MetricCard 
                icon={<TrendingUp />} 
                label={t('roi')}
                value={formatNumber(roi?.value, 2)} 
                unit="%" 
                bgColorClass="bg-purple-100"
                textColorClass="text-purple-800"
            />
             <MetricCard 
                icon={<CalendarCheck2 />} 
                label={t('payback')}
                value={payback?.value > 0 ? formatNumber(payback.value, 2) : '—'} 
                unit={payback?.value > 0 ? t('common:years') : ''}
                bgColorClass="bg-orange-100"
                textColorClass="text-orange-800"
            />
        </div>
    );
};