import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useTranslation } from 'react-i18next';
import { Info } from 'lucide-react';
import { Tooltip, TooltipProvider, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { PerformanceSummary } from '@/components/intensive-pasture/PerformanceSummary';
import { formatNumber } from '@/lib/utils';

const InputField = ({ label, name, value, onChange, unit, tooltipKey, t, disabled = false, type = "text" }) => (
    <div className="space-y-1">
        <div className="flex items-center space-x-2">
            <Label htmlFor={name} className="text-sm font-medium">{label}</Label>
            {tooltipKey && (
                <TooltipProvider>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                        </TooltipTrigger>
                        <TooltipContent>
                            <p className="max-w-xs">{t(`tooltips:${tooltipKey}`)}</p>
                        </TooltipContent>
                    </Tooltip>
                </TooltipProvider>
            )}
        </div>
        <div className="flex items-center">
            <Input id={name} name={name} value={value} onChange={onChange} className="text-right" disabled={disabled} type={type}/>
            {unit && <span className="ml-2 text-sm text-gray-500">{t(unit)}</span>}
        </div>
    </div>
);

const ReadOnlyField = ({ label, value, unit, tooltipKey, t }) => (
    <div className="space-y-1">
        <div className="flex items-center space-x-2">
            <Label className="text-sm font-medium">{label}</Label>
            {tooltipKey && (
                <TooltipProvider>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                        </TooltipTrigger>
                        <TooltipContent>
                            <p className="max-w-xs">{t(`tooltips:${tooltipKey}`)}</p>
                        </TooltipContent>
                    </Tooltip>
                </TooltipProvider>
            )}
        </div>
        <div className="flex items-center h-10 px-3 bg-gray-100 rounded-md border text-right justify-end">
            <span className="text-sm font-semibold">{value}</span>
            {unit && <span className="ml-2 text-sm text-gray-500">{t(unit)}</span>}
        </div>
    </div>
);


const SelectField = ({ label, name, value, onValueChange, options, placeholder, tooltipKey, t, disabled = false }) => (
    <div className="space-y-1">
        <div className="flex items-center space-x-2">
            <Label htmlFor={name} className="text-sm font-medium">{label}</Label>
            {tooltipKey && (
                <TooltipProvider>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                        </TooltipTrigger>
                        <TooltipContent>
                            <p className="max-w-xs">{t(`tooltips:${tooltipKey}`)}</p>
                        </TooltipContent>
                    </Tooltip>
                </TooltipProvider>
            )}
        </div>
        <Select name={name} value={value} onValueChange={onValueChange} disabled={disabled}>
            <SelectTrigger>
                <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
                {options.map(option => (
                    <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                ))}
            </SelectContent>
        </Select>
    </div>
);

export const IntensivePastureInputs = ({
    params,
    handleInputChange,
    handleSelectChange,
    handleFilterChange,
    filters,
    filterOptions,
    filteredPastures,
    performanceSummary,
}) => {
    const { t } = useTranslation(['intensivePasture', 'viability', 'common', 'tooltips']);
    
    const animalTypeOptions = [
        "Novillo Toro",
        "Novillo Capon",
        "Vaquilla",
        "Vaca de cria",
        "Vaca descarte"
    ].map(type => ({ value: type, label: type }));

    return (
        <Card>
            <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start">
                    
                    <div className="md:col-span-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pb-6 border-b">
                         <SelectField
                            label={t('inputs.pastureType')}
                            name="selectedPastureId"
                            value={params.selectedPastureId}
                            onValueChange={(value) => handleSelectChange('selectedPastureId', value)}
                            options={filteredPastures.map(p => ({ value: p.id, label: `${p.pasture_type} (${p.method})` }))}
                            placeholder={t('common:select')}
                            tooltipKey="pastureType"
                            t={t}
                            disabled={!filteredPastures.length}
                        />
                        <InputField label={t('inputs.startDate')} name="startDate" type="date" value={params.startDate} onChange={handleInputChange} tooltipKey="startDate" t={t} />
                        <InputField label={t('inputs.hectares')} name="hectares" value={params.hectares} onChange={handleInputChange} unit="common:ha" tooltipKey="hectares" t={t} />
                        <InputField label={t('inputs.pastureUtilization')} name="pastureUtilization" value={params.pastureUtilization} onChange={handleInputChange} unit="%" tooltipKey="pastureUtilization" t={t} />
                    </div>

                    
                    <div className="space-y-4">
                        <h3 className="font-semibold text-lg text-gray-700">{t('sections.animalParams')}</h3>
                        <SelectField
                            label={t('inputs.animalType')}
                            name="animalType"
                            value={params.animalType}
                            onValueChange={(value) => handleSelectChange('animalType', value)}
                            options={animalTypeOptions}
                            placeholder={t('common:select')}
                            t={t}
                        />
                        <InputField label={t('inputs.headsPerHectare')} name="headsPerHectare" value={params.headsPerHectare} onChange={handleInputChange} unit="units.headsHa" tooltipKey="headsPerHectare" t={t} />
                        <InputField label={t('inputs.startWeight')} name="startWeight" value={params.startWeight} onChange={handleInputChange} unit="kg" tooltipKey="startWeight" t={t} />
                        <InputField label={t('inputs.endWeight')} name="endWeight" value={params.endWeight} onChange={handleInputChange} unit="kg" tooltipKey="endWeight" t={t} />
                        
                    </div>

                    
                    <div className="space-y-4">
                        <h3 className="font-semibold text-lg text-gray-700">{t('sections.feedingParams')}</h3>
                        <InputField label={t('inputs.dailyConsumptionPercentage')} name="dailyConsumptionPercentage" value={params.dailyConsumptionPercentage} onChange={handleInputChange} unit="% MS" tooltipKey="dailyConsumptionPercentage" t={t} />
                        <InputField label={t('inputs.dailySupplementGram')} name="dailySupplementGram" value={params.dailySupplementGram} onChange={handleInputChange} unit="g/cab/día" tooltipKey="dailySupplementGram" t={t} />
                        <InputField label={t('inputs.supplementGdpGain')} name="supplementGdpGain" value={params.supplementGdpGain} onChange={handleInputChange} unit="g/día" tooltipKey="supplementGdpGain" t={t} />
                        <InputField label={t('inputs.supplementaryFeedCost')} name="supplementaryFeedCost" value={params.supplementaryFeedCost} onChange={handleInputChange} unit="$/kg" tooltipKey="supplementaryFeedCost" t={t} />
                    </div>
                    
                    
                    <div className="space-y-4">
                        <h3 className="font-semibold text-lg text-gray-700">{t('sections.financialParams')}</h3>
                        <InputField label={t('inputs.purchasePricePerHead')} name="purchasePricePerHead" value={params.purchasePricePerHead} onChange={handleInputChange} unit="$/cab" tooltipKey="purchasePricePerHead" t={t} />
                        <InputField label={t('inputs.carcassYieldPercentage')} name="carcassYieldPercentage" value={params.carcassYieldPercentage} onChange={handleInputChange} unit="%" tooltipKey="carcassYieldPercentage" t={t} />
                        <ReadOnlyField label={t('inputs.kgCarcassPerHead')} value={formatNumber(performanceSummary?.kgCarcasaPorCabeza?.value, 2)} unit="kg/cab" tooltipKey="kgCarcassPerHead" t={t} />
                        <InputField label={t('inputs.salePricePerKgHook')} name="salePricePerKgHook" value={params.salePricePerKgHook} onChange={handleInputChange} unit="$/kg" tooltipKey="salePricePerKgHook" t={t} />
                        <InputField label={t('inputs.annualOperatingCostPerHead')} name="annualOperatingCostPerHead" value={params.annualOperatingCostPerHead} onChange={handleInputChange} unit="$/cab" tooltipKey="annualOperatingCostPerHead" t={t} />
                        <InputField label={t('inputs.mortalityRate')} name="mortalityRate" value={params.mortalityRate} onChange={handleInputChange} unit="%" tooltipKey="mortalityRate" t={t} />
                    </div>

                    
                    <div className="space-y-4 bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-semibold text-lg text-gray-700">{t('sections.results')}</h3>
                        <PerformanceSummary data={performanceSummary} isCompact={true} />
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};