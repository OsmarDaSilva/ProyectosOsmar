import React from 'react';
import { formatNumber, formatCurrency } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

const SummaryItem = ({ label, value, unit, className = '' }) => {
    if (value === null || value === undefined || value === 'NaN' || value === 'Infinity') {
        value = '—';
        unit = '';
    }

    return (
        <div className={`flex justify-between items-center py-2 border-b ${className}`}>
            <span className="text-sm text-gray-600">{label}</span>
            <span className="font-semibold text-gray-800">
                {value} <span className="text-xs font-normal text-gray-500">{unit}</span>
            </span>
        </div>
    );
}

export const PerformanceSummary = ({ data, isCompact = false }) => {
    const { t } = useTranslation(['intensivePasture', 'viability', 'common']);
    if (!data) return null;

    const {
        totalHeads,
        hectares,
        fatteningDays,
        dailyWeightGain,
        totalWeightGain,
        supplementaryFeed,
        annualRevenuePerHead,
        stockingRate,
        carneTotalTon,
    } = data;
    
    const compactClass = isCompact ? 'py-1' : '';

    return (
        <div className="space-y-1">
          <SummaryItem label={t('performance.herdSize')} value={formatNumber(totalHeads?.value, 0)} unit={t('common:heads')} className={compactClass} />
          <SummaryItem label={t('performance.stockingRate')} value={formatNumber(stockingRate?.value, 2)} unit={t('intensivePasture:units.headsHa')} className={compactClass} />
          <SummaryItem label={t('performance.totalWeightGain')} value={formatNumber(totalWeightGain?.value, 1)} unit="kg" className={compactClass} />
          <SummaryItem label={t('performance.dailyWeightGain')} value={formatNumber(dailyWeightGain?.value, 3)} unit="kg/día" className={compactClass} />
          <SummaryItem label={t('performance.fatteningDays')} value={formatNumber(fatteningDays?.value, 0)} unit={t('common:days')} className={compactClass} />
          <SummaryItem label={t('performance.supplementaryFeed')} value={formatNumber(supplementaryFeed?.value, 2)} unit="ton MS" className={compactClass} />
          <SummaryItem label={t('performance.totalMeatProduction')} value={formatNumber(carneTotalTon?.value, 2)} unit="ton" className={compactClass} />
          <SummaryItem label={t('performance.annualRevenuePerHead')} value={formatCurrency(annualRevenuePerHead?.value)} unit="USD" className={`${compactClass} text-green-600 font-bold border-b-0`} />
        </div>
    );
};