import React from 'react';
import { ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine } from 'recharts';
import { formatNumber } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

const CustomTooltip = ({ active, payload, label }) => {
    const { t } = useTranslation(['intensivePasture', 'common']);
    if (active && payload && payload.length) {
        return (
            <div className="p-2 bg-background/80 backdrop-blur-sm rounded-lg border shadow-lg">
                <p className="font-bold text-foreground capitalize">{label}</p>
                {payload.map((pld, index) => {
                    const unit = pld.dataKey === 'balancePercentage' ? '%' : t('common:tonMS');
                    return (
                        <p key={index} style={{ color: pld.color || pld.fill }}>
                            {`${pld.name}: ${formatNumber(pld.value, 2)} ${unit}`}
                        </p>
                    )
                })}
            </div>
        );
    }
    return null;
};

export const ForageBalanceChart = ({ data }) => {
    const { t } = useTranslation(['intensivePasture', 'common']);

    if (!data || data.length === 0) {
        return <div className="flex items-center justify-center h-full text-muted-foreground">{t('noDataForChart')}</div>;
    }

    const chartData = data.map(d => ({
        month: d.month,
        supply: d.oferta,
        demand: d.demanda,
        balanceTon: d.balanceTon, // Usar balanceTon que ya está en toneladas
        balancePercentage: d.balancePercentage,
    }));


    return (
        <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
                data={chartData.map(d => ({ ...d, month: t(`common:months_short.${d.month.toLowerCase()}`) }))}
                margin={{ top: 20, right: 30, bottom: 20, left: 20 }}
            >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis yAxisId="left" label={{ value: t('chart.msPerYear'), angle: -90, position: 'insideLeft' }} tickFormatter={(value) => formatNumber(value, 0)} />
                <YAxis yAxisId="right" orientation="right" label={{ value: '%', angle: 90, position: 'insideRight' }} tickFormatter={(value) => `${formatNumber(value, 0)}%`} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <ReferenceLine y={0} yAxisId="left" stroke="#000" />
                <Bar yAxisId="left" dataKey="supply" name={t('chart.forageSupply')} fill="#16a34a" />
                <Bar yAxisId="left" dataKey="demand" name={t('chart.herdDemand')} fill="#dc2626" />
                <Line yAxisId="left" type="monotone" dataKey="balanceTon" name={t('chart.balanceTon')} stroke="#0ea5e9" strokeWidth={3} />
                <Line yAxisId="right" type="monotone" dataKey="balancePercentage" name={t('chart.balancePercentage')} stroke="#f97316" strokeWidth={2} strokeDasharray="5 5" />
            </ComposedChart>
        </ResponsiveContainer>
    );
};