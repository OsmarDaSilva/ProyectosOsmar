import React from 'react';
import { ResponsiveContainer, ComposedChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ReferenceLine, Bar, Line as RechartsLine, Cell } from 'recharts';

const formatCurrencyForTooltip = (value) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);

const yAxisFormatter = (value) => {
    if (Math.abs(value) >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
    if (Math.abs(value) >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
    if (Math.abs(value) >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
    return value;
};

export const PaybackChart = ({ cashFlows, payback }) => {
    const chartData = cashFlows.map((flow, index) => {
        let cumulative = 0;
        for (let i = 0; i <= index; i++) {
            cumulative += cashFlows[i];
        }
        return {
            name: index === 0 ? 'Inversión' : `Año ${index}`,
            year: index,
            "Flujo de Caja Anual": flow,
            "Flujo de Caja Acumulado": cumulative,
        };
    });

    const numericPayback = parseFloat(String(payback).replace('>', '').trim());
    const projectYears = chartData.length - 1;

    const gradientOffset = () => {
        const dataMax = Math.max(...chartData.map((i) => i['Flujo de Caja Acumulado']));
        const dataMin = Math.min(...chartData.map((i) => i['Flujo de Caja Acumulado']));
        if (dataMax <= 0) return 0;
        if (dataMin >= 0) return 1;
        return dataMax / (dataMax - dataMin);
    };
    const off = gradientOffset();

    return (
        <ResponsiveContainer width="100%" height={400}>
            <ComposedChart
                data={chartData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis tickFormatter={yAxisFormatter} />
                <Tooltip formatter={(value) => formatCurrencyForTooltip(value)} />
                <Legend />
                <ReferenceLine y={0} stroke="#000" strokeWidth={2} />
                <defs>
                    <linearGradient id="splitColorPayback" x1="0" y1="0" x2="0" y2="1">
                        <stop offset={off} stopColor="#3b82f6" stopOpacity={1} />
                        <stop offset={off} stopColor="#ef4444" stopOpacity={1} />
                    </linearGradient>
                </defs>
                <Bar dataKey="Flujo de Caja Anual">
                    {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry['Flujo de Caja Anual'] < 0 ? '#ef4444' : '#16a34a'} />
                    ))}
                </Bar>
                <RechartsLine type="linear" dataKey="Flujo de Caja Acumulado" stroke="url(#splitColorPayback)" strokeWidth={3} dot={false} />
                {!isNaN(numericPayback) && numericPayback > 0 && numericPayback <= projectYears && (
                    <ReferenceLine
                        x={`Año ${Math.floor(numericPayback)}`}
                        strokeDasharray="3 3"
                        stroke="#16a34a"
                        label={{ value: `Payback: ${payback} años`, position: 'insideTopRight', fill: '#16a34a' }}
                    />
                )}
            </ComposedChart>
        </ResponsiveContainer>
    );
};