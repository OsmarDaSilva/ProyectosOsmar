import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ForageBalanceChart } from '@/components/intensive-pasture/ForageBalanceChart';
import useIntensivePastureAnalysis from '@/hooks/useIntensivePastureAnalysis';
import { PerformanceSummary } from '@/components/intensive-pasture/PerformanceSummary';
import { FinancialSummary } from '@/components/intensive-pasture/FinancialSummary';
import { ViabilityMetrics } from '@/components/intensive-pasture/ViabilityMetrics';
import { formatNumber } from '@/lib/utils';
import { useTranslation } from 'react-i18next';
import { IntensivePastureInputs } from '@/components/intensive-pasture/IntensivePastureInputs';

export const ForageAnalysisContent = ({ forageData }) => {
    const { t } = useTranslation(['intensivePasture', 'viability', 'common']);

    const [filters, setFilters] = useState({
        country: 'all',
        region: 'all',
        production_method: 'all',
    });

    const [formState, setFormState] = useState({
        selectedPastureId: '',
        startDate: '2025-04-01',
        hectares: '100',
        headsPerHectare: '10',
        animalType: 'Novillo Toro',
        startWeight: '200',
        endWeight: '500',
        purchasePricePerHead: '400',
        dailyConsumptionPercentage: '2.5',
        supplementaryFeedCost: '0.25',
        initialInvestment: '0',
        annualOperatingCostPerHead: '320',
        plazo: '1',
        tasaInteres: '7',
        dailySupplementGram: '400',
        supplementGdpGain: '122',
        mortalityRate: '1.0',
        taxRate: '11.5',
        pastureUtilization: '85',
        carcassYieldPercentage: '54',
        salePricePerKgHook: '3.50'
    });

    const filterOptions = useMemo(() => {
        if (!forageData) return { countries: [], regions: [], methods: [] };
        const countries = [...new Set(forageData.map(p => p.country).filter(Boolean))];
        const regions = [...new Set(forageData.map(p => p.region).filter(Boolean))];
        const methods = [...new Set(forageData.map(p => p.production_method).filter(Boolean))];
        return { countries, regions, methods };
    }, [forageData]);

    const filteredPastures = useMemo(() => {
        if (!forageData) return [];
        return forageData.filter(p => 
            (filters.country === 'all' || p.country === filters.country) &&
            (filters.region === 'all' || p.region === filters.region) &&
            (filters.production_method === 'all' || p.production_method === filters.production_method)
        );
    }, [forageData, filters]);

    useEffect(() => {
        if (filteredPastures.length > 0) {
            const currentSelectionExists = filteredPastures.some(p => p.id === formState.selectedPastureId);
            if (!currentSelectionExists) {
                const defaultPasture = filteredPastures.find(p => p.pasture_type === 'BRS Zuri (Regada)') || filteredPastures[0];
                if (defaultPasture) {
                    setFormState(prev => ({ ...prev, selectedPastureId: defaultPasture.id }));
                }
            }
        } else {
             setFormState(prev => ({ ...prev, selectedPastureId: '' }));
        }
    }, [filteredPastures, formState.selectedPastureId]);


    const { results } = useIntensivePastureAnalysis({ ...formState, forageData });
    const { balanceData, performanceSummary, financialSummary, viabilityMetrics, totals } = results;

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormState(prev => ({ ...prev, [name]: value }));
    };
    
    const handleFilterChange = (name, value) => {
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleSelectChange = (name, value) => {
        setFormState(prev => ({ ...prev, [name]: value }));
    };

    const renderDetailTable = () => (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.month')}</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.animalWeight')} (kg)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.forageSupply')} (ton MS)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.herdDemand')} (ton MS)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.balance')} (ton MS)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.balancePercent')}</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {balanceData.map((item) => (
              <tr key={item.key}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 capitalize">{t(`common:months_short.${item.month.toLowerCase()}`)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500">{formatNumber(item.animalWeight, 1)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500">{formatNumber(item.oferta, 2)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500">{formatNumber(item.demanda, 2)}</td>
                <td className={`px-6 py-4 whitespace-nowrap text-sm text-right font-semibold ${item.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatNumber(item.balance, 2)}</td>
                <td className={`px-6 py-4 whitespace-nowrap text-sm text-right font-semibold ${item.balancePercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatNumber(item.balancePercentage, 1)}%</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-100 font-bold">
             <tr>
                <td className="px-6 py-3 text-left text-xs uppercase">{t('table.annualTotal')}</td>
                <td className="px-6 py-3"></td>
                <td className="px-6 py-3 text-right text-sm">{formatNumber(totals.oferta, 2)}</td>
                <td className="px-6 py-3 text-right text-sm">{formatNumber(totals.demanda, 2)}</td>
                <td className={`px-6 py-3 text-right text-sm ${totals.balance >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatNumber(totals.balance, 2)}</td>
                <td className={`px-6 py-3 text-right text-sm ${totals.balancePercentage >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatNumber(totals.balancePercentage, 1)}%</td>
            </tr>
          </tfoot>
        </table>
      </div>
    );

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Tabs defaultValue="params" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="params">{t('tabs.params')}</TabsTrigger>
                    <TabsTrigger value="detail">{t('tabs.monthlyDetail')}</TabsTrigger>
                    <TabsTrigger value="chart">{t('tabs.annualChart')}</TabsTrigger>
                    <TabsTrigger value="results">{t('tabs.results')}</TabsTrigger>
                </TabsList>
                <TabsContent value="params">
                    <IntensivePastureInputs
                        params={formState}
                        handleInputChange={handleInputChange}
                        handleSelectChange={handleSelectChange}
                        handleFilterChange={handleFilterChange}
                        filters={filters}
                        filterOptions={filterOptions}
                        filteredPastures={filteredPastures}
                        performanceSummary={performanceSummary}
                    />
                </TabsContent>
                <TabsContent value="detail">
                    <Card>
                        <CardHeader><CardTitle>{t('monthlyBalanceDetail')}</CardTitle></CardHeader>
                        <CardContent>{renderDetailTable()}</CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="chart">
                    <Card>
                        <CardHeader><CardTitle>{t('annualBalanceChart')}</CardTitle></CardHeader>
                        <CardContent className="h-[400px]"><ForageBalanceChart data={balanceData} /></CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="results">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <Card>
                            <CardHeader><CardTitle>{t('performanceSummary')}</CardTitle></CardHeader>
                            <CardContent><PerformanceSummary data={performanceSummary} /></CardContent>
                        </Card>
                         <Card>
                            <CardHeader><CardTitle>{t('financialSummary')}</CardTitle></CardHeader>
                            <CardContent><FinancialSummary data={financialSummary} /></CardContent>
                        </Card>
                         <Card className="lg:col-span-2">
                            <CardHeader><CardTitle>{t('viabilityMetrics')}</CardTitle></CardHeader>
                            <CardContent><ViabilityMetrics data={viabilityMetrics} /></CardContent>
                        </Card>
                    </div>
                </TabsContent>
            </Tabs>
        </motion.div>
    );
};