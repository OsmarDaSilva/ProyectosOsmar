import React from 'react';
import { formatCurrency } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

const SummaryItem = ({ label, value, unit, className = '', isCost = false, isBold = false }) => {
    const formattedValue = (value === null || value === undefined || isNaN(value))
        ? '—'
        : formatCurrency(value);

    const valueColor = isCost ? 'text-red-600' : 'text-gray-800';
    const fontWeight = isBold ? 'font-bold' : 'font-semibold';

    return (
        <div className={`flex justify-between items-center py-3 border-b ${className}`}>
            <span className="text-sm text-gray-600">{label}</span>
            <span className={`${fontWeight} ${valueColor}`}>
                {formattedValue} <span className="text-sm font-normal text-gray-500">{unit}</span>
            </span>
        </div>
    );
}

export const FinancialSummary = ({ data }) => {
    const { t } = useTranslation(['intensivePasture', 'common']);
    if (!data || Object.keys(data).length === 0) return null;

    const {
        totalRevenue,
        animalPurchaseCost,
        supplementaryFeedCost,
        annualOperatingCost,
        grossMargin,
        profitPerAnimal,
        profitPerHectare,
    } = data;
    
    const isGrossMarginPositive = grossMargin?.value >= 0;

    return (
        <div className="space-y-2">
            <SummaryItem label={t('financials.totalRevenue')} value={totalRevenue?.value} unit="USD" className="text-green-600 font-bold" />
            
            <div className="pl-4 border-l-2 border-gray-200 space-y-1 py-2">
                 <SummaryItem label={t('financials.animalPurchaseCost')} value={animalPurchaseCost?.value} unit="USD" isCost={true} />
                 <SummaryItem label={t('financials.supplementaryFeedCost')} value={supplementaryFeedCost?.value} unit="USD" isCost={true} />
                 <SummaryItem label={t('financials.annualOperatingCost')} value={annualOperatingCost?.value} unit="USD" isCost={true} />
            </div>

            <div className={`p-3 rounded-md ${isGrossMarginPositive ? 'bg-green-50' : 'bg-red-50'}`}>
                <SummaryItem 
                    label={t('financials.grossMargin')} 
                    value={grossMargin?.value} 
                    unit="USD" 
                    className={`${isGrossMarginPositive ? 'text-green-700' : 'text-red-700'} border-none`}
                    isBold={true}
                />
            </div>
            
            <div className="pl-4 border-l-2 border-blue-200 space-y-1 py-2 mt-4">
                <SummaryItem label={t('financials.profitPerAnimal')} value={profitPerAnimal?.value} unit={`USD/${t('common:head')}`} className="text-xs" />
                <SummaryItem label={t('financials.profitPerHectare')} value={profitPerHectare?.value} unit={`USD/${t('common:ha')}`} className="text-xs" />
            </div>
        </div>
    );
};