import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { AddEditProductionRow } from '@/components/AddEditProductionRow';
import { ProductionData } from '@/types/production';

const getNumericValue = (value: string | number | null | undefined): number => parseFloat(String(value || '0').replace(',', '.')) || 0;

const calculateNormalCost = (row: ProductionData): number => {
    return getNumericValue(row.input_cost_ha) + getNumericValue(row.machinery_cost_ha) + getNumericValue(row.freight_cost_ha);
};

const calculateFinalCost = (row: ProductionData): number => {
    const normalCost = calculateNormalCost(row);
    const otherCosts = getNumericValue(row.land_rent_ha) + getNumericValue(row.electrical_energy_cost_ha) + getNumericValue(row.maintenance_repair_cost_ha);
    return normalCost + otherCosts;
};

const formatCurrency = (value: number | null | undefined): string => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);
const formatNumber = (value: number | null | undefined): string => new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);

const HEADERS = [
    { key: 'country', label: 'País' },
    { key: 'department_province', label: 'Dpto/Provincia' },
    { key: 'city_locality', label: 'Ciudad/Localidad' },
    { key: 'year', label: 'Año' },
    { key: 'crop', label: 'Cultura' },
    { key: 'production_purpose', label: 'Finalidad' },
    { key: 'sowing_season', label: 'Época Siembra' },
    { key: 'cultivation_method', label: 'Forma Cultivo' },
    { key: 'yield_ton_ha', label: 'Prod. (ton/ha)' },
    { key: 'input_cost_ha', label: 'Costo Insumos/ha' },
    { key: 'machinery_cost_ha', label: 'Costo Maquinas/ha' },
    { key: 'freight_cost_ha', label: 'Costo Fletes/ha' },
    { key: 'cost_ha_normal', label: 'Costo por ha/normal' },
    { key: 'land_rent_ha', label: 'Alquiler Tierra/ha' },
    { key: 'electrical_energy_cost_ha', label: 'Energía Eléctrica/ha' },
    { key: 'maintenance_repair_cost_ha', label: 'Manutención/ha' },
    { key: 'final_cost_ha', label: 'Costo Final/ha' },
    { key: 'actions', label: 'Acciones' },
];

interface ProductionDataTableProps {
  data: ProductionData[];
  editingRow: ProductionData | null;
  onEditRow: (row: ProductionData) => void;
  onSaveRow: (row: ProductionData) => void;
  onCancelEdit: () => void;
  onDeleteRow: (id: string) => void;
}

export const ProductionDataTable: React.FC<ProductionDataTableProps> = ({ data, editingRow, onEditRow, onSaveRow, onCancelEdit, onDeleteRow }) => {
    return (
        <div className="overflow-x-auto">
            <Table>
                <TableHeader className="bg-gray-100">
                    <TableRow>
                        {HEADERS.map(h => <TableHead key={h.key}>{h.label}</TableHead>)}
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {data.length === 0 ? (
                        <TableRow><TableCell colSpan={HEADERS.length} className="text-center h-24">No hay datos de producción. Puede añadir un registro o importar una planilla.</TableCell></TableRow>
                    ) : (
                        data.map((row) => (
                            editingRow && editingRow.id === row.id ? (
                                <AddEditProductionRow
                                    key={row.id}
                                    row={editingRow}
                                    onSave={onSaveRow}
                                    onCancel={onCancelEdit}
                                    isEditing
                                />
                            ) : (
                                <TableRow key={row.id}>
                                    {HEADERS.map(header => {
                                        const key = header.key as keyof ProductionData;
                                        if (key === 'actions') {
                                            return (
                                                <TableCell key={key} className="sticky right-0 bg-white z-10">
                                                    <AddEditProductionRow
                                                        row={row}
                                                        onEdit={onEditRow}
                                                        onDelete={onDeleteRow}
                                                        onSave={onSaveRow}
                                                        onCancel={onCancelEdit}
                                                    />
                                                </TableCell>
                                            );
                                        }
                                        if (key === 'cost_ha_normal') {
                                            const normalCost = calculateNormalCost(row);
                                            return <TableCell key={key} className="font-semibold text-blue-700">{formatCurrency(normalCost)}</TableCell>;
                                        }
                                        if (key === 'final_cost_ha') {
                                            const finalCost = calculateFinalCost(row);
                                            return <TableCell key={key} className="font-bold text-green-700">{formatCurrency(finalCost)}</TableCell>;
                                        }
                                        const value = row[key];
                                        if (key === 'year') {
                                            return <TableCell key={key}>{value ? parseInt(value as any, 10) : ''}</TableCell>;
                                        }
                                        const isCurrency = key.toLowerCase().includes('cost') || key.toLowerCase().includes('rent');
                                        
                                        return (
                                            <TableCell key={key}>
                                                {isCurrency ? formatCurrency(value as number) : (typeof value === 'number' ? formatNumber(value) : value)}
                                            </TableCell>
                                        );
                                    })}
                                </TableRow>
                            )
                        ))
                    )}
                </TableBody>
            </Table>
        </div>
    );
};