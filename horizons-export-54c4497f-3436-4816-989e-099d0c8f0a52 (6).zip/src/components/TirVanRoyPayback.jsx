import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, Percent, Calendar, TrendingUp, AlertTriangle, BarChart3, CheckCircle } from 'lucide-react';
import { useTirVanRoyPayback } from '@/hooks/useTirVanRoyPayback';
import { useTranslation } from 'react-i18next';
import { useProjectData } from '@/contexts/ProjectDataContext';

const MetricCard = ({ title, value, subtext, colorClass }) => (
  <Card className="text-center">
    <CardHeader className="pb-2">
      <CardTitle className="text-sm font-medium text-gray-600">
        <span className="notranslate" translate="no">{title}</span>
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className={`text-3xl font-bold ${colorClass}`}>{value}</div>
      {subtext && <p className="text-xs text-muted-foreground mt-1">{subtext}</p>}
    </CardContent>
  </Card>
);

const TirVanRoyPayback = () => {
  const { t } = useTranslation(['viability', 'common']);
  const { projectData, agricultureData, ganaderiaData } = useProjectData();
  const { tableData, metrics, error } = useTirVanRoyPayback({ projectData, agricultureData, ganaderiaData });

  const formatCurrency = (value) => {
    if (typeof value !== 'number') return 'USD 0';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
  };
  
  const formatCurrencyWithDecimals = (value) => {
    if (typeof value !== 'number') return 'USD 0.00';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
  };

  const formatPercentage = (value) => {
    if (typeof value !== 'number') return '0.00%';
    return `${(value * 100).toFixed(2)}%`;
  };

  if (error) {
    return (
      <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
        <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-red-800">{t('errorTitle')}</h2>
        <p className="text-gray-600 text-lg mt-2">{error}</p>
      </div>
    );
  }

  if (!metrics || !tableData || tableData.length === 0) {
    return (
      <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
        <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800">{t('insufficientDataTitle')}</h2>
        <p className="text-gray-600 text-lg mt-2">{t('insufficientDataSubtitle')}</p>
        <p className="text-gray-500 mt-1">{t('insufficientDataSuggestion')}</p>
      </div>
    );
  }

  const getFlowStatus = (value) => {
    if (value > 0) return 'text-green-600';
    if (value < 0) return 'text-red-600';
    return 'text-gray-600';
  };

  const isTirViable = typeof metrics.tir === 'number' && typeof metrics.discountRateUsed === 'number' && (metrics.tir * 100) > metrics.discountRateUsed;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="text-center">
        <div className="flex justify-center items-center gap-3">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">{t('title')}</h1>
          <div className="flex items-center bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
              <CheckCircle className="w-4 h-4 mr-2" />
              <span>{t('common:validated')}</span>
          </div>
        </div>
        <p className="text-gray-600 mt-1">{t('subtitle')}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title={t('keyMetrics.npvShort')} value={formatCurrency(metrics.van)} subtext={`${t('keyMetrics.npvSubtext')} (${metrics.discountRateUsed.toFixed(2)}%)`} colorClass={metrics.van > 0 ? 'text-green-600' : 'text-red-600'} />
        <MetricCard title={t('keyMetrics.irrShort')} value={formatPercentage(metrics.tir)} subtext={t('keyMetrics.irrSubtext')} colorClass={isTirViable ? 'text-green-600' : 'text-red-600'} />
        <MetricCard title={t('keyMetrics.roiShort')} value={formatPercentage(metrics.roi)} subtext={t('keyMetrics.roiSubtext')} colorClass="text-blue-600" />
        <MetricCard title={t('keyMetrics.paybackShort')} value={`${metrics.payback} ${t('common:years')}`} subtext={t('keyMetrics.paybackSubtext')} colorClass="text-indigo-600" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="h-5 w-5 mr-2 text-gray-700" />
            {t('cashFlowDetailTitle')}
          </CardTitle>
          <p className="text-sm text-gray-500">{t('cashFlowDetailSubtitle')}</p>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.year')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('fixedInvestment')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('workingCapital')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('capitalRecovery')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('residualValue')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('grossCashFlow')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('taxes')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('netCashFlow')}</th>
                  <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('cumulativeCashFlow')}</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {tableData.map((row) => (
                  <tr key={row.year}>
                    <td className="px-2 py-4 whitespace-nowrap font-medium">{row.year === 0 ? t('financialAnalysis.initial') : row.year}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right ${getFlowStatus(-row.inversionFija)}`}>{formatCurrencyWithDecimals(row.inversionFija)}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right ${getFlowStatus(-row.capitalTrabajo)}`}>{formatCurrencyWithDecimals(row.capitalTrabajo)}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right ${getFlowStatus(row.recuperoCapitalTrabajo)}`}>{formatCurrencyWithDecimals(row.recuperoCapitalTrabajo)}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right ${getFlowStatus(row.valorResidual)}`}>{formatCurrencyWithDecimals(row.valorResidual)}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right ${getFlowStatus(row.flujoCajaBruto)}`}>{formatCurrencyWithDecimals(row.flujoCajaBruto)}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right ${getFlowStatus(row.impuestos)}`}>{formatCurrencyWithDecimals(row.impuestos)}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right font-semibold ${getFlowStatus(row.flujoCajaNeto)}`}>{formatCurrencyWithDecimals(row.flujoCajaNeto)}</td>
                    <td className={`px-2 py-4 whitespace-nowrap text-right font-semibold ${getFlowStatus(row.flujoCajaAcumulado)}`}>{formatCurrencyWithDecimals(row.flujoCajaAcumulado)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TirVanRoyPayback;