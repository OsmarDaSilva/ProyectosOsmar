import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, DollarSign, ArrowRight, Percent, Landmark } from 'lucide-react';
import { motion } from 'framer-motion';

const formatCurrency = (value) => {
  if (typeof value !== 'number' || isNaN(value)) {
    return 'USD 0';
  }
  return new Intl.NumberFormat('es-PY', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const formatPercentage = (value) => {
  if (typeof value !== 'number' || !isFinite(value)) {
    return '0.00%';
  }
  return `${value.toFixed(2)}%`;
};

const MetricCard = ({ title, value, icon: Icon, colorClass, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
  >
    <Card className="bg-white/60 backdrop-blur-sm shadow-lg hover:shadow-xl transition-shadow duration-300 border-l-4" style={{ borderLeftColor: colorClass }}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        <Icon className={`h-5 w-5 ${colorClass ? `text-${colorClass}-500` : 'text-gray-500'}`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-gray-800">{value}</div>
      </CardContent>
    </Card>
  </motion.div>
);

const InitialCalculationCard = ({ label, value }) => (
  <div className="bg-gray-50/50 p-4 rounded-lg text-center shadow-inner hover:bg-white transition-colors">
    <p className="text-sm text-gray-600">{label}</p>
    <p className="text-xl font-bold text-green-700">{value}</p>
  </div>
);

const ComparisonAnalysis = ({ calculations }) => {
  if (!calculations || Object.keys(calculations).length === 0) {
    return null;
  }

  const {
    metrics,
    loanDetails,
    traditional,
    tecnificado
  } = calculations;

  const profitDifference = tecnificado.gananciaNetaAnual - traditional.gananciaNetaAnual;
  const isTechMoreProfitable = profitDifference > 0;

  return (
    <div className="space-y-8">
      <Card className="bg-gradient-to-br from-white to-gray-50 shadow-xl overflow-hidden">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800">Resultados del Cálculo Inicial</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4">
            <InitialCalculationCard label="Valor del Préstamo" value={formatCurrency(loanDetails.valorPrestamo)} />
            <InitialCalculationCard label="Cuota Anual del Préstamo" value={formatCurrency(loanDetails.cuotaAnual)} />
            <InitialCalculationCard label="Total Intereses del Préstamo" value={formatCurrency(loanDetails.totalIntereses)} />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-white to-gray-50 shadow-xl overflow-hidden">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800">Análisis Comparativo de Rentabilidad</CardTitle>
          <p className="text-sm text-gray-500">Modelo Tecnificado vs. Modelo Tradicional</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center text-center">
            <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
              <Card className="bg-orange-50 border-orange-200 h-full">
                <CardHeader><CardTitle className="text-lg text-orange-800">Tradicional</CardTitle></CardHeader>
                <CardContent><p className="text-3xl font-bold text-orange-900">{formatCurrency(traditional.gananciaNetaAnual)}</p><p className="text-sm text-gray-500">Ganancia Neta Anual</p></CardContent>
              </Card>
            </motion.div>
            
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2, duration: 0.5 }}>
              <div className={`p-4 rounded-full mx-auto w-24 h-24 flex items-center justify-center ${isTechMoreProfitable ? 'bg-green-100' : 'bg-red-100'}`}>
                <ArrowRight className={`w-12 h-12 ${isTechMoreProfitable ? 'text-green-600' : 'text-red-600'}`} />
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
              <Card className="bg-teal-50 border-teal-200 h-full">
                <CardHeader><CardTitle className="text-lg text-teal-800">Tecnificado</CardTitle></CardHeader>
                <CardContent><p className="text-3xl font-bold text-teal-900">{formatCurrency(tecnificado.gananciaNetaAnual)}</p><p className="text-sm text-gray-500">Ganancia Neta Anual</p></CardContent>
              </Card>
            </motion.div>
          </div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4, duration: 0.5 }}>
            <Card className={`p-6 rounded-lg text-center ${isTechMoreProfitable ? 'bg-green-50' : 'bg-red-50'}`}>
              <h4 className={`text-lg font-semibold ${isTechMoreProfitable ? 'text-green-800' : 'text-red-800'}`}>Diferencial de Ganancia Anual</h4>
              <p className={`text-4xl font-extrabold mt-2 ${isTechMoreProfitable ? 'text-green-900' : 'text-red-900'}`}>{formatCurrency(profitDifference)}</p>
              <p className="text-sm text-gray-600 mt-1">{isTechMoreProfitable ? 'a favor del modelo tecnificado' : 'a favor del modelo tradicional'}</p>
            </Card>
          </motion.div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-white to-gray-50 shadow-xl overflow-hidden">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800">Indicadores Financieros Clave (Modelo Tecnificado)</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <MetricCard title="TIR (Tasa Interna de Retorno)" value={typeof metrics.tir === 'number' ? formatPercentage(metrics.tir * 100) : metrics.tir} icon={TrendingUp} colorClass="green" delay={0.1} />
          <MetricCard title="VAN (Valor Actual Neto)" value={formatCurrency(metrics.van)} icon={DollarSign} colorClass="blue" delay={0.2} />
          <MetricCard title="ROI (Retorno de Inversión)" value={formatPercentage(metrics.roi * 100)} icon={Percent} colorClass="purple" delay={0.3} />
          <MetricCard title="Payback (Años)" value={metrics.payback} icon={Landmark} colorClass="yellow" delay={0.4} />
        </CardContent>
      </Card>
    </div>
  );
};

export default ComparisonAnalysis;