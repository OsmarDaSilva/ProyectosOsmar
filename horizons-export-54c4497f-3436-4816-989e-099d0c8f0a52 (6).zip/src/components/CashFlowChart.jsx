import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Line,
} from 'recharts';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const formatCurrency = (value) =>
      new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(value);

    const techPayload = payload.find(p => p.dataKey === 'cumulativeTech');

    return (
      <div className="p-2 sm:p-4 bg-white/80 backdrop-blur-sm rounded-lg shadow-lg border border-gray-200">
        <p className="font-bold text-gray-800 text-sm sm:text-base">{label === '0' ? 'Inversión Inicial' : `Año ${label}`}</p>
        {techPayload && <p className="text-xs sm:text-sm text-green-600">{`Acumulado: ${formatCurrency(techPayload.value)}`}</p>}
      </div>
    );
  }

  return null;
};

const CashFlowChart = ({ data }) => {
  const chartData = data.map(item => ({
    ...item,
    name: item.year === 0 ? 'Inicial' : `${item.year}`
  }));

  const yAxisFormatter = (value) => {
    if (Math.abs(value) >= 1e9) {
      return `${(value / 1e9).toFixed(1)}B`;
    }
    if (Math.abs(value) >= 1e6) {
      return `${(value / 1e6).toFixed(1)}M`;
    }
    if (Math.abs(value) >= 1e3) {
      return `${(value / 1e3).toFixed(1)}K`;
    }
    return value;
  };
  
  const gradientOffset = (dataKey) => {
    const dataMax = Math.max(...chartData.map((i) => i[dataKey] || 0));
    const dataMin = Math.min(...chartData.map((i) => i[dataKey] || 0));
  
    if (dataMax <= 0) return 0;
    if (dataMin >= 0) return 1;
  
    return dataMax / (dataMax - dataMin);
  };
  
  const offTech = gradientOffset('cumulativeTech');

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={chartData}
        margin={{
          top: 5,
          right: 5,
          left: 5,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
        <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 12 }} />
        <YAxis tickFormatter={yAxisFormatter} tick={{ fill: '#6b7280', fontSize: 12 }} />
        <Tooltip content={<CustomTooltip />} />
        <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
        <defs>
            <linearGradient id="splitColorTech" x1="0" y1="0" x2="0" y2="1">
                <stop offset={offTech} stopColor="#16a34a" stopOpacity={1} />
                <stop offset={offTech} stopColor="#ef4444" stopOpacity={1} />
            </linearGradient>
        </defs>
        <Line
          type="linear"
          dataKey="cumulativeTech"
          name="Acumulado Tecnificado"
          stroke="url(#splitColorTech)"
          strokeWidth={3}
          dot={{ r: 4 }}
          activeDot={{ r: 8 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default CashFlowChart;