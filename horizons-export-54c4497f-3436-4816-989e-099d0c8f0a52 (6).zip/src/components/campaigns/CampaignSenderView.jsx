import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Filter, Users, Paperclip, Send } from 'lucide-react';

    const CampaignSenderView = ({ currentCampaign, clients, onSend, onBack, isSending }) => {
      const [filters, setFilters] = useState({ country: '', department_province: '', city_locality: '' });
      const [filteredContacts, setFilteredContacts] = useState([]);
      const [locations, setLocations] = useState({ countries: [], departments: [], cities: [] });

      useEffect(() => {
        const countries = [...new Set(clients.map(c => c.country).filter(Boolean))];
        const departments = [...new Set(clients.map(c => c.department_province).filter(Boolean))];
        const cities = [...new Set(clients.map(c => c.city_locality).filter(Boolean))];
        setLocations({ countries, departments, cities });
      }, [clients]);

      useEffect(() => {
        let results = clients.flatMap(client => 
          client.contacts.length > 0 ? client.contacts.map(c => ({...c, clientName: client.name, address: client.address, country: client.country, department_province: client.department_province, city_locality: client.city_locality})) : []
        );

        if (filters.country) {
          results = results.filter(c => c.country === filters.country);
        }
        if (filters.department_province) {
          results = results.filter(c => c.department_province === filters.department_province);
        }
        if (filters.city_locality) {
          results = results.filter(c => c.city_locality === filters.city_locality);
        }
        
        setFilteredContacts(results.filter(c => c.email));
      }, [filters, clients]);

      return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Filter className="h-5 w-5"/> Filtrar Destinatarios</CardTitle>
                    <CardDescription>Seleccione a quién desea enviar esta campaña.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <Select onValueChange={value => setFilters(f => ({...f, country: value, department_province: '', city_locality: ''}))}>
                        <SelectTrigger><SelectValue placeholder="Filtrar por País" /></SelectTrigger>
                        <SelectContent>{locations.countries.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Select onValueChange={value => setFilters(f => ({...f, department_province: value, city_locality: ''}))}>
                        <SelectTrigger><SelectValue placeholder="Filtrar por Departamento/Provincia" /></SelectTrigger>
                        <SelectContent>{locations.departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                    </Select>
                     <Select onValueChange={value => setFilters(f => ({...f, city_locality: value}))}>
                        <SelectTrigger><SelectValue placeholder="Filtrar por Localidad/Ciudad" /></SelectTrigger>
                        <SelectContent>{locations.cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Button variant="outline" onClick={() => setFilters({ country: '', department_province: '', city_locality: '' })}>Limpiar Filtros</Button>
                </CardContent>
            </Card>
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Users className="h-5 w-5"/> Resumen de Envío</CardTitle>
                    <CardDescription>Campaña: <strong>{currentCampaign.subject}</strong></CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {currentCampaign.attachment_name && (
                        <p className="text-sm flex items-center gap-2"><Paperclip className="h-4 w-4 text-gray-500" /> Archivo adjunto: <strong>{currentCampaign.attachment_name}</strong></p>
                    )}
                    <p>Se enviará a <strong>{filteredContacts.length}</strong> contacto(s).</p>
                    <div className="max-h-48 overflow-y-auto border p-2 rounded-md">
                        <ul className="text-sm">
                            {filteredContacts.map(c => <li key={c.id}>{c.name} ({c.email})</li>)}
                        </ul>
                    </div>
                     <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={onBack}>Volver al Editor</Button>
                        <Button onClick={() => onSend(filteredContacts)} disabled={isSending}>
                            {isSending ? 'Enviando...' : <><Send className="mr-2 h-4 w-4"/> Enviar Campaña</>}
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
      );
    };

    export default CampaignSenderView;