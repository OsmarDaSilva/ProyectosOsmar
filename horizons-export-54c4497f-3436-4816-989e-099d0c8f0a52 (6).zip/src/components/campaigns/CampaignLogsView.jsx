import React from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
    import { Badge } from "@/components/ui/badge";
    import { format } from 'date-fns';

    const CampaignLogsView = ({ currentCampaign, campaignLogs, loading }) => {
      return (
        <Card>
          <CardHeader>
            <CardTitle>Logs de la Campaña</CardTitle>
            <CardDescription>Asunto: <strong>{currentCampaign?.subject}</strong></CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? <p>Cargando logs...</p> : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fecha</TableHead>
                    <TableHead>Destinatario</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Detalles</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {campaignLogs.length === 0 ? (
                    <TableRow><TableCell colSpan="4" className="text-center">No hay logs para esta campaña.</TableCell></TableRow>
                  ) : (
                    campaignLogs.map(log => (
                      <TableRow key={log.id}>
                        <TableCell>{format(new Date(log.sent_at), 'dd/MM/yyyy HH:mm')}</TableCell>
                        <TableCell>{log.contacts?.name || 'N/A'} ({log.contacts?.email || 'N/A'})</TableCell>
                        <TableCell>
                          <Badge variant={log.status === 'sent' ? 'default' : 'destructive'}>
                            {log.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          {log.error_message ? (
                            <p className="text-red-600">{log.error_message}</p>
                          ) : (
                            <details>
                              <summary>Ver respuesta</summary>
                              <pre className="mt-2 bg-gray-100 p-2 rounded text-xs overflow-auto">
                                {JSON.stringify(log.response_payload, null, 2)}
                              </pre>
                            </details>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      );
    };

    export default CampaignLogsView;