import React, { useState, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Send, UploadCloud, Loader, Paperclip, X } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

const WhatsAppCampaignEditorView = ({ currentCampaign, onSave, onCancel, user }) => {
  const [campaign, setCampaign] = useState(currentCampaign);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);
  const { toast } = useToast();

  const handleMediaUpload = async (event) => {
    const file = event.target.files[0];
    if (!file || !user) return;

    if (!file.type.startsWith('image/')) {
        toast({ variant: "destructive", title: "Archivo no válido", description: "Por ahora, solo se admiten imágenes para las plantillas de WhatsApp." });
        return;
    }

    setIsUploading(true);
    const fileName = `whatsapp_media/${user.id}/${uuidv4()}-${file.name}`;

    try {
        const { error: uploadError } = await supabase.storage
            .from('campaign_attachments')
            .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
            .from('campaign_attachments')
            .getPublicUrl(fileName);

        setCampaign(p => ({ ...p, media_url: urlData.publicUrl, media_type: 'image' }));
        toast({ title: "Imagen subida", description: file.name });
    } catch (error) {
        toast({ variant: "destructive", title: "Error al subir imagen", description: error.message });
    } finally {
        setIsUploading(false);
        if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleRemoveMedia = () => {
    setCampaign(p => ({ ...p, media_url: null, media_type: 'none' }));
    toast({ title: "Imagen eliminada" });
  };

  const handleSave = () => {
    if (!campaign?.template_name?.trim()) {
      toast({ variant: "destructive", title: "El nombre de la plantilla es obligatorio." });
      return;
    }
    if (!campaign?.template_body?.trim()) {
      toast({ variant: "destructive", title: "El cuerpo del mensaje es obligatorio." });
      return;
    }
    onSave(campaign);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{campaign?.id ? 'Editar Plantilla de WhatsApp' : 'Nueva Plantilla de WhatsApp'}</CardTitle>
        <CardDescription>
          Cree su plantilla de mensaje. Recuerde que debe ser aprobada por Meta antes de poder usarla.
          {' Use `{{1}}` para la variable del nombre del contacto.'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label htmlFor="template_name">Nombre de la Plantilla</Label>
          <Input 
            id="template_name"
            placeholder="Ej: bienvenida_clientes_2024" 
            value={campaign?.template_name || ''}
            onChange={(e) => setCampaign(p => ({ ...p, template_name: e.target.value.toLowerCase().replace(/\s/g, '_') }))}
          />
           <p className="text-xs text-muted-foreground mt-1">Solo minúsculas y guiones bajos. Este nombre debe coincidir exactamente con el aprobado en Meta.</p>
        </div>
        
        <div>
            <Label htmlFor="template_body">Cuerpo del Mensaje</Label>
            <Textarea 
                id="template_body"
                placeholder="Hola {{1}}, te damos la bienvenida a AGROinvest..." 
                rows={12}
                value={campaign?.template_body || ''}
                onChange={(e) => setCampaign(p => ({ ...p, template_body: e.target.value }))}
            />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <Label htmlFor="cta_button_text">Texto del Botón (Opcional)</Label>
                <Input 
                    id="cta_button_text"
                    placeholder="Hablar con un asesor" 
                    value={campaign?.cta_button_text || ''}
                    onChange={(e) => setCampaign(p => ({...p, cta_button_text: e.target.value}))}
                />
            </div>
            <div>
                <Label htmlFor="cta_button_url">URL del Botón (Opcional)</Label>
                <Input 
                    id="cta_button_url"
                    type="url"
                    placeholder="https://irrigar.com.py/contacto" 
                    value={campaign?.cta_button_url || ''}
                    onChange={(e) => setCampaign(p => ({...p, cta_button_url: e.target.value}))}
                />
            </div>
        </div>
        
        <div>
            <Label>Imagen de Cabecera (Opcional)</Label>
            <input type="file" ref={fileInputRef} onChange={handleMediaUpload} className="hidden" accept="image/*" />
            {!campaign?.media_url && (
                <Button variant="outline" onClick={() => fileInputRef.current.click()} disabled={isUploading}>
                    {isUploading ? <><Loader className="mr-2 h-4 w-4 animate-spin"/> Subiendo...</> : <><UploadCloud className="mr-2 h-4 w-4" />Subir Imagen</>}
                </Button>
            )}

            {campaign?.media_url && (
                <div className="flex items-center justify-between p-2 bg-gray-100 rounded-md">
                    <div className="flex items-center gap-2">
                        <Paperclip className="h-4 w-4"/>
                        <img src={campaign.media_url} alt="preview" className="h-10 w-10 object-cover rounded-md"/>
                        <span className="font-medium text-sm">Imagen adjunta</span>
                    </div>
                    <Button variant="ghost" size="icon" onClick={handleRemoveMedia}>
                        <X className="h-4 w-4"/>
                    </Button>
                </div>
            )}
             <p className="text-xs text-muted-foreground mt-1">Sugerencia: Pivote funcionando o pastura irrigada.</p>
        </div>

        <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={onCancel}>Cancelar</Button>
            <Button onClick={handleSave}>Guardar Plantilla <Send className="ml-2 h-4 w-4"/></Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default WhatsAppCampaignEditorView;