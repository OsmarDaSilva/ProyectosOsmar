import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import LoadingScreen from '@/components/LoadingScreen';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import CampaignListView from '@/components/campaigns/CampaignListView';
import CampaignEditorView from '@/components/campaigns/CampaignEditorView';
import CampaignSenderView from '@/components/campaigns/CampaignSenderView';
import CampaignLogsView from '@/components/campaigns/CampaignLogsView';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

const EmailCampaigns = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [campaigns, setCampaigns] = useState([]);
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('list');
  const [currentCampaign, setCurrentCampaign] = useState(null);
  const [campaignLogs, setCampaignLogs] = useState([]);
  const [isSending, setIsSending] = useState(false);

  const fetchCampaignsAndClients = useCallback(async () => {
    setLoading(true);
    try {
      const [campaignsRes, clientsRes] = await Promise.all([
        supabase.from('campaigns').select('*').order('created_at', { ascending: false }),
        supabase.from('clients').select('*, contacts(*)')
      ]);

      if (campaignsRes.error) throw campaignsRes.error;
      if (clientsRes.error) throw clientsRes.error;

      setCampaigns(campaignsRes.data);
      setClients(clientsRes.data);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al cargar datos de email', description: error.message });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchCampaignsAndClients();
  }, [fetchCampaignsAndClients]);

  const handleSaveCampaign = async (campaignData) => {
    const { data, error } = await supabase.from('campaigns').upsert(campaignData).select().single();

    if (error) {
      toast({ variant: 'destructive', title: 'Error al guardar campaña', description: error.message });
    } else {
      toast({ title: 'Campaña guardada' });
      setCurrentCampaign(data);
      setView('sender');
      fetchCampaignsAndClients();
    }
  };

  const handleDeleteCampaign = async (campaignId) => {
    const { error } = await supabase.from('campaigns').delete().eq('id', campaignId);
    if (error) {
      toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
    } else {
      toast({ title: 'Campaña eliminada' });
      fetchCampaignsAndClients();
    }
  };

  const handleSendCampaign = async (contacts) => {
    if (contacts.length === 0) {
      toast({ variant: 'destructive', title: 'No hay destinatarios', description: 'Seleccione un grupo de clientes para enviar la campaña.' });
      return;
    }
    setIsSending(true);
    try {
      const { error } = await supabase.functions.invoke('send-campaign-final', {
        body: {
          campaignId: currentCampaign.id,
          contacts: contacts.map(c => ({ id: c.id, email: c.email, name: c.name, clientId: c.client_id }))
        }
      });

      if (error) {
        let errorMessage = error.message;
        try { const errorBody = await error.context.json(); errorMessage = errorBody.error || errorMessage; } catch (e) { /* ignore */ }
        throw new Error(errorMessage);
      }

      await supabase.from('campaigns').update({ status: 'sent' }).eq('id', currentCampaign.id);
      toast({ title: 'Proceso de envío iniciado', description: `La campaña se está enviando a ${contacts.length} contactos.` });
      setView('list');
      fetchCampaignsAndClients();

    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al enviar campaña', description: error.message });
    } finally {
      setIsSending(false);
    }
  };

  const handleViewLogs = async (campaignId) => {
    setLoading(true);
    setView('logs');
    try {
      const { data, error } = await supabase.from('campaign_logs').select('*, contacts(name, email)').eq('campaign_id', campaignId).order('sent_at', { ascending: false });
      if (error) throw error;
      const campaign = campaigns.find(c => c.id === campaignId);
      setCurrentCampaign(campaign);
      setCampaignLogs(data);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al cargar logs', description: error.message });
      setView('list');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateNew = () => {
    setCurrentCampaign({ subject: '', body: '', status: 'draft', attachment_url: null, attachment_name: null, user_id: user?.id });
    setView('editor');
  };

  const handleEdit = (campaign) => {
    setCurrentCampaign(campaign);
    setView('editor');
  };
  
  const renderContent = () => {
    if (loading && view !== 'logs') return <LoadingScreen message="Cargando campañas de Email..." />;

    switch (view) {
      case 'editor':
        return <CampaignEditorView currentCampaign={currentCampaign} onSave={handleSaveCampaign} onCancel={() => { setView('list'); setCurrentCampaign(null); }} user={user} />;
      case 'sender':
        return <CampaignSenderView currentCampaign={currentCampaign} clients={clients} onSend={handleSendCampaign} onBack={() => setView('editor')} isSending={isSending} />;
      case 'logs':
        return <CampaignLogsView currentCampaign={currentCampaign} campaignLogs={campaignLogs} loading={loading} />;
      case 'list':
      default:
        return (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Campañas de Email</CardTitle>
                <CardDescription>Cree y gestione sus campañas de email marketing.</CardDescription>
              </div>
              <Button onClick={handleCreateNew}><Plus className="mr-2 h-4 w-4" /> Nueva Campaña de Email</Button>
            </CardHeader>
            <CardContent>
                <CampaignListView campaigns={campaigns} loading={loading} onViewLogs={handleViewLogs} onEdit={handleEdit} onDelete={handleDeleteCampaign} />
            </CardContent>
          </Card>
        );
    }
  };

  return <div className="mt-4">{renderContent()}</div>;
};

export default EmailCampaigns;