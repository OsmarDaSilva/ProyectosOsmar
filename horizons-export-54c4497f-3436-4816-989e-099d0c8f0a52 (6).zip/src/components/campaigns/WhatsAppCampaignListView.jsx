import React from 'react';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
    import { Edit, Trash2, FileText, Send, Image as ImageIcon, MessageSquare } from 'lucide-react';
    import { Badge } from "@/components/ui/badge";
    import { useToast } from '@/components/ui/use-toast';

    const WhatsAppCampaignListView = ({ campaigns, loading, onViewLogs, onEdit, onDelete }) => {
      const { toast } = useToast();
      
      const getStatusBadgeVariant = (status) => {
        switch (status) {
          case 'approved': return 'success';
          case 'pending_approval': return 'secondary';
          case 'rejected': return 'destructive';
          case 'draft':
          default:
            return 'outline';
        }
      };
      
      const handleSend = () => {
        toast({
          title: "Funcionalidad en desarrollo",
          description: "La integración para el envío de campañas de WhatsApp estará disponible pronto. Primero, cree y guarde sus plantillas.",
        });
      };

      return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre de Plantilla</TableHead>
              <TableHead>Contenido</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan="4" className="text-center">Cargando...</TableCell></TableRow>
            ) : campaigns.length === 0 ? (
              <TableRow><TableCell colSpan="4" className="text-center h-24">No ha creado ninguna plantilla de WhatsApp todavía.</TableCell></TableRow>
            ) : (
              campaigns.map(c => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.template_name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4 text-gray-500 flex-shrink-0" />
                        <span className="truncate w-64" title={c.template_body}>{c.template_body}</span>
                        {c.media_url && <ImageIcon className="h-4 w-4 text-blue-500 flex-shrink-0" />}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(c.status)}>{c.status.replace('_', ' ').toUpperCase()}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex space-x-2 justify-end">
                      <Button variant="outline" size="icon" onClick={handleSend} title="Enviar Campaña">
                        <Send className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" onClick={() => onViewLogs(c.id)} title="Ver Logs">
                        <FileText className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" onClick={() => onEdit(c)} title="Editar">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="destructive" size="icon" onClick={() => onDelete(c.id)} title="Eliminar">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      );
    };

    export default WhatsAppCampaignListView;