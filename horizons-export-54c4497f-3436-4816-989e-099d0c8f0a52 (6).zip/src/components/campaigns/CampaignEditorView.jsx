import React, { useState, useRef } from 'react';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Send, UploadCloud, Loader, Paperclip, X } from 'lucide-react';
    import { v4 as uuidv4 } from 'uuid';

    const CampaignEditorView = ({ currentCampaign, onSave, onCancel, user }) => {
      const [campaign, setCampaign] = useState(currentCampaign);
      const [isUploading, setIsUploading] = useState(false);
      const fileInputRef = useRef(null);
      const { toast } = useToast();

      const handleFileUpload = async (event) => {
        const file = event.target.files[0];
        if (!file || !user) return;

        setIsUploading(true);
        const fileName = `${user.id}/${uuidv4()}-${file.name}`;

        try {
            const { error: uploadError } = await supabase.storage
                .from('campaign_attachments')
                .upload(fileName, file);

            if (uploadError) throw uploadError;

            const { data: urlData } = supabase.storage
                .from('campaign_attachments')
                .getPublicUrl(fileName);

            setCampaign(p => ({...p, attachment_url: urlData.publicUrl, attachment_name: file.name }));
            toast({ title: "Archivo subido", description: file.name });
        } catch (error) {
            toast({ variant: "destructive", title: "Error al subir archivo", description: error.message });
        } finally {
            setIsUploading(false);
            if(fileInputRef.current) fileInputRef.current.value = "";
        }
      };
      
      const handleRemoveAttachment = () => {
        setCampaign(p => ({...p, attachment_url: null, attachment_name: null }));
        toast({ title: "Archivo adjunto eliminado" });
      };

      const handleSave = () => {
        if (!campaign?.subject?.trim()) {
          toast({ variant: "destructive", title: "El asunto es obligatorio." });
          return;
        }
        if (!campaign?.body?.trim()) {
          toast({ variant: "destructive", title: "El cuerpo del email es obligatorio." });
          return;
        }
        onSave(campaign);
      };

      return (
        <Card>
          <CardHeader>
            <CardTitle>{campaign?.id ? 'Editar Campaña' : 'Nueva Campaña'}</CardTitle>
            <CardDescription>Cree el contenido de su email y adjunte archivos si es necesario.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input 
              placeholder="Asunto del Email" 
              value={campaign?.subject || ''}
              onChange={(e) => setCampaign(p => ({...p, subject: e.target.value}))}
            />
            <Textarea 
              placeholder="Cuerpo del email... Puede usar HTML simple para dar formato. El enlace de descarga del adjunto se añadirá automáticamente al final." 
              rows={15}
              value={campaign?.body || ''}
              onChange={(e) => setCampaign(p => ({...p, body: e.target.value}))}
            />
            
            <div>
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
                {!campaign?.attachment_name && (
                    <Button variant="outline" onClick={() => fileInputRef.current.click()} disabled={isUploading}>
                        {isUploading ? <><Loader className="mr-2 h-4 w-4 animate-spin"/> Subiendo...</> : <><UploadCloud className="mr-2 h-4 w-4" />Subir Archivo Adjunto</>}
                    </Button>
                )}

                {campaign?.attachment_name && (
                    <div className="flex items-center justify-between p-2 bg-gray-100 rounded-md text-sm">
                        <div className="flex items-center gap-2">
                            <Paperclip className="h-4 w-4"/>
                            <span className="font-medium">{campaign.attachment_name}</span>
                        </div>
                        <Button variant="ghost" size="icon" onClick={handleRemoveAttachment}>
                            <X className="h-4 w-4"/>
                        </Button>
                    </div>
                )}
            </div>

            <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={onCancel}>Cancelar</Button>
                <Button onClick={handleSave}>Guardar y Seleccionar Destinatarios <Send className="ml-2 h-4 w-4"/></Button>
            </div>
          </CardContent>
        </Card>
      );
    };

    export default CampaignEditorView;