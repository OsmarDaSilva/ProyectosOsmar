import React from 'react';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Edit, Trash2, FileText, Paperclip } from 'lucide-react';

    const CampaignListView = ({ campaigns, loading, onViewLogs, onEdit, onDelete }) => {
      return (
        <Card>
          <CardHeader>
            <CardTitle>Mis Campañas</CardTitle>
            <CardDescription>Cree y gestione sus campañas de email marketing.</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? <p>Cargando...</p> : (
              <div className="space-y-4">
                {campaigns.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">No ha creado ninguna campaña todavía.</p>
                ) : (
                  campaigns.map(c => (
                    <div key={c.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 border rounded-lg gap-4">
                      <div className="flex items-center gap-2">
                        {c.attachment_name && <Paperclip className="h-4 w-4 text-gray-500 flex-shrink-0" />}
                        <div>
                          <p className="font-bold">{c.subject}</p>
                          <p className="text-sm text-gray-500">Estado: <span className="font-semibold">{c.status}</span></p>
                        </div>
                      </div>
                      <div className="flex space-x-2 flex-shrink-0">
                        <Button variant="outline" size="icon" onClick={() => onViewLogs(c.id)} title="Ver Logs">
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="icon" onClick={() => onEdit(c)} title="Editar">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="destructive" size="icon" onClick={() => onDelete(c.id)} title="Eliminar">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </CardContent>
        </Card>
      );
    };

    export default CampaignListView;