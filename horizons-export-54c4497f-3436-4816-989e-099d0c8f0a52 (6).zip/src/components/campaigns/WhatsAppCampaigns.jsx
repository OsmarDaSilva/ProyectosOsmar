import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import LoadingScreen from '@/components/LoadingScreen';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import WhatsAppCampaignListView from '@/components/campaigns/WhatsAppCampaignListView';
import WhatsAppCampaignEditorView from '@/components/campaigns/WhatsAppCampaignEditorView';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

const WhatsAppCampaigns = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('list'); // 'list', 'editor', 'sender', 'logs'
  const [currentCampaign, setCurrentCampaign] = useState(null);

  const fetchWhatsAppCampaigns = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('whatsapp_campaigns').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      setCampaigns(data);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al cargar campañas de WhatsApp', description: error.message });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchWhatsAppCampaigns();
  }, [fetchWhatsAppCampaigns]);
  
  const handleSaveCampaign = async (campaignData) => {
    const { data, error } = await supabase.from('whatsapp_campaigns').upsert(campaignData).select().single();
    if (error) {
      toast({ variant: 'destructive', title: 'Error al guardar plantilla', description: error.message });
    } else {
      toast({ title: 'Plantilla guardada', description: 'La plantilla se ha guardado y está lista para revisión y envío.' });
      setView('list');
      fetchWhatsAppCampaigns();
    }
  };

  const handleDeleteCampaign = async (campaignId) => {
    const { error } = await supabase.from('whatsapp_campaigns').delete().eq('id', campaignId);
    if (error) {
      toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
    } else {
      toast({ title: 'Plantilla eliminada' });
      fetchWhatsAppCampaigns();
    }
  };

  const handleCreateNew = () => {
    setCurrentCampaign({ 
        template_name: 'agroinvest_promocion_riego_2025',
        template_body: '¡Hola {{1}}! 🌱\n\nTe saluda el equipo de AGROinvest by Irrigar S.A. 🚀\n\nQueremos ayudarte a **aumentar tu rentabilidad agrícola y ganadera** con soluciones tecnificadas de riego, pasturas y energía.\n\n✅ Simulaciones completas online\n✅ Soporte técnico especializado\n✅ Financiamiento a medida\n\n🌾 Transformá tu campo con inteligencia y tecnología.\n\nEscribinos para más detalles o simulaciones personalizadas 👇',
        cta_button_text: 'Hablar con un asesor',
        cta_button_url: '',
        media_url: '',
        media_type: 'none',
        status: 'draft', 
        user_id: user?.id 
    });
    setView('editor');
  };

  const handleEdit = (campaign) => {
    setCurrentCampaign(campaign);
    setView('editor');
  };
  
  const handleViewLogs = (campaignId) => {
    toast({ title: 'Próximamente', description: 'La vista de logs de campañas de WhatsApp estará disponible pronto.'});
  };

  const renderContent = () => {
    if (loading) return <LoadingScreen message="Cargando plantillas de WhatsApp..." />;

    switch (view) {
      case 'editor':
        return <WhatsAppCampaignEditorView 
            currentCampaign={currentCampaign} 
            onSave={handleSaveCampaign} 
            onCancel={() => { setView('list'); setCurrentCampaign(null); }}
            user={user}
        />;
      // TODO: Add sender and logs views
      case 'list':
      default:
        return (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Plantillas de WhatsApp</CardTitle>
                <CardDescription>Cree y gestione sus plantillas para campañas de WhatsApp. Las plantillas deben ser aprobadas por Meta.</CardDescription>
              </div>
              <Button onClick={handleCreateNew}><Plus className="mr-2 h-4 w-4" /> Nueva Plantilla</Button>
            </CardHeader>
            <CardContent>
                <WhatsAppCampaignListView 
                    campaigns={campaigns} 
                    loading={loading} 
                    onViewLogs={handleViewLogs} 
                    onEdit={handleEdit} 
                    onDelete={handleDeleteCampaign}
                />
            </CardContent>
          </Card>
        );
    }
  };

  return <div className="mt-4">{renderContent()}</div>;
};

export default WhatsAppCampaigns;