import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { AddEditProductionRow } from '@/components/production-database/AddEditProductionRow';

const getNumericValue = (value) => parseFloat(String(value).replace(',', '.')) || 0;

const calculateNormalCost = (row) => {
    return getNumericValue(row.input_cost_ha) + getNumericValue(row.machinery_cost_ha) + getNumericValue(row.freight_cost_ha);
};

const calculateFinalCost = (row) => {
    const normalCost = calculateNormalCost(row);
    const otherCosts = getNumericValue(row.land_rent_ha) + getNumericValue(row.electrical_energy_cost_ha) + getNumericValue(row.maintenance_repair_cost_ha);
    return normalCost + otherCosts;
};

const formatCurrency = (value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);
const formatNumber = (value) => new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);

const HEADERS = [
    { key: 'country', label: 'País' },
    { key: 'department_province', label: 'Dpto/Provincia' },
    { key: 'city_locality', label: 'Ciudad/Localidad' },
    { key: 'year', label: 'Año' },
    { key: 'Cultura', label: 'Cultura' },
    { key: 'production_purpose', label: 'Finalidad' },
    { key: 'Época Siembra', label: 'Época Siembra' },
    { key: 'forma_cultivo', label: 'Forma Cultivo' },
    { key: 'Prod. (ton/ha)', label: 'Prod. (ton/ha)' },
    { key: 'input_cost_ha', label: 'Costo Insumos/ha' },
    { key: 'machinery_cost_ha', label: 'Costo Maquinas/ha' },
    { key: 'freight_cost_ha', label: 'Costo Fletes/ha' },
    { key: 'costo_por_ha_normal', label: 'Costo por ha/normal' },
    { key: 'land_rent_ha', label: 'Alquiler Tierra/ha' },
    { key: 'electrical_energy_cost_ha', label: 'Energía Eléctrica/ha' },
    { key: 'maintenance_repair_cost_ha', label: 'Manutención/ha' },
    { key: 'costo_final_ha', label: 'Costo Final/ha' },
    { key: 'actions', label: 'Acciones' },
];

export const ProductionDataTable = ({ data, editingRow, onEditRow, onSaveRow, onCancelEdit, onDeleteRow }) => {
    return (
        <div className="overflow-x-auto">
            <Table>
                <TableHeader className="bg-gray-100 sticky top-0 z-20">
                    <TableRow>
                        {HEADERS.map(h => <TableHead key={h.key} className="whitespace-nowrap">{h.label}</TableHead>)}
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {data.length === 0 ? (
                        <TableRow><TableCell colSpan={HEADERS.length} className="text-center h-24">No hay datos de producción. Puede añadir un registro o importar una planilla.</TableCell></TableRow>
                    ) : (
                        data.map((row) => (
                            editingRow && editingRow.id === row.id ? (
                                <AddEditProductionRow
                                    key={row.id}
                                    row={editingRow}
                                    onSave={onSaveRow}
                                    onCancel={onCancelEdit}
                                    isEditing
                                />
                            ) : (
                                <TableRow key={row.id}>
                                    {HEADERS.map(header => {
                                        if (header.key === 'actions') {
                                            return (
                                                <TableCell key={header.key} className="sticky right-0 bg-white z-10">
                                                    <AddEditProductionRow
                                                        row={row}
                                                        onEdit={onEditRow}
                                                        onDelete={onDeleteRow}
                                                    />
                                                </TableCell>
                                            );
                                        }
                                        if (header.key === 'costo_por_ha_normal') {
                                            return <TableCell key={header.key} className="font-semibold text-blue-700">{formatCurrency(row.costo_por_ha_normal || calculateNormalCost(row))}</TableCell>;
                                        }
                                        if (header.key === 'costo_final_ha') {
                                            return <TableCell key={header.key} className="font-bold text-green-700">{formatCurrency(row.costo_final_ha || calculateFinalCost(row))}</TableCell>;
                                        }
                                        const value = row[header.key];
                                        if (header.key === 'year') {
                                            return <TableCell key={header.key}>{value ? parseInt(value, 10) : ''}</TableCell>;
                                        }
                                        const isCurrency = header.key.toLowerCase().includes('cost') || header.key.toLowerCase().includes('rent') || header.key.toLowerCase().includes('alquiler');
                                        
                                        return (
                                            <TableCell key={header.key}>
                                                {isCurrency ? formatCurrency(value) : (typeof value === 'number' ? formatNumber(value) : value)}
                                            </TableCell>
                                        );
                                    })}
                                </TableRow>
                            )
                        ))
                    )}
                </TableBody>
            </Table>
        </div>
    );
};