import React, { useRef } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import * as XLSX from 'xlsx';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, Download, FileText, List, RefreshCw, XCircle as CircleX, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useImportJobs, useCreateImportJob } from '@/hooks/useImportJobs';

const statusMapping = {
  queued: { text: "En Cola", variant: "default" },
  processing: { text: "Procesando", variant: "secondary" },
  completed: { text: "Completado", variant: "success" },
  completed_with_errors: { text: "Con Errores", variant: "destructive" },
  failed: { text: "Fallido", variant: "destructive" },
};

const ImportHistory = ({ jobs, onRefresh, onDownloadErrors, onCancelJob, onResumeJob, isResuming, isCancelling }) => (
  <Card className="mt-6">
    <CardHeader className="flex flex-row items-center justify-between">
      <CardTitle className="flex items-center gap-2"><List /> Historial Reciente</CardTitle>
      <Button variant="ghost" size="sm" onClick={onRefresh}><RefreshCw className="h-4 w-4" /></Button>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        {(jobs?.length ?? 0) === 0 ? <p className="text-sm text-muted-foreground">No hay importaciones recientes.</p> :
          jobs?.map(job => {
            const { text, variant } = statusMapping[job.status] || { text: 'Desconocido', variant: 'secondary' };
            const progress = job.total_rows > 0 ? Math.round(((job.processed_rows || 0) / job.total_rows) * 100) : (job.status.startsWith('completed') || job.status === 'failed' ? 100 : 0);
            return (
              <div key={job.id} className="p-3 border rounded-lg bg-background">
                <div className="flex justify-between items-start flex-wrap gap-2">
                  <div className="flex-1 min-w-[200px]">
                    <p className="font-semibold text-sm truncate" title={job.summary?.fileName || job.file_path?.split('/').pop()}>
                      {job.summary?.fileName || job.file_path?.split('/').pop() || 'Trabajo sin archivo'}
                    </p>
                    <div className="flex items-center gap-2">
                      <Badge variant={variant}>{text}</Badge>
                      <p className="text-xs text-muted-foreground">{new Date(job.created_at).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {job.status === 'failed' && <Button size="sm" variant="outline" onClick={() => onResumeJob(job.id)} disabled={isResuming}>{isResuming ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />} Reanudar</Button>}
                    {['queued', 'processing'].includes(job.status) && <Button size="sm" variant="destructive" onClick={() => onCancelJob(job.id)} disabled={isCancelling}>{isCancelling ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CircleX className="mr-2 h-4 w-4" />} Cancelar</Button>}
                    {job.status === 'completed_with_errors' && <Button size="sm" variant="outline" onClick={() => onDownloadErrors(job)}><Download className="mr-2 h-4 w-4" /> Errores</Button>}
                  </div>
                </div>
                {job.status === 'processing' && job.total_rows > 0 && (
                  <div className="mt-2">
                    <Progress value={progress} className="w-full" />
                    <p className="text-xs text-muted-foreground text-right mt-1">{job.processed_rows || 0} / {job.total_rows} filas</p>
                  </div>
                )}
                {job.status === 'failed' && job.error_details?.errors?.[0]?.error && (
                  <div className="text-xs mt-2 border-t pt-2"><p className="text-red-600"><span className="font-bold">Error:</span> {job.error_details.errors[0].error}</p></div>
                )}
                {job.status?.startsWith('completed') && job.summary && (
                  <div className="text-xs mt-2 border-t pt-2 grid grid-cols-3 gap-2">
                    <p>Total: <span className="font-bold">{job.summary.total}</span></p>
                    <p className="text-green-600">Éxito: <span className="font-bold">{job.summary.success}</span></p>
                    <p className="text-red-600">Fallos: <span className="font-bold">{job.summary.failed}</span></p>
                  </div>
                )}
              </div>
            );
          })}
      </div>
    </CardContent>
  </Card>
);

const ImportTabContent = () => {
  const fileInputRef = useRef(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const createImportJob = useCreateImportJob();
  const { jobs, refetch: refetchJobs, cancelJob, resumeJob, isResuming, isCancelling } = useImportJobs(user?.id, 'production_imports');

  const handleFileImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    createImportJob.mutate({ file, user, jobType: 'production_imports', metadata: { fileName: file.name } }, {
      onSuccess: () => {
        toast({ title: 'Importación iniciada', description: 'Tu archivo se está procesando. Verás el progreso en la sección de historial.' });
        setTimeout(() => refetchJobs(), 1000);
      },
      onError: (error) => toast({ variant: 'destructive', title: 'Error de Importación', description: `No se pudo iniciar: ${error.message}` }),
      onSettled: () => { if (fileInputRef.current) fileInputRef.current.value = null; }
    });
  };

  const downloadTemplate = () => {
    const headers = ["País", "Dpto/Provincia", "Ciudad/Localidad", "Año", "Cultura", "Finalidad", "Época Siembra", "Forma Cultivo", "Prod. (ton/ha)", "Costo Insumos/ha", "Costo Maquinas/ha", "Costo Fletes/ha", "Costo por ha/normal", "Alquiler Tierra/ha", "Energía Eléctrica/ha", "Manutención/ha", "Costo Final/ha"];
    const sampleData = [{'País': 'Paraguay', 'Dpto/Provincia': 'Alto Paraná', 'Ciudad/Localidad': 'Santa Rita', 'Año': 2024, 'Cultura': 'Soja', 'Finalidad': 'Grano', 'Época Siembra': 'Primavera/Verano', 'Forma Cultivo': 'Siembra Directa', 'Prod. (ton/ha)': '3,5', 'Costo Insumos/ha': 450, 'Costo Maquinas/ha': 150, 'Costo Fletes/ha': 60, 'Costo por ha/normal': 660, 'Alquiler Tierra/ha': 350, 'Energía Eléctrica/ha': 15, 'Manutención/ha': 25, 'Costo Final/ha': 1050 }];
    const ws = XLSX.utils.json_to_sheet(sampleData, { header: headers, skipHeader: true });
    XLSX.utils.sheet_add_aoa(ws, [headers], { origin: "A1" });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Produccion");
    XLSX.writeFile(wb, "plantilla_produccion_agricola.xlsx");
  };

  const downloadErrors = (job) => {
    if (!job.error_details?.errors?.length) {
      toast({ title: 'Info', description: 'No hay errores para descargar.' });
      return;
    }
    const errorData = job.error_details.errors.map(e => ({ Fila: e.row, Error: e.error, Datos: JSON.stringify(e.data) }));
    const ws = XLSX.utils.json_to_sheet(errorData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Errores");
    XLSX.writeFile(wb, `errores_produccion_${job.file_path.split('/').pop().split('.')[0]}.xlsx`);
  };

  const handleResumeJob = (jobId) => resumeJob({ jobId, userId: user.id, jobType: 'production_imports' });
  const handleCancelJob = (jobId) => cancelJob(jobId);

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><FileText /> Instrucciones y Plantilla</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm text-muted-foreground space-y-2">
            <p>1. Descarga la plantilla para asegurar el formato correcto de las columnas.</p>
            <p>2. Rellena la plantilla con tus datos. No es necesario completar todas las columnas, pero 'Cultura' es obligatoria.</p>
            <p>3. Sube el archivo. El sistema **reemplazará todos los datos existentes** con el contenido del archivo.</p>
          </div>
          <div className="flex gap-4">
            <Button variant="outline" onClick={downloadTemplate}><Download className="mr-2 h-4 w-4" /> Plantilla</Button>
            <Button onClick={() => fileInputRef.current.click()}><Upload className="mr-2 h-4 w-4" />Importar</Button>
            <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls, .csv" onChange={handleFileImport} />
          </div>
        </CardContent>
      </Card>
      <ImportHistory jobs={jobs} onRefresh={() => refetchJobs()} onDownloadErrors={downloadErrors} onCancelJob={handleCancelJob} onResumeJob={handleResumeJob} isResuming={isResuming} isCancelling={isCancelling} />
    </>
  );
};

export default ImportTabContent;