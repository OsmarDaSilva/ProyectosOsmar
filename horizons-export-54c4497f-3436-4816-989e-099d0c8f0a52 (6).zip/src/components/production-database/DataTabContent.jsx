import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/lib/customSupabaseClient';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { Skeleton } from '@/components/ui/skeleton';
import { ProductionDataTable } from '@/components/production-database/ProductionDataTable';

const fetchProductionData = async (userId) => {
  if (!userId) return [];
  const { data, error } = await supabase.from('Produccion_Agricola').select('*').eq('user_id', userId).order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data;
};

const upsertProductionRow = async ({ user, rowData }) => {
  const dataToUpsert = { ...rowData, user_id: user.id };
  if (rowData.id && rowData.id.toString().startsWith('new-')) {
    delete dataToUpsert.id;
  }
  const { data, error } = await supabase.from('Produccion_Agricola').upsert(dataToUpsert).select().single();
  if (error) throw error;
  return data;
};

const deleteProductionRow = async ({ user, rowId }) => {
  const { error } = await supabase.from('Produccion_Agricola').delete().match({ user_id: user.id, id: rowId });
  if (error) throw error;
  return rowId;
};

const ProductionDatabaseLoader = () => (
  <div className="space-y-4 p-4">
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-8 w-full" />
    <Skeleton className="h-8 w-full" />
    <Skeleton className="h-8 w-full" />
  </div>
);

const DataTabContent = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const queryKey = ['productionData', user?.id];

  const [editingRow, setEditingRow] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);

  const { data: productionDbData, isLoading, isError, error, refetch } = useQuery({
    queryKey,
    queryFn: () => fetchProductionData(user?.id),
    enabled: !!user,
  });

  const upsertMutation = useMutation({
    mutationFn: upsertProductionRow,
    onSuccess: () => {
      setEditingRow(null);
      queryClient.invalidateQueries({ queryKey });
      toast({ title: "Guardado", description: "El registro se guardó correctamente." });
    },
    onError: (error) => {
      toast({ variant: "destructive", title: "Error", description: `No se pudo guardar: ${error.message}` });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: deleteProductionRow,
    onSuccess: () => {
      setShowDeleteConfirm(null);
      queryClient.invalidateQueries({ queryKey });
      toast({ title: "Eliminado", description: "El registro fue eliminado." });
    },
    onError: (error) => {
      toast({ variant: "destructive", title: "Error", description: `No se pudo eliminar: ${error.message}` });
    },
  });

  const handleAddNew = () => {
    const newRow = {
      id: `new-${uuidv4()}`, country: 'Paraguay', department_province: '', city_locality: '', year: new Date().getFullYear(),
      'Cultura': '', production_purpose: 'Grano', 'Época Siembra': 'Primavera/Verano', forma_cultivo: 'Normal',
      'Prod. (ton/ha)': 0, input_cost_ha: 0, machinery_cost_ha: 0, freight_cost_ha: 0,
      land_rent_ha: 0, electrical_energy_cost_ha: 0, maintenance_repair_cost_ha: 0,
      costo_por_ha_normal: 0, costo_final_ha: 0,
    };
    setEditingRow(newRow);
  };
  
  const handleCancelEdit = () => setEditingRow(null);
  const handleSave = (rowData) => upsertMutation.mutate({ user, rowData });
  const handleDelete = (rowId) => deleteMutation.mutate({ user, rowId });

  const isMutating = upsertMutation.isPending || deleteMutation.isPending;

  const dataWithTemporaryRow = editingRow?.id.startsWith('new-') ? [editingRow, ...(productionDbData || [])] : productionDbData;

  return (
    <>
      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Registros</CardTitle>
            <Button onClick={handleAddNew} disabled={isMutating || !!editingRow}>
              <PlusCircle className="mr-2 h-4 w-4" />Añadir Registro
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <QueryStateWrapper isLoading={isLoading} isError={isError} error={error} data={dataWithTemporaryRow} loader={<ProductionDatabaseLoader />} onRetry={refetch}>
            {(data) => (
              <ProductionDataTable
                data={data || []}
                editingRow={editingRow}
                onEditRow={setEditingRow}
                onSaveRow={handleSave}
                onCancelEdit={handleCancelEdit}
                onDeleteRow={setShowDeleteConfirm}
              />
            )}
          </QueryStateWrapper>
        </CardContent>
      </Card>
      
      <AlertDialog open={!!showDeleteConfirm} onOpenChange={(open) => !open && setShowDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente el registro.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => handleDelete(showDeleteConfirm)}>Eliminar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default DataTabContent;