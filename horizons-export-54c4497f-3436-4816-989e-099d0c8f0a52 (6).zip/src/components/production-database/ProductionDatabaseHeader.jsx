import React from 'react';
import { Button } from '@/components/ui/button';
import { Database, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ProductionDatabaseHeader = ({ isMutating }) => {
  const navigate = useNavigate();

  return (
    <div className="flex justify-between items-start flex-wrap gap-4 mb-6">
      <div>
        <div className="flex items-center gap-3">
          <Database className="h-8 w-8 text-green-600" />
          <h1 className="text-3xl font-bold">Base de Datos de Producción</h1>
        </div>
        <p className="mt-2 text-muted-foreground">Gestione y analice datos históricos de producción agrícola de diferentes regiones.</p>
      </div>
      <Button onClick={() => navigate('/calculator')} variant="outline" disabled={isMutating}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Volver
      </Button>
    </div>
  );
};

export default ProductionDatabaseHeader;