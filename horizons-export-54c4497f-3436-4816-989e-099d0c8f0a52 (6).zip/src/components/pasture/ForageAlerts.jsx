import React, { useMemo } from 'react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Lightbulb, AlertCircle, CheckCircle, BarChartHorizontal, Loader2 } from 'lucide-react';
import useIntensivePastureAnalysis from '@/hooks/useIntensivePastureAnalysis';
import { Skeleton } from '@/components/ui/skeleton';

const ForageAlerts = ({ fullForageData, ganaderiaData }) => {
    const { params } = ganaderiaData || {};
    const hectares = parseFloat(params?.hectareasIntensivo || 0);
    const animalWeight = parseFloat(params?.pesoVivoEntrada || 0);

    // Default values for animal parameters if not provided by ganaderiaData
    const defaultHerdSize = 150; // Example default
    const defaultDailyConsumptionPercentage = 2.5; // Example default

    // Derive herdSize from hectares and animal_per_hectare for intensive, or use default
    const herdSize = params?.cantidadIntensivo && hectares ? (parseFloat(params.cantidadIntensivo) * hectares) : defaultHerdSize;

    const { results, isLoading: isLoadingAnalysis } = useIntensivePastureAnalysis({
        forageData: fullForageData,
        hectares: hectares,
        herdSize: herdSize,
        animalWeight: animalWeight,
        dailyConsumptionPercentage: defaultDailyConsumptionPercentage,
        supplementaryFeedCost: 0.15, // Hardcoded, might come from ganaderiaData later
        initialInvestment: 100000, // Hardcoded
        annualRevenuePerHead: 600, // Hardcoded
        annualOperatingCostPerHead: 250, // Hardcoded
        selectedPastureId: fullForageData?.[0]?.id || '' // Use first pasture by default if none selected
    });

    const alerts = useMemo(() => {
        if (isLoadingAnalysis || !results?.balanceData) {
            return [{
                id: 'loading',
                type: 'loading',
                title: 'Analizando datos...',
                description: 'Estamos calculando las alertas y sugerencias.',
                icon: <Loader2 className="h-4 w-4 animate-spin" />
            }];
        }

        const calculatedAlerts = [];
        const { balanceData } = results;
        const totalProduction = balanceData.reduce((acc, month) => acc + month.oferta, 0);
        const totalConsumption = balanceData.reduce((acc, month) => acc + month.demanda, 0);
        const totalBalance = totalProduction - totalConsumption;

        const deficitMonths = balanceData.filter(m => m.balance < 0).map(m => m.month);

        if (totalBalance < 0) {
            calculatedAlerts.push({
                id: 'annual-deficit',
                type: 'warning',
                title: 'Déficit Anual de Forraje',
                description: `Se proyecta un déficit anual de ${Math.abs(totalBalance).toLocaleString('es-ES', { maximumFractionDigits: 0 })} ton de MS. La producción total no cubre la demanda.`,
                icon: <AlertCircle className="h-4 w-4" />
            });
        }

        if (deficitMonths.length > 0) {
            calculatedAlerts.push({
                id: 'monthly-deficit',
                type: 'warning',
                title: 'Déficit Forrajero Mensual',
                description: `Atención en los meses de: ${deficitMonths.join(', ')}. Considere suplementación o diferimiento de potreros.`,
                icon: <AlertCircle className="h-4 w-4" />
            });
        }
        
        const consumptionToProductionRatio = totalProduction > 0 ? totalConsumption / totalProduction : 0;
        if (consumptionToProductionRatio > 0.95 && totalBalance > 0) {
             calculatedAlerts.push({
                id: 'high-load',
                type: 'info',
                title: 'Carga Animal Ajustada',
                description: `El consumo anual (${(consumptionToProductionRatio * 100).toFixed(0)}%) está muy cerca de la producción. El sistema tiene poca flexibilidad ante imprevistos.`,
                icon: <BarChartHorizontal className="h-4 w-4" />
            });
        }

        if (totalBalance > 0 && deficitMonths.length === 0) {
            calculatedAlerts.push({
                id: 'success',
                type: 'success',
                title: 'Balance Forrajero Positivo',
                description: `¡Excelente gestión! Su producción de forraje supera la demanda anual en un ${(consumptionToProductionRatio > 0 ? (1/consumptionToProductionRatio - 1) * 100 : 0).toFixed(0)}%.`,
                icon: <CheckCircle className="h-4 w-4" />
            });
        }
        
        if (calculatedAlerts.length === 0) {
             calculatedAlerts.push({
                id: 'info-placeholder',
                type: 'info',
                title: 'Sin alertas',
                description: 'El balance forrajero parece estable según los datos actuales. Continúe monitoreando.',
                icon: <Lightbulb className="h-4 w-4" />
            });
        }

        return calculatedAlerts;
    }, [results, isLoadingAnalysis]);

    const getAlertVariant = (type) => {
        switch (type) {
            case 'warning': return 'destructive';
            case 'success': return 'default';
            default: return 'default';
        }
    };
    
    const getAlertClass = (type) => {
        switch (type) {
            case 'warning': return 'bg-red-50 border-red-200 text-red-800 dark:bg-red-900/20 dark:border-red-700/40 dark:text-red-400';
            case 'success': return 'bg-green-50 border-green-200 text-green-800 dark:bg-green-900/20 dark:border-green-700/40 dark:text-green-400';
            case 'loading': return 'bg-gray-50 border-gray-200 dark:bg-gray-800 dark:border-gray-700';
            default: return 'bg-blue-50 border-blue-200 text-blue-800 dark:bg-blue-900/20 dark:border-blue-700/40 dark:text-blue-400';
        }
    };
    
    if (isLoadingAnalysis) {
        return (
            <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
            </div>
        );
    }

    return (
        <div className="space-y-4">
            {alerts.map(alert => (
                <Alert key={alert.id} variant={getAlertVariant(alert.type)} className={getAlertClass(alert.type)}>
                    <div className="flex items-start">
                        <div className="pt-0.5">{alert.icon}</div>
                        <div className="ml-4">
                            <AlertTitle>{alert.title}</AlertTitle>
                            <AlertDescription>
                                {alert.description}
                            </AlertDescription>
                        </div>
                    </div>
                </Alert>
            ))}
        </div>
    );
};

export default ForageAlerts;