import React, { useMemo } from 'react';
import { ResponsiveContainer, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Bar } from 'recharts';
import useIntensivePastureAnalysis from '@/hooks/useIntensivePastureAnalysis';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2 } from 'lucide-react';

const ForageSummaryChart = ({ fullForageData, ganaderiaData }) => {
    const { params } = ganaderiaData || {};
    const hectares = parseFloat(params?.hectareasIntensivo || 0);
    const animalWeight = parseFloat(params?.pesoVivoEntrada || 0);
    
    // Default values for animal parameters if not provided by ganaderiaData
    const defaultHerdSize = 150; // Example default
    const defaultDailyConsumptionPercentage = 2.5; // Example default

    // Derive herdSize from hectares and animal_per_hectare for intensive, or use default
    const herdSize = params?.cantidadIntensivo && hectares ? (parseFloat(params.cantidadIntensivo) * hectares) : defaultHerdSize;


    const { results, isLoading: isLoadingAnalysis } = useIntensivePastureAnalysis({
        forageData: fullForageData,
        hectares: hectares,
        herdSize: herdSize,
        animalWeight: animalWeight,
        dailyConsumptionPercentage: defaultDailyConsumptionPercentage,
        supplementaryFeedCost: 0.15, // Hardcoded, might come from ganaderiaData later
        initialInvestment: 100000, // Hardcoded
        annualRevenuePerHead: 600, // Hardcoded
        annualOperatingCostPerHead: 250, // Hardcoded
        selectedPastureId: fullForageData?.[0]?.id || '' // Use first pasture by default if none selected
    });

    const chartData = useMemo(() => {
        if (!results?.balanceData) return [];
        
        const totalProduction = results.balanceData.reduce((acc, month) => acc + month.oferta, 0);
        const totalConsumption = results.balanceData.reduce((acc, month) => acc + month.demanda, 0);

        return [
            { name: 'Forraje', Producido: totalProduction * 1000, Consumido: totalConsumption * 1000 }
        ];
    }, [results]);

    const formatNumber = (value) => {
        if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M kg`;
        if (value >= 1e3) return `${(value / 1e3).toFixed(0)}K kg`;
        return `${value.toFixed(0)} kg`;
    };

    if (isLoadingAnalysis) {
        return <Skeleton className="w-full h-full" />;
    }
    
    if (!results || chartData.length === 0) {
        return (
            <div className="flex items-center justify-center h-full text-muted-foreground">
                 <Loader2 className="h-8 w-8 animate-spin" />
                 <p className="ml-4">Cargando resumen...</p>
            </div>
        );
    }

    return (
        <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical" margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" tickFormatter={formatNumber} />
                <YAxis type="category" dataKey="name" width={60} />
                <Tooltip formatter={(value) => `${formatNumber(value)} MS`} />
                <Legend />
                <Bar dataKey="Producido" fill="#22c55e" name="Total Producido (kg MS)" />
                <Bar dataKey="Consumido" fill="#f97316" name="Total Consumido (kg MS)" />
            </BarChart>
        </ResponsiveContainer>
    );
};

export default ForageSummaryChart;