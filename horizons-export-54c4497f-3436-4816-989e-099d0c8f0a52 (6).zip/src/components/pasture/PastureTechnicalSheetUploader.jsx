import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Upload, FileText, Trash2, Loader2 } from 'lucide-react';

const PastureTechnicalSheetUploader = ({ isOpen, setIsOpen, forageRow, userId }) => {
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const fileInputRef = useRef(null);
    const [file, setFile] = useState(null);
    const [description, setDescription] = useState('');
    const [isUploading, setIsUploading] = useState(false);

    const { data: sheet, isLoading: isLoadingSheet } = useQuery({
        queryKey: ['pastureSheet', forageRow?.id],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('pasture_technical_sheets')
                .select('*')
                .eq('forage_production_id', forageRow.id)
                .single();
            if (error && error.code !== 'PGRST116') throw error;
            return data;
        },
        enabled: !!forageRow?.id,
    });

    useEffect(() => {
        if (sheet) {
            setDescription(sheet.description || '');
        } else {
            setDescription('');
        }
        setFile(null);
    }, [sheet, isOpen]);

    const uploadMutation = useMutation({
        mutationFn: async () => {
            if (!file) throw new Error('No se ha seleccionado ningún archivo.');
            setIsUploading(true);

            const filePath = `${userId}/${forageRow.id}/${file.name}`;
            const { error: uploadError } = await supabase.storage.from('pasture_sheets').upload(filePath, file, { upsert: true });
            if (uploadError) throw uploadError;

            const { data: { publicUrl } } = supabase.storage.from('pasture_sheets').getPublicUrl(filePath);

            const { data: embeddingData, error: embeddingError } = await supabase.functions.invoke('generate-embedding', {
                body: { text: `Ficha técnica para ${forageRow.pasture_type}: ${description}` },
            });
            if (embeddingError) throw new Error(`Error generando embedding: ${embeddingError.message}`);

            const sheetData = {
                user_id: userId,
                forage_production_id: forageRow.id,
                file_name: file.name,
                file_url: publicUrl,
                description: description,
                embedding: embeddingData.embedding,
                updated_at: new Date().toISOString(),
            };

            const { error: dbError } = await supabase.from('pasture_technical_sheets').upsert({ ...sheetData, id: sheet?.id }, { onConflict: 'forage_production_id' });
            if (dbError) throw dbError;
        },
        onSuccess: () => {
            toast({ title: 'Éxito', description: 'Ficha técnica guardada correctamente.' });
            queryClient.invalidateQueries({ queryKey: ['pastureSheet', forageRow?.id] });
            setIsOpen(false);
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        },
        onSettled: () => {
            setIsUploading(false);
        }
    });

    const deleteMutation = useMutation({
        mutationFn: async () => {
            if (!sheet) return;
            const { error: storageError } = await supabase.storage.from('pasture_sheets').remove([`${userId}/${forageRow.id}/${sheet.file_name}`]);
            if (storageError) console.warn("Error eliminando archivo de storage, puede que no exista:", storageError.message);

            const { error: dbError } = await supabase.from('pasture_technical_sheets').delete().eq('id', sheet.id);
            if (dbError) throw dbError;
        },
        onSuccess: () => {
            toast({ title: 'Eliminado', description: 'Ficha técnica eliminada.' });
            queryClient.invalidateQueries({ queryKey: ['pastureSheet', forageRow?.id] });
            setIsOpen(false);
        },
        onError: (error) => {
            toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
        }
    });

    const handleFileChange = (e) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Ficha Técnica de: {forageRow?.pasture_type}</DialogTitle>
                    <DialogDescription>
                        Adjunte un documento (PDF, Word, Excel) con información técnica sobre esta pastura. La IA podrá usar esta información.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label htmlFor="description">Descripción Breve</Label>
                        <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ej: Variedad resistente a la sequía, ideal para suelos arenosos..." />
                    </div>
                    <div className="space-y-2">
                        <Label>Archivo</Label>
                        {sheet && !file && (
                            <div className="flex items-center justify-between p-2 border rounded-md">
                                <a href={sheet.file_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-blue-600 hover:underline">
                                    <FileText className="h-5 w-5" />
                                    <span>{sheet.file_name}</span>
                                </a>
                                <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate()} disabled={deleteMutation.isPending}>
                                    {deleteMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4 text-red-500" />}
                                </Button>
                            </div>
                        )}
                        <div className="flex items-center gap-2">
                            <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                                <Upload className="mr-2 h-4 w-4" /> {sheet ? 'Reemplazar Archivo' : 'Seleccionar Archivo'}
                            </Button>
                            <Input ref={fileInputRef} type="file" className="hidden" onChange={handleFileChange} />
                            {file && <span className="text-sm text-muted-foreground">{file.name}</span>}
                        </div>
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
                    <Button onClick={() => uploadMutation.mutate()} disabled={(!file && !description) || isUploading || uploadMutation.isPending}>
                        {(isUploading || uploadMutation.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Guardar Ficha
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default PastureTechnicalSheetUploader;