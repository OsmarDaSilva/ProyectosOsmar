import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import { Loader2, MessageSquare, Send, CheckCircle, PlusCircle } from 'lucide-react';
import AddEditActivityDialog from '@/components/pipeline/AddEditActivityDialog';

const fetchAlertComments = async (alertId) => {
    if (!alertId) return [];
    const { data, error } = await supabase
        .from('alert_comments')
        .select('*')
        .eq('alert_id', alertId)
        .order('created_at', { ascending: true });
    if (error) throw error;
    return data;
};

const AlertComment = ({ comment }) => (
    <div className="flex items-start space-x-3 py-3">
        <div className="flex-shrink-0">
            <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-sm font-semibold text-gray-600">
                {comment.user_email ? comment.user_email.substring(0, 2).toUpperCase() : 'U'}
            </div>
        </div>
        <div className="flex-1">
            <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-900">{comment.user_email || 'Usuario desconocido'}</p>
                <p className="text-xs text-gray-500">
                    {comment.created_at ? formatDistanceToNow(parseISO(comment.created_at), { addSuffix: true, locale: es }) : ''}
                </p>
            </div>
            <p className="mt-1 text-sm text-gray-700 whitespace-pre-wrap">{comment.comment}</p>
        </div>
    </div>
);

const AlertDetailDialog = ({ alert, isOpen, onOpenChange }) => {
    const queryClient = useQueryClient();
    const { user } = useAuth();
    const [newComment, setNewComment] = useState('');
    const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);
    const [activityDefaults, setActivityDefaults] = useState({});

    const { data: comments, isLoading: isLoadingComments } = useQuery({
        queryKey: ['alertComments', alert?.id],
        queryFn: () => fetchAlertComments(alert?.id),
        enabled: !!alert && isOpen,
    });
    
    const { data: clients } = useQuery({
        queryKey: ['clientsForDialog'],
        queryFn: async () => {
            const { data } = await supabase.from('clients').select('id, name');
            return data;
        },
        enabled: isOpen,
    });

    const updateActivityMutation = useMutation({
        mutationFn: async ({ commentText }) => {
            if (!alert?.id || !user?.email) return;
            
            const { data: activity, error: fetchError } = await supabase
                .from('activities')
                .select('id, comment_history')
                .eq('source_alert_id', alert.id)
                .single();

            if (fetchError && fetchError.code !== 'PGRST116') {
                throw fetchError;
            }

            if (!activity) {
                console.log("No activity found for this alert, skipping update.");
                return;
            }

            const newHistoryEntry = `${new Date().toISOString()} - ${user.email}: ${commentText}`;
            const updatedHistory = [...(activity.comment_history || []), newHistoryEntry];

            const { error: updateError } = await supabase
                .from('activities')
                .update({ comment_history: updatedHistory })
                .eq('id', activity.id);

            if (updateError) throw updateError;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['activities'] });
        }
    });

    const addCommentMutation = useMutation({
        mutationFn: async (commentText) => {
            if (!alert || !user) throw new Error('Alerta o usuario no disponible');
            const { data, error } = await supabase
                .from('alert_comments')
                .insert({
                    alert_id: alert.id,
                    user_id: user.id,
                    user_email: user.email,
                    comment: commentText,
                }).select().single();
            if (error) throw error;
            return { data, commentText };
        },
        onSuccess: ({ data, commentText }) => {
            queryClient.setQueryData(['alertComments', alert.id], (old) => [...(old || []), data]);
            setNewComment('');
            updateActivityMutation.mutate({ commentText });
        },
    });

    const resolveAlertMutation = useMutation({
        mutationFn: async () => {
            if (!alert || !user) throw new Error('Alerta o usuario no disponible');
            const { error } = await supabase
                .from('alerts')
                .update({ 
                    is_resolved: true, 
                    resolved_at: new Date().toISOString(),
                    resolved_by: user.id,
                    resolution_comment: newComment || 'Resuelta sin comentarios.'
                })
                .eq('id', alert.id);
            if (error) throw error;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['notifications'] });
            queryClient.invalidateQueries({ queryKey: ['resolvedAlerts'] });
            queryClient.invalidateQueries({ queryKey: ['allCriticalAlerts'] });
            onOpenChange(false);
        },
    });

    const handleCreateCorrectiveAction = () => {
        setActivityDefaults({
            client_id: alert.client_id,
            notes: `Acción correctiva para la alerta: "${alert.description}"`,
            type: 'Tarea',
            due_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16),
            source_alert_id: alert.id,
        });
        setIsActivityModalOpen(true);
    };

    const handleSaveActivity = async (activityData) => {
        const { error } = await supabase.from('activities').insert({ ...activityData, user_id: user.id });
        if (error) {
            console.error("Error saving activity:", error);
            return false;
        }
        queryClient.invalidateQueries({ queryKey: ['activities'] });
        setIsActivityModalOpen(false);
        return true;
    };

    const handleSubmitComment = (e) => {
        e.preventDefault();
        if (newComment.trim()) {
            addCommentMutation.mutate(newComment.trim());
        }
    };

    if (!alert) return null;

    return (
        <>
            <Dialog open={isOpen} onOpenChange={onOpenChange}>
                <DialogContent className="sm:max-w-2xl">
                    <DialogHeader>
                        <DialogTitle className="text-xl">Detalle de la Alerta</DialogTitle>
                        <DialogDescription>{alert.description}</DialogDescription>
                        <div className="flex items-center gap-2 pt-2 flex-wrap">
                            <Badge variant={alert.severity === 'critical' ? 'destructive' : 'secondary'}>{alert.severity}</Badge>
                            <Badge variant="outline">{alert.module}</Badge>
                            {alert.client?.name && <Badge variant="outline">Cliente: {alert.client.name}</Badge>}
                        </div>
                    </DialogHeader>
                    
                    <div className="py-4">
                        <h3 className="text-lg font-medium mb-2 flex items-center gap-2"><MessageSquare className="h-5 w-5" /> Comentarios</h3>
                        <ScrollArea className="h-64 border rounded-md">
                            <div className="p-4">
                                {isLoadingComments ? (
                                    <div className="flex justify-center items-center h-full"><Loader2 className="h-6 w-6 animate-spin" /></div>
                                ) : comments && comments.length > 0 ? (
                                    <div className="divide-y">
                                        {comments.map(comment => <AlertComment key={comment.id} comment={comment} />)}
                                    </div>
                                ) : (
                                    <p className="text-center text-sm text-gray-500 py-8">No hay comentarios aún. Sé el primero en añadir uno.</p>
                                )}
                            </div>
                        </ScrollArea>
                    </div>

                    <form onSubmit={handleSubmitComment}>
                        <div className="space-y-2">
                            <Textarea
                                placeholder="Escribe tu comentario o nota de resolución aquí..."
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                rows={3}
                            />
                            <div className="flex justify-end">
                                <Button type="submit" disabled={addCommentMutation.isPending || !newComment.trim()}>
                                    {addCommentMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                                    Enviar Comentario
                                </Button>
                            </div>
                        </div>
                    </form>

                    <DialogFooter className="flex-col sm:flex-row sm:justify-between w-full pt-4">
                        <Button variant="outline" onClick={handleCreateCorrectiveAction}>
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Crear Acción Correctiva
                        </Button>
                        {!alert.is_resolved && (
                            <Button 
                                className="bg-green-600 hover:bg-green-700 text-white"
                                onClick={() => resolveAlertMutation.mutate()}
                                disabled={resolveAlertMutation.isPending}
                            >
                                {resolveAlertMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
                                Marcar como Resuelta
                            </Button>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            <AddEditActivityDialog
                isOpen={isActivityModalOpen}
                setIsOpen={setIsActivityModalOpen}
                onSave={handleSaveActivity}
                clients={clients || []}
                activity={activityDefaults}
            />
        </>
    );
};

export default AlertDetailDialog;