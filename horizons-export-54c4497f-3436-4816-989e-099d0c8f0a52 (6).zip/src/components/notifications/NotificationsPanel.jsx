import React, { useState } from 'react';
    import { useQuery } from '@tanstack/react-query';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Bell, AlertCircle, BellOff, Settings, Loader2 } from 'lucide-react';
    import { formatDistanceToNow, parseISO } from 'date-fns';
    import { es } from 'date-fns/locale';
    import { Skeleton } from '@/components/ui/skeleton';
    import { Button } from '@/components/ui/button';
    import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
    import AlertDetailDialog from './AlertDetailDialog';
    import AlertSettingsDialog from './AlertSettingsDialog';
    import { Badge } from '@/components/ui/badge';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Separator } from '@/components/ui/separator';
    import { logError } from '@/lib/error-logger';

    const NotificationsPanel = ({ isOpen, onOpenChange }) => {
        const { supabase, user } = useAuth();
        const [selectedAlert, setSelectedAlert] = useState(null);
        const [isSettingsOpen, setIsSettingsOpen] = useState(false);

        const fetchNotifications = async () => {
            if (!user) return [];
            const { data, error } = await supabase
                .from('alerts')
                .select('*, client:clients(name)')
                .eq('is_resolved', false)
                .order('created_at', { ascending: false });
            
            if (error) {
                logError(error, { module: 'NotificationsPanel', function: 'fetchNotifications' });
                throw new Error(error.message);
            }
            return data;
        };

        const { data: notifications, isLoading, isError, refetch } = useQuery({
            queryKey: ['notifications', user?.id],
            queryFn: fetchNotifications,
            enabled: !!user && isOpen,
            refetchInterval: 60000,
        });
        
        const handleAlertClick = (alert) => {
            setSelectedAlert(alert);
        };

        const handleDialogClose = () => {
            setSelectedAlert(null);
        };

        const getSeverityBadge = (severity) => {
            switch (severity) {
                case 'critical': return 'destructive';
                case 'high': return 'secondary';
                default: return 'outline';
            }
        };

        return (
            <>
                <Sheet open={isOpen} onOpenChange={onOpenChange}>
                    <SheetContent className="w-[400px] sm:w-[540px] flex flex-col p-0">
                        <SheetHeader className="p-6 pb-4">
                            <SheetTitle className="flex items-center justify-between">
                                Notificaciones
                                <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)}>
                                    <Settings className="h-5 w-5" />
                                </Button>
                            </SheetTitle>
                        </SheetHeader>
                        <Separator />
                        <ScrollArea className="flex-grow">
                            <div className="p-6">
                                {isLoading && (
                                    <div className="space-y-4">
                                        {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
                                    </div>
                                )}
                                {isError && (
                                    <div className="flex flex-col items-center justify-center h-full text-red-500 py-16">
                                        <AlertCircle className="w-12 h-12 mb-4" />
                                        <p className="font-semibold">Error al cargar</p>
                                        <p className="text-sm text-center">No se pudieron obtener las notificaciones.</p>
                                        <Button onClick={() => refetch()} className="mt-4">
                                            Reintentar
                                        </Button>
                                    </div>
                                )}
                                {!isLoading && !isError && notifications?.length === 0 && (
                                    <div className="flex flex-col items-center justify-center h-full text-gray-500 py-16">
                                        <BellOff className="w-16 h-16 mb-4" />
                                        <p className="text-lg font-semibold">Todo en calma</p>
                                        <p className="text-sm">No tienes notificaciones pendientes.</p>
                                    </div>
                                )}
                                {!isLoading && !isError && notifications?.length > 0 && (
                                    <ul className="space-y-3">
                                        {notifications.map(alert => (
                                            <li key={alert.id} onClick={() => handleAlertClick(alert)} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer border border-transparent hover:border-gray-200 transition-colors">
                                                <div className="flex items-start gap-4">
                                                    <div>
                                                        <AlertCircle className={`mt-1 h-5 w-5 ${alert.severity === 'critical' ? 'text-red-500' : 'text-yellow-500'}`} />
                                                    </div>
                                                    <div className="flex-1">
                                                        <div className="flex justify-between items-center">
                                                            <p className="font-semibold text-gray-800">{alert.description}</p>
                                                            <Badge variant={getSeverityBadge(alert.severity)} className="capitalize text-xs">{alert.severity}</Badge>
                                                        </div>
                                                        <p className="text-sm text-gray-600">Cliente: {alert.client?.name || 'General'}</p>
                                                        <p className="text-xs text-gray-400 mt-1">
                                                            {formatDistanceToNow(parseISO(alert.created_at), { addSuffix: true, locale: es })}
                                                        </p>
                                                    </div>
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                )}
                            </div>
                        </ScrollArea>
                    </SheetContent>
                </Sheet>

                <AlertDetailDialog
                    alert={selectedAlert}
                    isOpen={!!selectedAlert}
                    onOpenChange={handleDialogClose}
                />
                <AlertSettingsDialog
                    isOpen={isSettingsOpen}
                    onOpenChange={setIsSettingsOpen}
                />
            </>
        );
    };

    export default NotificationsPanel;