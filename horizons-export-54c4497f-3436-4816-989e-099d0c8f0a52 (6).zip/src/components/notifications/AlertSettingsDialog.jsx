import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Loader2, Save } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const fetchAlertSettings = async (userId) => {
    if (!userId) return null;
    const { data, error } = await supabase
        .from('user_alert_settings')
        .select('*')
        .eq('user_id', userId)
        .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data;
};

const defaultThresholds = {
    finance_low_roi: 10,
    livestock_high_mortality: 3,
    livestock_low_gain: 500,
    agriculture_high_cost: 600,
};

const AlertSettingsContent = ({ onSave, isPage = false }) => {
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const { toast } = useToast();
    const [settings, setSettings] = useState({
        thresholds: defaultThresholds,
        enable_email_notifications: true,
        enable_whatsapp_notifications: false,
    });
    
    const { data: initialSettings, isLoading } = useQuery({
        queryKey: ['alertSettings', user?.id],
        queryFn: () => fetchAlertSettings(user?.id),
        enabled: !!user,
    });

    useEffect(() => {
        if (initialSettings) {
            setSettings({
                thresholds: { ...defaultThresholds, ...initialSettings.thresholds },
                enable_email_notifications: initialSettings.enable_email_notifications,
                enable_whatsapp_notifications: initialSettings.enable_whatsapp_notifications,
            });
        }
    }, [initialSettings]);

    const mutation = useMutation({
        mutationFn: async (updatedSettings) => {
            const { data, error } = await supabase
                .from('user_alert_settings')
                .upsert({ user_id: user.id, ...updatedSettings }, { onConflict: 'user_id' })
                .select()
                .single();
            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['alertSettings', user.id] });
            toast({
                title: "Configuración guardada",
                description: "Tus preferencias de alerta han sido actualizadas.",
            });
            if (onSave) onSave();
        },
        onError: (error) => {
            toast({
                variant: "destructive",
                title: "Error al guardar",
                description: `No se pudo guardar la configuración: ${error.message}`,
            });
        },
    });

    const handleThresholdChange = (key, value) => {
        setSettings(prev => ({
            ...prev,
            thresholds: {
                ...prev.thresholds,
                [key]: value,
            },
        }));
    };
    
    const handleFormSubmit = (e) => {
        e.preventDefault();
        mutation.mutate(settings);
    };

    const content = (
        <form id="settings-form" onSubmit={handleFormSubmit}>
            {isLoading ? <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin" /></div> : (
                <div className="py-4 space-y-6">
                    <div>
                        <h3 className="text-lg font-medium mb-3">Umbrales de Alertas</h3>
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <Label htmlFor="finance_low_roi">ROI Financiero Mínimo (%)</Label>
                                <Input id="finance_low_roi" type="number" value={settings.thresholds.finance_low_roi} onChange={e => handleThresholdChange('finance_low_roi', parseFloat(e.target.value) || 0)} className="w-24" />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label htmlFor="livestock_high_mortality">Mortandad Ganadera Máxima (%)</Label>
                                <Input id="livestock_high_mortality" type="number" value={settings.thresholds.livestock_high_mortality} onChange={e => handleThresholdChange('livestock_high_mortality', parseFloat(e.target.value) || 0)} className="w-24" />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label htmlFor="livestock_low_gain">Ganancia de Peso Mínima (g/día)</Label>
                                <Input id="livestock_low_gain" type="number" value={settings.thresholds.livestock_low_gain} onChange={e => handleThresholdChange('livestock_low_gain', parseInt(e.target.value, 10) || 0)} className="w-24" />
                            </div>
                             <div className="flex items-center justify-between">
                                <Label htmlFor="agriculture_high_cost">Costo de Implantación Máximo (USD/ha)</Label>
                                <Input id="agriculture_high_cost" type="number" value={settings.thresholds.agriculture_high_cost} onChange={e => handleThresholdChange('agriculture_high_cost', parseFloat(e.target.value) || 0)} className="w-24" />
                            </div>
                        </div>
                    </div>
                    <div>
                        <h3 className="text-lg font-medium mb-3">Notificaciones Externas</h3>
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <Label htmlFor="email-notifications">Habilitar notificaciones por Email</Label>
                                <Switch id="email-notifications" checked={settings.enable_email_notifications} onCheckedChange={checked => setSettings(s => ({...s, enable_email_notifications: checked}))} />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label htmlFor="whatsapp-notifications" className="text-gray-400">Habilitar notificaciones por WhatsApp (Próximamente)</Label>
                                <Switch id="whatsapp-notifications" checked={settings.enable_whatsapp_notifications} onCheckedChange={checked => setSettings(s => ({...s, enable_whatsapp_notifications: checked}))} disabled />
                            </div>
                        </div>
                    </div>
                </div>
            )}
             {isPage && (
                <div className="flex justify-end pt-4">
                    <Button type="submit" disabled={mutation.isPending || isLoading}>
                        {mutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                        Guardar Cambios
                    </Button>
                </div>
            )}
        </form>
    );

    if (isPage) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>Configuración de Alertas</CardTitle>
                     <CardDescription>
                        Personaliza los umbrales que disparan alertas automáticas y cómo prefieres ser notificado.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    {content}
                </CardContent>
            </Card>
        );
    }
    return content;
};

const AlertSettingsDialog = ({ isOpen, onOpenChange, isPage = false }) => {
    
    const handleSaveAndClose = () => {
       document.querySelector('#settings-form button[type="submit"]').click();
       onOpenChange(false);
    }
    
    if (isPage) return <AlertSettingsContent isPage={true} />;

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Configuración de Alertas</DialogTitle>
                    <DialogDescription>
                        Personaliza los umbrales de las alertas y tus preferencias de notificación.
                    </DialogDescription>
                </DialogHeader>
                <AlertSettingsContent />
                <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                    <Button type="submit" form="settings-form">Guardar Cambios</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default AlertSettingsDialog;