import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import ClientSelector from './ClientSelector';
import UserSelector from './UserSelector';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase-helpers';
import { useMutation, useQueryClient } from '@tanstack/react-query';

const createTicket = async (payload) => {
    const { data, error } = await supabase.rpc('create_support_ticket', payload);
    if (error) throw new Error(error.message);
    return data;
};

const AddEditTicketDialog = ({ isOpen, onOpenChange, ticket, onSave }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [asunto, setAsunto] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [cliente, setCliente] = useState(null);
  const [asignadoA, setAsignadoA] = useState(null);
  
  const [userOptions, setUserOptions] = useState([]);

  const mutation = useMutation({
    mutationFn: createTicket,
    onSuccess: () => {
      toast({ title: 'Éxito', description: 'Ticket creado correctamente.' });
      queryClient.invalidateQueries(['tickets']);
      onSave?.();
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      console.error("Error guardando ticket:", error);
      toast({ variant: 'destructive', title: 'Error al guardar el ticket', description: error.message });
    }
  });

  const resetForm = () => {
    setAsunto('');
    setDescripcion('');
    setCliente(null);
    setAsignadoA(null);
  };
  
  useEffect(() => {
    const fetchInitialData = async () => {
        const { data: usersData, error: usersError } = await supabase.rpc('get_all_users');
        if (usersError) console.error("Error fetching users:", usersError);
        setUserOptions(usersData || []);
    };

    if (isOpen) {
        fetchInitialData();
        if (ticket) {
            setAsunto(ticket.asunto || '');
            setDescripcion(ticket.descripcion || '');
            setCliente(ticket.client ? { id: ticket.client_id, name: ticket.client.name } : null);
            setAsignadoA(ticket.assigned_user ? { id: ticket.assigned_to_user_id, full_name: ticket.assigned_user.full_name, email: ticket.assigned_user.email } : null);
        } else {
            resetForm();
        }
    }
  }, [ticket, isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!asunto.trim()) {
        toast({ variant: 'destructive', title: 'Error de validación', description: 'El Asunto es obligatorio.' });
        return;
    }
    
    if (ticket?.id) {
       toast({ title: 'En desarrollo', description: 'La edición de tickets aún no está implementada.' });
    } else {
        mutation.mutate({
            p_user_id: user.id,
            p_cliente_id: cliente?.id || null,
            p_asunto: asunto.trim(),
            p_detalle: descripcion?.trim() || null,
        });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>{ticket ? 'Editar Ticket' : 'Nuevo Ticket de Soporte'}</DialogTitle>
            <DialogDescription>
              {ticket ? 'Actualice los detalles del ticket.' : 'Cree un nuevo ticket para un cliente.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="asunto">Asunto <span className="text-red-500">*</span></Label>
              <Input
                id="asunto"
                placeholder="Escribe el asunto del ticket"
                value={asunto}
                maxLength={160}
                onChange={(e) => setAsunto(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cliente">Cliente</Label>
              <ClientSelector value={cliente} onSelect={setCliente} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="asignadoA">Asignado a</Label>
              <UserSelector value={asignadoA} options={userOptions} onSelect={setAsignadoA} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                rows={4}
                placeholder="Describe brevemente el problema"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={mutation.isPending}>{mutation.isPending ? 'Guardando...' : 'Guardar Ticket'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddEditTicketDialog;