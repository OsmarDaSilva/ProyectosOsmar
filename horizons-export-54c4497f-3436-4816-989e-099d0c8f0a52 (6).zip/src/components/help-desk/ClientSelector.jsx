import React, { useEffect, useState } from "react";
import { supabase } from "@/lib/customSupabaseClient";

export default function ClientSelector({ value, onSelect }) {
  const [opts, setOpts] = useState([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("clients")
        .select("id, name")
        .order("name", { ascending: true });
      setOpts(data || []);
    })();
  }, []);

  const currentId = value?.id ?? "";

  const handleChange = (e) => {
    const id = e.target.value;
    const found = opts.find(o => String(o.id) === String(id)) || null;
    onSelect(found);
  };

  return (
    <select className="w-full border rounded px-3 py-2 bg-background text-foreground"
            value={currentId}
            onChange={handleChange}>
      <option value="">(Ninguno)</option>
      {opts.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
    </select>
  );
}