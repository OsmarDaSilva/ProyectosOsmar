import React from 'react';

export default function UserSelector({ value, options = [], onSelect }) {
  const currentId = value?.id ?? "";
  
  const handleChange = (e) => {
    const id = e.target.value;
    const found = options.find(o => String(o.id) === String(id)) || null;
    onSelect(found);
  };

  return (
    <select className="w-full border rounded px-3 py-2 bg-background text-foreground"
            value={currentId}
            onChange={handleChange}>
      <option value="">(Sin asignar)</option>
      {options.map(u => <option key={u.id} value={u.id}>{u.full_name || u.email}</option>)}
    </select>
  );
}