import React, { useState, useEffect, FC, FormEvent } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Ticket, Client, UserProfile, TicketStatus, TicketPriority } from '@/types/tickets';

interface AddEditTicketDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  ticket?: Ticket | null;
  clients: Client[];
  users: UserProfile[];
  onSave: (ticketData: Partial<Ticket>) => Promise<boolean>;
}

const AddEditTicketDialog: FC<AddEditTicketDialogProps> = ({ isOpen, onOpenChange, ticket, clients, users, onSave }) => {
  const { user } = useAuth();
  const TICKET_STATUSES: TicketStatus[] = ['Abierto', 'En Progreso', 'Resuelto', 'Cerrado'];
  const TICKET_PRIORITIES: TicketPriority[] = ['Baja', 'Media', 'Alta', 'Urgente'];

  const getInitialFormData = (): Partial<Ticket> => ({
    client_id: '',
    assigned_to: '',
    subject: '',
    description: '',
    status: 'Abierto',
    priority: 'Media',
    created_by: user?.id,
  });

  const [formData, setFormData] = useState<Partial<Ticket>>(getInitialFormData());
  const [isSaving, setIsSaving] = useState<boolean>(false);

  useEffect(() => {
    if (ticket) {
      setFormData({
        id: ticket.id,
        client_id: ticket.client_id || '',
        assigned_to: ticket.assigned_to || '',
        subject: ticket.subject || '',
        description: ticket.description || '',
        status: ticket.status || 'Abierto',
        priority: ticket.priority || 'Media',
        created_by: ticket.created_by,
      });
    } else {
      setFormData(getInitialFormData());
    }
  }, [ticket, isOpen, user]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id: keyof Ticket, value: string) => {
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    const success = await onSave(formData);
    setIsSaving(false);
    if (success) {
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>{ticket ? 'Editar Ticket' : 'Nuevo Ticket de Soporte'}</DialogTitle>
            <DialogDescription>
              {ticket ? 'Actualice los detalles del ticket.' : 'Cree un nuevo ticket para un cliente.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="subject" className="text-right">Asunto</Label>
              <Input id="subject" value={formData.subject} onChange={handleChange} className="col-span-3" required />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="client_id" className="text-right">Cliente</Label>
              <Select value={formData.client_id} onValueChange={(v) => handleSelectChange('client_id', v)}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccione un cliente" /></SelectTrigger>
                <SelectContent>
                  {clients.map(client => <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="assigned_to" className="text-right">Asignado a</Label>
              <Select value={formData.assigned_to} onValueChange={(v) => handleSelectChange('assigned_to', v)}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder="Asignar a un usuario" /></SelectTrigger>
                <SelectContent>
                  {users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="status" className="text-right">Estado</Label>
              <Select value={formData.status} onValueChange={(v) => handleSelectChange('status', v as TicketStatus)}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TICKET_STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="priority" className="text-right">Prioridad</Label>
              <Select value={formData.priority} onValueChange={(v) => handleSelectChange('priority', v as TicketPriority)}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TICKET_PRIORITIES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="description" className="text-right pt-2">Descripción</Label>
              <Textarea id="description" value={formData.description} onChange={handleChange} className="col-span-3" rows={5} />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSaving}>{isSaving ? 'Guardando...' : 'Guardar Ticket'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddEditTicketDialog;