import React, { FC, useState } from 'react';
    import {
      ColumnDef,
      SortingState,
      VisibilityState,
      ColumnFiltersState,
      flexRender,
      getCoreRowModel,
      getFilteredRowModel,
      getPaginationRowModel,
      getSortedRowModel,
      useReactTable,
    } from '@tanstack/react-table';
    import {
      Table,
      TableBody,
      TableCell,
      TableHead,
      TableHeader,
      TableRow,
    } from '@/components/ui/table';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { ArrowUpDown, ChevronDown } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';
    import { Badge } from '@/components/ui/badge';
    import {
      DropdownMenu,
      DropdownMenuCheckboxItem,
      DropdownMenuContent,
      DropdownMenuTrigger,
    } from '@/components/ui/dropdown-menu';
    import { Ticket, TicketStatus, TicketPriority } from '@/types/tickets';

    interface DataTableProps {
      data: Ticket[];
    }

    export const getStatusBadgeVariant = (status: TicketStatus | undefined) => {
      switch (status) {
        case 'Abierto': return 'secondary';
        case 'En Progreso': return 'default';
        case 'Resuelto': return 'success';
        case 'Cerrado': return 'outline';
        default: return 'secondary';
      }
    };

    export const getPriorityBadgeVariant = (priority: TicketPriority | undefined) => {
        switch (priority) {
          case 'Baja': return 'outline';
          case 'Media': return 'secondary';
          case 'Alta': return 'default';
          case 'Urgente': return 'destructive';
          default: return 'secondary';
        }
      };

    export const TicketsDataTable: FC<DataTableProps> = ({ data }) => {
      const navigate = useNavigate();
      const [sorting, setSorting] = useState<SortingState>([]);
      const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
      const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});

      const columns: ColumnDef<Ticket>[] = [
        {
          accessorKey: 'ticket_number',
          header: ({ column }) => (
            <Button
              variant="ghost"
              onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
            >
              # Ticket
              <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
          ),
          cell: ({ row }) => <div className="font-medium text-blue-600">#{row.getValue('ticket_number')}</div>,
        },
        {
          accessorKey: 'subject',
          header: 'Asunto',
          cell: ({ row }) => <div>{row.getValue('subject')}</div>,
        },
        {
          accessorKey: 'client.name',
          header: 'Cliente',
          cell: ({ row }) => <div>{row.original.client?.name || 'N/A'}</div>,
        },
        {
          accessorKey: 'status',
          header: 'Estado',
          cell: ({ row }) => (
            <Badge variant={getStatusBadgeVariant(row.getValue('status'))}>{row.getValue('status')}</Badge>
          ),
        },
        {
            accessorKey: 'priority',
            header: 'Prioridad',
            cell: ({ row }) => (
              <Badge variant={getPriorityBadgeVariant(row.getValue('priority'))}>{row.getValue('priority')}</Badge>
            ),
          },
        {
          accessorKey: 'assigned_user_full_name', // Adjusted accessorKey
          header: 'Asignado a',
          cell: ({ row }) => <div>{row.original.assigned_user?.full_name || row.original.assigned_user?.email || 'Sin asignar'}</div>,
        },
        {
            accessorKey: 'created_at',
            header: 'Creado el',
            cell: ({ row }) => <div>{new Date(row.getValue('created_at')).toLocaleDateString()}</div>,
          },
      ];

      const table = useReactTable({
        data,
        columns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        onSortingChange: setSorting,
        getSortedRowModel: getSortedRowModel(),
        onColumnFiltersChange: setColumnFilters,
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        state: {
          sorting,
          columnFilters,
          columnVisibility,
        },
      });

      return (
        <div className="w-full">
          <div className="flex items-center py-4">
            <Input
              placeholder="Filtrar por asunto..."
              value={(table.getColumn('subject')?.getFilterValue() as string) ?? ''}
              onChange={(event) =>
                table.getColumn('subject')?.setFilterValue(event.target.value)
              }
              className="max-w-sm"
            />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto">
                  Columnas <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    const headerText = typeof column.columnDef.header === 'string'
                      ? column.columnDef.header
                      : column.id.replace(/_/g, ' ');
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {headerText}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                      return (
                        <TableHead key={header.id}>
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                        </TableHead>
                      );
                    })}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && 'selected'}
                      onClick={() => navigate(`/help-desk/ticket/${row.original.id}`)}
                      className="cursor-pointer"
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>
                          {flexRender(cell.column.columnDef.cell, cell.getContext())}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={columns.length} className="h-24 text-center">
                      No se encontraron resultados.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
            >
              Anterior
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
            >
              Siguiente
            </Button>
          </div>
        </div>
      );
    };