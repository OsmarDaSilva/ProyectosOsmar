import React, { useState } from 'react';
    import {
      flexRender,
      getCoreRowModel,
      getFilteredRowModel,
      getPaginationRowModel,
      getSortedRowModel,
      useReactTable,
    } from '@tanstack/react-table';
    import {
      Table,
      TableBody,
      TableCell,
      TableHead,
      TableHeader,
      TableRow,
    } from '@/components/ui/table';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { ArrowUpDown, ChevronDown, MoreHorizontal, Pencil, Trash2 } from 'lucide-react';
    import { useNavigate } from 'react-router-dom';
    import { Badge } from '@/components/ui/badge';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuLabel,
      DropdownMenuSeparator,
      DropdownMenuTrigger,
      DropdownMenuCheckboxItem,
    } from '@/components/ui/dropdown-menu';

    export const getStatusBadgeVariant = (status) => {
      switch (status) {
        case 'Abierto':
          return 'secondary';
        case 'En Progreso':
          return 'default';
        case 'Resuelto':
          return 'success';
        case 'Cerrado':
          return 'outline';
        default:
          return 'secondary';
      }
    };

    export const getPriorityBadgeVariant = (priority) => {
        switch (priority) {
          case 'Baja':
            return 'outline';
          case 'Media':
            return 'secondary';
          case 'Alta':
            return 'default';
          case 'Urgente':
            return 'destructive';
          default:
            return 'secondary';
        }
      };

    export const TicketsDataTable = ({ data, onEdit, onDelete }) => {
      const navigate = useNavigate();
      const [sorting, setSorting] = useState([]);
      const [columnFilters, setColumnFilters] = useState([]);
      const [columnVisibility, setColumnVisibility] = useState({});

      const columns = [
        {
          accessorKey: 'ticket_number',
          header: ({ column }) => (
            <Button
              variant="ghost"
              onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
            >
              # Ticket
              <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
          ),
          cell: ({ row }) => <div className="font-medium text-blue-600">#{row.getValue('ticket_number')}</div>,
        },
        {
          accessorKey: 'asunto',
          header: 'Asunto',
          cell: ({ row }) => <div>{row.getValue('asunto')}</div>,
        },
        {
          accessorKey: 'client.name',
          header: 'Cliente',
          cell: ({ row }) => <div>{row.original.client?.name || 'N/A'}</div>,
        },
        {
          accessorKey: 'status',
          header: 'Estado',
          cell: ({ row }) => (
            <Badge variant={getStatusBadgeVariant(row.getValue('status'))}>{row.getValue('status')}</Badge>
          ),
        },
        {
            accessorKey: 'priority',
            header: 'Prioridad',
            cell: ({ row }) => (
              <Badge variant={getPriorityBadgeVariant(row.getValue('priority'))}>{row.getValue('priority')}</Badge>
            ),
          },
        {
          accessorKey: 'assigned_user.full_name',
          header: 'Asignado a',
          cell: ({ row }) => <div>{row.original.assigned_user?.full_name || 'Sin asignar'}</div>,
        },
        {
            accessorKey: 'created_at',
            header: 'Creado el',
            cell: ({ row }) => <div>{new Date(row.getValue('created_at')).toLocaleDateString()}</div>,
          },
        {
            id: 'actions',
            cell: ({ row }) => {
                const ticket = row.original;
                return (
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Abrir menú</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => navigate(`/help-desk/ticket/${ticket.id}`)}>
                                Ver Detalles
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => onEdit(ticket)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onDelete(ticket)} className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Eliminar
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                );
            },
        },
      ];

      const table = useReactTable({
        data,
        columns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        onSortingChange: setSorting,
        getSortedRowModel: getSortedRowModel(),
        onColumnFiltersChange: setColumnFilters,
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        state: {
          sorting,
          columnFilters,
          columnVisibility,
        },
      });

      return (
        <div className="w-full">
          <div className="flex items-center py-4">
            <Input
              placeholder="Filtrar por asunto..."
              value={(table.getColumn('asunto')?.getFilterValue()) ?? ''}
              onChange={(event) =>
                table.getColumn('asunto')?.setFilterValue(event.target.value)
              }
              className="max-w-sm"
            />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-auto">
                  Columnas <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {column.id === 'ticket_number' ? '# Ticket' : column.id.replace(/_/g, ' ')}
                      </DropdownMenuCheckboxItem>
                    );
                  })}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                      return (
                        <TableHead key={header.id}>
                          {header.isPlaceholder
                            ? null
                            : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                        </TableHead>
                      );
                    })}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      data-state={row.getIsSelected() && 'selected'}
                      className="cursor-pointer"
                    >
                      {row.getVisibleCells().map((cell) => (
                         <TableCell 
                            key={cell.id} 
                            onClick={() => cell.column.id !== 'actions' && navigate(`/help-desk/ticket/${row.original.id}`)}
                         >
                          {flexRender(cell.column.columnDef.cell, cell.getContext())}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={columns.length} className="h-24 text-center">
                      No se encontraron resultados.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 py-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
            >
              Anterior
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
            >
              Siguiente
            </Button>
          </div>
        </div>
      );
    };