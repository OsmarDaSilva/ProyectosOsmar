import React, { useRef, FC } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { AlertTriangle, Loader2, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { exportToPdf } from '@/lib/pdfUtils';
import { TirVanCalculations } from '@/types/project';

interface TirVanRoyPaybackProps {
  calculations: TirVanCalculations | null;
}

const formatCurrency = (value: number | undefined, decimals = 0): string => {
    const num = Number(value);
    if (isNaN(num)) return 'U$ 0';
    return `U$ ${new Intl.NumberFormat('de-DE', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
    }).format(num)}`;
};

const formatNumber = (value: number | undefined, decimals = 0): string => {
    const num = Number(value);
    if (isNaN(num)) return '0';
    return new Intl.NumberFormat('de-DE', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
    }).format(num);
};

const formatPercentage = (value: number | undefined): string => {
    const num = Number(value);
    if (isNaN(num) || !isFinite(num)) return '0,00%';
    return `${(num * 100).toFixed(2).replace('.', ',')}%`;
};

const TirVanRoyPayback: FC<TirVanRoyPaybackProps> = ({ calculations }) => {
    const printableRef = useRef<HTMLDivElement>(null);

    const handlePrint = () => {
        if(printableRef.current) exportToPdf(printableRef.current, 'analisis_viabilidad');
    };

    if (!calculations) {
        return (
            <div className="flex items-center justify-center py-20 bg-white/50 rounded-lg shadow-inner">
                <Loader2 className="h-16 w-16 text-gray-400 animate-spin" />
                <p className="ml-4 text-gray-600 text-lg">Calculando datos financieros...</p>
            </div>
        );
    }

    const { tableData, metrics, error } = calculations;

    if (error) {
        return (
            <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
                <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">Error en los Cálculos</h2>
                <p className="text-gray-600 text-lg mt-2">{error}</p>
            </div>
        );
    }
    
    if (!tableData || !metrics) {
         return (
            <div className="flex items-center justify-center py-20 bg-white/50 rounded-lg shadow-inner">
                <Loader2 className="h-16 w-16 text-gray-400 animate-spin" />
                <p className="ml-4 text-gray-600 text-lg">Preparando la tabla de análisis...</p>
            </div>
        );
    }

    const rowHeaders = [
        { key: 'ingresosGanaderia', label: 'Ingresos Ganadería', header: true },
        { key: 'ingresosAgricultura', label: 'Ingresos Agricultura', header: true },
        { key: 'totalIngresos', label: 'Total de Ingresos del proyecto', bold: true },
        { key: 'costosOperativosGanaderia', label: 'Costos operativos Ganadería', header: true },
        { key: 'costosOperativosAgricultura', label: 'Costos operativos Agricultura', header: true },
        { key: 'totalCostosOperativos', label: 'Total de Costos operativos', bold: true },
        { key: 'valorCompraRebano', label: 'Valor Compra del Rebaño', header: true },
        { key: 'flujoBrutoCaja', label: 'Flujo Bruto de Caja', bold: true, highlight: 'bg-yellow-100' },
        { key: 'impuestoRenta', label: 'Impuesto de Renta', header: true },
        { key: 'flujoNetoOperativo', label: 'Flujo Neto operativo', bold: true, highlight: 'bg-blue-100' },
        { key: 'valorResidual', label: 'Valor Residual', header: true },
        { key: 'inversionesFijas', label: 'Inversiones Fijas', header: true },
        { key: 'amortizacionPrestamo', label: 'Amortización del Préstamo', header: true },
        { key: 'interesesPrestamo', label: 'Intereses del préstamo', header: true },
        { key: 'flujoNetoProyecto', label: 'Flujo neto del proyecto', bold: true, highlight: 'bg-green-100' },
        { key: 'flujoNetoAcumulado', label: 'Flujo neto acumulado', bold: true, highlight: 'bg-green-200' },
    ];

    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div ref={printableRef} className="p-2">
                <Card>
                    <CardHeader className="flex flex-row justify-between items-center">
                        <CardTitle className="text-center text-2xl font-bold text-gray-800">Análisis de Viabilidad Financiera (TIR, VAN, Payback, ROI)</CardTitle>
                        <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700">
                            <Printer className="mr-2 h-4 w-4" />
                            Exportar a PDF
                        </Button>
                    </CardHeader>
                </Card>

                <Card>
                    <CardContent className="p-0">
                        <div className="overflow-x-auto">
                            <Table className="min-w-full">
                                <TableHeader>
                                    <TableRow className="bg-gray-800">
                                        <TableHead className="text-white font-bold sticky left-0 bg-gray-800 z-10 w-64">Concepto</TableHead>
                                        {tableData.map((_, index) => (
                                            <TableHead key={index} className="text-white text-center w-40">{`Año ${index}`}</TableHead>
                                        ))}
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {rowHeaders.map(row => (
                                        <TableRow key={row.key} className={cn(row.highlight, row.header && 'bg-gray-50')}>
                                            <TableCell className={cn('sticky left-0 bg-white z-10', row.bold && 'font-bold', row.highlight, row.header && 'bg-gray-50')}>
                                                {row.label}
                                            </TableCell>
                                            {tableData.map((yearData, index) => (
                                                <TableCell key={index} className={cn('text-right', row.bold && 'font-bold', (yearData[row.key as keyof typeof yearData] < 0) && 'text-red-600' )}>
                                                    {formatCurrency(yearData[row.key as keyof typeof yearData] as number)}
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardHeader>
                        <CardTitle className="text-center text-xl font-bold">Indicadores Clave de Rentabilidad</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                        <div className="p-4 bg-green-100 rounded-lg">
                            <p className="font-semibold text-green-800">TIR (Tasa Interna de Retorno)</p>
                            <p className="text-3xl font-bold text-green-600">{metrics.tir}</p>
                            <p className="text-xs text-green-700 mt-1">(Anual)</p>
                        </div>
                        <div className="p-4 bg-blue-100 rounded-lg">
                            <p className="font-semibold text-blue-800">VAN (Valor Actual Neto)</p>
                            <p className="text-3xl font-bold text-blue-600">{formatNumber(metrics.van)}</p>
                            <p className="text-xs text-blue-700 mt-1">(Total del Proyecto)</p>
                        </div>
                        <div className="p-4 bg-yellow-100 rounded-lg">
                            <p className="font-semibold text-yellow-800">Payback (Años)</p>
                            <p className="text-3xl font-bold text-yellow-600">{metrics.payback}</p>
                            <p className="text-xs text-yellow-700 mt-1">(Tiempo de Recuperación)</p>
                        </div>
                        <div className="p-4 bg-purple-100 rounded-lg">
                            <p className="font-semibold text-purple-800">ROI (Retorno sobre Inversión)</p>
                            <p className="text-3xl font-bold text-purple-600">{formatPercentage(metrics.roi)}</p>
                            <p className="text-xs text-purple-700 mt-1">(Anualizado)</p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </motion.div>
    );
};

export default TirVanRoyPayback;