import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

const LoadDataModal = ({ isOpen, onClose, onLoadData, type }) => {
    const { toast } = useToast();
    const [countries, setCountries] = useState([]);
    const [departments, setDepartments] = useState([]);
    const [cities, setCities] = useState([]);
    const [crops, setCrops] = useState([]);
    const [purposes, setPurposes] = useState([]);
    const [seasons, setSeasons] = useState([]);

    const [selectedCountry, setSelectedCountry] = useState('');
    const [selectedDepartment, setSelectedDepartment] = useState('');
    const [selectedCity, setSelectedCity] = useState('');
    const [selectedCrop, setSelectedCrop] = useState('');
    const [selectedPurpose, setSelectedPurpose] = useState('');
    const [selectedSeason, setSelectedSeason] = useState('');

    const [isLoading, setIsLoading] = useState(false);
    const [isFetchingFilters, setIsFetchingFilters] = useState(false);

    const resetFilters = (level) => {
        const levels = ['country', 'department', 'city', 'crop', 'purpose', 'season'];
        const index = levels.indexOf(level);
        if (index === -1) return;

        if (index < 1) { setSelectedCountry(''); setDepartments([]); setCities([]); setCrops([]); setPurposes([]); setSeasons([]); }
        if (index < 2) { setSelectedDepartment(''); setCities([]); setCrops([]); setPurposes([]); setSeasons([]); }
        if (index < 3) { setSelectedCity(''); setCrops([]); setPurposes([]); setSeasons([]); }
        if (index < 4) { setSelectedCrop(''); setPurposes([]); setSeasons([]); }
        if (index < 5) { setSelectedPurpose(''); setSeasons([]); }
        if (index < 6) { setSelectedSeason(''); }
    };
    
    const fetchUniqueValues = useCallback(async (field, filters = {}) => {
        const cultivationMethod = type === 'traditional' ? 'Normal' : 'Regado';
        let query = supabase.from('production_data').select(field, { count: 'exact' });
        
        Object.entries(filters).forEach(([key, value]) => {
            if (value) {
                query = query.eq(key, value);
            }
        });
        query = query.eq('cultivation_method', cultivationMethod);
        query = query.not(field, 'is', null);

        const { data, error } = await query;

        if (error) {
            toast({ title: 'Error', description: `No se pudieron cargar los datos de ${field}.`, variant: 'destructive' });
            return [];
        }
        return [...new Set(data.map(item => item[field]).filter(Boolean))].sort();
    }, [toast, type]);

    useEffect(() => {
        if (isOpen) {
            setIsFetchingFilters(true);
            fetchUniqueValues('country').then(fetchedCountries => {
                setCountries(fetchedCountries);
                setIsFetchingFilters(false);
            });
            resetFilters('country');
        }
    }, [isOpen, fetchUniqueValues]);

    useEffect(() => {
        if (selectedCountry) {
            setIsFetchingFilters(true);
            fetchUniqueValues('department_province', { country: selectedCountry }).then(fetchedDepartments => {
                setDepartments(fetchedDepartments);
                setIsFetchingFilters(false);
            });
        }
        resetFilters('department');
    }, [selectedCountry, fetchUniqueValues]);

    useEffect(() => {
        if (selectedDepartment) {
            setIsFetchingFilters(true);
            fetchUniqueValues('city_locality', { country: selectedCountry, department_province: selectedDepartment }).then(fetchedCities => {
                setCities(fetchedCities);
                setIsFetchingFilters(false);
            });
        }
        resetFilters('city');
    }, [selectedDepartment, selectedCountry, fetchUniqueValues]);

     useEffect(() => {
        if (selectedCity) {
            setIsFetchingFilters(true);
            fetchUniqueValues('crop', { country: selectedCountry, department_province: selectedDepartment, city_locality: selectedCity }).then(fetchedCrops => {
                setCrops(fetchedCrops);
                setIsFetchingFilters(false);
            });
        }
        resetFilters('crop');
    }, [selectedCity, selectedDepartment, selectedCountry, fetchUniqueValues]);

    useEffect(() => {
        if (selectedCrop) {
            setIsFetchingFilters(true);
            fetchUniqueValues('production_purpose', { country: selectedCountry, department_province: selectedDepartment, city_locality: selectedCity, crop: selectedCrop }).then(fetchedPurposes => {
                setPurposes(fetchedPurposes);
                setIsFetchingFilters(false);
            });
        }
        resetFilters('purpose');
    }, [selectedCrop, selectedCity, selectedDepartment, selectedCountry, fetchUniqueValues]);

    useEffect(() => {
        if (selectedPurpose) {
            setIsFetchingFilters(true);
            fetchUniqueValues('sowing_season', { country: selectedCountry, department_province: selectedDepartment, city_locality: selectedCity, crop: selectedCrop, production_purpose: selectedPurpose }).then(fetchedSeasons => {
                setSeasons(fetchedSeasons);
                setIsFetchingFilters(false);
            });
        }
        resetFilters('season');
    }, [selectedPurpose, selectedCrop, selectedCity, selectedDepartment, selectedCountry, fetchUniqueValues]);

    const handleLoad = async () => {
        if (!selectedCountry || !selectedDepartment || !selectedCity || !selectedCrop || !selectedPurpose || !selectedSeason) {
            toast({ title: 'Faltan datos', description: 'Por favor, completa todos los filtros.', variant: 'destructive' });
            return;
        }
        setIsLoading(true);
        try {
            const cultivationMethod = type === 'traditional' ? 'Normal' : 'Regado';
            let query = supabase
                .from('production_data')
                .select('yield_ton_ha, input_cost_ha, machinery_cost_ha, freight_cost_ha, electrical_energy_cost_ha, maintenance_repair_cost_ha')
                .eq('country', selectedCountry)
                .eq('department_province', selectedDepartment)
                .eq('city_locality', selectedCity)
                .eq('crop', selectedCrop)
                .eq('production_purpose', selectedPurpose)
                .eq('sowing_season', selectedSeason)
                .eq('cultivation_method', cultivationMethod);

            const { data, error } = await query;

            if (error) throw error;
            if (data.length === 0) {
                toast({ title: 'Sin datos', description: `No se encontraron registros para los filtros seleccionados.`, variant: 'destructive' });
                setIsLoading(false);
                return;
            }

            const averages = data.reduce((acc, row, _, arr) => {
                Object.keys(row).forEach(key => {
                    const value = parseFloat(String(row[key]).replace(',', '.')) || 0;
                    if (!acc[key]) acc[key] = 0;
                    acc[key] += value / arr.length;
                });
                return acc;
            }, {});

            Object.keys(averages).forEach(key => {
                if (key.toLowerCase().includes('cost')) {
                    averages[key] = Math.abs(averages[key]);
                }
            });
            
            onLoadData({ ...averages, crop: selectedCrop });
            onClose();

        } catch (error) {
            toast({ title: 'Error al cargar promedios', description: error.message, variant: 'destructive' });
        } finally {
            setIsLoading(false);
        }
    };
    
    const renderSelect = (label, value, onValueChange, options, placeholder, disabled = false) => (
      <div className="space-y-2">
          <Label>{label}</Label>
          <Select onValueChange={onValueChange} value={value} disabled={disabled || options.length === 0}>
              <SelectTrigger><SelectValue placeholder={placeholder} /></SelectTrigger>
              <SelectContent>
                  {options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
              </SelectContent>
          </Select>
      </div>
    );

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-xl">
                <DialogHeader>
                    <DialogTitle>Cargar Datos de Referencia Detallados</DialogTitle>
                    <DialogDescription>
                        Selecciona filtros específicos para cargar costos y rendimientos promedio.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
                     {isFetchingFilters && <div className="flex items-center justify-center p-4"><Loader2 className="mr-2 h-6 w-6 animate-spin" /><span>Cargando filtros...</span></div>}
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {renderSelect("País", selectedCountry, setSelectedCountry, countries, "Selecciona un país", isFetchingFilters)}
                        {renderSelect("Dpto/Provincia", selectedDepartment, setSelectedDepartment, departments, "Selecciona un depto.", isFetchingFilters || !selectedCountry)}
                        {renderSelect("Ciudad/Localidad", selectedCity, setSelectedCity, cities, "Selecciona una ciudad", isFetchingFilters || !selectedDepartment)}
                        {renderSelect("Cultivo", selectedCrop, setSelectedCrop, crops, "Selecciona un cultivo", isFetchingFilters || !selectedCity)}
                        {renderSelect("Finalidad Producción", selectedPurpose, setSelectedPurpose, purposes, "Selecciona una finalidad", isFetchingFilters || !selectedCrop)}
                        {renderSelect("Época de Siembra", selectedSeason, setSelectedSeason, seasons, "Selecciona una época", isFetchingFilters || !selectedPurpose)}
                     </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancelar</Button>
                    <Button onClick={handleLoad} disabled={isLoading || isFetchingFilters}>
                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Cargar Datos
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default LoadDataModal;