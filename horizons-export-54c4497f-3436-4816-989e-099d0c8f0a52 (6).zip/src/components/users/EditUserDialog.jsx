import React from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Label } from '@/components/ui/label';
    import { Input } from '@/components/ui/input';
    import { Button } from '@/components/ui/button';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

    const EditUserDialog = ({ isOpen, onOpenChange, userToEdit, setUserToEdit, updateMutation, currentUser }) => {
        const isOwner = currentUser?.role === 'owner';
        
        const handleUpdateUser = () => {
            if (userToEdit) {
                // La mutación ahora solo maneja el perfil (nombre/teléfono)
                updateMutation.mutate({
                    id: userToEdit.id,
                    full_name: userToEdit.full_name,
                    phone: userToEdit.phone
                });
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={onOpenChange}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Editar Usuario</DialogTitle>
                        <DialogDescription>Actualice la información del usuario. Solo el propietario puede cambiar roles directamente en la tabla.</DialogDescription>
                    </DialogHeader>
                    {userToEdit && (
                        <div className="space-y-4 py-4">
                            <div className="space-y-2">
                                <Label>Email</Label>
                                <Input value={userToEdit.email} disabled />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="full_name">Nombre Completo</Label>
                                <Input
                                    id="full_name"
                                    value={userToEdit.full_name || ''}
                                    onChange={(e) => setUserToEdit({ ...userToEdit, full_name: e.target.value })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="phone">Teléfono</Label>
                                <Input
                                    id="phone"
                                    value={userToEdit.phone || ''}
                                    onChange={(e) => setUserToEdit({ ...userToEdit, phone: e.target.value })}
                                />
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="role">Rol</Label>
                                 <Input value={userToEdit.role.charAt(0).toUpperCase() + userToEdit.role.slice(1)} disabled />
                                <p className="text-sm text-muted-foreground">
                                    Los roles solo pueden ser cambiados por el Propietario desde la tabla principal.
                                </p>
                            </div>
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                        <Button onClick={handleUpdateUser} disabled={updateMutation.isPending}>
                            {updateMutation.isPending ? 'Guardando...' : 'Guardar Cambios'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    };

    export default EditUserDialog;