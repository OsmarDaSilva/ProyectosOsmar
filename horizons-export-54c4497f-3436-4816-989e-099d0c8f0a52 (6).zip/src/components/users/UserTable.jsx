import React, { useMemo } from 'react';
    import { DataTable } from '@/components/ui/data-table';
    import { MoreHorizontal, Trash2, Edit, KeyRound } from 'lucide-react';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuTrigger,
      DropdownMenuSeparator,
    } from "@/components/ui/dropdown-menu";
    import { Button } from '@/components/ui/button';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

    const UserTable = ({ users, isLoading, currentUser, onEditUser, onDeleteUser, onResetPassword, updateMutation }) => {
      const isOwner = currentUser?.role === 'owner';

      const handleRoleChange = async (userId, newRole) => {
        // En lugar de una mutación directa, llamamos a la RPC segura.
        // La mutación `updateMutation` se usará solo para nombre/teléfono.
        // Aquí necesitaríamos una nueva mutación para la RPC.
        try {
          const { error } = await updateMutation.mutateAsync({ id: userId, role: newRole });
          if (error) throw error;
        } catch (error) {
          // Toast de error ya se maneja en la mutación
        }
      };

      const columns = useMemo(() => [
        {
          accessorKey: 'email',
          header: 'Email',
        },
        {
          accessorKey: 'full_name',
          header: 'Nombre Completo',
          cell: ({ row }) => row.original.full_name || 'N/A',
        },
        {
          accessorKey: 'phone',
          header: 'Teléfono',
          cell: ({ row }) => row.original.phone || 'N/A',
        },
        {
          accessorKey: 'role',
          header: 'Rol',
          cell: ({ row }) => {
            const user = row.original;
            const currentRole = user.role;

            if (user.id === currentUser.id) {
              return <span className="px-2 py-1 rounded-full bg-yellow-200 text-yellow-900 text-xs font-medium capitalize">{currentRole} (tu rol)</span>;
            }

            if (!isOwner) {
                return <span className="px-2 py-1 rounded-full bg-gray-200 text-gray-800 text-xs font-medium capitalize">{currentRole}</span>;
            }

            return (
              <Select 
                value={currentRole} 
                onValueChange={(newRole) => handleRoleChange(user.id, newRole)} 
                disabled={updateMutation.isPending || !isOwner}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Seleccionar Rol" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="collaborator">Collaborator</SelectItem>
                  {/* El rol de owner no se puede asignar desde aquí */}
                </SelectContent>
              </Select>
            );
          },
        },
        {
          accessorKey: 'last_sign_in_at',
          header: 'Último Acceso',
          cell: ({ row }) => row.original.last_sign_in_at ? new Date(row.original.last_sign_in_at).toLocaleString() : 'Nunca',
        },
        {
          id: 'actions',
          cell: ({ row }) => {
            const user = row.original;
            if (user.id === currentUser.id) return null;

            return (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">Abrir menú</span>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <>
                      <DropdownMenuItem onClick={() => onEditUser(user)}>
                        <Edit className="mr-2 h-4 w-4" /> Editar Nombre/Teléfono
                      </DropdownMenuItem>
                      {(isOwner || currentUser.role === 'admin') && (
                        <DropdownMenuItem onClick={() => onResetPassword(user)}>
                          <KeyRound className="mr-2 h-4 w-4" /> Restablecer Contraseña
                        </DropdownMenuItem>
                      )}
                      {isOwner && user.role !== 'owner' && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600" onClick={() => onDeleteUser(user)}>
                            <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                          </DropdownMenuItem>
                        </>
                      )}
                    </>
                </DropdownMenuContent>
              </DropdownMenu>
            );
          },
        },
      ], [currentUser, isOwner, updateMutation.isPending, onEditUser, onDeleteUser, onResetPassword]);

      return (
        <DataTable
          columns={columns}
          data={users || []}
          isLoading={isLoading}
          filterColumn="email"
          filterPlaceholder="Filtrar por email..."
        />
      );
    };

    export default UserTable;