import React, { useState } from 'react';
    import { useMutation } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from "@/components/ui/use-toast";
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Label } from '@/components/ui/label';
    import { Input } from '@/components/ui/input';
    import { Button } from '@/components/ui/button';

    const ResetPasswordDialog = ({ isOpen, onOpenChange, userToResetPassword }) => {
        const { toast } = useToast();
        const [newPassword, setNewPassword] = useState('');

        const resetPasswordMutation = useMutation({
            mutationFn: async ({ userId, newPassword }) => {
                const { data, error } = await supabase.functions.invoke('reset-user-password', {
                    body: { userId, newPassword },
                });
                if (error) throw error;
                return data;
            },
            onSuccess: (data) => {
                onOpenChange(false);
                setNewPassword('');
                toast({
                    title: "Contraseña restablecida",
                    description: data.message,
                });
            },
            onError: (error) => {
                toast({
                    variant: "destructive",
                    title: "Error al restablecer contraseña",
                    description: error.message,
                });
            },
        });
        
        const confirmResetPassword = () => {
            if (userToResetPassword && newPassword) {
                resetPasswordMutation.mutate({ userId: userToResetPassword.id, newPassword });
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={onOpenChange}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Restablecer Contraseña</DialogTitle>
                        <DialogDescription>
                            Establezca una nueva contraseña para {userToResetPassword?.email}. El usuario será notificado del cambio.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                            <Label htmlFor="new-password">Nueva Contraseña</Label>
                            <Input
                                id="new-password"
                                type="password"
                                placeholder="••••••••"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                            />
                            <p className="text-sm text-muted-foreground">
                                La contraseña debe tener al menos 6 caracteres.
                            </p>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                        <Button onClick={confirmResetPassword} disabled={resetPasswordMutation.isPending || newPassword.length < 6}>
                            {resetPasswordMutation.isPending ? 'Restableciendo...' : 'Restablecer Contraseña'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    };

    export default ResetPasswordDialog;