import React from 'react';
    import {
        AlertDialog,
        AlertDialogAction,
        AlertDialogCancel,
        AlertDialogContent,
        AlertDialogDescription,
        AlertDialogFooter,
        AlertDialogHeader,
        AlertDialogTitle,
    } from "@/components/ui/alert-dialog";
    import { useQueryClient } from '@tanstack/react-query';

    const DeleteUserDialog = ({ isOpen, onOpenChange, userToDelete, deleteMutation }) => {
        const queryClient = useQueryClient();

        const confirmDelete = () => {
            if (userToDelete) {
                deleteMutation.mutate(userToDelete.id, {
                    onSuccess: () => {
                        onOpenChange(false);
                    }
                });
            }
        };

        return (
            <AlertDialog open={isOpen} onOpenChange={onOpenChange}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>¿Está seguro?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Esta acción no se puede deshacer. Esto eliminará permanentemente al usuario {userToDelete?.email} y todos sus datos asociados.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending} className="bg-destructive hover:bg-destructive/90">
                            Eliminar
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        );
    };

    export default DeleteUserDialog;