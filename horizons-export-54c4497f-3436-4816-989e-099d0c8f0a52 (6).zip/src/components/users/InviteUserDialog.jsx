import React, { useState, useEffect } from 'react';
    import { useMutation } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from "@/components/ui/use-toast";
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Label } from '@/components/ui/label';
    import { Input } from '@/components/ui/input';
    import { Button } from '@/components/ui/button';
    import { Copy, Check } from 'lucide-react';

    const InviteUserDialog = ({ isOpen, onOpenChange }) => {
        const { toast } = useToast();
        const [inviteEmail, setInviteEmail] = useState('');
        const [inviteLink, setInviteLink] = useState('');
        const [inviteLinkType, setInviteLinkType] = useState('invite');
        const [copied, setCopied] = useState(false);

        useEffect(() => {
            if (!isOpen) {
                setInviteEmail('');
                setInviteLink('');
                setCopied(false);
            }
        }, [isOpen]);

        const inviteMutation = useMutation({
            mutationFn: async (email) => {
              const { data, error } = await supabase.functions.invoke('create-invite-link', {
                body: { email },
              });

              if (error) {
                const errorContext = await error.context.json();
                throw new Error(errorContext.error || 'Ocurrió un error en el servidor.');
              }
              return data;
            },
            onSuccess: (data) => {
              setInviteLink(data.link);
              setInviteLinkType(data.type);
              const title = data.type === 'invite' ? "Enlace de invitación generado" : "Enlace de recuperación generado";
              const description = data.type === 'invite' 
                ? "Copie el enlace y envíelo al nuevo usuario."
                : "El usuario ya existe. Envíe este enlace para que restablezca su contraseña.";
              toast({
                title,
                description,
              });
            },
            onError: (error) => {
              toast({
                variant: "destructive",
                title: "Error al invitar",
                description: error.message,
              });
            },
        });

        const handleInvite = () => {
            if (inviteEmail) {
                inviteMutation.mutate(inviteEmail);
            }
        };

        const copyToClipboard = () => {
            navigator.clipboard.writeText(inviteLink);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        };
        
        return (
            <Dialog open={isOpen} onOpenChange={onOpenChange}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Invitar Nuevo Usuario</DialogTitle>
                        <DialogDescription>
                            Genere un enlace de invitación único para un nuevo usuario.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                            <Label htmlFor="email">Email del nuevo usuario</Label>
                            <Input
                                id="email"
                                type="email"
                                placeholder="nombre@ejemplo.com"
                                value={inviteEmail}
                                onChange={(e) => setInviteEmail(e.target.value)}
                                disabled={inviteMutation.isPending}
                            />
                        </div>
                        {inviteLink && (
                            <div className="space-y-2">
                                <Label>{inviteLinkType === 'invite' ? 'Enlace de Invitación' : 'Enlace de Recuperación'}</Label>
                                <div className="flex items-center space-x-2">
                                    <Input value={inviteLink} readOnly />
                                    <Button variant="outline" size="icon" onClick={copyToClipboard}>
                                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                                    </Button>
                                </div>
                                <p className="text-sm text-muted-foreground">
                                    {inviteLinkType === 'invite'
                                        ? 'Envíe este enlace al usuario para que pueda registrarse.'
                                        : 'El usuario ya existe. Envíe este enlace para que restablezca su contraseña.'}
                                </p>
                            </div>
                        )}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                        <Button onClick={handleInvite} disabled={inviteMutation.isPending || !inviteEmail}>
                            {inviteMutation.isPending ? 'Generando...' : 'Generar Enlace'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    };
    
    export default InviteUserDialog;