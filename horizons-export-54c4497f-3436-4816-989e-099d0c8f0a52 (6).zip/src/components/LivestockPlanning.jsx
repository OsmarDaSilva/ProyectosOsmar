import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Sprout, AlertTriangle, LineChart, Users } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const LivestockPlanning = ({ fullForageData }) => {
    const { toast } = useToast();
    const [params, setParams] = useState({
        startMonth: '4',
        animalsPerHectare: 10,
        hectares: 400,
        startWeight: 200,
        monthlyWeightGain: 25,
        pastureType: 'BRS Zuri',
        dailyConsumptionPct: 2.75,
        pastureUtilization: 75,
        selectedRegion: 'Occidental/Chaco',
        selectedProductionForm: 'Regada',
    });

    const [results, setResults] = useState(null);

    const handleParamChange = (field, value) => {
        setParams(prev => {
            const newState = { ...prev, [field]: value };
            if (field === 'selectedRegion') {
                const newForms = [...new Set(pastureProfiles.filter(p => p.region === value).map(p => p.productionForm))];
                newState.selectedProductionForm = newForms[0] || '';
                const newTypes = [...new Set(pastureProfiles.filter(p => p.region === value && p.productionForm === newState.selectedProductionForm).map(p => p.pastureType))];
                newState.pastureType = newTypes[0] || '';
            } else if (field === 'selectedProductionForm') {
                const newTypes = [...new Set(pastureProfiles.filter(p => p.region === newState.selectedRegion && p.productionForm === value).map(p => p.pastureType))];
                newState.pastureType = newTypes[0] || '';
            }
            return newState;
        });
    };
    
    const parseValue = (value) => {
        if (typeof value === 'string') {
            return parseFloat(value.replace(',', '.')) || 0;
        }
        return parseFloat(value) || 0;
    };

    const findHeader = (headers, keywords) => {
        if (!headers) return null;
        const lowerCaseHeaders = headers.map(h => String(h || '').toLowerCase().trim().replace(/[\s/]+/g, '_'));
        for (const keyword of keywords) {
            const normalizedKeyword = keyword.replace(/[\s/]+/g, '_');
            const headerIndex = lowerCaseHeaders.findIndex(h => h.includes(normalizedKeyword));
            if (headerIndex !== -1) {
                return headers[headerIndex];
            }
        }
        return null;
    };

    const getMonthIndex = (monthValue) => {
        if (!monthValue) return -1;
        const monthString = String(monthValue).toLowerCase().trim();
        const monthMap = {
            'enero': 0, 'jan': 0, '1': 0, 'febrero': 1, 'feb': 1, '2': 1, 'marzo': 2, 'mar': 2, '3': 2,
            'abril': 3, 'apr': 3, '4': 3, 'mayo': 4, 'may': 4, '5': 4, 'junio': 5, 'jun': 5, '6': 5,
            'julio': 6, 'jul': 6, '7': 6, 'agosto': 7, 'aug': 7, '8': 7, 'septiembre': 8, 'sep': 8, '9': 8,
            'octubre': 9, 'oct': 9, '10': 9, 'noviembre': 10, 'nov': 10, '11': 10, 'diciembre': 11, 'dec': 11, '12': 11
        };
        for (const key in monthMap) if (monthString.startsWith(key)) return monthMap[key];
        const numericMonth = parseInt(monthString, 10);
        if (!isNaN(numericMonth) && numericMonth >= 1 && numericMonth <= 12) return numericMonth - 1;
        return -1;
    };

    const pastureProfiles = useMemo(() => {
        const rows = fullForageData?.rows;
        const headers = fullForageData?.headers;
        if (!rows || rows.length === 0 || !headers || headers.length === 0) return [];

        const pastureTypeHeader = findHeader(headers, ['tipo_pastura', 'tipo de pastura']);
        const productionFormHeader = findHeader(headers, ['forma_producida', 'forma productiva']);
        const regionHeader = findHeader(headers, ['region/pais', 'region']);
        const monthHeader = findHeader(headers, ['mes', 'meses']);
        const productionHeader = findHeader(headers, ['kg/ms/mes/region', 'kg_ms_mes_region', 'produccion', 'kg ms/ha']);

        if (!pastureTypeHeader || !monthHeader || !productionHeader || !regionHeader || !productionFormHeader) return [];
        
        const groupedData = rows.reduce((acc, row) => {
            const pastureType = row[pastureTypeHeader];
            const productionForm = row[productionFormHeader];
            const region = row[regionHeader];
            if (!pastureType || !productionForm || !region) return acc;
            const profileKey = `${region}|${productionForm}|${pastureType}`;

            if (!acc[profileKey]) {
                acc[profileKey] = {
                    region,
                    productionForm,
                    pastureType,
                    monthly_production: Array(12).fill(0),
                };
            }
            const monthIndex = getMonthIndex(row[monthHeader]);
            if (monthIndex !== -1) {
                acc[profileKey].monthly_production[monthIndex] = parseValue(row[productionHeader]);
            }
            return acc;
        }, {});

        return Object.values(groupedData);
    }, [fullForageData]);
    
    const { regions, productionForms, pastureTypes } = useMemo(() => {
        const regions = [...new Set(pastureProfiles.map(p => p.region))];
        const productionForms = [...new Set(pastureProfiles.filter(p => p.region === params.selectedRegion).map(p => p.productionForm))];
        const pastureTypes = [...new Set(pastureProfiles.filter(p => p.region === params.selectedRegion && p.productionForm === params.selectedProductionForm).map(p => p.pastureType))];
        return { regions, productionForms, pastureTypes };
    }, [pastureProfiles, params.selectedRegion, params.selectedProductionForm]);
    
    useEffect(() => {
        const selectedPasture = pastureProfiles.find(p => 
            p.region === params.selectedRegion &&
            p.productionForm === params.selectedProductionForm &&
            p.pastureType === params.pastureType
        );

        if (!selectedPasture) {
            setResults(null);
            return;
        }

        const pAnimalsPerHectare = parseValue(params.animalsPerHectare);
        const pHectares = parseValue(params.hectares);
        const pStartWeight = parseValue(params.startWeight);
        const pMonthlyWeightGain = parseValue(params.monthlyWeightGain);
        const pDailyConsumptionPct = parseValue(params.dailyConsumptionPct) / 100;
        const pPastureUtilization = parseValue(params.pastureUtilization) / 100;
        const pStartMonth = parseInt(params.startMonth, 10);

        const totalAnimals = pAnimalsPerHectare * pHectares;
        const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();

        const data = [];
        let currentWeight = pStartWeight;

        for (let i = 0; i < 12; i++) {
            const monthIndex = (pStartMonth + i) % 12;
            const year = new Date().getFullYear() + (monthIndex < pStartMonth ? 1 : 0);
            const daysInMonth = getDaysInMonth(year, monthIndex);
            
            const dailyConsumption = currentWeight * pDailyConsumptionPct;
            const totalMonthlyConsumption = dailyConsumption * daysInMonth * totalAnimals;
            const forageProductionPerHa = selectedPasture.monthly_production[monthIndex];
            const totalForageProduction = forageProductionPerHa * pHectares * pPastureUtilization;
            
            data.push({
                month: new Date(year, monthIndex).toLocaleString('es-ES', { month: 'short', year: '2-digit' }),
                animal_demand: totalMonthlyConsumption,
                forage_supply: totalForageProduction,
                balance: totalForageProduction - totalMonthlyConsumption
            });
            
            currentWeight += pMonthlyWeightGain;
        }

        const totalDemand = data.reduce((acc, row) => acc + row.animal_demand, 0);
        const totalSupply = data.reduce((acc, row) => acc + row.forage_supply, 0);
        const finalBalance = totalSupply - totalDemand;

        const maxDeficit = Math.min(0, ...data.map(d => d.balance));
        const maxSurplus = Math.max(0, ...data.map(d => d.balance));
        const monthsWithDeficit = data.filter(d => d.balance < 0).length;
        
        const possibleAnimals = totalSupply / (totalDemand / totalAnimals);

        setResults({
            balanceData: data,
            totalDemand,
            totalSupply,
            finalBalance,
            maxDeficit,
            maxSurplus,
            monthsWithDeficit,
            currentAnimals: totalAnimals,
            possibleAnimals: isNaN(possibleAnimals) ? 0 : possibleAnimals,
        });

    }, [params, pastureProfiles, toast]);


    const monthOptions = [
        { value: '0', label: 'Enero' }, { value: '1', label: 'Febrero' }, { value: '2', label: 'Marzo' },
        { value: '3', label: 'Abril' }, { value: '4', label: 'Mayo' }, { value: '5', label: 'Junio' },
        { value: '6', label: 'Julio' }, { value: '7', label: 'Agosto' }, { value: '8', label: 'Septiembre' },
        { value: '9', label: 'Octubre' }, { value: '10', label: 'Noviembre' }, { value: '11', label: 'Diciembre' }
    ];

    const formatNumber = (num) => num.toLocaleString('es-ES', { maximumFractionDigits: 0 });

    const CustomTooltip = ({ active, payload, label }) => {
        if (active && payload && payload.length) {
            return (
                <div className="bg-white p-2 border rounded shadow-lg">
                    <p className="font-bold">{label}</p>
                    <p className="text-blue-500">{`Oferta: ${formatNumber(payload[0].value)} kg MS`}</p>
                    <p className="text-orange-500">{`Demanda: ${formatNumber(payload[1].value)} kg MS`}</p>
                    <p className={`font-semibold ${payload[0].payload.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {`Balance: ${formatNumber(payload[0].payload.balance)} kg MS`}
                    </p>
                </div>
            );
        }
        return null;
    };


    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <Card>
                <CardHeader>
                    <div className="flex items-center gap-3">
                        <LineChart className="h-6 w-6 text-blue-600" />
                        <CardTitle>Parámetros de Simulación de Carga Animal</CardTitle>
                    </div>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="space-y-2"><Label>Región/País</Label>
                        <Select value={params.selectedRegion} onValueChange={(v) => handleParamChange('selectedRegion', v)}>
                            <SelectTrigger><SelectValue placeholder="Seleccione..." /></SelectTrigger>
                            <SelectContent>{regions.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2"><Label>Forma Productiva</Label>
                        <Select value={params.selectedProductionForm} onValueChange={(v) => handleParamChange('selectedProductionForm', v)} disabled={!params.selectedRegion}>
                            <SelectTrigger><SelectValue placeholder="Seleccione..." /></SelectTrigger>
                            <SelectContent>{productionForms.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2"><Label>Tipo de Pastura</Label>
                        <Select value={params.pastureType} onValueChange={(v) => handleParamChange('pastureType', v)} disabled={!params.selectedProductionForm}>
                            <SelectTrigger><SelectValue placeholder="Seleccione..." /></SelectTrigger>
                            <SelectContent>{pastureTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2"><Label>Mes de Inicio del Ciclo</Label>
                        <Select value={params.startMonth} onValueChange={(v) => handleParamChange('startMonth', v)}>
                            <SelectTrigger><SelectValue placeholder="Seleccione mes..." /></SelectTrigger>
                            <SelectContent>{monthOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2"><Label>Hectáreas de Pastura</Label><Input type="number" value={params.hectares} onChange={(e) => handleParamChange('hectares', e.target.value)} /></div>
                    <div className="space-y-2"><Label>Carga Programada (an/ha)</Label><Input type="number" value={params.animalsPerHectare} onChange={(e) => handleParamChange('animalsPerHectare', e.target.value)} /></div>
                    <div className="space-y-2"><Label>Peso Vivo Inicial (kg)</Label><Input type="number" value={params.startWeight} onChange={(e) => handleParamChange('startWeight', e.target.value)} /></div>
                    <div className="space-y-2"><Label>Ganancia Mensual (kg)</Label><Input type="number" value={params.monthlyWeightGain} onChange={(e) => handleParamChange('monthlyWeightGain', e.target.value)} /></div>
                    <div className="space-y-2"><Label>% Consumo Materia Seca</Label><Input type="number" value={params.dailyConsumptionPct} onChange={(e) => handleParamChange('dailyConsumptionPct', e.target.value)} /></div>
                    <div className="space-y-2"><Label>% de Aprovechamiento de Pastura</Label><Input type="number" value={params.pastureUtilization} onChange={(e) => handleParamChange('pastureUtilization', e.target.value)} /></div>
                </CardContent>
            </Card>

            {results && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3"><Sprout className="h-6 w-6 text-green-600" /> Resultados del Balance Forrajero</CardTitle>
                        <CardDescription>Análisis de oferta y demanda de forraje (en kg de Materia Seca).</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
                             <div className={`p-4 rounded-lg ${results.finalBalance >= 0 ? 'bg-green-100' : 'bg-red-100'}`}>
                                <p className="text-sm font-semibold">Balance Anual</p>
                                <p className={`text-2xl font-bold ${results.finalBalance >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatNumber(results.finalBalance)}</p>
                            </div>
                             <div className="p-4 rounded-lg bg-red-100">
                                <p className="text-sm font-semibold">Déficit Máximo Mensual</p>
                                <p className="text-2xl font-bold text-red-700">{formatNumber(results.maxDeficit)}</p>
                            </div>
                             <div className="p-4 rounded-lg bg-blue-100">
                                <p className="text-sm font-semibold">Carga Actual</p>
                                <p className="text-2xl font-bold text-blue-700">{formatNumber(results.currentAnimals)} an.</p>
                            </div>
                            <div className="p-4 rounded-lg bg-yellow-100">
                                <p className="text-sm font-semibold">Carga Óptima</p>
                                <p className="text-2xl font-bold text-yellow-700">{formatNumber(results.possibleAnimals)} an.</p>
                            </div>
                        </div>

                        <div className="h-96 w-full">
                            <ResponsiveContainer>
                                <BarChart data={results.balanceData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="month" />
                                    <YAxis tickFormatter={(value) => new Intl.NumberFormat('es-ES', { notation: 'compact', compactDisplay: 'short' }).format(value)} />
                                    <Tooltip content={<CustomTooltip />} />
                                    <Legend />
                                    <ReferenceLine y={0} stroke="#000" />
                                    <Bar dataKey="forage_supply" name="Oferta Forraje" fill="#82ca9d" />
                                    <Bar dataKey="animal_demand" name="Demanda Animal" fill="#ffc658" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Mes</TableHead>
                                    <TableHead>Oferta Forraje (kg MS)</TableHead>
                                    <TableHead>Demanda Animal (kg MS)</TableHead>
                                    <TableHead>Balance (kg MS)</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {results.balanceData.map(row => (
                                    <TableRow key={row.month}>
                                        <TableCell>{row.month}</TableCell>
                                        <TableCell>{formatNumber(row.forage_supply)}</TableCell>
                                        <TableCell>{formatNumber(row.animal_demand)}</TableCell>
                                        <TableCell className={row.balance < 0 ? 'text-red-500 font-bold' : 'text-green-600'}>{formatNumber(row.balance)}</TableCell>
                                    </TableRow>
                                ))}
                                <TableRow className="font-bold bg-gray-50">
                                    <TableCell>Total</TableCell>
                                    <TableCell>{formatNumber(results.totalSupply)}</TableCell>
                                    <TableCell>{formatNumber(results.totalDemand)}</TableCell>
                                    <TableCell className={results.finalBalance < 0 ? 'text-red-500' : 'text-green-600'}>{formatNumber(results.finalBalance)}</TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                         {results.monthsWithDeficit > 0 && (
                            <div className="p-4 bg-red-50 text-red-700 rounded-lg flex items-center gap-3">
                                <AlertTriangle />
                                <div>
                                    <h4 className="font-bold">¡Atención! Se registra un déficit forrajero en {results.monthsWithDeficit} mes(es).</h4>
                                    <p>Considere estrategias como la suplementación, diferimiento de potreros o ajuste de la carga animal.</p>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            )}
        </motion.div>
    );
};

export default LivestockPlanning;