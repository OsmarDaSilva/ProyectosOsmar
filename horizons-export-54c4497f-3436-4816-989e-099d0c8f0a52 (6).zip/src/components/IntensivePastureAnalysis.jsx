import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Filter } from 'lucide-react';
import { ForageBalanceChart } from '@/components/intensive-pasture/ForageBalanceChart';
import useIntensivePastureAnalysis from '@/hooks/useIntensivePastureAnalysis';
import { PerformanceSummary } from '@/components/intensive-pasture/PerformanceSummary';
import { FinancialSummary } from '@/components/intensive-pasture/FinancialSummary';
import { ViabilityMetrics } from '@/components/intensive-pasture/ViabilityMetrics';
import { formatNumber } from '@/lib/utils';
import useForageData from '@/hooks/useForageData';
import QueryStateWrapper from '@/components/QueryStateWrapper';
import { useTranslation } from 'react-i18next';

const formatDateForInput = (date) => {
    if (!date) return '';
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const IntensivePastureAnalysis = () => {
    const { t } = useTranslation(['intensivePasture', 'common']);
    const { user } = useAuth();
    const { data: forageData, isLoading, isError, error, refetch } = useForageData(user?.id);

    const [filters, setFilters] = useState({
        country: 'all',
        region: 'all',
        production_method: 'all',
    });

    const [formState, setFormState] = useState({
        selectedPastureId: '',
        startDate: '2025-08-29',
        hectares: '100',
        headsPerHectare: '10',
        startWeight: '200',
        endWeight: '500',
        purchasePricePerHead: '400',
        dailyConsumptionPercentage: '2.75',
        supplementaryFeedCost: '0.25',
        initialInvestment: '300000',
        annualRevenuePerHead: '945',
        annualOperatingCostPerHead: '250',
        plazo: '10',
        tasaInteres: '7',
        dailySupplementGram: '1000',
        supplementGdpGain: '0.122',
        mortalityRate: '1.0',
        taxRate: '11.5',
    });

    const filterOptions = useMemo(() => {
        if (!forageData) return { countries: [], regions: [], methods: [] };
        const countries = [...new Set(forageData.map(p => p.country).filter(Boolean))];
        const regions = [...new Set(forageData.map(p => p.region).filter(Boolean))];
        const methods = [...new Set(forageData.map(p => p.production_method).filter(Boolean))];
        return { countries, regions, methods };
    }, [forageData]);

    const filteredPastures = useMemo(() => {
        if (!forageData) return [];
        return forageData.filter(p => 
            (filters.country === 'all' || p.country === filters.country) &&
            (filters.region === 'all' || p.region === filters.region) &&
            (filters.production_method === 'all' || p.production_method === filters.production_method)
        );
    }, [forageData, filters]);

    useEffect(() => {
        if (filteredPastures.length > 0) {
            const currentSelectionExists = filteredPastures.some(p => p.id === formState.selectedPastureId);
            if (!currentSelectionExists) {
                setFormState(prev => ({ ...prev, selectedPastureId: filteredPastures[0].id }));
            }
        } else {
             setFormState(prev => ({ ...prev, selectedPastureId: '' }));
        }
    }, [filteredPastures, formState.selectedPastureId]);


    const { results } = useIntensivePastureAnalysis({ ...formState, forageData });
    const { balanceData, performanceSummary, financialSummary, viabilityMetrics, totals } = results;

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormState(prev => ({ ...prev, [name]: value }));
    };
    
    const handleFilterChange = (name, value) => {
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleSelectChange = (name, value) => {
        setFormState(prev => ({ ...prev, [name]: value }));
    };

    const totalHerdSize = (parseFloat(formState.hectares) || 0) * (parseFloat(formState.headsPerHectare) || 0);
    const dailyWeightGain = parseFloat(performanceSummary?.dailyWeightGain?.value) || 0;

    const renderInput = (name, label, placeholder, unit) => (
        <div className="flex flex-col space-y-1.5">
            <Label htmlFor={name} className="text-sm font-medium text-gray-600">{label}</Label>
            <div className="relative">
                <Input
                    id={name}
                    name={name}
                    type={name === 'startDate' ? 'date' : 'text'}
                    placeholder={placeholder}
                    value={formState[name]}
                    onChange={handleInputChange}
                    className="pr-12"
                />
                {unit && <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-sm text-gray-500">{unit}</span>}
            </div>
        </div>
    );
    
    const renderSelect = (name, label, placeholder, options, value, onChange) => (
        <div className="flex flex-col space-y-1.5">
            <Label htmlFor={name} className="text-sm font-medium text-gray-600">{label}</Label>
            <Select name={name} value={value} onValueChange={onChange}>
                <SelectTrigger id={name}><SelectValue placeholder={placeholder} /></SelectTrigger>
                <SelectContent>{options.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
            </Select>
        </div>
    );

    const renderReadOnly = (label, value, unit, className = "") => (
        <div className="flex flex-col space-y-1.5">
            <Label className="text-sm font-medium text-gray-600">{label}</Label>
            <div className={`flex items-center h-10 px-3 py-2 text-sm bg-gray-100 rounded-md border ${className}`}>
                <span>{value}</span>
                {unit && <span className="ml-2 text-sm text-gray-500">{unit}</span>}
            </div>
        </div>
    );
    
    const renderDetailTable = () => (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.month')}</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.animalWeight')} (kg)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.forageSupply')} (ton MS)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.herdDemand')} (ton MS)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.balance')} (ton MS)</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('table.balancePercent')}</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {balanceData.map((item, index) => (
              <tr key={index}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 capitalize">{t(`common:months_short.${item.month.toLowerCase()}`)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500">{formatNumber(item.animalWeight, 1)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500">{formatNumber(item.oferta, 2)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-500">{formatNumber(item.demanda, 2)}</td>
                <td className={`px-6 py-4 whitespace-nowrap text-sm text-right font-semibold ${item.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatNumber(item.balance, 2)}</td>
                <td className={`px-6 py-4 whitespace-nowrap text-sm text-right font-semibold ${item.balancePercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatNumber(item.balancePercentage, 1)}%</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-100 font-bold">
             <tr>
                <td className="px-6 py-3 text-left text-xs uppercase">{t('table.annualTotal')}</td>
                <td className="px-6 py-3"></td>
                <td className="px-6 py-3 text-right text-sm">{formatNumber(totals.oferta, 2)}</td>
                <td className="px-6 py-3 text-right text-sm">{formatNumber(totals.demanda, 2)}</td>
                <td className={`px-6 py-3 text-right text-sm ${totals.balance >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatNumber(totals.balance, 2)}</td>
                <td className={`px-6 py-3 text-right text-sm ${totals.balancePercentage >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatNumber(totals.balancePercentage, 1)}%</td>
            </tr>
          </tfoot>
        </table>
      </div>
    );

    return (
        <QueryStateWrapper isLoading={isLoading} isError={isError} error={error} onRetry={refetch}>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <Tabs defaultValue="params" className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="params">{t('tabs.params')}</TabsTrigger>
                        <TabsTrigger value="detail">{t('tabs.monthlyDetail')}</TabsTrigger>
                        <TabsTrigger value="chart">{t('tabs.annualChart')}</TabsTrigger>
                        <TabsTrigger value="results">{t('tabs.results')}</TabsTrigger>
                    </TabsList>
                    <TabsContent value="params">
                        <Card>
                            <CardHeader>
                                <CardTitle>{t('simulationParams')}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <Card className="bg-gray-50 p-4">
                                    <CardHeader className="p-0 pb-4">
                                        <CardTitle className="text-lg flex items-center gap-2">
                                            <Filter className="h-5 w-5 text-gray-600"/>
                                            {t('pastureFilters')}
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="p-0 grid grid-cols-1 md:grid-cols-4 gap-4">
                                        {renderSelect('country', t('country'), t('common:all'), [{value: 'all', label: t('common:all')}, ...filterOptions.countries.map(c => ({value: c, label: c}))], filters.country, (v) => handleFilterChange('country', v))}
                                        {renderSelect('region', t('region'), t('common:all'), [{value: 'all', label: t('common:all')}, ...filterOptions.regions.map(r => ({value: r, label: r}))], filters.region, (v) => handleFilterChange('region', v))}
                                        {renderSelect('production_method', t('method'), t('common:all'), [{value: 'all', label: t('common:all')}, ...filterOptions.methods.map(m => ({value: m, label: m}))], filters.production_method, (v) => handleFilterChange('production_method', v))}
                                        {renderSelect('selectedPastureId', t('pastureType'), t('common:select'), filteredPastures.map(p => ({ value: p.id, label: p.pasture_type })), formState.selectedPastureId, (v) => handleSelectChange('selectedPastureId', v))}
                                    </CardContent>
                                </Card>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                    {renderInput('startDate', t('cycleStartDate'), 'YYYY-MM-DD')}
                                    {renderInput('hectares', t('pastureHectares'), t('ph.eg100'), 'ha')}
                                    {renderInput('headsPerHectare', t('headsPerHectare'), t('ph.eg4'), t('units.headsHa'))}
                                    {renderReadOnly(t('totalHeads'), formatNumber(totalHerdSize, 0), 'cab')}
                                    {renderInput('startWeight', t('initialLiveWeight'), t('ph.eg200'), 'kg')}
                                    {renderInput('endWeight', t('finalLiveWeight'), t('ph.eg500'), 'kg')}
                                    {renderReadOnly(t('avgDailyGain'), formatNumber(dailyWeightGain, 3), 'kg/día', 'font-semibold text-green-700')}
                                    {renderReadOnly(t('fatteningDays'), formatNumber(performanceSummary.fatteningDays?.value, 0), t('common:days'))}
                                    {renderInput('dailyConsumptionPercentage', t('dailyConsumption'), t('ph.eg25'), '%')}
                                    {renderInput('dailySupplementGram', t('dailySupplement'), t('ph.eg500g'), 'g/día')}
                                    {renderInput('supplementGdpGain', t('supplementGdpGain'), t('ph.eg150g'), 'g/día')}
                                    {renderInput('supplementaryFeedCost', t('supplementCost'), t('ph.eg025'), 'USD/kg')}
                                    {renderInput('purchasePricePerHead', t('animalPurchasePrice'), t('ph.eg400'), 'USD/cab')}
                                    {renderInput('annualRevenuePerHead', t('annualRevenuePerHead'), t('ph.eg600'), 'USD')}
                                    {renderInput('annualOperatingCostPerHead', t('annualOperatingCost'), t('ph.eg250k'), 'USD/cab')}
                                    {renderInput('initialInvestment', t('initialInvestment'), t('ph.eg250kUsd'), 'USD')}
                                    {renderInput('plazo', t('loanTerm'), t('ph.eg10'), t('common:years'))}
                                    {renderInput('tasaInteres', t('annualInterestRate'), t('ph.eg7'), '%')}
                                    {renderInput('mortalityRate', t('mortalityRate'), t('ph.eg15'), '%')}
                                    {renderInput('taxRate', t('taxRate'), t('ph.eg115'), '%')}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="detail">
                        <Card>
                            <CardHeader><CardTitle>{t('monthlyBalanceDetail')}</CardTitle></CardHeader>
                            <CardContent>{renderDetailTable()}</CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="chart">
                        <Card>
                            <CardHeader><CardTitle>{t('annualBalanceChart')}</CardTitle></CardHeader>
                            <CardContent className="h-[400px]"><ForageBalanceChart data={balanceData} /></CardContent>
                        </Card>
                    </TabsContent>
                    <TabsContent value="results">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <Card>
                                <CardHeader><CardTitle>{t('performanceSummary')}</CardTitle></CardHeader>
                                <CardContent><PerformanceSummary data={performanceSummary} /></CardContent>
                            </Card>
                             <Card>
                                <CardHeader><CardTitle>{t('financialSummary')}</CardTitle></CardHeader>
                                <CardContent><FinancialSummary data={financialSummary} /></CardContent>
                            </Card>
                             <Card className="lg:col-span-2">
                                <CardHeader><CardTitle>{t('viabilityMetrics')}</CardTitle></CardHeader>
                                <CardContent><ViabilityMetrics data={viabilityMetrics} /></CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>
            </motion.div>
        </QueryStateWrapper>
    );
};

export default IntensivePastureAnalysis;