import React from 'react';
import { Button } from '@/components/ui/button';
import { Edit, Trash2 } from 'lucide-react';

export const forageTableColumns = [
  { accessorKey: 'pasture_type', header: 'Tipo de Pastura' },
  { accessorKey: 'country', header: 'País' },
  { accessorKey: 'region', header: 'Región' },
  { accessorKey: 'production_method', header: 'Método' },
  { accessorKey: 'monthly_production.0', header: 'Ene' },
  { accessorKey: 'monthly_production.1', header: 'Feb' },
  { accessorKey: 'monthly_production.2', header: 'Mar' },
  { accessorKey: 'monthly_production.3', header: 'Abr' },
  { accessorKey: 'monthly_production.4', header: 'May' },
  { accessorKey: 'monthly_production.5', header: 'Jun' },
  { accessorKey: 'monthly_production.6', header: 'Jul' },
  { accessorKey: 'monthly_production.7', header: 'Ago' },
  { accessorKey: 'monthly_production.8', header: 'Sep' },
  { accessorKey: 'monthly_production.9', header: 'Oct' },
  { accessorKey: 'monthly_production.10', header: 'Nov' },
  { accessorKey: 'monthly_production.11', header: 'Dic' },
  {
    id: 'actions',
    cell: ({ row, table }) => (
      <div className="flex gap-2 justify-end">
        <Button size="sm" variant="outline" onClick={() => table.options.meta?.setEditingRowId(row.original.id)}><Edit className="h-4 w-4" /></Button>
        <Button size="sm" variant="destructive" onClick={() => table.options.meta?.handleDelete(row.original.id)}><Trash2 className="h-4 w-4" /></Button>
      </div>
    ),
  },
];