import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Edit, Trash2, Save, XCircle, Loader2 } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface ForageRowData {
    id: string;
    user_id: string;
    pasture_type: string;
    production_method: 'Normal' | 'Regada';
    country: string | null;
    region: string | null;
    monthly_production: number[];
}

interface EditableRowProps {
    row: ForageRowData;
    onSave: (row: ForageRowData) => void;
    onCancel: () => void;
    isSaving: boolean;
}

const EditableRow: React.FC<EditableRowProps> = ({ row, onSave, onCancel, isSaving }) => {
    const [editedRow, setEditedRow] = useState(row);
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    const handleChange = (field: keyof ForageRowData, value: any) => {
        setEditedRow(prev => ({ ...prev, [field]: value }));
    };

    const handleMonthChange = (index: number, value: string) => {
        const newMonthlyProduction = [...editedRow.monthly_production];
        newMonthlyProduction[index] = parseFloat(String(value).replace(',', '.')) || 0;
        setEditedRow({ ...editedRow, monthly_production: newMonthlyProduction });
    };

    return (
        <TableRow className="bg-blue-50 dark:bg-blue-900/20">
            <TableCell><Input value={editedRow.pasture_type} onChange={(e) => handleChange('pasture_type', e.target.value)} className="h-8 min-w-[150px]" /></TableCell>
            <TableCell><Input value={editedRow.country || ''} onChange={(e) => handleChange('country', e.target.value)} className="h-8 min-w-[100px]" /></TableCell>
            <TableCell><Input value={editedRow.region || ''} onChange={(e) => handleChange('region', e.target.value)} className="h-8 min-w-[100px]" /></TableCell>
            <TableCell>
                <Select value={editedRow.production_method} onValueChange={(v: 'Normal' | 'Regada') => handleChange('production_method', v)}>
                    <SelectTrigger className="h-8 w-[120px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Normal">Normal</SelectItem>
                        <SelectItem value="Regada">Regada</SelectItem>
                    </SelectContent>
                </Select>
            </TableCell>
            {months.map((_, index) => (
                <TableCell key={index}>
                    <Input type="number" step="0.001" value={editedRow.monthly_production[index]} onChange={(e) => handleMonthChange(index, e.target.value)} className="h-8 w-24 text-center" />
                </TableCell>
            ))}
            <TableCell className="sticky right-0 bg-blue-50 dark:bg-blue-900/20 z-10">
                <div className="flex gap-2">
                    <Button size="sm" onClick={() => onSave(editedRow)} disabled={isSaving}>
                        {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    </Button>
                    <Button size="sm" variant="outline" onClick={onCancel} disabled={isSaving}><XCircle className="h-4 w-4" /></Button>
                </div>
            </TableCell>
        </TableRow>
    );
};

interface ForageDataTableProps {
    data: ForageRowData[];
    userId: string;
    editingRowId: string | null;
    setEditingRowId: (id: string | null) => void;
    onRowSaved: () => void;
    onRowDeleted: () => void;
    onCancelEdit: () => void;
}

export const ForageDataTable: React.FC<ForageDataTableProps> = ({
    data,
    userId,
    editingRowId,
    setEditingRowId,
    onRowSaved,
    onRowDeleted,
    onCancelEdit,
}) => {
    const { toast } = useToast();
    const [rowToDelete, setRowToDelete] = useState<string | null>(null);

    const upsertMutation = useMutation({
        mutationFn: async (row: ForageRowData) => {
            const isNew = row.id.startsWith('new-');
            // Convert monthly_production from tons to kg before saving
            const monthlyProductionInKg = row.monthly_production.map(val => val * 1000); 
            const { id, ...rowData } = row;
            const payload = isNew ? { ...rowData, user_id: userId, monthly_production: undefined, // Exclude typed monthly_production
                ene: monthlyProductionInKg[0], feb: monthlyProductionInKg[1], mar: monthlyProductionInKg[2], abr: monthlyProductionInKg[3],
                may: monthlyProductionInKg[4], jun: monthlyProductionInKg[5], jul: monthlyProductionInKg[6], ago: monthlyProductionInKg[7],
                sep: monthlyProductionInKg[8], oct: monthlyProductionInKg[9], nov: monthlyProductionInKg[10], dic: monthlyProductionInKg[11]
            } : { ...rowData, id, user_id: userId, monthly_production: undefined, // Exclude typed monthly_production
                ene: monthlyProductionInKg[0], feb: monthlyProductionInKg[1], mar: monthlyProductionInKg[2], abr: monthlyProductionInKg[3],
                may: monthlyProductionInKg[4], jun: monthlyProductionInKg[5], jul: monthlyProductionInKg[6], ago: monthlyProductionInKg[7],
                sep: monthlyProductionInKg[8], oct: monthlyProductionInKg[9], nov: monthlyProductionInKg[10], dic: monthlyProductionInKg[11]
            };
            
            const { error } = await supabase.from('forage_production').upsert(payload, { onConflict: 'id' });
            if (error) throw error;
        },
        onSuccess: () => {
            toast({ title: 'Guardado', description: 'El perfil de pastura ha sido guardado.' });
            onRowSaved();
        },
        onError: (error: any) => {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (id: string) => {
            const { error } = await supabase.from('forage_production').delete().eq('id', id);
            if (error) throw error;
        },
        onSuccess: () => {
            toast({ title: 'Eliminado', description: 'El perfil ha sido eliminado.' });
            onRowDeleted();
        },
        onError: (error: any) => {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        },
    });

    const handleSave = (row: ForageRowData) => {
        upsertMutation.mutate(row);
    };

    const handleDelete = (id: string) => {
        setRowToDelete(id);
    };

    const confirmDelete = () => {
        if (rowToDelete) {
            deleteMutation.mutate(rowToDelete);
            setRowToDelete(null);
        }
    };
    
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    
    const displayData = [...(data || [])];
    if (editingRowId && editingRowId.startsWith('new-') && !displayData.some(r => r.id === editingRowId)) {
        const newRow: ForageRowData = {
            id: editingRowId,
            user_id: userId,
            pasture_type: 'Nueva Pastura',
            production_method: 'Normal',
            country: '',
            region: '',
            monthly_production: Array(12).fill(0),
        };
        displayData.unshift(newRow);
    }
    
    const isMutating = upsertMutation.isPending || deleteMutation.isPending;

    return (
        <>
            <div className="overflow-x-auto">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="min-w-[150px]">Tipo de Pastura</TableHead>
                            <TableHead className="min-w-[100px]">País</TableHead>
                            <TableHead className="min-w-[100px]">Región</TableHead>
                            <TableHead className="min-w-[120px]">Método</TableHead>
                            {months.map(month => <TableHead key={month} className="text-center">{month}</TableHead>)}
                            <TableHead className="sticky right-0 bg-background z-10 text-right">Acciones</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {displayData.length === 0 ? (
                            <TableRow><TableCell colSpan={17} className="text-center h-24">No hay datos. Puede añadir un perfil o importar una planilla.</TableCell></TableRow>
                        ) : (
                            displayData.map(row => (
                                editingRowId === row.id ? (
                                    <EditableRow key={row.id} row={row} onSave={handleSave} onCancel={onCancelEdit} isSaving={upsertMutation.isPending}/>
                                ) : (
                                    <TableRow key={row.id}>
                                        <TableCell className="font-medium">{row.pasture_type}</TableCell>
                                        <TableCell>{row.country || 'N/A'}</TableCell>
                                        <TableCell>{row.region || 'N/A'}</TableCell>
                                        <TableCell><span className={`px-2 py-1 rounded-full text-xs font-semibold ${row.production_method === 'Regada' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>{row.production_method}</span></TableCell>
                                        {row.monthly_production.map((prod, index) => <TableCell key={index} className="text-center">{new Intl.NumberFormat('es-PY', { minimumFractionDigits: 0, maximumFractionDigits: 3 }).format(prod)}</TableCell>)}
                                        <TableCell className="sticky right-0 bg-background z-10">
                                            <div className="flex gap-2 justify-end">
                                                <Button size="sm" variant="outline" onClick={() => setEditingRowId(row.id)} disabled={isMutating}><Edit className="h-4 w-4" /></Button>
                                                <Button size="sm" variant="destructive" onClick={() => handleDelete(row.id)} disabled={isMutating}><Trash2 className="h-4 w-4" /></Button>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                )
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>
            <AlertDialog open={!!rowToDelete} onOpenChange={(open) => !open && setRowToDelete(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>¿Está absolutamente seguro?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Esta acción no se puede deshacer. Esto eliminará permanentemente el perfil de pastura de la base de datos.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete}>Continuar</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
};