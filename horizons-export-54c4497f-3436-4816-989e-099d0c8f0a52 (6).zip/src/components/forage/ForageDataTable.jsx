import React, { useState } from 'react';
    import {
      Table,
      TableBody,
      TableCell,
      TableHead,
      TableHeader,
      TableRow,
    } from '@/components/ui/table';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Edit, Trash2, Save, XCircle, Loader2 } from 'lucide-react';
    import {
        AlertDialog,
        AlertDialogAction,
        AlertDialogCancel,
        AlertDialogContent,
        AlertDialogDescription,
        AlertDialogFooter,
        AlertDialogHeader,
        AlertDialogTitle,
    } from '@/components/ui/alert-dialog';

    const monthKeys = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

    const EditableRow = ({ row, onSave, onCancel, isSaving }) => {
        const [editedRow, setEditedRow] = useState(row);
        
        const handleChange = (field, value) => {
            setEditedRow(prev => ({ ...prev, [field]: value }));
        };

        const handleMonthChange = (month, value) => {
            setEditedRow(prev => ({
                ...prev,
                months: {
                    ...prev.months,
                    [month]: value
                }
            }));
        };

        return (
            <TableRow className="bg-blue-50 dark:bg-blue-900/20">
                <TableCell className="sticky left-0 bg-blue-50 dark:bg-blue-900/20 z-20"><Input value={editedRow.pasture_type} onChange={(e) => handleChange('pasture_type', e.target.value)} className="h-8 min-w-[150px]" /></TableCell>
                <TableCell><Input value={editedRow.country || ''} onChange={(e) => handleChange('country', e.target.value)} className="h-8 min-w-[100px]" /></TableCell>
                <TableCell><Input value={editedRow.region || ''} onChange={(e) => handleChange('region', e.target.value)} className="h-8 min-w-[100px]" /></TableCell>
                <TableCell>
                    <Select value={editedRow.method} onValueChange={(v) => handleChange('method', v)}>
                        <SelectTrigger className="h-8 w-[120px]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Normal">Normal</SelectItem>
                            <SelectItem value="Regada">Regada</SelectItem>
                        </SelectContent>
                    </Select>
                </TableCell>
                {monthKeys.map(month => (
                    <TableCell key={month}>
                        <Input 
                            type="number" 
                            value={editedRow.months?.[month] ?? ''} 
                            onChange={(e) => handleMonthChange(month, e.target.value)} 
                            className="h-8 w-20"
                        />
                    </TableCell>
                ))}
                <TableCell className="font-bold">
                    {Object.values(editedRow.months || {}).reduce((acc, val) => acc + (parseFloat(val) || 0), 0).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
                <TableCell className="sticky right-0 bg-blue-50 dark:bg-blue-900/20 z-20">
                    <div className="flex gap-2">
                        <Button size="sm" onClick={() => onSave(editedRow)} disabled={isSaving}>
                            {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                        </Button>
                        <Button size="sm" variant="outline" onClick={onCancel} disabled={isSaving}><XCircle className="h-4 w-4" /></Button>
                    </div>
                </TableCell>
            </TableRow>
        );
    };

    export const ForageDataTable = ({
        data,
        userId,
        editingRowId,
        setEditingRowId,
        onSave,
        onDelete,
        onCancelEdit,
        isSaving,
        isDeleting,
    }) => {
        const [rowToDelete, setRowToDelete] = useState(null);
        
        const handleDeleteClick = (id) => {
            setRowToDelete(id);
        };

        const confirmDelete = () => {
            if (rowToDelete) {
                onDelete(rowToDelete);
                setRowToDelete(null);
            }
        };
        
        const displayData = [...(data || [])];
        if (editingRowId && editingRowId.startsWith('new-') && !displayData.some(r => r.id === editingRowId)) {
            const newRow = {
                id: editingRowId,
                user_id: userId,
                pasture_type: 'Nueva Pastura',
                method: 'Normal',
                country: '',
                region: '',
                months: monthKeys.reduce((acc, month) => ({ ...acc, [month]: null }), {}),
            };
            displayData.unshift(newRow);
        }
        
        const isMutating = isSaving || isDeleting;

        const formatMonthValue = (value) => {
            if (value === null || value === undefined) {
                return <span className="text-muted-foreground">-</span>;
            }
            const num = parseFloat(value);
            if (isNaN(num)) {
                return <span className="text-muted-foreground">-</span>;
            }
            return num.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        };

        return (
            <>
                <div className="overflow-x-auto relative">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="min-w-[150px] sticky left-0 bg-background z-10">Tipo de Pastura</TableHead>
                                <TableHead className="min-w-[100px]">País</TableHead>
                                <TableHead className="min-w-[100px]">Región</TableHead>
                                <TableHead className="min-w-[120px]">Método</TableHead>
                                {monthKeys.map(month => <TableHead key={month} className="capitalize min-w-[80px]">{month.slice(0,3)}</TableHead>)}
                                <TableHead className="min-w-[100px] font-bold">Total Anual (kg/ha)</TableHead>
                                <TableHead className="sticky right-0 bg-background z-10 text-right">Acciones</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {displayData.length === 0 ? (
                                <TableRow><TableCell colSpan={18} className="text-center h-24">No hay datos. Puede añadir un perfil o importar una planilla.</TableCell></TableRow>
                            ) : (
                                displayData.map(row => (
                                    editingRowId === row.id ? (
                                        <EditableRow key={row.id} row={row} onSave={onSave} onCancel={onCancelEdit} isSaving={isSaving}/>
                                    ) : (
                                        <TableRow key={row.id}>
                                            <TableCell className="font-medium sticky left-0 bg-background z-10">{row.pasture_type || 'N/A'}</TableCell>
                                            <TableCell>{row.country || 'N/A'}</TableCell>
                                            <TableCell>{row.region || 'N/A'}</TableCell>
                                            <TableCell><span className={`px-2 py-1 rounded-full text-xs font-semibold ${row.method === 'Regada' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>{row.method || 'N/A'}</span></TableCell>
                                            {monthKeys.map(month => <TableCell key={month}>{formatMonthValue(row.months?.[month])}</TableCell>)}
                                            <TableCell className="font-bold">
                                                {Object.values(row.months || {}).reduce((acc, val) => acc + (parseFloat(val) || 0), 0).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                            </TableCell>
                                            <TableCell className="sticky right-0 bg-background z-10">
                                                <div className="flex gap-2 justify-end">
                                                    <Button size="sm" variant="outline" onClick={() => setEditingRowId(row.id)} disabled={isMutating}><Edit className="h-4 w-4" /></Button>
                                                    <Button size="sm" variant="destructive" onClick={() => handleDeleteClick(row.id)} disabled={isMutating}><Trash2 className="h-4 w-4" /></Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    )
                                ))
                            )}
                        </TableBody>
                    </Table>
                </div>
                <AlertDialog open={!!rowToDelete} onOpenChange={(open) => !open && setRowToDelete(null)}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>¿Está absolutamente seguro?</AlertDialogTitle>
                            <AlertDialogDescription>
                                Esta acción no se puede deshacer. Esto eliminará permanentemente el perfil de pastura de la base de datos.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmDelete}>Continuar</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </>
        );
    };