import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Lock } from 'lucide-react';

const AddEditActivityDialog = ({ isOpen, setIsOpen, activity, clients, deals, onSave, defaults }) => {
  const ACTIVITY_TYPES = ['Llamada', 'Reunión', 'Tarea', 'Email'];
  const REMINDER_OPTIONS = [
    { label: 'Sin recordatorio', value: null },
    { label: '15 minutos antes', value: 15 },
    { label: '30 minutos antes', value: 30 },
    { label: '1 hora antes', value: 60 },
    { label: '1 día antes', value: 1440 },
  ];

  const getInitialFormData = () => {
      const base = {
        type: 'Llamada',
        notes: '',
        due_date: '',
        client_id: null,
        deal_id: null,
        reminder_minutes_before: null,
        is_confidential: false,
      };

      if (activity) {
        return {
            ...base,
            id: activity.id,
            type: activity.type || 'Llamada',
            notes: activity.notes || '',
            due_date: activity.due_date ? new Date(activity.due_date).toISOString().slice(0, 16) : '',
            client_id: activity.client_id || null,
            deal_id: activity.deal_id || null,
            reminder_minutes_before: activity.reminder_minutes_before,
            is_confidential: activity.is_confidential || false,
        };
      }

      if (defaults) {
          return { ...base, ...defaults };
      }

      return base;
  }

  const [formData, setFormData] = useState(getInitialFormData());
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setFormData(getInitialFormData());
  }, [activity, defaults, isOpen]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id, value) => {
    const newState = { ...formData, [id]: value === 'null' ? null : value };
    if (id === 'client_id') {
      newState.deal_id = null; // Reset deal if client changes
    }
    if (id === 'reminder_minutes_before') {
        newState[id] = value === 'null' ? null : parseInt(value, 10);
    }
    setFormData(newState);
  };

  const handleSwitchChange = (id, checked) => {
    setFormData(prev => ({ ...prev, [id]: checked }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    const dataToSave = { ...formData };
    if (!dataToSave.client_id) dataToSave.client_id = null;
    if (!dataToSave.deal_id) dataToSave.deal_id = null;
    if (!dataToSave.due_date) dataToSave.due_date = null;
    
    const success = await onSave(dataToSave);
    setIsSaving(false);
    if (success) {
      setIsOpen(false);
    }
  };

  const filteredDeals = formData.client_id && Array.isArray(deals) ? deals.filter(d => d.client_id === formData.client_id) : [];

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>{activity ? 'Editar Actividad' : 'Nueva Actividad'}</DialogTitle>
            <DialogDescription>
              {activity ? 'Actualice los detalles de la actividad.' : 'Añada una nueva actividad a su agenda.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">Tipo</Label>
              <Select value={formData.type} onValueChange={(v) => handleSelectChange('type', v)}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ACTIVITY_TYPES.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="due_date" className="text-right">Vencimiento</Label>
              <Input id="due_date" type="datetime-local" value={formData.due_date} onChange={handleChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="reminder_minutes_before" className="text-right">Recordatorio</Label>
              <Select value={String(formData.reminder_minutes_before)} onValueChange={(v) => handleSelectChange('reminder_minutes_before', v)}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {REMINDER_OPTIONS.map(opt => <SelectItem key={String(opt.value)} value={String(opt.value)}>{opt.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="notes" className="text-right pt-2">Notas</Label>
              <Textarea id="notes" value={formData.notes} onChange={handleChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="client_id" className="text-right">Cliente</Label>
              <Select value={formData.client_id || 'null'} onValueChange={(v) => handleSelectChange('client_id', v)}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccione un cliente" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="null">Seleccione un cliente</SelectItem>
                  {Array.isArray(clients) && clients.map(client => <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="deal_id" className="text-right">Oportunidad</Label>
              <Select value={formData.deal_id || 'null'} onValueChange={(v) => handleSelectChange('deal_id', v)} disabled={!formData.client_id}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccione una oportunidad" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="null">Seleccione una oportunidad</SelectItem>
                  {filteredDeals.map(deal => <SelectItem key={deal.id} value={deal.id}>{deal.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="is_confidential" className="text-right flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Confidencial
              </Label>
              <Switch
                id="is_confidential"
                checked={formData.is_confidential}
                onCheckedChange={(checked) => handleSwitchChange('is_confidential', checked)}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSaving}>{isSaving ? 'Guardando...' : 'Guardar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddEditActivityDialog;