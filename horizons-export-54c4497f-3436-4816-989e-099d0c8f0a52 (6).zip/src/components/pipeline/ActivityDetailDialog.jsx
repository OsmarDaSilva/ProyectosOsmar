import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { User, Clock } from 'lucide-react';

const ActivityDetailDialog = ({ isOpen, setIsOpen, activity, onUpdate }) => {
  const { toast } = useToast();
  const [newNote, setNewNote] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  if (!activity) return null;

  const handleSaveNote = async () => {
    if (!newNote.trim()) return;
    setIsSaving(true);

    const newLogEntry = {
      content: newNote,
      timestamp: new Date().toISOString(),
    };

    const updatedLog = [...(activity.log || []), newLogEntry];

    const { error } = await supabase
      .from('activities')
      .update({ log: updatedLog })
      .eq('id', activity.id);

    if (error) {
      toast({ variant: 'destructive', title: 'Error al guardar la nota', description: error.message });
    } else {
      toast({ title: 'Nota guardada' });
      setNewNote('');
      onUpdate(); // Refresh the activities list to get the latest log
    }
    setIsSaving(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Detalles de la Actividad: {activity.type}</DialogTitle>
          <DialogDescription>
            Vence el: {activity.due_date ? new Date(activity.due_date).toLocaleString('es-ES') : 'N/A'}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div>
            <h4 className="font-semibold mb-2">Notas de la Actividad</h4>
            <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-md">{activity.notes || 'Sin notas.'}</p>
          </div>
          <Separator />
          <div>
            <h4 className="font-semibold mb-2">Registro de Interacción</h4>
            <ScrollArea className="h-48 w-full rounded-md border p-4 bg-gray-50">
              {activity.log && activity.log.length > 0 ? (
                activity.log.slice().reverse().map((entry, index) => (
                  <div key={index} className="mb-4 pb-4 border-b last:border-b-0">
                    <p className="text-sm text-gray-800 whitespace-pre-wrap">{entry.content}</p>
                    <div className="text-xs text-gray-500 mt-2 flex items-center gap-2">
                      <Clock className="h-3 w-3" />
                      <span>{new Date(entry.timestamp).toLocaleString('es-ES')}</span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 text-center py-8">No hay notas en el registro.</p>
              )}
            </ScrollArea>
          </div>
          <div className="grid w-full gap-1.5">
            <Label htmlFor="new-note">Añadir Nota al Registro</Label>
            <Textarea
              id="new-note"
              placeholder="Escriba aquí lo conversado, acuerdos, etc."
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
            />
            <Button onClick={handleSaveNote} disabled={isSaving || !newNote.trim()} className="mt-2 w-full sm:w-auto ml-auto">
              {isSaving ? 'Guardando...' : 'Guardar Nota'}
            </Button>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>Cerrar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ActivityDetailDialog;