import React from 'react';
import { ResponsiveContainer, FunnelChart, Funnel, Tooltip, LabelList } from 'recharts';

const FunnelChartComponent = ({ data }) => {
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  const chartData = data.map((item, index) => ({
    ...item,
    fill: COLORS[index % COLORS.length]
  }));

  return (
    <ResponsiveContainer width="100%" height={400}>
      <FunnelChart>
        <Tooltip
          formatter={(value, name) => {
            if (name === 'Valor Total') {
              return [`$${value.toLocaleString('es-PY')}`, 'Valor'];
            }
            if (name === 'Conversión') {
               return [`${value}%`, 'Conversión'];
            }
            return [value, 'Oportunidades'];
          }}
        />
        <Funnel
          dataKey="deal_count"
          data={chartData}
          isAnimationActive
          labelLine
        >
          <LabelList
            position="right"
            fill="#000"
            stroke="none"
            dataKey="stage"
            formatter={(value) => `${value}`}
            className="text-sm font-semibold"
          />
           <LabelList
            position="center"
            fill="#fff"
            stroke="none"
            dataKey="deal_count"
            formatter={(value) => `${value}`}
            className="text-lg font-bold"
          />
        </Funnel>
      </FunnelChart>
    </ResponsiveContainer>
  );
};

export default FunnelChartComponent;