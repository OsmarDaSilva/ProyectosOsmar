import React, { useState, useEffect } from 'react';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogDescription,
      DialogFooter,
    } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Star, Percent } from 'lucide-react';

    const AddEditDealDialog = ({ isOpen, setIsOpen, deal, clients, onSave }) => {
      const STAGES = ['Lead', 'Contactado', 'Propuesta', 'Negociación', 'Ganado', 'Perdido'];
      const [formData, setFormData] = useState({
        title: '',
        stage: 'Lead',
        value: '',
        client_id: null,
        expected_close_date: '',
        score: 0,
        confidence: 0,
      });
      const [isSaving, setIsSaving] = useState(false);

      useEffect(() => {
        if (deal) {
          setFormData({
            id: deal.id,
            title: deal.title || '',
            stage: deal.stage || 'Lead',
            value: deal.value || '',
            client_id: deal.client_id || null,
            expected_close_date: deal.expected_close_date ? new Date(deal.expected_close_date).toISOString().split('T')[0] : '',
            score: deal.score || 0,
            confidence: deal.confidence || 0,
          });
        } else {
          setFormData({ title: '', stage: 'Lead', value: '', client_id: null, expected_close_date: '', score: 0, confidence: 0 });
        }
      }, [deal, isOpen]);

      const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
      };

      const handleSelectChange = (id, value) => {
        setFormData(prev => ({ ...prev, [id]: value === 'null' ? null : value }));
      };
      
      const handleScoreChange = (newScore) => {
        setFormData(prev => ({ ...prev, score: newScore }));
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        const dataToSave = { 
          ...formData, 
          value: parseFloat(formData.value) || 0,
          score: parseInt(formData.score) || 0,
          confidence: parseInt(formData.confidence) || 0,
        };
        if (dataToSave.client_id === 'null') {
            dataToSave.client_id = null;
        }
        const success = await onSave(dataToSave);
        setIsSaving(false);
        if (success) {
          setIsOpen(false);
        }
      };

      return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent className="sm:max-w-md">
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>{deal ? 'Editar Oportunidad' : 'Nueva Oportunidad'}</DialogTitle>
                <DialogDescription>
                  {deal ? 'Actualice los detalles de la oportunidad.' : 'Añada una nueva oportunidad a su pipeline.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="title" className="text-right">Título</Label>
                  <Input id="title" value={formData.title} onChange={handleChange} className="col-span-3" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="client_id" className="text-right">Cliente</Label>
                  <Select value={formData.client_id || 'null'} onValueChange={(v) => handleSelectChange('client_id', v)}>
                    <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccione un cliente" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="null">Seleccione un cliente</SelectItem>
                      {clients.map(client => <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="stage" className="text-right">Etapa</Label>
                  <Select value={formData.stage} onValueChange={(v) => handleSelectChange('stage', v)}>
                    <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STAGES.map(stage => <SelectItem key={stage} value={stage}>{stage}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="value" className="text-right">Valor (USD)</Label>
                  <Input id="value" type="number" value={formData.value} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="expected_close_date" className="text-right">Cierre</Label>
                  <Input id="expected_close_date" type="date" value={formData.expected_close_date} onChange={handleChange} className="col-span-3" />
                </div>
                 <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="confidence" className="text-right flex items-center gap-1"><Percent className="h-4 w-4" /> Confianza</Label>
                  <div className="col-span-3 flex items-center gap-2">
                    <Input id="confidence" type="number" value={formData.confidence} onChange={handleChange} className="w-20" min="0" max="100" />
                    <span className="text-gray-500">%</span>
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label className="text-right">Puntuación</Label>
                    <div className="col-span-3 flex items-center">
                        {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                                key={star}
                                className={`h-6 w-6 cursor-pointer ${formData.score >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                                onClick={() => handleScoreChange(star)}
                            />
                        ))}
                    </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
                <Button type="submit" disabled={isSaving}>{isSaving ? 'Guardando...' : 'Guardar'}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    };

    export default AddEditDealDialog;