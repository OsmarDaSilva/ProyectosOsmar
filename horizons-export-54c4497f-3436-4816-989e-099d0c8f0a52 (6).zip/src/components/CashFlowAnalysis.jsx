import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, BarChart3 } from 'lucide-react';
import CashFlowChart from '@/components/CashFlowChart';
import { useTranslation } from 'react-i18next';

const CashFlowAnalysis = ({ calculations }) => {
  const { t, i18n } = useTranslation(['viability','common','calculator']);
  
  const formatCurrency = (value) => {
    return new Intl.NumberFormat(i18n.language === 'es' ? 'es-PY' : 'en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const getFlowStatus = (value) => {
    if (value > 0) return 'text-green-600';
    if (value < 0) return 'text-red-600';
    return 'text-gray-600';
  };
  
  const { tableData, metrics } = calculations;
  const years = metrics.plazo;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <h1 className="text-2xl sm:text-4xl font-bold gradient-text">{t('financialAnalysis.title')}</h1>
        <p className="text-sm sm:text-base text-gray-600">{t('financialAnalysis.subtitle', { years })}</p>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="data-table">
          <CardHeader className="table-header">
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-green-600" />
              <span>{t('financialAnalysis.projectedTableTitle')}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.year')}</th>
                    <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.investment')}</th>
                    <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.grossFlow')}</th>
                    <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.taxes')}</th>
                    <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.residualValue')}</th>
                    <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.netCashFlow')}</th>
                    <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">{t('financialAnalysis.headers.cumulativeCashFlow')}</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {tableData.map((flow, index) => (
                    <motion.tr
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 + index * 0.1 }}
                      className="hover:bg-gray-50"
                    >
                      <td className="px-2 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="font-medium text-gray-900">{flow.year === 0 ? t('financialAnalysis.initial') : t('financialAnalysis.yearN', { n: flow.year })}</span>
                        </div>
                      </td>
                      <td className="px-2 py-4 whitespace-nowrap text-right">
                        <span className={`font-medium ${getFlowStatus(-flow.inversionFija)}`}>{formatCurrency(flow.inversionFija)}</span>
                      </td>
                      <td className="px-2 py-4 whitespace-nowrap text-right">
                        <span className={`font-medium ${getFlowStatus(flow.flujoCajaBruto)}`}>{formatCurrency(flow.flujoCajaBruto)}</span>
                      </td>
                      <td className="px-2 py-4 whitespace-nowrap text-right">
                        <span className={`font-medium ${getFlowStatus(flow.impuestos)}`}>{formatCurrency(flow.impuestos)}</span>
                      </td>
                      <td className="px-2 py-4 whitespace-nowrap text-right">
                        <span className={`font-medium ${getFlowStatus(flow.valorResidual)}`}>{formatCurrency(flow.valorResidual)}</span>
                      </td>
                      <td className="px-2 py-4 whitespace-nowrap text-right">
                        <span className={`font-medium ${getFlowStatus(flow.flujoCajaNeto)}`}>{formatCurrency(flow.flujoCajaNeto)}</span>
                      </td>
                      <td className="px-2 py-4 whitespace-nowrap text-right">
                        <span className={`font-medium ${getFlowStatus(flow.flujoCajaAcumulado)}`}>{formatCurrency(flow.flujoCajaAcumulado)}</span>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <Card className="chart-container">
          <CardHeader>
            <CardTitle>{t('financialAnalysis.cumulativeChartTitle')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <CashFlowChart data={tableData.map(d => ({ year: d.year, cumulativeTech: d.flujoCajaAcumulado }))} />
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default CashFlowAnalysis;