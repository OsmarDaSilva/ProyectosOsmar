import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPortal } from 'react-dom';
import { Bot, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useGlobalAssistant } from '@/contexts/GlobalAssistantContext';
import AiAssistantPanel from '@/components/assistant/AiAssistantPanel';

const GlobalAssistant = () => {
    const { isOpen, toggleAssistant, closeAssistant } = useGlobalAssistant();

    useEffect(() => {
        const handleKeyDown = (event) => {
            if (event.key === 'Escape' && isOpen) {
                closeAssistant();
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, closeAssistant]);

    return (
        <>
            <AnimatePresence>
                {isOpen && <AiAssistantPanel />}
            </AnimatePresence>
            
            {createPortal(
                <div className="fixed bottom-6 right-6" style={{ zIndex: 2147483647 }}>
                    <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.5 }}
                    >
                        <Button
                            size="icon"
                            className="w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 focus:ring-2 focus:ring-ring focus:ring-offset-2 md:w-16 md:h-16"
                            onClick={toggleAssistant}
                            aria-label={isOpen ? "Cerrar asistente" : "Abrir asistente"}
                        >
                            <AnimatePresence mode="wait">
                                <motion.div
                                    key={isOpen ? 'close' : 'open'}
                                    initial={{ rotate: -90, scale: 0 }}
                                    animate={{ rotate: 0, scale: 1 }}
                                    exit={{ rotate: 90, scale: 0 }}
                                    transition={{ duration: 0.2 }}
                                >
                                    {isOpen ? <X className="h-7 w-7 md:h-8 md:w-8" /> : <Bot className="h-7 w-7 md:h-8 md:w-8" />}
                                </motion.div>
                            </AnimatePresence>
                        </Button>
                    </motion.div>
                </div>,
                document.getElementById('portal-root')
            )}
        </>
    );
};

export default GlobalAssistant;