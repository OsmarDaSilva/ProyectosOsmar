import React, { useState, useRef, useEffect } from 'react';
    import useAiAssistant from '@/hooks/useAiAssistant';
    import { Textarea } from '@/components/ui/textarea';
    import { Button } from '@/components/ui/button';
    import { Send, Loader2, Sparkles, AlertCircle, FileText, RotateCcw, Search, Lightbulb, HelpCircle, ChevronsUpDown } from 'lucide-react';
    import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
    import { Badge } from "@/components/ui/badge";
    import { useTranslation } from 'react-i18next';
    import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { useGlobalAssistant } from '@/contexts/GlobalAssistantContext';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

    const AiChatTab = ({ isOpen }) => {
        const { t } = useTranslation(['assistant', 'common']);
        const { messages, setMessages, isLoading, error, handleQuery, retryQuery } = useAiAssistant();
        const { closeAssistant } = useGlobalAssistant();
        const [query, setQuery] = useState('');
        const scrollAreaRef = useRef(null);
        const inputRef = useRef(null);

        const scrollToEnd = () => {
            setTimeout(() => {
                const viewport = scrollAreaRef.current?.querySelector('[data-radix-scroll-area-viewport]');
                if (viewport) {
                    viewport.scrollTo({ top: viewport.scrollHeight, behavior: 'smooth' });
                }
            }, 100);
        };

        useEffect(() => {
            scrollToEnd();
        }, [messages]);

        useEffect(() => {
            if (isOpen) {
                setTimeout(() => {
                    inputRef.current?.focus();
                    scrollToEnd();
                }, 300); 
            }
        }, [isOpen]);
        
        useEffect(() => {
            const handleKeyDown = (event) => {
                if (event.key === 'Escape' && isOpen) {
                    closeAssistant();
                }
            };

            window.addEventListener('keydown', handleKeyDown);
            return () => window.removeEventListener('keydown', handleKeyDown);
        }, [isOpen, closeAssistant]);

        useEffect(() => {
            if (messages.length === 0) {
                setMessages([
                    {
                        type: 'ai',
                        isWelcome: true,
                        content: t('welcomeMessage'),
                        id: 'welcome'
                    }
                ]);
            }
        }, [t, messages.length, setMessages]);
        
        const handleFollowupClick = (followupQuery, intent) => {
            handleQuery(followupQuery, false, intent);
        };

        const handleSubmit = (e) => {
            e.preventDefault();
            if (query.trim()) {
                handleQuery(query);
                setQuery('');
                setTimeout(() => inputRef.current?.focus(), 100);
            }
        }
        
        const handleKeyDown = (event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                handleSubmit(event);
            }
        };


        const renderContent = (content) => {
            if (!content) return null;
            const parts = content.split(/(\*\*.*?\*\*|\n)/g);
            return parts.map((part, i) => {
                if (part === '\n') {
                    return <br key={i} />;
                }
                if (part.startsWith('**') && part.endsWith('**')) {
                    return <strong key={i}>{part.slice(2, -2)}</strong>;
                }
                return part;
            });
        };
        
        const renderAlternativeCard = (msg) => (
            <Card className="bg-muted/50">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                        <Search className="h-5 w-5 text-amber-500" />
                        {t('noExactResults')}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="mb-2">{renderContent(msg.answer)}</p>
                     {msg.bullets?.length > 0 && (
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        {msg.bullets.map((bullet, i) => <li key={i}>{renderContent(bullet)}</li>)}
                      </ul>
                    )}
                     {msg.sources?.[0]?.title && (
                        <div className="mt-3 pt-3 border-t">
                            <h4 className="text-xs font-bold text-muted-foreground mb-2">{t('sourcesTitle')}:</h4>
                            <Badge variant="secondary"><FileText className="h-3 w-3 mr-1.5" />{msg.sources[0].title}</Badge>
                        </div>
                    )}
                     {msg.followups?.length > 0 && (
                      <div className="mt-3 pt-3 border-t">
                           <h4 className="text-xs font-bold text-muted-foreground mb-2">{t('followupsTitle')}:</h4>
                           <div className="flex flex-wrap gap-2">
                             {msg.followups.map((fu, i) => (
                               <Button key={i} size="sm" variant="outline" onClick={() => handleFollowupClick(fu.query, fu.intent)} className="text-xs">
                                 <Lightbulb className="mr-2 h-3 w-3" />
                                 {fu.label}
                               </Button>
                             ))}
                           </div>
                      </div>
                    )}
                </CardContent>
            </Card>
        );

        const renderProductionReport = (msg) => {
            const { report } = msg;
            if (!report || report.length === 0) return null;
        
            return (
                <div className="flex justify-start mb-4">
                    <div className="bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-lg py-3 px-4 max-w-lg w-full">
                        <div className="prose prose-sm dark:prose-invert max-w-none">
                            <p className="font-semibold text-base mb-4">{msg.answer}</p>
                            <Accordion type="multiple" defaultValue={report.map((_, i) => `item-${i}`)} className="w-full">
                                {report.map((item, index) => (
                                    <AccordionItem value={`item-${index}`} key={index} className="border-b-0">
                                        <Card className="bg-background/70 mb-3 shadow-sm">
                                            <AccordionTrigger className="p-4 text-left hover:no-underline">
                                                <div className="flex-1">
                                                    <p className="font-bold text-primary text-base">🌱 {item.group.crop} - {item.group.region}</p>
                                                    {item.group.season && <p className="text-xs text-muted-foreground mt-1">📅 Safra: {item.group.season}</p>}
                                                </div>
                                            </AccordionTrigger>
                                            <AccordionContent className="px-4 pb-4">
                                                <div className="space-y-3">
                                                    {Object.entries(item.systems).map(([system, stats]) => (
                                                        <div key={system}>
                                                            <p className="font-semibold text-sm mb-2">▸ Sistema {system}</p>
                                                            <ul className="list-none pl-4 text-sm space-y-1 text-muted-foreground">
                                                                <li><span className="font-medium text-foreground">Máximo:</span> {stats.max.toFixed(2)} ton/ha</li>
                                                                <li><span className="font-medium text-foreground">Mínimo:</span> {stats.min.toFixed(2)} ton/ha</li>
                                                                <li><span className="font-medium text-foreground">Promedio:</span> {stats.avg.toFixed(2)} ton/ha</li>
                                                            </ul>
                                                        </div>
                                                    ))}
                                                </div>
                                            </AccordionContent>
                                        </Card>
                                    </AccordionItem>
                                ))}
                            </Accordion>
                        </div>
                        {msg.followups?.length > 0 && (
                            <div className="mt-4 pt-3 border-t border-gray-300 dark:border-gray-600">
                                <h4 className="text-xs font-bold text-muted-foreground mb-2">{t('followupsTitle')}:</h4>
                                <div className="flex flex-wrap gap-2">
                                    {msg.followups.map((fu, i) => (
                                        <Button key={i} size="sm" variant="outline" onClick={() => handleFollowupClick(fu.query, fu.intent)} className="text-xs">
                                            <Lightbulb className="mr-2 h-3 w-3" />
                                            {fu.label}
                                        </Button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            );
        };

        const renderMessage = (msg, index) => {
            if (msg.isWelcome) {
                return (
                    <Alert key={msg.id || index} className="mb-4 bg-blue-50 border-blue-200 dark:bg-blue-900/30 dark:border-blue-700">
                        <Sparkles className="h-4 w-4 text-blue-500" />
                        <AlertTitle className="text-blue-800 dark:text-blue-300">{t('welcomeTitle')}</AlertTitle>
                        <AlertDescription className="text-blue-700 dark:text-blue-400">
                            {msg.content}
                        </AlertDescription>
                    </Alert>
                );
            }

            if (msg.type === 'user') {
                return (
                    <div key={msg.id || index} className="flex justify-end mb-4">
                        <div className="bg-primary text-primary-foreground rounded-lg py-2 px-4 max-w-sm">
                            {msg.content}
                        </div>
                    </div>
                );
            }
            
            if (msg.isError) {
                 return (
                    <div key={msg.id || index} className="flex justify-start mb-4">
                        <div className="bg-red-100 dark:bg-red-900/50 border border-red-300 dark:border-red-700 text-gray-800 dark:text-gray-200 rounded-lg py-2 px-4 max-w-lg">
                            <div className="prose prose-sm dark:prose-invert max-w-none flex items-start gap-2">
                                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                                <div>
                                    <p>{msg.answer}</p>
                                    {msg.isRetryable && (
                                        <Button variant="outline" size="sm" onClick={() => retryQuery(msg.query)} className="mt-3">
                                            <RotateCcw className="mr-2 h-4 w-4" />
                                            {t('common:retry')}
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                );
            }
            
            if (msg.stage === 'no_results' || msg.stage?.includes('fallback')) {
                 return <div key={msg.id || index} className="mb-4">{renderAlternativeCard(msg)}</div>;
            }

            if (msg.stage === 'clarification_needed') {
                return (
                  <div key={msg.id || index} className="flex justify-start mb-4">
                    <div className="bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg py-2 px-4 max-w-lg">
                        <div className="prose prose-sm dark:prose-invert max-w-none flex items-start gap-2">
                            <HelpCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                            <div>{renderContent(msg.answer)}</div>
                        </div>
                        {msg.followups?.length > 0 && (
                            <div className="mt-3 pt-3 border-t border-gray-300 dark:border-gray-600">
                               <div className="flex flex-wrap gap-2">
                                 {msg.followups.map((fu, i) => (
                                   <Button key={i} size="sm" variant="outline" onClick={() => handleFollowupClick(fu.query, fu.intent)} className="text-xs">
                                     <Lightbulb className="mr-2 h-3 w-3" />
                                     {fu.label}
                                   </Button>
                                 ))}
                               </div>
                            </div>
                        )}
                    </div>
                  </div>
                );
            }

            if (msg.type === 'ai') {
                if (msg.intent === 'PRODUCTION' && msg.report) {
                    return renderProductionReport(msg);
                }

                const hasSources = msg.sources && msg.sources.length > 0;
                const hasFollowups = msg.followups && msg.followups.length > 0;
                const hasBullets = msg.bullets && msg.bullets.length > 0;

                return (
                    <div key={msg.id || index} className="flex justify-start mb-4">
                        <div className="bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg py-2 px-4 max-w-lg">
                            <div className="prose prose-sm dark:prose-invert max-w-none flex items-start gap-2">
                               <Sparkles className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                               <div>{renderContent(msg.answer)}</div>
                            </div>
                             {hasBullets && (
                              <ul className="list-none pl-0 mt-2 space-y-1">
                                {msg.bullets.map((bullet, i) => <li key={i}>{renderContent(bullet)}</li>)}
                              </ul>
                            )}
                            {hasSources && (
                                <div className="mt-3 pt-3 border-t border-gray-300 dark:border-gray-600">
                                    <h4 className="text-xs font-bold text-gray-500 dark:text-gray-400 mb-2">{t('sourcesTitle')}:</h4>
                                    <div className="flex flex-wrap gap-2">
                                        {msg.sources.map((source, i) => (
                                          <Badge key={source.id || i} variant="secondary" className="flex items-center gap-1.5">
                                            <FileText className="h-3 w-3" />
                                            {source.title || t('untitledSource')}
                                          </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                            {hasFollowups && (
                              <div className="mt-3 pt-3 border-t border-gray-300 dark:border-gray-600">
                                   <h4 className="text-xs font-bold text-gray-500 dark:text-gray-400 mb-2">{t('followupsTitle')}:</h4>
                                   <div className="flex flex-wrap gap-2">
                                     {msg.followups.map((fu, i) => (
                                       <Button key={i} size="sm" variant="outline" onClick={() => handleFollowupClick(fu.query, fu.intent)} className="text-xs">
                                         <Lightbulb className="mr-2 h-3 w-3" />
                                         {fu.label}
                                       </Button>
                                     ))}
                                   </div>
                              </div>
                            )}
                        </div>
                    </div>
                );
            }
            return null;
        };


        return (
            <div className="flex flex-col h-full bg-background">
                <ScrollArea className="flex-grow" ref={scrollAreaRef}>
                    <div className="p-4" style={{ paddingBottom: '88px' }}>
                        {messages.map(renderMessage)}
                        {isLoading && (
                            <div className="flex justify-start mb-4">
                                <div className="bg-muted rounded-lg p-3">
                                    <Loader2 className="animate-spin w-5 h-5 text-muted-foreground" />
                                </div>
                            </div>
                        )}
                        {error && !messages.some(m => m.isError) && (
                             <Alert variant="destructive">
                                <AlertCircle className="h-4 w-4" />
                                <AlertTitle>Error</AlertTitle>
                                <AlertDescription>
                                  {error.message}
                                  <Button variant="ghost" size="sm" onClick={() => retryQuery(error.query)} className="mt-2">
                                    <RotateCcw className="mr-2 h-4 w-4" />
                                    {t('common:retry')}
                                  </Button>
                                </AlertDescription>
                            </Alert>
                        )}
                    </div>
                </ScrollArea>
                <div className="flex-shrink-0 p-4 border-t bg-background sticky bottom-0 z-[2001] shadow-inner" style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom, 0px))' }}>
                    <form onSubmit={handleSubmit} className="relative">
                        <Textarea
                            ref={inputRef}
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder={t('chatPlaceholder')}
                            className="pr-12 min-h-[48px] max-h-48 resize-y"
                            rows={1}
                            disabled={isLoading}
                        />
                        <Button type="submit" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8" disabled={isLoading || !query.trim()}>
                            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                            <span className="sr-only">{t('common:buttons.send')}</span>
                        </Button>
                    </form>
                </div>
            </div>
        );
    };

    export default AiChatTab;