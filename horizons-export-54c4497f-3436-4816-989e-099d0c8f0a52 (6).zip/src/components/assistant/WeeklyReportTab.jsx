import React from 'react';
    import { useQuery } from '@tanstack/react-query';
    import { supabase } from '@/lib/supabase-helpers';
    import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
    import { Loader2, AlertTriangle, CheckCircle, CalendarClock, Info } from 'lucide-react';
    import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
    import { useTranslation } from 'react-i18next';

    const fetchWeeklyReport = async () => {
        const { data, error } = await supabase.rpc('get_weekly_activity_report');
        if (error) throw error;
        return data && data.length > 0 ? data[0] : { completed_last_week: [], pending_last_week: [], planned_next_week: [] };
    };

    const ActivityList = ({ title, activities, icon: Icon, color, emptyMessage }) => (
        <Card>
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 text-base ${color}`}><Icon /> {title}</CardTitle>
          </CardHeader>
          <CardContent>
            {!activities || activities.length === 0 ? (
              <p className="text-sm text-muted-foreground p-4 text-center">{emptyMessage}</p>
            ) : (
              <ul className="space-y-2">
                {activities.map((activity) => (
                  <li key={activity.activity_id} className="text-sm p-2 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                    <strong>{activity.activity_type}</strong> para {activity.client_name || 'N/A'} (Asignado a: {activity.user_email || 'N/A'})
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
    );

    const WeeklyReportTab = () => {
      const { t } = useTranslation('assistant');
      const { data, isLoading, isError, error } = useQuery({
        queryKey: ['weeklyReport'],
        queryFn: fetchWeeklyReport,
      });

      if (isLoading) {
        return <div className="flex justify-center items-center h-full p-4"><Loader2 className="h-8 w-8 animate-spin" /></div>;
      }

      if (isError) {
        return (
            <div className="p-4">
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>{t('errors.loadReportTitle')}</AlertTitle>
                    <AlertDescription>{error.message}</AlertDescription>
                </Alert>
            </div>
        );
      }

      const allEmpty = !data || (data.completed_last_week.length === 0 && data.pending_last_week.length === 0 && data.planned_next_week.length === 0);

      if (allEmpty) {
        return (
            <div className="flex flex-col items-center justify-center h-full p-4 text-center">
                <Info className="h-12 w-12 text-blue-500 mb-4" />
                <h3 className="font-semibold text-lg">{t('report.allClearTitle')}</h3>
                <p className="text-muted-foreground">{t('report.allClearMessage')}</p>
            </div>
        );
      }

      return (
        <div className="space-y-4 p-4">
          <ActivityList title={t('report.completed')} activities={data?.completed_last_week} icon={CheckCircle} color="text-green-600" emptyMessage={t('report.noCompleted')} />
          <ActivityList title={t('report.pending')} activities={data?.pending_last_week} icon={AlertTriangle} color="text-red-600" emptyMessage={t('report.noPending')} />
          <ActivityList title={t('report.planned')} activities={data?.planned_next_week} icon={CalendarClock} color="text-blue-600" emptyMessage={t('report.noPlanned')} />
        </div>
      );
    };

    export default WeeklyReportTab;