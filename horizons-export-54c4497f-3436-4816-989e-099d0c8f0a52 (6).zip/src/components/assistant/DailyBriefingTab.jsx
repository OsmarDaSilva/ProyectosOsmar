import React from 'react';
    import { useQuery } from '@tanstack/react-query';
    import { supabase } from '@/lib/supabase-helpers';
    import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
    import { Loader2, AlertTriangle, CalendarCheck, Bell, ListTodo, Info } from 'lucide-react';
    import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
    import { useTranslation } from 'react-i18next';

    const fetchBriefingData = async () => {
        const { data, error } = await supabase.rpc('get_daily_briefing');
        if (error) throw error;
        return data && data.length > 0 ? data[0] : { todays_activities: [], recent_alerts: [], overdue_activities: [] };
    };

    const DailyBriefingTab = () => {
      const { t } = useTranslation('assistant');
      const { data, isLoading, isError, error } = useQuery({
        queryKey: ['dailyBriefing'],
        queryFn: fetchBriefingData,
      });

      const renderList = (items, emptyMessage) => {
        if (!items || items.length === 0) {
          return <p className="text-sm text-muted-foreground p-4 text-center">{emptyMessage}</p>;
        }
        return (
          <ul className="space-y-2">
            {items.map((item, index) => (
              <li key={item.id || index} className="text-sm p-2 bg-gray-50 dark:bg-gray-700/50 rounded-md">
                {item.notes || item.description || t('noDetails')}
              </li>
            ))}
          </ul>
        );
      };

      if (isLoading) {
        return <div className="flex justify-center items-center h-full p-4"><Loader2 className="h-8 w-8 animate-spin" /></div>;
      }

      if (isError) {
        return (
            <div className="p-4">
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>{t('errors.loadBriefingTitle')}</AlertTitle>
                    <AlertDescription>{error.message}</AlertDescription>
                </Alert>
            </div>
        );
      }

      const allEmpty = !data || (data.todays_activities.length === 0 && data.recent_alerts.length === 0 && data.overdue_activities.length === 0);

      if (allEmpty) {
        return (
            <div className="flex flex-col items-center justify-center h-full p-4 text-center">
                <Info className="h-12 w-12 text-blue-500 mb-4" />
                <h3 className="font-semibold text-lg">{t('briefing.allClearTitle')}</h3>
                <p className="text-muted-foreground">{t('briefing.allClearMessage')}</p>
            </div>
        );
      }

      return (
        <div className="space-y-4 p-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><CalendarCheck /> {t('briefing.todayTasks')}</CardTitle>
            </CardHeader>
            <CardContent>
              {renderList(data?.todays_activities, t('briefing.noTodayTasks'))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Bell /> {t('briefing.recentAlerts')}</CardTitle>
            </CardHeader>
            <CardContent>
             {renderList(data?.recent_alerts, t('briefing.noRecentAlerts'))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><ListTodo /> {t('briefing.overdueTasks')}</CardTitle>
            </CardHeader>
            <CardContent>
             {renderList(data?.overdue_activities, t('briefing.noOverdueTasks'))}
            </CardContent>
          </Card>
        </div>
      );
    };

    export default DailyBriefingTab;