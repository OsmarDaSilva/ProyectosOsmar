import React, { useState } from 'react';
    import { useQuery } from '@tanstack/react-query';
    import { supabase } from '@/lib/supabase-helpers';
    import { Input } from '@/components/ui/input';
    import { Loader2, Search, FileText, ServerCrash } from 'lucide-react';
    import { useDebounce } from '@/hooks/useDebounce';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { useTranslation } from 'react-i18next';
    import { Badge } from '@/components/ui/badge';
    import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
    import { AlertTriangle } from 'lucide-react';

    const searchKnowledgeBase = async (searchTerm) => {
      if (!searchTerm) return [];
      const { data, error } = await supabase.rpc('search_knowledge_base', { search_term: searchTerm });
      if (error) throw error;
      return data || [];
    };

    const KnowledgeBaseTab = () => {
      const { t } = useTranslation('assistant');
      const [searchTerm, setSearchTerm] = useState('');
      const debouncedSearchTerm = useDebounce(searchTerm, 500);

      const { data: results, isLoading, isError, error, isFetching } = useQuery({
        queryKey: ['kbSearch', debouncedSearchTerm],
        queryFn: () => searchKnowledgeBase(debouncedSearchTerm),
        enabled: !!debouncedSearchTerm,
      });

      return (
        <div className="p-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t('kb.searchPlaceholder')}
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {(isLoading || isFetching) && <Loader2 className="absolute right-2.5 top-2.5 h-4 w-4 animate-spin" />}
          </div>
          <div>
            {isError && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>{t('errors.kbSearchTitle')}</AlertTitle>
                <AlertDescription>{error.message}</AlertDescription>
              </Alert>
            )}
            {results && results.length > 0 && (
              <div className="space-y-2">
                {results.map(item => (
                    <Card key={item.id}>
                        <CardHeader>
                            <CardTitle className="text-base flex items-center gap-2">
                                <FileText className="text-primary"/>
                                {item.title}
                            </CardTitle>
                            {item.file_url && (
                              <CardDescription>
                                <a href={item.file_url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{t('kb.viewFile')}</a>
                              </CardDescription>
                            )}
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-muted-foreground line-clamp-3">{item.content}</p>
                             {item.tags && item.tags.length > 0 && (
                                <div className="mt-2 flex flex-wrap gap-1">
                                    {item.tags.map(tag => (
                                        <Badge key={tag} variant="secondary">{tag}</Badge>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                ))}
              </div>
            )}
            {results && results.length === 0 && debouncedSearchTerm && !isFetching && !isError && (
              <div className="text-center text-muted-foreground py-10">
                <ServerCrash className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="font-semibold">{t('kb.noResults', { term: debouncedSearchTerm })}</p>
                <p className="text-sm">{t('kb.noResultsHint')}</p>
              </div>
            )}
             {!debouncedSearchTerm && (
              <div className="text-center text-muted-foreground py-10">
                <Search className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="font-semibold">{t('kb.prompt')}</p>
                <p className="text-sm">{t('kb.promptHint')}</p>
              </div>
            )}
          </div>
        </div>
      );
    };

    export default KnowledgeBaseTab;