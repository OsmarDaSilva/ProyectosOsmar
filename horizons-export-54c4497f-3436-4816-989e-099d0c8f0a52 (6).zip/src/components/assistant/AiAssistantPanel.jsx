import React from 'react';
import { createPortal } from 'react-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bot, MessageSquare, Calendar, BookOpen, BarChart2, X } from 'lucide-react';
import AiChatTab from '@/components/assistant/AiChatTab';
import DailyBriefingTab from '@/components/assistant/DailyBriefingTab';
import WeeklyReportTab from '@/components/assistant/WeeklyReportTab';
import KnowledgeBaseTab from '@/components/assistant/KnowledgeBaseTab';
import { useTranslation } from 'react-i18next';
import { useGlobalAssistant } from '@/contexts/GlobalAssistantContext';
import { Button } from '@/components/ui/button';

const AiAssistantPanel = () => {
  const { t } = useTranslation('assistant');
  const { isOpen, closeAssistant } = useGlobalAssistant();

  const tabs = [
    { value: 'chat', label: t('tabs.chat'), icon: MessageSquare, component: <AiChatTab isOpen={isOpen} /> },
    { value: 'daily-briefing', label: t('tabs.daily'), icon: Calendar, component: <DailyBriefingTab /> },
    { value: 'weekly-report', label: t('tabs.weekly'), icon: BarChart2, component: <WeeklyReportTab /> },
    { value: 'knowledge-base', label: t('tabs.kb'), icon: BookOpen, component: <KnowledgeBaseTab /> },
  ];

  if (!isOpen) return null;

  return createPortal(
    <>
      <div className="fixed inset-0 bg-black/30 z-[2000]" onClick={closeAssistant} />
      <div 
        className="fixed top-0 right-0 w-full max-w-md bg-background shadow-2xl border-l border-border flex flex-col"
        style={{ height: '100dvh', zIndex: 2000 }}
      >
        <div className="p-4 border-b flex items-center justify-between flex-shrink-0 relative">
          <div className="flex items-center">
            <Bot className="w-8 h-8 text-primary mr-3" />
            <div>
              <h2 className="text-xl font-bold">{t('mainTitle')}</h2>
              <p className="text-sm text-muted-foreground">{t('subtitle')}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={closeAssistant} className="absolute top-2 right-2 h-10 w-10 z-[2001]">
            <X className="h-5 w-5" />
            <span className="sr-only">Cerrar asistente</span>
          </Button>
        </div>
        <Tabs defaultValue="chat" className="flex-grow flex flex-col min-h-0">
          <TabsList className="flex-shrink-0 grid w-full grid-cols-4 rounded-none border-b">
            {tabs.map((tab) => (
              <TabsTrigger key={tab.value} value={tab.value} className="flex-col h-16">
                <tab.icon className="w-5 h-5 mb-1" />
                <span className="text-xs">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
          {tabs.map((tab) => (
            <TabsContent key={tab.value} value={tab.value} className="flex-grow m-0 p-0 overflow-hidden">
              {tab.component}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </>,
    document.getElementById('portal-root')
  );
};

export default AiAssistantPanel;