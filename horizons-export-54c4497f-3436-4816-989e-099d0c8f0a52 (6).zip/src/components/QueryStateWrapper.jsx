import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, AlertTriangle, WifiOff } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const QueryStateWrapper = ({ isLoading, isError, error, data, onRetry, loader, children }) => {
  const { t } = useTranslation('common');

  if (isLoading) {
    return loader || (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-green-600" />
      </div>
    );
  }

  const isNetworkError = error && error.message && error.message.toLowerCase().includes('failed to fetch');

  if (isError) {
    return (
      <Card className="border-red-500 bg-red-50 dark:bg-red-900/20">
        <CardHeader>
            <div className="flex items-center gap-3">
                {isNetworkError ? <WifiOff className="h-6 w-6 text-red-600 dark:text-red-400" /> : <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />}
                <CardTitle className="text-red-800 dark:text-red-300">{isNetworkError ? t('errors.connectionTitle') : t('errors.genericTitle')}</CardTitle>
            </div>
            <CardDescription className="text-red-700 dark:text-red-400">
                {isNetworkError 
                    ? t('errors.connectionMessage')
                    : `${t('errors.genericMessage')} ${error.message || t('errors.unknown')}`}
            </CardDescription>
        </CardHeader>
        {onRetry && (
            <CardContent>
                <Button onClick={onRetry} variant="destructive">
                    {isNetworkError ? t('actions.retryConnection') : t('actions.retryLoad')}
                </Button>
            </CardContent>
        )}
      </Card>
    );
  }

  if (typeof children === 'function') {
    return children(data);
  }

  return children;
};

export default QueryStateWrapper;