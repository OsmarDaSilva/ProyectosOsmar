import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { TableCell, TableRow } from '@/components/ui/table';
import { Save, XCircle, Edit, Trash2 } from 'lucide-react';

export const AddEditProductionRow = ({ row, onSave, onCancel, onEdit, onDelete, isEditing = false }) => {
    const [localRow, setLocalRow] = useState(row);

    const handleInputChange = (e, field) => {
        let value = e.target.value;
        if (field === 'year') {
            value = parseInt(value, 10) || ''; // Ensure year is an integer
        }
        setLocalRow({ ...localRow, [field]: value });
    };
    
    const renderCell = (field) => (
        <TableCell>
            <Input
                type={field === 'year' ? 'number' : (typeof localRow[field] === 'number' ? 'number' : 'text')}
                value={localRow[field]}
                onChange={(e) => handleInputChange(e, field)}
                className="h-8 min-w-[100px]"
            />
        </TableCell>
    );

    const getNumericValue = (value) => parseFloat(String(value).replace(',', '.')) || 0;

    const calculateNormalCost = (row) => {
        return getNumericValue(row.input_cost_ha) + getNumericValue(row.machinery_cost_ha) + getNumericValue(row.freight_cost_ha);
    };

    const calculateFinalCost = (row) => {
        const normalCost = calculateNormalCost(row);
        const otherCosts = getNumericValue(row.land_rent_ha) + getNumericValue(row.electrical_energy_cost_ha) + getNumericValue(row.maintenance_repair_cost_ha);
        return normalCost + otherCosts;
    };

    const formatCurrency = (value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);

    if (!isEditing) {
        return (
            <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => onEdit(row)}><Edit className="h-4 w-4" /></Button>
                <Button size="sm" variant="destructive" onClick={() => onDelete(row.id)}><Trash2 className="h-4 w-4" /></Button>
            </div>
        )
    }
    
    return (
        <TableRow className="bg-green-50">
            {renderCell('country')}
            {renderCell('department_province')}
            {renderCell('city_locality')}
            {renderCell('year')}
            {renderCell('Cultura')}
            {renderCell('production_purpose')}
            {renderCell('Época Siembra')}
            {renderCell('cultivation_method')}
            {renderCell('Prod. (ton/ha)')}
            {renderCell('input_cost_ha')}
            {renderCell('machinery_cost_ha')}
            {renderCell('freight_cost_ha')}
            <TableCell className="font-semibold text-blue-700">{formatCurrency(calculateNormalCost(localRow))}</TableCell>
            {renderCell('land_rent_ha')}
            {renderCell('electrical_energy_cost_ha')}
            {renderCell('maintenance_repair_cost_ha')}
            <TableCell className="font-bold text-green-700">{formatCurrency(calculateFinalCost(localRow))}</TableCell>
            <TableCell className="sticky right-0 bg-green-50 z-10">
                <div className="flex gap-2">
                    <Button size="sm" onClick={() => onSave(localRow)}><Save className="h-4 w-4" /></Button>
                    <Button size="sm" variant="outline" onClick={onCancel}><XCircle className="h-4 w-4" /></Button>
                </div>
            </TableCell>
        </TableRow>
    );
};