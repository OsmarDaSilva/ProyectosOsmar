import React, { useState, useEffect, useMemo, useCallback } from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Loader2 } from 'lucide-react';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from "@/components/ui/use-toast";
    import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
    import QuoteForm from './quote-dialog/QuoteForm';
    import QuoteItems from './quote-dialog/QuoteItems';
    import QuoteTotals from './quote-dialog/QuoteTotals';
    import { useTranslation } from 'react-i18next';
    import { toNumberSafe, round2 } from '@/lib/utils';

    const AddEditQuoteDialog = ({ isOpen, setIsOpen, quote, onSave, clients, isLoading }) => {
        const { user } = useAuth();
        const { toast } = useToast();
        const queryClient = useQueryClient();
        const { t } = useTranslation('support');
        const [formData, setFormData] = useState({});
        const [items, setItems] = useState([]);
        const [discountPercentage, setDiscountPercentage] = useState(0);

        const [kmQuantity, setKmQuantity] = useState(0);
        const [kmPrice, setKmPrice] = useState(0);
        const [laborQuantity, setLaborQuantity] = useState(0);
        const [laborPrice, setLaborPrice] = useState(0);
        
        const { data: deposits, isLoading: isLoadingDeposits } = useQuery({
            queryKey: ['deposits'],
            queryFn: async () => {
                const { data, error } = await supabase.from('deposits').select('id, name');
                if (error) throw error;
                return data;
            },
        });
        
        const approveQuoteMutation = useMutation({
            mutationFn: async (quoteId) => {
                const { data, error } = await supabase.rpc('approve_quote_and_create_so', { p_quote_id: quoteId });
                if (error) throw error;
                return data;
            },
            onSuccess: () => {
                toast({
                    title: t("quoteDialog.approvedTitle"),
                    description: t("quoteDialog.approvedDescription"),
                });
                queryClient.invalidateQueries({ queryKey: ['quotes'] });
                queryClient.invalidateQueries({ queryKey: ['service_orders'] });
                queryClient.invalidateQueries({ queryKey: ['v_stock_per_deposit_summary'] });
                setIsOpen(false);
            },
            onError: (error) => {
                toast({
                    variant: "destructive",
                    title: t("quoteDialog.approveErrorTitle"),
                    description: error.message,
                });
            },
        });

        const handleSaveAndApprove = async (dataToSave) => {
            const { data: savedQuote, error } = await supabase
                .from('quotes')
                .upsert(dataToSave)
                .select()
                .single();

            if (error) {
                toast({ variant: "destructive", title: t("common:error"), description: t("quoteDialog.saveError", { error: error.message }) });
                return;
            }

            approveQuoteMutation.mutate(savedQuote.id);
        };
        
        const totals = useMemo(() => {
            const itemsTotal = items.reduce((s, i) => s + toNumberSafe(i.quantity) * toNumberSafe(i.price), 0);
            const kmTotal = toNumberSafe(kmQuantity) * toNumberSafe(kmPrice);
            const laborTotal = toNumberSafe(laborQuantity) * toNumberSafe(laborPrice);
            
            const grossTotal = itemsTotal + kmTotal + laborTotal;
            const discountAmount = round2(grossTotal * (toNumberSafe(discountPercentage) / 100));
            const totalWithDiscount = grossTotal - discountAmount;
            
            const taxAmount = round2(totalWithDiscount / 11);
            const netAmount = totalWithDiscount - taxAmount;
            
            return {
              itemsTotal: round2(itemsTotal),
              kmTotal: round2(kmTotal),
              laborTotal: round2(laborTotal),
              subtotal: round2(grossTotal),
              discountAmount,
              taxAmount,
              netAmount,
              total: round2(totalWithDiscount),
            };
        }, [items, kmQuantity, kmPrice, laborQuantity, laborPrice, discountPercentage]);

        const fetchNextQuoteNumber = useCallback(async () => {
            if (!quote) { 
              const { data, error } = await supabase
                .from('quotes')
                .select('quote_number')
                .order('quote_number', { ascending: false })
                .limit(1)
                .single();
        
              if (error && error.code !== 'PGRST116') {
                toast({
                  variant: "destructive",
                  title: t("common:error"),
                  description: t("quoteDialog.numberError"),
                });
                return 1;
              }
              
              return (data?.quote_number || 0) + 1;
            }
            return quote.quote_number;
          }, [quote, toast, t]);

        useEffect(() => {
            const initializeForm = async () => {
                if (isOpen) {
                    if (quote) {
                        setFormData({
                            id: quote.id,
                            quote_number: quote.quote_number,
                            manual_quote_number: quote.manual_quote_number || '',
                            client_id: quote.client_id || null,
                            status: quote.status || 'Borrador',
                            notes: quote.notes || '',
                            created_at: quote.created_at,
                        });
                        setItems(quote.items.map(i => ({...i, deposit_id: i.deposit_id || null})) || []);
                        setDiscountPercentage(quote.discount_percentage || 0);
                        setKmQuantity(quote.km_quantity || 0);
                        setKmPrice(quote.km_price || 0);
                        setLaborQuantity(quote.labor_quantity || 0);
                        setLaborPrice(quote.labor_price || 0);
                    } else {
                        const nextNumber = await fetchNextQuoteNumber();
                        setFormData({
                            quote_number: nextNumber,
                            manual_quote_number: '',
                            client_id: null,
                            status: 'Borrador',
                            notes: '',
                        });
                        setItems([]);
                        setDiscountPercentage(0);
                        setKmQuantity(0);
                        setKmPrice(0);
                        setLaborQuantity(0);
                        setLaborPrice(0);
                    }
                }
            };
            initializeForm();
        }, [quote, isOpen, fetchNextQuoteNumber]);

        const handleSubmit = (e) => {
            e.preventDefault();
            if (!formData.client_id) {
                toast({
                    variant: "destructive",
                    title: t("quoteDialog.requiredField"),
                    description: t("quoteDialog.clientRequired"),
                });
                return;
            }

            const isNew = !quote?.id;
            const isBeingApproved = formData.status === 'Aceptado' && quote?.status !== 'Aceptado';
            
            const dataToSave = {
                ...formData,
                user_id: user.id,
                items: items.map(i => ({...i, quantity: toNumberSafe(i.quantity), price: toNumberSafe(i.price)})),
                km_quantity: toNumberSafe(kmQuantity),
                km_price: toNumberSafe(kmPrice),
                labor_quantity: toNumberSafe(laborQuantity),
                labor_price: toNumberSafe(laborPrice),
                discount_percentage: toNumberSafe(discountPercentage),
            };

            if (isNew && formData.status === 'Aceptado') {
                handleSaveAndApprove(dataToSave);
            } else if (!isNew && isBeingApproved) {
                if (quote.status !== 'Aceptado') {
                    approveQuoteMutation.mutate(quote.id);
                } else {
                    toast({
                        variant: "destructive",
                        title: t("quoteDialog.actionNotAllowed"),
                        description: t("quoteDialog.alreadyAccepted"),
                    });
                    onSave(dataToSave);
                }
            } else {
                onSave(dataToSave);
            }
        };

        return (
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="sm:max-w-7xl">
                    <form id="quote-form" onSubmit={handleSubmit}>
                        <DialogHeader>
                            <DialogTitle>{quote ? t("quoteDialog.editTitle") : t("quoteDialog.createTitle")}</DialogTitle>
                            <DialogDescription>{t("quoteDialog.addDescription")}</DialogDescription>
                        </DialogHeader>
                        <ScrollArea className="h-[70vh] pr-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
                                <QuoteForm
                                    formData={formData}
                                    setFormData={setFormData}
                                    clients={clients}
                                />
                                <div className="md:col-span-2 space-y-4">
                                    <QuoteItems
                                        items={items}
                                        setItems={setItems}
                                        deposits={deposits}
                                        isLoadingDeposits={isLoadingDeposits}
                                        setKmQuantity={setKmQuantity}
                                        setKmPrice={setKmPrice}
                                        setLaborQuantity={setLaborQuantity}
                                        setLaborPrice={setLaborPrice}
                                        kmQuantity={kmQuantity}
                                        kmPrice={kmPrice}
                                        laborQuantity={laborQuantity}
                                        laborPrice={laborPrice}
                                        kmTotal={totals.kmTotal}
                                        laborTotal={totals.laborTotal}
                                    />
                                    <QuoteTotals
                                        netAmount={totals.netAmount}
                                        subtotal={totals.subtotal}
                                        discountAmount={totals.discountAmount}
                                        discountPercentage={discountPercentage}
                                        setDiscountPercentage={setDiscountPercentage}
                                        taxAmount={totals.taxAmount}
                                        total={totals.total}
                                    />
                                </div>
                            </div>
                        </ScrollArea>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={() => setIsOpen(false)} disabled={isLoading || approveQuoteMutation.isPending}>{t("common:cancel")}</Button>
                            <Button type="submit" form="quote-form" disabled={isLoading || approveQuoteMutation.isPending}>
                                {(isLoading || approveQuoteMutation.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {t("quoteDialog.saveQuote")}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        );
    };

    export default AddEditQuoteDialog;