import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Loader2 } from 'lucide-react';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from "@/components/ui/use-toast";
    import { toNumberSafe, round2 } from '@/lib/utils';
    import { useTranslation } from 'react-i18next';
    import { format } from 'date-fns';

    import PurchaseOrderForm from './purchase-order-dialog/PurchaseOrderForm';
    import PurchaseOrderItems from './purchase-order-dialog/PurchaseOrderItems';
    import PurchaseOrderTotals from './purchase-order-dialog/PurchaseOrderTotals';

    const fetchOrderDetails = async (orderId) => {
        if (!orderId) return null;
        const { data: order, error: orderError } = await supabase
            .from('purchase_orders')
            .select('*, supplier:suppliers(id, name)')
            .eq('id', orderId)
            .single();
        if (orderError) throw orderError;

        const { data: items, error: itemsError } = await supabase
            .from('purchase_order_items')
            .select('*')
            .eq('po_id', orderId);
        if (itemsError) throw itemsError;
        
        return { ...order, items };
    };

    const savePurchaseOrder = async ({ orderData, items, user }) => {
        if (!user || !user.id) {
            throw new Error("Información de usuario no disponible. Por favor, inicie sesión de nuevo.");
        }
        
        const { data: savedOrder, error } = await supabase.rpc('save_purchase_order', {
          p_user_id: user.id,
          p_supplier_id: orderData.supplier_id,
          p_status: orderData.status,
          p_notes: orderData.notes,
          p_due_date: orderData.due_date ? format(new Date(orderData.due_date), 'yyyy-MM-dd') : null,
          p_items: items.map(it => ({
            sku: it.sku,
            qty: toNumberSafe(it.quantity),
            unit_price_purchase: toNumberSafe(it.purchase_price),
            product_name: it.product_name,
          })),
          p_discount_percentage: 0
        });

        if (error) throw error;

        return { id: savedOrder[0].order_id };
    };

    function AddEditPurchaseOrderDialog({ isOpen, setIsOpen, purchaseOrderId }) {
        const { user } = useAuth();
        const queryClient = useQueryClient();
        const { toast } = useToast();
        const { t } = useTranslation('support');

        const { data: purchaseOrder, isLoading: isLoadingOrder } = useQuery({
            queryKey: ['purchaseOrderDetails', purchaseOrderId],
            queryFn: () => fetchOrderDetails(purchaseOrderId),
            enabled: !!purchaseOrderId && isOpen,
        });

        const [formData, setFormData] = useState({});
        const [items, setItems] = useState([]);
        const [selectedSupplier, setSelectedSupplier] = useState(null);
        
        const initializeForm = useCallback((order) => {
            if (order) {
                setFormData({
                    id: order.id,
                    order_number: order.order_number,
                    supplier_id: order.supplier_id || null,
                    status: order.status || 'Borrador',
                    notes: order.notes || '',
                    due_date: order.due_date || '',
                });
                if (order.supplier) {
                  setSelectedSupplier(order.supplier);
                }
                setItems(order.items.map(item => ({
                    ...item,
                    product_name: item.product_name_snapshot,
                    purchase_price: item.purchase_price || item.unit_price || 0,
                    quantity: item.quantity,
                })) || []);
            } else {
                setFormData({ id: undefined, supplier_id: null, status: 'Borrador', notes: '', due_date: new Date().toISOString().split('T')[0] });
                setSelectedSupplier(null);
                setItems([]);
            }
        }, []);

        useEffect(() => {
            if (isOpen) {
              if (purchaseOrderId) {
                if (purchaseOrder) {
                  initializeForm(purchaseOrder);
                }
              } else {
                initializeForm(null);
              }
            }
        }, [purchaseOrder, purchaseOrderId, isOpen, initializeForm]);


        const mutation = useMutation({
            mutationFn: savePurchaseOrder,
            onSuccess: (data) => {
                toast({ title: t("common:success"), description: t("purchaseOrderDialog.saveSuccess") });
                queryClient.invalidateQueries({ queryKey: ['purchaseOrders'] });
                queryClient.invalidateQueries({ queryKey: ['purchaseOrderDetails', data.id]});
                setIsOpen(false);
            },
            onError: (error) => {
                toast({ variant: "destructive", title: t("common:error"), description: t("purchaseOrderDialog.saveError", { error: error.message }) });
            },
        });

        const handleSubmit = (e) => {
            e.preventDefault();
            if (!user) {
                toast({ variant: "destructive", title: t("auth.authError"), description: t("auth.authErrorDesc") });
                return;
            }
            if (!formData.supplier_id) {
                toast({ variant: "destructive", title: t("purchaseOrderDialog.requiredField"), description: t("purchaseOrderDialog.supplierRequired") });
                return;
            }
            if (items.length === 0 || items.some(it => !it.sku || !it.product_name || !it.quantity || it.purchase_price === undefined)) {
                toast({ variant: "destructive", title: t("purchaseOrderDialog.requiredField"), description: t("purchaseOrderDialog.itemFieldsRequired") });
                return;
            }
            mutation.mutate({ orderData: formData, items, user });
        };

        const handleSupplierSelect = (supplier) => {
          setSelectedSupplier(supplier);
          setFormData(prev => ({ ...prev, supplier_id: supplier?.id || null }));
        };

        const { subtotal, taxAmount, total } = useMemo(() => {
            const sub = items.reduce((acc, item) => acc + (toNumberSafe(item.quantity) * toNumberSafe(item.purchase_price)), 0);
            const tax = sub / 11;
            return { subtotal: round2(sub), taxAmount: round2(tax), total: round2(sub) };
        }, [items]);

        const isDialogLoading = isLoadingOrder && !!purchaseOrderId;
        const canSave = formData.supplier_id && items.length > 0 && !mutation.isPending;

        return (
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="sm:max-w-5xl">
                    {isDialogLoading ? (
                         <div className="p-8 h-[70vh] flex items-center justify-center"><Loader2 className="mx-auto h-12 w-12 animate-spin" /></div>
                    ) : (
                    <form id="purchase-order-form" onSubmit={handleSubmit}>
                        <DialogHeader>
                            <DialogTitle>{purchaseOrderId ? t("purchaseOrderDialog.editTitle", { orderNumber: formData.order_number }) : t("purchaseOrderDialog.createTitle")}</DialogTitle>
                            <DialogDescription>{t("purchaseOrderDialog.description")}</DialogDescription>
                        </DialogHeader>
                        <ScrollArea className="h-[70vh] pr-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
                                <PurchaseOrderForm
                                    formData={formData}
                                    setFormData={setFormData}
                                    onSelectSupplier={handleSupplierSelect}
                                    selectedSupplier={selectedSupplier}
                                />
                                <div className="md:col-span-2 space-y-4">
                                    <PurchaseOrderItems
                                        items={items}
                                        setItems={setItems}
                                    />
                                    <PurchaseOrderTotals
                                        subtotal={subtotal}
                                        taxAmount={taxAmount}
                                        total={total}
                                    />
                                </div>
                            </div>
                        </ScrollArea>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={() => setIsOpen(false)} disabled={mutation.isPending}>{t("common:cancel")}</Button>
                            <Button type="submit" form="purchase-order-form" disabled={!canSave}>
                                {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {t("purchaseOrderDialog.saveOrder")}
                            </Button>
                        </DialogFooter>
                    </form>
                    )}
                </DialogContent>
            </Dialog>
        );
    }

    export default AddEditPurchaseOrderDialog;