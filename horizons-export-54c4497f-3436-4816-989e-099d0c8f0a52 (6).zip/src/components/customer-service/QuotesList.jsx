import React, { useState, useMemo, useRef } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { PlusCircle, MoreHorizontal, Trash2, Edit, FileText, Printer, X, CheckCircle, Loader2, Truck } from 'lucide-react';
    import { useToast } from "@/components/ui/use-toast";
    import { DataTable } from '@/components/ui/data-table';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuTrigger,
      DropdownMenuSeparator,
    } from "@/components/ui/dropdown-menu";
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
    } from "@/components/ui/alert-dialog";
    import AddEditQuoteDialog from './AddEditQuoteDialog';
    import { formatCurrency, normalizeText } from '@/lib/utils';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
    import { useReactToPrint } from 'react-to-print';
    import QuotePrintView from './QuotePrintView';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useTranslation } from 'react-i18next';

    const QuotesList = () => {
      const { toast } = useToast();
      const { user } = useAuth();
      const { t } = useTranslation('support');
      const queryClient = useQueryClient();
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [selectedQuote, setSelectedQuote] = useState(null);
      const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
      const [quoteToDelete, setQuoteToDelete] = useState(null);
      const [isPrintDialogOpen, setIsPrintDialogOpen] = useState(false);
      const [quoteToPrint, setQuoteToPrint] = useState(null);
      const [quoteToDispatch, setQuoteToDispatch] = useState(null);
      const printComponentRef = useRef();

      const handlePrint = useReactToPrint({
        content: () => printComponentRef.current,
        documentTitle: `${t('quoteList.pdfFilename')}-${quoteToPrint?.quote_number || 'documento'}`,
      });

      const { data: quotes, isLoading: isLoadingQuotes, isError, error } = useQuery({
        queryKey: ['quotes', user?.id],
        queryFn: async () => {
            if (!user) return [];
            const { data, error } = await supabase
                .from('quotes')
                .select('*, client:clients(name, ruc_ci, address, phone, email)')
                .eq('user_id', user.id)
                .order('quote_number', { ascending: false });
            if (error) {
                toast({ variant: "destructive", title: "Error", description: `Error al cargar presupuestos: ${error.message}` });
                throw new Error(error.message);
            }
            return data;
        },
        enabled: !!user,
      });

      const { data: clients, isLoading: isLoadingClients } = useQuery({
        queryKey: ['clientsForQuotes', user?.id],
        queryFn: async () => {
          if (!user) return [];
          const { data, error } = await supabase.from('clients').select('id, name').eq('user_id', user.id);
          if (error) throw new Error(error.message);
          return data;
        },
        enabled: !!user,
      });

      const approveQuoteMutation = useMutation({
        mutationFn: (quoteId) => supabase.rpc('approve_quote_and_create_so', { p_quote_id: quoteId }),
        onSuccess: (data, quoteId) => {
          toast({
            title: t("quoteDialog.approvedTitle"),
            description: t("quoteDialog.approvedDescription"),
          });
          queryClient.invalidateQueries({ queryKey: ['quotes'] });
          queryClient.invalidateQueries({ queryKey: ['service_orders'] });
          queryClient.invalidateQueries({ queryKey: ['v_stock_per_deposit_summary'] });
        },
        onError: (error) => {
          toast({
            variant: "destructive",
            title: t("quoteDialog.approveErrorTitle"),
            description: error.message,
          });
        },
      });

      const dispatchQuoteMutation = useMutation({
        mutationFn: (quoteId) => supabase.rpc('finalize_quote_without_so', { p_quote_id: quoteId }),
        onSuccess: () => {
            toast({ title: t("common:success"), description: t("quoteList.dispatchSuccess") });
            queryClient.invalidateQueries({ queryKey: ['quotes'] });
            queryClient.invalidateQueries({ queryKey: ['v_stock_per_deposit'] });
            queryClient.invalidateQueries({ queryKey: ['v_kardex'] });
        },
        onError: (error) => {
            toast({ variant: "destructive", title: t("quoteList.dispatchErrorTitle"), description: error.message });
        },
        onSettled: () => setQuoteToDispatch(null)
      });

      const mutation = useMutation({
        mutationFn: async (quoteData) => {
          const { id, ...dataToSave } = quoteData;
          let response;
          if (id) {
            response = await supabase.from('quotes').update(dataToSave).eq('id', id).select().single();
          } else {
            const dataWithCreator = { ...dataToSave, created_by: user.id, user_id: user.id };
            response = await supabase.from('quotes').insert(dataWithCreator).select().single();
          }
          if (response.error) throw new Error(response.error.message);
          return response.data;
        },
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['quotes'] });
          setIsDialogOpen(false);
          toast({
            title: t("common:success"),
            description: t("quoteList.saveSuccess"),
            className: "bg-green-100 border-green-400"
          });
        },
        onError: (error) => {
          toast({
            variant: "destructive",
            title: t("quoteList.saveErrorTitle"),
            description: error.message,
          });
        },
      });

      const deleteMutation = useMutation({
        mutationFn: async (quoteId) => {
          const { error } = await supabase.from('quotes').delete().eq('id', quoteId);
          if (error) throw new Error(error.message);
        },
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['quotes'] });
          setIsDeleteDialogOpen(false);
          toast({
            title: t("quoteList.deletedTitle"),
            description: t("quoteList.deletedDescription"),
          });
        },
        onError: (error) => {
          toast({
            variant: "destructive",
            title: t("quoteList.deleteErrorTitle"),
            description: error.message,
          });
        },
      });

      const handleNewQuote = () => {
        setSelectedQuote(null);
        setIsDialogOpen(true);
      };

      const handleEditQuote = (quote) => {
        setSelectedQuote(quote);
        setIsDialogOpen(true);
      };

      const handleDeleteQuote = (quote) => {
        setQuoteToDelete(quote);
        setIsDeleteDialogOpen(true);
      };

      const handleViewPrintQuote = (quote) => {
        setQuoteToPrint(quote);
        setIsPrintDialogOpen(true);
      };
      
      const handleApproveQuote = (quote) => {
        if(quote.status === 'Aceptado' || quote.status === 'Despachado') {
            toast({ variant: 'destructive', title: t("quoteDialog.actionNotAllowed"), description: t("quoteList.alreadyProcessed")});
            return;
        }
        approveQuoteMutation.mutate(quote.id);
      };
      
      const handleDispatchQuote = (quote) => {
        if(quote.status === 'Aceptado' || quote.status === 'Despachado') {
          toast({ variant: 'destructive', title: t("quoteDialog.actionNotAllowed"), description: t("quoteList.alreadyProcessed")});
          return;
        }
        setQuoteToDispatch(quote);
      }

      const confirmDelete = () => {
        if (quoteToDelete) {
          deleteMutation.mutate(quoteToDelete.id);
        }
      };

      const confirmDispatch = () => {
        if (quoteToDispatch) {
            dispatchQuoteMutation.mutate(quoteToDispatch.id);
        }
      }

      const columns = useMemo(() => [
        {
          accessorKey: 'quote_number',
          header: t("quoteList.internalNumber"),
        },
        {
            accessorKey: 'manual_quote_number',
            header: t("quoteList.manualNumber"),
        },
        {
          accessorKey: 'client.name',
          header: t("quoteList.client"),
          accessorFn: row => row.client?.name,
          filterFn: (row, id, value) => {
            const normalizedRowValue = normalizeText(row.original.client?.name || '');
            const normalizedFilterValue = normalizeText(value);
            return normalizedRowValue.includes(normalizedFilterValue);
          },
        },
        {
          accessorKey: 'status',
          header: t("quoteList.status"),
          cell: ({ row }) => {
            const status = row.original.status;
            const statusClasses = {
              'Borrador': 'bg-gray-100 text-gray-800',
              'Enviado': 'bg-blue-100 text-blue-800',
              'Aceptado': 'bg-green-100 text-green-800',
              'Despachado': 'bg-purple-100 text-purple-800',
              'Rechazado': 'bg-red-100 text-red-800',
            };
            return <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusClasses[status] || 'bg-gray-100'}`}>{status}</span>;
          },
        },
        {
          accessorKey: 'total',
          header: t("quoteList.total"),
          cell: ({ row }) => formatCurrency(row.original.total),
        },
        {
          accessorKey: 'created_at',
          header: t("quoteList.date"),
          cell: ({ row }) => new Date(row.original.created_at).toLocaleDateString(),
        },
        {
          id: 'actions',
          cell: ({ row }) => {
            const quote = row.original;
            const isActionable = quote.status === 'Borrador' || quote.status === 'Enviado';
            return (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">{t("quoteList.openMenu")}</span>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => handleEditQuote(quote)} disabled={!isActionable}>
                    <Edit className="mr-2 h-4 w-4" /> {t("common:viewEdit")}</DropdownMenuItem>
                   {isActionable && (
                    <>
                    <DropdownMenuItem onClick={() => handleApproveQuote(quote)} disabled={approveQuoteMutation.isPending && approveQuoteMutation.variables === quote.id}>
                       {approveQuoteMutation.isPending && approveQuoteMutation.variables === quote.id ? 
                         <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 
                         <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                       }
                      {t("quoteList.approveCreateOS")}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDispatchQuote(quote)} disabled={dispatchQuoteMutation.isPending && dispatchQuoteMutation.variables === quote.id}>
                        {dispatchQuoteMutation.isPending && dispatchQuoteMutation.variables === quote.id ?
                         <Loader2 className="mr-2 h-4 w-4 animate-spin" /> :
                         <Truck className="mr-2 h-4 w-4 text-blue-500" />
                        }
                        {t("quoteList.approveDispatch")}
                    </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuItem onClick={() => handleViewPrintQuote(quote)}>
                    <FileText className="mr-2 h-4 w-4" /> {t("quoteList.viewPrint")}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteQuote(quote)}>
                    <Trash2 className="mr-2 h-4 w-4" /> {t("common:delete")}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            );
          },
        },
      ], [approveQuoteMutation.isPending, approveQuoteMutation.variables, dispatchQuoteMutation.isPending, dispatchQuoteMutation.variables, queryClient, t]);

      return (
        <>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>{t("quoteList.quotesTitle")}</CardTitle>
                <CardDescription>{t("quoteList.quotesDescription")}</CardDescription>
              </div>
              <Button onClick={handleNewQuote}>
                <PlusCircle className="mr-2 h-4 w-4" />
                {t("quoteList.newQuote")}
              </Button>
            </CardHeader>
            <CardContent>
              <DataTable
                columns={columns}
                data={quotes || []}
                isLoading={isLoadingQuotes}
                isError={isError}
                error={error}
                filterColumn="client.name"
                filterPlaceholder={t("quoteList.filterClientPlaceholder")}
              />
            </CardContent>
          </Card>

          <AddEditQuoteDialog
            isOpen={isDialogOpen}
            setIsOpen={setIsDialogOpen}
            quote={selectedQuote}
            onSave={mutation.mutate}
            clients={clients}
            isLoading={mutation.isPending || isLoadingClients}
          />

          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t("common:areYouSure")}</AlertDialogTitle>
                <AlertDialogDescription>
                  {t("quoteList.deleteConfirmation", { quoteNumber: quoteToDelete?.quote_number })}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t("common:cancel")}</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending} className="bg-destructive hover:bg-destructive/90">
                  {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {t("common:delete")}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          
          <AlertDialog open={!!quoteToDispatch} onOpenChange={() => setQuoteToDispatch(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t("quoteList.confirmDispatchTitle")}</AlertDialogTitle>
                <AlertDialogDescription>
                  {t("quoteList.confirmDispatchDesc")}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t("common:cancel")}</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDispatch} disabled={dispatchQuoteMutation.isPending}>
                  {dispatchQuoteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {t("quoteList.confirmDispatch")}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <Dialog open={isPrintDialogOpen} onOpenChange={setIsPrintDialogOpen}>
            <DialogContent className="max-w-4xl h-[90vh]">
                <DialogHeader>
                    <DialogTitle>{t("quoteList.previewTitle", { quoteNumber: quoteToPrint?.quote_number })}</DialogTitle>
                </DialogHeader>
                <div className="overflow-auto p-2 h-full">
                    <QuotePrintView ref={printComponentRef} quote={quoteToPrint} />
                </div>
                <DialogFooter className="sm:justify-between">
                    <Button variant="outline" onClick={() => setIsPrintDialogOpen(false)}>
                        <X className="mr-2 h-4 w-4" /> {t("common:cancel")}
                    </Button>
                    <Button onClick={handlePrint}>
                        <Printer className="mr-2 h-4 w-4" /> {t("quoteList.printSavePdf")}
                    </Button>
                </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      );
    };

    export default QuotesList;