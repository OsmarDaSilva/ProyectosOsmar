import React from 'react';
    import { formatCurrency } from '@/lib/utils';
    import { useQuery } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useTranslation } from 'react-i18next';

    const ServiceOrderPrintView = React.forwardRef(({ serviceOrder }, ref) => {
        const { user } = useAuth();
        const { t } = useTranslation('support');

        const { data: companyData } = useQuery({
            queryKey: ['companyDataForPrint', user?.id],
            queryFn: async () => {
                const { data, error } = await supabase
                    .from('companies')
                    .select('*')
                    .eq('user_id', user.id)
                    .single();
                if (error && error.code !== 'PGRST116') {
                    console.error("Error fetching company data:", error);
                    return null;
                }
                return data;
            },
            enabled: !!user,
            staleTime: 5 * 60 * 1000,
        });

        if (!serviceOrder) return null;

        const companyName = companyData?.name || t('serviceOrderPrintView.companyNamePlaceholder');
        const companyLogo = companyData?.logo_url;
        const companyAddress = companyData?.address || '';
        const companyPhone = companyData?.phone || '';
        const companyEmail = companyData?.email || '';
        const companyWebsite = companyData?.website || '';
        const companyCountry = companyData?.country || t('serviceOrderPrintView.countryPlaceholder');
        const companyRuc = companyData?.ruc || t('serviceOrderPrintView.rucPlaceholder');

        return (
            <div ref={ref} className="bg-white text-gray-800 font-sans p-8 print-container">
                <header className="flex justify-between items-start pb-4 border-b-2 border-gray-200">
                    <div className="flex items-center">
                        {companyLogo && <img  alt="Logo de la empresa" class="w-24 h-24 mr-4 object-contain" src="https://images.unsplash.com/photo-1485531865381-286666aa80a9" />}
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">{companyName}</h1>
                            <p className="text-sm">{companyAddress}</p>
                            <p className="text-sm">{t('serviceOrderPrintView.ruc')}: {companyRuc}</p>
                            <p className="text-sm">{t('serviceOrderPrintView.tel')}: {companyPhone}</p>
                            <p className="text-sm">{t('serviceOrderPrintView.email')}: {companyEmail}</p>
                            <p className="text-sm">{companyWebsite}</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <h2 className="text-3xl font-bold uppercase text-blue-600">{t('serviceOrderPrintView.title')}</h2>
                        <p className="text-lg">{t('serviceOrderPrintView.number')}: <span className="font-semibold">{String(serviceOrder.order_number).padStart(5, '0')}</span></p>
                        {serviceOrder.manual_order_number && <p className="text-sm">{t('serviceOrderPrintView.manualRef')}: <span className="font-semibold">{serviceOrder.manual_order_number}</span></p>}
                        <p className="text-sm">{t('serviceOrderPrintView.date')}: <span className="font-semibold">{new Date(serviceOrder.created_at).toLocaleDateString()}</span></p>
                    </div>
                </header>

                <section className="grid grid-cols-2 gap-8 my-6">
                    <div>
                        <h3 className="text-sm uppercase font-semibold text-gray-500 mb-2">{t('serviceOrderPrintView.client')}</h3>
                        <div className="text-base">
                            <p className="font-bold text-gray-900">{serviceOrder.client?.name}</p>
                            <p>{serviceOrder.client?.address || t('serviceOrderPrintView.addressPlaceholder')}</p>
                            <p>{t('serviceOrderPrintView.rucCi')}: {serviceOrder.client?.ruc_ci || t('serviceOrderPrintView.notSpecified')}</p>
                            <p>{t('serviceOrderPrintView.tel')}: {serviceOrder.client?.phone || t('serviceOrderPrintView.notSpecified')}</p>
                        </div>
                    </div>
                     <div>
                        <h3 className="text-sm uppercase font-semibold text-gray-500 mb-2">{t('serviceOrderPrintView.equipment')}</h3>
                        <div className="text-base">
                            <p className="font-bold text-gray-900">{t('serviceOrderPrintView.serialNumber')}: {serviceOrder.equipment?.serial_number || serviceOrder.unregistered_equipment}</p>
                        </div>
                    </div>
                </section>

                <section>
                    <table className="w-full text-left">
                        <thead className="bg-gray-100">
                            <tr>
                                <th className="p-3 text-sm font-semibold uppercase">{t('serviceOrderPrintView.codeConcept')}</th>
                                <th className="p-3 text-sm font-semibold uppercase w-2/5">{t('serviceOrderPrintView.description')}</th>
                                <th className="p-3 text-sm font-semibold uppercase text-right">{t('serviceOrderPrintView.quantity')}</th>
                                <th className="p-3 text-sm font-semibold uppercase text-right">{t('serviceOrderPrintView.unitPrice')}</th>
                                <th className="p-3 text-sm font-semibold uppercase text-right">{t('serviceOrderPrintView.subtotalVat')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {serviceOrder.items?.map((item, index) => (
                                <tr key={`item-${index}`} className="border-b border-gray-100">
                                    <td className="p-3 text-sm">{item.sku}</td>
                                    <td className="p-3 text-sm">{item.product_name}</td>
                                    <td className="p-3 text-sm text-right">{item.quantity}</td>
                                    <td className="p-3 text-sm text-right">{formatCurrency(item.price)}</td>
                                    <td className="p-3 text-sm text-right font-medium">{formatCurrency(item.quantity * item.price)}</td>
                                </tr>
                            ))}
                            {(serviceOrder.km_total > 0) && (
                                <tr key="km" className="border-b border-gray-100">
                                    <td className="p-3 text-sm">{t('serviceOrderPrintView.kmCode')}</td>
                                    <td className="p-3 text-sm">{t('serviceOrderPrintView.transfer')}</td>
                                    <td className="p-3 text-sm text-right">{serviceOrder.km_quantity}</td>
                                    <td className="p-3 text-sm text-right">{formatCurrency(serviceOrder.km_price)}</td>
                                    <td className="p-3 text-sm text-right font-medium">{formatCurrency(serviceOrder.km_total)}</td>
                                </tr>
                            )}
                             {(serviceOrder.labor_total > 0) && (
                                <tr key="labor" className="border-b border-gray-100">
                                    <td className="p-3 text-sm">{t('serviceOrderPrintView.moCode')}</td>
                                    <td className="p-3 text-sm">{t('serviceOrderPrintView.labor')}</td>
                                    <td className="p-3 text-sm text-right">{serviceOrder.labor_quantity}</td>
                                    <td className="p-3 text-sm text-right">{formatCurrency(serviceOrder.labor_price)}</td>
                                    <td className="p-3 text-sm text-right font-medium">{formatCurrency(serviceOrder.labor_total)}</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </section>

                <section className="flex justify-end mt-6">
                    <div className="w-full max-w-sm space-y-2">
                        <div className="flex justify-between text-base">
                            <span>{t('serviceOrderPrintView.subtotal')}</span>
                            <span className="font-medium">{formatCurrency(serviceOrder.subtotal)}</span>
                        </div>
                        {serviceOrder.discount_percentage > 0 && (
                            <div className="flex justify-between text-base">
                                <span>{t('serviceOrderPrintView.discount')} ({serviceOrder.discount_percentage}%)</span>
                                <span className="font-medium">-{formatCurrency(serviceOrder.discount_amount)}</span>
                            </div>
                        )}
                        <div className="flex justify-between text-sm text-gray-500">
                            <span>{t('serviceOrderPrintView.vatIncluded')}</span>
                            <span>{formatCurrency(serviceOrder.tax_amount)}</span>
                        </div>
                        <div className="flex justify-between text-xl font-bold border-t-2 border-gray-300 pt-2 mt-2">
                            <span>{t('serviceOrderPrintView.grandTotal')}</span>
                            <span>{formatCurrency(serviceOrder.total)}</span>
                        </div>
                    </div>
                </section>
                
                {serviceOrder.description && (
                     <section className="mt-8">
                        <h3 className="text-sm uppercase font-semibold text-gray-500 mb-2">{t('serviceOrderPrintView.serviceDescription')}</h3>
                        <p className="text-sm border p-3 rounded-md bg-gray-50 whitespace-pre-wrap">{serviceOrder.description}</p>
                    </section>
                )}
                 {serviceOrder.notes && (
                     <section className="mt-8">
                        <h3 className="text-sm uppercase font-semibold text-gray-500 mb-2">{t('serviceOrderPrintView.observations')}</h3>
                        <p className="text-sm border p-3 rounded-md bg-gray-50 whitespace-pre-wrap">{serviceOrder.notes}</p>
                    </section>
                )}

                <footer className="text-center text-xs text-gray-500 pt-8 mt-8 border-t border-gray-200">
                    {serviceOrder.technician_profile && (
                        <div className="mb-4">
                            <p>{t('serviceOrderPrintView.assignedTechnician')}: {serviceOrder.technician_profile.full_name || t('serviceOrderPrintView.notSpecified')}</p>
                        </div>
                    )}
                    <p>{t('serviceOrderPrintView.thanks')}</p>
                </footer>
            </div>
        );
    });

    export default ServiceOrderPrintView;