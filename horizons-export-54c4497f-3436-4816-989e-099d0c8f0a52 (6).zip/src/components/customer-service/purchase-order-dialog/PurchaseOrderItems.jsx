import React from 'react';
import ProductSelector from '../ProductSelector';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2 } from 'lucide-react';
import { fmtUSD, toNumberSafe } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

const PurchaseOrderItems = ({ items, setItems }) => {
    const { t } = useTranslation('support');

    const handleProductSelect = (product) => {
        if (!items.find(p => p.sku === product.sku)) {
            setItems(prevItems => [...prevItems, {
                id: undefined,
                sku: product.sku,
                product_name: product.name,
                brand: product.brand,
                quantity: 1,
                purchase_price: product.purchase_price || 0,
            }]);
        }
    };

    const handleItemFieldChange = (sku, field, value) => {
        setItems(items.map(p => (p.sku === sku) ? { ...p, [field]: value } : p));
    };

    const removeItem = (sku) => {
        setItems(items.filter(p => p.sku !== sku));
    };

    return (
        <>
            <h3>{t("purchaseOrderDialog.products")}</h3>
            <ProductSelector onSelectProduct={handleProductSelect} />
            <div className="border rounded-md">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead className="w-[15%]">{t("purchaseOrderDialog.productCode")}</TableHead>
                        <TableHead>{t("purchaseOrderDialog.productDescription")}</TableHead>
                        <TableHead className="w-[15%] text-right">{t("purchaseOrderDialog.quantity")}</TableHead>
                        <TableHead className="w-[20%] text-right">{t("purchaseOrderDialog.purchasePrice")}</TableHead>
                        <TableHead className="w-[20%] text-right">{t("purchaseOrderDialog.subtotal")}</TableHead>
                        <TableHead className="w-[5%]"></TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {items.length > 0 ? items.map(item => (
                            <TableRow key={item.sku}>
                                <TableCell className="text-xs">{item.sku}</TableCell>
                                <TableCell className="font-medium text-sm">{item.product_name || item.name}</TableCell>
                                <TableCell><Input type="text" inputMode="decimal" value={item.quantity} onChange={(e) => handleItemFieldChange(item.sku, 'quantity', e.target.value)} className="h-8 text-right" min="0" /></TableCell>
                                <TableCell><Input type="text" inputMode="decimal" value={item.purchase_price} onChange={(e) => handleItemFieldChange(item.sku, 'purchase_price', e.target.value)} className="h-8 text-right" min="0" /></TableCell>
                                <TableCell className="text-right font-medium">{fmtUSD(toNumberSafe(item.quantity) * toNumberSafe(item.purchase_price))}</TableCell>
                                <TableCell><Button type="button" variant="ghost" size="icon" onClick={() => removeItem(item.sku)} className="h-8 w-8"><Trash2 className="h-4 w-4 text-red-500" /></Button></TableCell>
                            </TableRow>
                        )) : (
                            <TableRow><TableCell colSpan={6} className="h-24 text-center text-muted-foreground">{t("purchaseOrderDialog.noProducts")}</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
        </>
    );
};

export default PurchaseOrderItems;