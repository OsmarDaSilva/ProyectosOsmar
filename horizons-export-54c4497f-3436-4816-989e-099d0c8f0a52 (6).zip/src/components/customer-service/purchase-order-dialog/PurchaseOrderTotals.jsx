import React from 'react';
import { fmtUSD } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

const PurchaseOrderTotals = ({ subtotal, taxAmount, total }) => {
    const { t } = useTranslation('support');
    return (
        <div className="flex justify-end pt-4">
            <div className="w-full max-w-sm space-y-2">
                <div className="flex justify-between">
                    <span>{t("purchaseOrderDialog.subtotal")}</span>
                    <span>{fmtUSD(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{t("purchaseOrderDialog.vatBreakdown")}</span>
                    <span>{fmtUSD(taxAmount)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t pt-2 mt-2">
                    <span>{t("purchaseOrderDialog.total")}</span>
                    <span>{fmtUSD(total)}</span>
                </div>
            </div>
        </div>
    );
};

export default PurchaseOrderTotals;