import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import SupplierSelector from '../SupplierSelector';
import { useTranslation } from 'react-i18next';

const PurchaseOrderForm = ({ formData, setFormData, onSelectSupplier, selectedSupplier }) => {
    const { t } = useTranslation('support');

    return (
        <div className="md:col-span-1 space-y-4">
            <div className="space-y-2">
                <Label>{t("purchaseOrderDialog.supplier")}</Label>
                <SupplierSelector 
                    onSelectSupplier={onSelectSupplier} 
                    initialSupplier={selectedSupplier} 
                />
            </div>
            <div className="space-y-2">
                <Label>{t("purchaseOrderDialog.dueDate")}</Label>
                <Input type="date" value={formData.due_date || ''} onChange={(e) => setFormData({...formData, due_date: e.target.value})} />
            </div>
            <div className="space-y-2">
                <Label>{t("purchaseOrderDialog.status")}</Label>
                <Select onValueChange={(value) => setFormData({...formData, status: value})} value={formData.status}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Borrador">{t("purchaseOrderDialog.statusDraft")}</SelectItem>
                        <SelectItem value="Enviado">{t("purchaseOrderDialog.statusSent")}</SelectItem>
                        <SelectItem value="Recibido Parcialmente">{t("purchaseOrderDialog.statusPartiallyReceived")}</SelectItem>
                        <SelectItem value="Recibido Completo">{t("purchaseOrderDialog.statusCompleted")}</SelectItem>
                        <SelectItem value="Cancelado">{t("purchaseOrderDialog.statusCancelled")}</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div className="space-y-2">
                <Label>{t("purchaseOrderDialog.notes")}</Label>
                <Textarea value={formData.notes || ''} onChange={(e) => setFormData({...formData, notes: e.target.value})} />
            </div>
        </div>
    );
};

export default PurchaseOrderForm;