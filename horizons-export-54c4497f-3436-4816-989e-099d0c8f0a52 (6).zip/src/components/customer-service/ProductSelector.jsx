import React, { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDebounce } from '@/hooks/useDebounce';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { PackageSearch, Loader2, AlertTriangle } from 'lucide-react';
import { fmtUSD } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider } from '@/components/ui/tooltip';
import { useTranslation } from 'react-i18next';
import { useToast } from "@/components/ui/use-toast";

const ProductSelector = ({ onSelectProduct, disabled }) => {
    const { user } = useAuth();
    const { toast } = useToast();
    const { t } = useTranslation('support');
    const [searchTerm, setSearchTerm] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);
    const wrapperRef = useRef(null);
    const debouncedSearchTerm = useDebounce(searchTerm, 300);
    const abortControllerRef = useRef(null);

    const { data: searchResult, isLoading, isError, error: queryError } = useQuery({
        queryKey: ['product_search_for_os', debouncedSearchTerm, user?.id],
        queryFn: async () => {
            if (abortControllerRef.current) {
                abortControllerRef.current.abort();
            }
            abortControllerRef.current = new AbortController();
            const signal = abortControllerRef.current.signal;

            if (!user || !debouncedSearchTerm || debouncedSearchTerm.length < 2) {
                return { products: [] };
            }
            
            try {
                const { data, error } = await supabase.rpc('search_products_for_os', {
                    p_user_id: user.id,
                    p_query: debouncedSearchTerm
                }, { signal });

                if (error) {
                    if (error.name === 'AbortError') {
                        return { products: [] };
                    }
                    throw new Error(error.message);
                }
                return { products: data || [] };

            } catch (e) {
                if (e.name === 'AbortError') {
                    return { products: [] };
                }
                console.error('Error buscando producto:', e);
                toast({
                    variant: "destructive",
                    title: t('productSelector.searchError'),
                    description: e.message || t('common.unknownError'),
                });
                throw e;
            }
        },
        enabled: !!user && debouncedSearchTerm.length > 2,
        staleTime: 1000 * 30, // 30 seconds
    });
    
    const handleSelect = (product) => {
        if (product.purchase_price === null || product.purchase_price === undefined) {
             toast({
                variant: "destructive",
                title: t('productSelector.noPurchasePriceTitle'),
                description: t('productSelector.noPurchasePriceDescription', { sku: product.sku }),
             });
        }
        onSelectProduct(product);
        setSearchTerm('');
        setShowSuggestions(false);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && searchResult?.products && searchResult.products.length > 0) {
            e.preventDefault();
            handleSelect(searchResult.products[0]);
        }
    };

    useEffect(() => {
        function handleClickOutside(event) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
            if (abortControllerRef.current) {
                abortControllerRef.current.abort();
            }
        };
    }, [wrapperRef]);
    
    const showNoResults = showSuggestions && debouncedSearchTerm.length > 2 && !isLoading && !isError && (!searchResult?.products || searchResult.products.length === 0);

    return (
        <TooltipProvider>
        <div className="relative" ref={wrapperRef}>
            <div className="relative">
                {isLoading ? (
                    <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 animate-spin text-muted-foreground" />
                ) : (
                    <PackageSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                )}
                <Input
                    type="text"
                    placeholder={t("productSelector.placeholder")}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onFocus={() => setShowSuggestions(true)}
                    onKeyDown={handleKeyDown}
                    disabled={disabled}
                    className="pl-10"
                />
            </div>
            {showSuggestions && searchResult?.products?.length > 0 && !isError && (
                <Card className="absolute z-10 w-full mt-1 shadow-lg">
                    <CardContent className="p-2 max-h-80 overflow-y-auto">
                        {searchResult.products.map(product => (
                            <div
                                key={product.sku}
                                className="p-2 hover:bg-accent rounded-md cursor-pointer"
                                onMouseDown={() => handleSelect(product)}
                            >
                                <p className="font-medium">{product.name || t('productSelector.unnamedProduct')}</p>
                                <p className="text-xs text-muted-foreground">
                                    {product.sku} {product.brand ? `– ${product.brand}` : ''}
                                </p>
                                <div className="flex flex-wrap gap-1 mt-1">
                                    <Badge variant="outline" className="text-xs">{t("productSelector.salePrice")}: {fmtUSD(product.sale_price)}</Badge>
                                    <Badge variant="outline" className="text-xs">{t("productSelector.purchasePrice")}: {fmtUSD(product.purchase_price)}</Badge>
                                    {(product.purchase_price === null || product.purchase_price === undefined) && <Badge variant="destructive" className="text-xs">{t("productSelector.noPurchasePrice")}</Badge>}
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            )}
            {(showNoResults || isError) && (
                 <Card className="absolute z-10 w-full mt-1 shadow-lg">
                    <CardContent className="p-4 text-center text-sm text-muted-foreground space-y-2 flex flex-col items-center">
                        <AlertTriangle className="h-6 w-6 text-amber-500 mb-2" />
                        <p>{isError ? t("productSelector.searchError") : t("productSelector.notFound")}</p>
                        {isError && <p className="text-xs text-red-500">{queryError.message}</p>}
                        <Button size="sm" onClick={() => { toast({ title: t("common:notImplemented"), description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀", duration: 2000 }) }}>{t("productSelector.createOrder")}</Button>
                    </CardContent>
                </Card>
            )}
        </div>
        </TooltipProvider>
    );
};

export default ProductSelector;