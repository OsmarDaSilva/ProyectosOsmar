import React from 'react';
    import { formatCurrency } from '@/lib/utils';
    import { useQuery } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useTranslation } from 'react-i18next';

    const QuotePrintView = React.forwardRef(({ quote }, ref) => {
        const { user } = useAuth();
        const { t } = useTranslation('support');

        const { data: companyData } = useQuery({
            queryKey: ['companyDataForPrint', user.id],
            queryFn: async () => {
                const { data, error } = await supabase
                    .from('companies')
                    .select('*')
                    .eq('user_id', user.id)
                    .single();
                if (error && error.code !== 'PGRST116') {
                    console.error("Error fetching company data:", error);
                    return null;
                }
                return data;
            },
            staleTime: 5 * 60 * 1000,
        });

        const { data: createdByUserData } = useQuery({
            queryKey: ['quoteCreator', quote?.created_by],
            queryFn: async () => {
                if (!quote?.created_by) return null;
                
                const { data, error } = await supabase.functions.invoke('get-user-details', {
                  body: { userId: quote.created_by }
                });

                if (error) {
                  console.error("Error fetching user details:", error);
                  return null;
                }
                
                return data;
            },
            enabled: !!quote?.created_by,
            staleTime: 5 * 60 * 1000,
        });
        
        if (!quote) return null;

        const companyName = companyData?.name || t('quotePrintView.companyNamePlaceholder');
        const companyLogo = companyData?.logo_url;
        const companyAddress = companyData?.address || '';
        const companyPhone = companyData?.phone || '';
        const companyEmail = companyData?.email || '';
        const companyWebsite = companyData?.website || '';
        const companyCountry = companyData?.country || t('quotePrintView.countryPlaceholder');

        return (
            <div ref={ref} className="bg-white text-gray-800 font-sans p-8">
                <header className="flex justify-between items-start pb-4 border-b-2 border-gray-200">
                    <div className="flex items-center">
                        {companyLogo && <img  alt="Logo de la empresa" class="w-24 h-24 mr-4 object-contain" src="https://images.unsplash.com/photo-1653055270282-029e5ba3e3a6" />}
                        <div>
                            <h1 className="text-2xl font-bold text-gray-900">{companyName}</h1>
                            <p className="text-sm">{companyAddress}</p>
                            <p className="text-sm">{companyCountry}</p>
                            <p className="text-sm">{t('quotePrintView.tel')}: {companyPhone}</p>
                            <p className="text-sm">{t('quotePrintView.email')}: {companyEmail}</p>
                            <p className="text-sm">{companyWebsite}</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <h2 className="text-3xl font-bold uppercase text-blue-600">{t('quotePrintView.title')}</h2>
                        <p className="text-lg">{t('quotePrintView.number')}: <span className="font-semibold">{String(quote.quote_number).padStart(5, '0')}</span></p>
                        {quote.manual_quote_number && <p className="text-sm">{t('quotePrintView.manualRef')}: <span className="font-semibold">{quote.manual_quote_number}</span></p>}
                        <p className="text-sm">{t('quotePrintView.date')}: <span className="font-semibold">{new Date(quote.created_at).toLocaleDateString()}</span></p>
                    </div>
                </header>

                <section className="grid grid-cols-2 gap-8 my-6">
                    <div>
                        <h3 className="text-sm uppercase font-semibold text-gray-500 mb-2">{t('quotePrintView.client')}</h3>
                        <div className="text-base">
                            <p className="font-bold text-gray-900">{quote.client?.name}</p>
                            <p>{quote.client?.address}</p>
                            <p>{t('quotePrintView.rucCi')}: {quote.client?.ruc_ci}</p>
                            <p>{t('quotePrintView.tel')}: {quote.client?.phone}</p>
                            <p>{t('quotePrintView.email')}: {quote.client?.email}</p>
                        </div>
                    </div>
                </section>

                <section>
                    <table className="w-full text-left">
                        <thead className="bg-gray-100">
                            <tr>
                                <th className="p-3 text-sm font-semibold uppercase">{t('quotePrintView.codeConcept')}</th>
                                <th className="p-3 text-sm font-semibold uppercase w-2/5">{t('quotePrintView.description')}</th>
                                <th className="p-3 text-sm font-semibold uppercase text-right">{t('quotePrintView.quantity')}</th>
                                <th className="p-3 text-sm font-semibold uppercase text-right">{t('quotePrintView.unitPrice')}</th>
                                <th className="p-3 text-sm font-semibold uppercase text-right">{t('quotePrintView.subtotalVat')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {quote.items?.map((item, index) => (
                                <tr key={`item-${index}`} className="border-b border-gray-100">
                                    <td className="p-3 text-sm">{item.sku}</td>
                                    <td className="p-3 text-sm">{item.product_name_snapshot}</td>
                                    <td className="p-3 text-sm text-right">{item.quantity}</td>
                                    <td className="p-3 text-sm text-right">{formatCurrency(item.price)}</td>
                                    <td className="p-3 text-sm text-right font-medium">{formatCurrency(item.quantity * item.price)}</td>
                                </tr>
                            ))}
                            {(quote.km_total > 0) && (
                                <tr key="km" className="border-b border-gray-100">
                                    <td className="p-3 text-sm">{t('quotePrintView.kmCode')}</td>
                                    <td className="p-3 text-sm">{t('quotePrintView.transfer')}</td>
                                    <td className="p-3 text-sm text-right">{quote.km_quantity}</td>
                                    <td className="p-3 text-sm text-right">{formatCurrency(quote.km_price)}</td>
                                    <td className="p-3 text-sm text-right font-medium">{formatCurrency(quote.km_total)}</td>
                                </tr>
                            )}
                             {(quote.labor_total > 0) && (
                                <tr key="labor" className="border-b border-gray-100">
                                    <td className="p-3 text-sm">{t('quotePrintView.moCode')}</td>
                                    <td className="p-3 text-sm">{t('quotePrintView.labor')}</td>
                                    <td className="p-3 text-sm text-right">{quote.labor_quantity}</td>
                                    <td className="p-3 text-sm text-right">{formatCurrency(quote.labor_price)}</td>
                                    <td className="p-3 text-sm text-right font-medium">{formatCurrency(quote.labor_total)}</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </section>

                <section className="flex justify-end mt-6">
                    <div className="w-full max-w-sm space-y-2">
                        <div className="flex justify-between text-base">
                            <span>{t('quotePrintView.subtotal')}</span>
                            <span className="font-medium">{formatCurrency(quote.subtotal)}</span>
                        </div>
                        {quote.discount_percentage > 0 && (
                            <div className="flex justify-between text-base">
                                <span>{t('quotePrintView.discount')} ({quote.discount_percentage}%)</span>
                                <span className="font-medium">-{formatCurrency(quote.discount_amount)}</span>
                            </div>
                        )}
                        <div className="flex justify-between text-sm text-gray-500">
                            <span>{t('quotePrintView.vatIncluded')}</span>
                            <span>{formatCurrency(quote.tax_amount)}</span>
                        </div>
                        <div className="flex justify-between text-xl font-bold border-t-2 border-gray-300 pt-2 mt-2">
                            <span>{t('quotePrintView.grandTotal')}</span>
                            <span>{formatCurrency(quote.total)}</span>
                        </div>
                    </div>
                </section>
                
                {quote.notes && (
                     <section className="mt-8">
                        <h3 className="text-sm uppercase font-semibold text-gray-500 mb-2">{t('quotePrintView.observations')}</h3>
                        <p className="text-sm border p-3 rounded-md bg-gray-50 whitespace-pre-wrap">{quote.notes}</p>
                    </section>
                )}

                <footer className="text-center text-xs text-gray-500 pt-8 mt-8 border-t border-gray-200">
                    {createdByUserData && (
                        <div className="mb-4">
                            <p>{t('quotePrintView.preparedBy')}: {createdByUserData.full_name || createdByUserData.email} | {t('quotePrintView.contact')}: {createdByUserData.email} / {createdByUserData.phone || 'N/A'}</p>
                        </div>
                    )}
                    <p>{t('quotePrintView.thanks')}</p>
                    <p>{companyName} - {companyCountry}</p>
                    <p>{companyWebsite}</p>
                </footer>
            </div>
        );
    });

    export default QuotePrintView;