import React, { useState } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { PlusCircle, MoreHorizontal, Trash2, Edit, Loader2, CheckCircle } from 'lucide-react';
    import { useToast } from "@/components/ui/use-toast";
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Badge } from '@/components/ui/badge';
    import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
    import AddEditPurchaseOrderDialog from './AddEditPurchaseOrderDialog';
    import { format } from 'date-fns';
    import { fmtUSD } from '@/lib/utils';
    import { Skeleton } from '@/components/ui/skeleton';
    import { useTranslation } from 'react-i18next';

    const PAGE_SIZE = 15;

    const fetchPurchaseOrders = async (userId, page) => {
        if (!userId) return { data: [], count: 0 };
        const from = (page - 1) * PAGE_SIZE;
        const to = from + PAGE_SIZE - 1;

        const { data, error, count } = await supabase
            .from('v_purchase_orders')
            .select('*', { count: 'exact' })
            .eq('user_id', userId)
            .order('order_number', { ascending: false })
            .range(from, to);

        if (error) {
            console.error('Error fetching purchase orders:', error);
            throw new Error(error.message);
        }
        return { data, count };
    };

    const deletePurchaseOrder = async (id) => {
        await supabase.from('purchase_order_items').delete().eq('po_id', id);
        const { error } = await supabase.from('purchase_orders').delete().eq('id', id);
        if (error) throw error;
    };

    const receivePurchaseOrder = async (id) => {
        const { data, error } = await supabase.rpc('receive_purchase_order', { p_po_id: id });
        if (error) throw error;
        return data;
    };

    const statusVariant = {
        'Borrador': 'secondary',
        'Enviado': 'default',
        'Recibido Parcialmente': 'outline',
        'Recibido Completo': 'success',
        'Cancelado': 'destructive',
    };

    const PurchaseOrdersList = () => {
        const { user } = useAuth();
        const queryClient = useQueryClient();
        const { toast } = useToast();
        const { t } = useTranslation('support');
        const [page, setPage] = useState(1);
        const [isDialogOpen, setIsDialogOpen] = useState(false);
        const [selectedOrderId, setSelectedOrderId] = useState(null);
        const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
        const [orderToDelete, setOrderToDelete] = useState(null);
        const [orderToReceive, setOrderToReceive] = useState(null);

        const { data, isLoading, isError, error } = useQuery({
            queryKey: ['purchaseOrders', user?.id, page],
            queryFn: () => fetchPurchaseOrders(user.id, page),
            enabled: !!user,
            keepPreviousData: true,
            onError: (err) => {
                toast({ variant: "destructive", title: "Error", description: `Error al cargar pedidos: ${err.message}` });
            }
        });
        
        const purchaseOrders = data?.data ?? [];
        const totalCount = data?.count ?? 0;
        const totalPages = Math.ceil(totalCount / PAGE_SIZE);

        const deleteMutation = useMutation({
            mutationFn: deletePurchaseOrder,
            onSuccess: () => {
                toast({ title: t("common:success"), description: t("purchaseOrderList.deleteSuccess") });
                queryClient.invalidateQueries({ queryKey: ['purchaseOrders'] });
            },
            onError: (error) => {
                toast({ variant: "destructive", title: t("common:error"), description: t("purchaseOrderList.deleteError", { error: error.message }) });
            },
            onSettled: () => setIsDeleteDialogOpen(false),
        });

        const receiveMutation = useMutation({
            mutationFn: receivePurchaseOrder,
            onSuccess: (message) => {
                toast({ title: t("purchaseOrderList.receptionProcessed"), description: message });
                queryClient.invalidateQueries({ queryKey: ['purchaseOrders'] });
                queryClient.invalidateQueries({ queryKey: ['inventory'] });
            },
            onError: (error) => {
                toast({ variant: "destructive", title: t("purchaseOrderList.receptionError"), description: error.message });
            },
            onSettled: () => setOrderToReceive(null),
        });

        const handleNewOrder = () => {
            setSelectedOrderId(null);
            setIsDialogOpen(true);
        };

        const handleEdit = (orderId) => {
            setSelectedOrderId(orderId);
            setIsDialogOpen(true);
        };

        const handleDelete = (order) => {
            setOrderToDelete(order);
            setIsDeleteDialogOpen(true);
        };

        const handleReceive = (order) => {
            setOrderToReceive(order);
        };

        const confirmDelete = () => {
            if (orderToDelete) {
                deleteMutation.mutate(orderToDelete.id);
            }
        };

        const confirmReceive = () => {
            if (orderToReceive) {
                receiveMutation.mutate(orderToReceive.id);
            }
        };
        
        const TableLoader = () => (
            <TableBody>
                {[...Array(5)].map((_, i) => (
                    <TableRow key={i}>
                        <TableCell colSpan="7"><Skeleton className="h-8 w-full" /></TableCell>
                    </TableRow>
                ))}
            </TableBody>
        );

        return (
            <>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                            <CardTitle>{t("purchaseOrderList.title")}</CardTitle>
                            <CardDescription>{t("purchaseOrderList.description")}</CardDescription>
                        </div>
                        <Button onClick={handleNewOrder}>
                            <PlusCircle className="mr-2 h-4 w-4" />
                            {t("purchaseOrderList.newOrder")}
                        </Button>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>{t("purchaseOrderList.orderNumber")}</TableHead>
                                    <TableHead>{t("purchaseOrderList.supplier")}</TableHead>
                                    <TableHead>{t("purchaseOrderList.date")}</TableHead>
                                    <TableHead>{t("purchaseOrderList.status")}</TableHead>
                                    <TableHead>{t("purchaseOrderList.items")}</TableHead>
                                    <TableHead className="text-right">{t("purchaseOrderList.total")}</TableHead>
                                    <TableHead className="text-right">{t("purchaseOrderList.actions")}</TableHead>
                                </TableRow>
                            </TableHeader>
                            {isLoading ? <TableLoader /> : (
                            <TableBody>
                                {isError ? (
                                    <TableRow><TableCell colSpan="7" className="text-center text-red-500 py-8">{`Error: ${error.message}`}</TableCell></TableRow>
                                ) : purchaseOrders.length > 0 ? purchaseOrders.map(order => (
                                    <TableRow key={order.id}>
                                        <TableCell className="font-medium">{order.order_number}</TableCell>
                                        <TableCell>{order.supplier_name || 'N/A'}</TableCell>
                                        <TableCell>{format(new Date(order.created_at), 'dd/MM/yyyy')}</TableCell>
                                        <TableCell><Badge variant={statusVariant[order.status] || 'default'}>{order.status}</Badge></TableCell>
                                        <TableCell>{order.total_qty}</TableCell>
                                        <TableCell className="text-right">{fmtUSD(order.total)}</TableCell>
                                        <TableCell className="text-right">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild><Button variant="ghost" className="h-8 w-8 p-0"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuItem onClick={() => handleEdit(order.id)}><Edit className="mr-2 h-4 w-4" /> {t("common:viewEdit")}</DropdownMenuItem>
                                                    {order.status !== 'Recibido Completo' && (
                                                        <DropdownMenuItem onClick={() => handleReceive(order)}>
                                                            <CheckCircle className="mr-2 h-4 w-4" /> {t("purchaseOrderList.markReceived")}
                                                        </DropdownMenuItem>
                                                    )}
                                                    <DropdownMenuSeparator />
                                                    <DropdownMenuItem onClick={() => handleDelete(order)} className="text-red-600"><Trash2 className="mr-2 h-4 w-4" /> {t("common:delete")}</DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                )) : (
                                    <TableRow><TableCell colSpan="7" className="h-24 text-center text-gray-500">{t("purchaseOrderList.noOrders")}</TableCell></TableRow>
                                )}
                            </TableBody>
                            )}
                        </Table>
                        <div className="flex items-center justify-end space-x-2 py-4">
                            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1 || isLoading}>{t("purchaseOrderList.previous")}</Button>
                            <span className="text-sm">{t("common:page")} {page} {t("common:of")} {totalPages > 0 ? totalPages : 1}</span>
                            <Button variant="outline" size="sm" onClick={() => setPage(p => p + 1)} disabled={page >= totalPages || isLoading}>{t("purchaseOrderList.next")}</Button>
                        </div>
                    </CardContent>
                </Card>
                <AddEditPurchaseOrderDialog
                    isOpen={isDialogOpen}
                    setIsOpen={setIsDialogOpen}
                    purchaseOrderId={selectedOrderId}
                />
                <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>{t("common:areYouSure")}</AlertDialogTitle>
                            <AlertDialogDescription>{t("purchaseOrderList.deleteConfirmation", { orderNumber: orderToDelete?.order_number })}</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>{t("common:cancel")}</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isLoading}>
                                {deleteMutation.isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {t("common:delete")}
                            </AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
                <AlertDialog open={!!orderToReceive} onOpenChange={() => setOrderToReceive(null)}>
                     <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>{t("purchaseOrderList.confirmReceptionTitle")}</AlertDialogTitle>
                            <AlertDialogDescription>
                                {t("purchaseOrderList.confirmReceptionDesc", { orderNumber: orderToReceive?.order_number })}
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>{t("common:cancel")}</AlertDialogCancel>
                            <AlertDialogAction onClick={confirmReceive} disabled={receiveMutation.isPending}>
                                {receiveMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {t("purchaseOrderList.confirmReception")}
                            </AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </>
        );
    };

    export default PurchaseOrdersList;