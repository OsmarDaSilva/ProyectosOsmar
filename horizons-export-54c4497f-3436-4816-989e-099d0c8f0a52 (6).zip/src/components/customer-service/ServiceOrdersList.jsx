import React, { useState, useRef } from 'react';
    import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { PlusCircle, MoreHorizontal, Trash2, Pencil, Loader2, Printer, X, CheckSquare } from 'lucide-react';
    import { useToast } from "@/components/ui/use-toast";
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
    import AddEditServiceOrderDialog from './AddEditServiceOrderDialog';
    import { formatCurrency } from '@/lib/utils';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useReactToPrint } from 'react-to-print';
    import ServiceOrderPrintView from './ServiceOrderPrintView';
    import { Badge } from '@/components/ui/badge';
    import { useTranslation } from 'react-i18next';


    const ServiceOrdersList = () => {
      const { toast } = useToast();
      const queryClient = useQueryClient();
      const { user } = useAuth();
      const { t } = useTranslation('support');
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [selectedOrder, setSelectedOrder] = useState(null);
      const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
      const [orderToDelete, setOrderToDelete] = useState(null);
      const [isPrintDialogOpen, setIsPrintDialogOpen] = useState(false);
      const [orderToPrint, setOrderToPrint] = useState(null);
      const [orderToClose, setOrderToClose] = useState(null);
      const printComponentRef = useRef();

      const handlePrint = useReactToPrint({
        content: () => printComponentRef.current,
        documentTitle: `${t('serviceOrderList.pdfFilename')}-${String(orderToPrint?.order_number || '').padStart(5, '0')}`,
      });

      const { data: serviceOrders, isLoading: isLoadingOrders, isError: isErrorOrders, error: errorOrders } = useQuery({
        queryKey: ['service_orders', user?.id],
        queryFn: async () => {
          if (!user) return [];
          const { data, error } = await supabase
            .from('service_orders')
            .select(`
              *,
              client:clients(*),
              equipment:equipment(*),
              technician_profile:profiles(user_id, full_name),
              quote:quotes(manual_quote_number)
            `)
            .eq('user_id', user.id)
            .order('order_number', { ascending: false });

          if (error) {
              toast({ variant: "destructive", title: "Error", description: `Error al cargar órdenes de servicio: ${error.message}` });
              throw new Error(error.message);
          }
          return data;
        },
        enabled: !!user,
      });


      const { data: clients } = useQuery({
        queryKey: ['clients', user?.id],
        queryFn: async () => {
          if (!user) return [];
          const { data, error } = await supabase.from('clients').select('id, name').eq('user_id', user.id);
          if (error) throw error;
          return data;
        },
        enabled: !!user,
      });

      const { data: technicians } = useQuery({
        queryKey: ['technicians'],
        queryFn: async () => {
          if (!user) return [];
          const { data, error } = await supabase.functions.invoke('get-users');
          if (error) throw error;
          return data.filter(u => u.role === 'technician' || u.role === 'admin' || u.role === 'owner');
        },
        enabled: !!user,
      });

      const { data: lastOrderNumber } = useQuery({
        queryKey: ['last_service_order_number', user?.id],
        queryFn: async () => {
            if (!user) return 0;
            const { data, error } = await supabase
                .from('service_orders')
                .select('order_number')
                .eq('user_id', user.id)
                .order('order_number', { ascending: false })
                .limit(1)
                .single();
            if (error && error.code !== 'PGRST116') throw error;
            return data?.order_number || 0;
        },
        enabled: !!user,
      });

      const closeOrderMutation = useMutation({
        mutationFn: (orderId) => supabase.rpc('close_service_order', { p_so_id: orderId }),
        onSuccess: (result) => {
            const { data, error } = result;
            if (error) throw new Error(error.message);
            toast({ title: t("serviceOrderList.orderClosed"), description: data });
            queryClient.invalidateQueries({ queryKey: ['service_orders'] });
            queryClient.invalidateQueries({ queryKey: ['v_stock_per_deposit_summary'] });
            queryClient.invalidateQueries({ queryKey: ['kardex'] });
        },
        onError: (error) => {
            toast({ variant: "destructive", title: t("serviceOrderList.closeOrderErrorTitle"), description: error.message });
        },
        onSettled: () => setOrderToClose(null),
      });

      const mutation = useMutation({
        mutationFn: async (orderData) => {
          const { id, ...dataToUpsert } = orderData;
          const { data, error } = await supabase
            .from('service_orders')
            .upsert({ id, ...dataToUpsert }, { onConflict: 'id' })
            .select()
            .single();

          if (error) throw new Error(error.message);
          return data;
        },
        onSuccess: (data) => {
          queryClient.invalidateQueries({ queryKey: ['service_orders'] });
          queryClient.invalidateQueries({ queryKey: ['last_service_order_number'] });
          queryClient.invalidateQueries({ queryKey: ['v_stock_per_deposit_summary'] }); // Invalidate stock on change
          toast({
            title: t("serviceOrderList.saveSuccessTitle", { orderNumber: data.order_number }),
            description: t("serviceOrderList.saveSuccessDescription"),
          });
          setIsDialogOpen(false);
          setSelectedOrder(null);
        },
        onError: (error) => {
          toast({
            title: t("serviceOrderList.saveErrorTitle"),
            description: error.message,
            variant: "destructive",
          });
        },
      });

      const deleteMutation = useMutation({
        mutationFn: async (orderId) => {
          const { error } = await supabase.from('service_orders').delete().eq('id', orderId);
          if (error) throw new Error(error.message);
        },
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['service_orders'] });
          queryClient.invalidateQueries({ queryKey: ['v_stock_per_deposit_summary'] });
          toast({
            title: t("serviceOrderList.deleteSuccessTitle"),
            description: t("serviceOrderList.deleteSuccessDescription"),
          });
          setIsDeleteAlertOpen(false);
          setOrderToDelete(null);
        },
        onError: (error) => {
          toast({
            title: t("serviceOrderList.deleteErrorTitle"),
            description: error.message,
            variant: "destructive",
          });
        },
      });

      const handleNewOrder = () => {
        setSelectedOrder(null);
        setIsDialogOpen(true);
      };

      const handleEditOrder = (order) => {
        setSelectedOrder(order);
        setIsDialogOpen(true);
      };

      const handleDeleteOrder = (order) => {
        setOrderToDelete(order);
        setIsDeleteAlertOpen(true);
      };

      const handleViewPrintOrder = (order) => {
        setOrderToPrint(order);
        setIsPrintDialogOpen(true);
      };
      
      const handleCloseOrder = (order) => {
        setOrderToClose(order);
      };

      const confirmDelete = () => {
        if (orderToDelete) {
          deleteMutation.mutate(orderToDelete.id);
        }
      };

      const confirmCloseOrder = () => {
        if (orderToClose) {
          closeOrderMutation.mutate(orderToClose.id);
        }
      };
      
      const statusVariant = {
        'Borrador': 'secondary',
        'En Proceso': 'default',
        'Cerrado': 'success',
        'Facturado': 'outline',
        'Cancelado': 'destructive',
      };

      return (
        <>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>{t("serviceOrderList.title")}</CardTitle>
                <CardDescription>{t("serviceOrderList.description")}</CardDescription>
              </div>
              <Button onClick={handleNewOrder}>
                <PlusCircle className="mr-2 h-4 w-4" />
                {t("serviceOrderList.newOrder")}
              </Button>
            </CardHeader>
            <CardContent>
              {isLoadingOrders ? (
                <div className="flex justify-center items-center h-64">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("serviceOrderList.internalNumber")}</TableHead>
                        <TableHead>{t("serviceOrderList.manualNumber")}</TableHead>
                        <TableHead>{t("serviceOrderList.client")}</TableHead>
                        <TableHead>{t("serviceOrderList.equipmentSerial")}</TableHead>
                        <TableHead>{t("serviceOrderList.origin")}</TableHead>
                        <TableHead>{t("serviceOrderList.status")}</TableHead>
                        <TableHead className="text-right">{t("serviceOrderList.total")}</TableHead>
                        <TableHead>{t("serviceOrderList.date")}</TableHead>
                        <TableHead><span className="sr-only">{t("serviceOrderList.actions")}</span></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                    {isErrorOrders ? (
                      <TableRow><TableCell colSpan={9} className="h-24 text-center text-red-500">{`Error: ${errorOrders.message}`}</TableCell></TableRow>
                    ) : serviceOrders && serviceOrders.length > 0 ? (
                        serviceOrders.map(order => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">#{String(order.order_number).padStart(5, '0')}</TableCell>
                            <TableCell>{order.manual_order_number || '-'}</TableCell>
                            <TableCell>{order.client?.name || 'N/A'}</TableCell>
                            <TableCell>{order.equipment?.serial_number || order.unregistered_equipment || '—'}</TableCell>
                            <TableCell>{order.quote_id ? `${t('serviceOrderList.quoteShort')} ${order.quote?.manual_quote_number || t('serviceOrderList.approved')}` : t('serviceOrderList.direct')}</TableCell>
                            <TableCell><Badge variant={statusVariant[order.status] || 'default'}>{order.status}</Badge></TableCell>
                            <TableCell className="text-right">{formatCurrency(order.total)}</TableCell>
                            <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">{t("serviceOrderList.openMenu")}</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handleEditOrder(order)}>
                                    <Pencil className="mr-2 h-4 w-4" /> {t("common:viewEdit")}
                                  </DropdownMenuItem>
                                  {order.status !== 'Cerrado' && order.status !== 'Cancelado' && (
                                     <DropdownMenuItem onClick={() => handleCloseOrder(order)}>
                                        <CheckSquare className="mr-2 h-4 w-4 text-green-600" /> {t("serviceOrderList.closeOrder")}
                                    </DropdownMenuItem>
                                  )}
                                  <DropdownMenuItem onClick={() => handleViewPrintOrder(order)}>
                                    <Printer className="mr-2 h-4 w-4" /> {t("serviceOrderList.print")}
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => handleDeleteOrder(order)} className="text-red-600">
                                    <Trash2 className="mr-2 h-4 w-4" /> {t("common:delete")}
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={9} className="h-24 text-center">
                            {t("serviceOrderList.noOrdersFound")}
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {isDialogOpen && (
            <AddEditServiceOrderDialog
              isOpen={isDialogOpen}
              setIsOpen={setIsDialogOpen}
              serviceOrder={selectedOrder}
              onSave={(data) => mutation.mutate(data)}
              clients={clients}
              technicians={technicians}
              isLoading={mutation.isPending}
              lastOrderNumber={lastOrderNumber}
            />
          )}

          <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t("common:areYouSure")}</AlertDialogTitle>
                <AlertDialogDescription>
                  {t("serviceOrderList.deleteConfirmation", { orderNumber: orderToDelete?.order_number })}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t("common:cancel")}</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} disabled={deleteMutation.isPending}>
                  {deleteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {t("common:delete")}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          
          <AlertDialog open={!!orderToClose} onOpenChange={() => setOrderToClose(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>{t("serviceOrderList.closeOrderTitle")}</AlertDialogTitle>
                        <AlertDialogDescription>
                            {t("serviceOrderList.closeOrderConfirmation", { orderNumber: orderToClose?.order_number })}
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>{t("common:cancel")}</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmCloseOrder} disabled={closeOrderMutation.isPending}>
                            {closeOrderMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {t("serviceOrderList.confirmAndClose")}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
          
          <Dialog open={isPrintDialogOpen} onOpenChange={setIsPrintDialogOpen}>
            <DialogContent className="max-w-4xl h-[90vh]">
                <DialogHeader>
                    <DialogTitle>{t("serviceOrderList.previewTitle", { orderNumber: String(orderToPrint?.order_number || '').padStart(5, '0') })}</DialogTitle>
                </DialogHeader>
                <div className="overflow-auto p-2 h-full bg-gray-100">
                    <ServiceOrderPrintView ref={printComponentRef} serviceOrder={orderToPrint} />
                </div>
                <DialogFooter className="sm:justify-between">
                    <Button variant="outline" onClick={() => setIsPrintDialogOpen(false)}>
                        <X className="mr-2 h-4 w-4" /> {t("common:cancel")}
                    </Button>
                    <Button onClick={handlePrint}>
                        <Printer className="mr-2 h-4 w-4" /> {t("serviceOrderList.printSavePdf")}
                    </Button>
                </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      );
    };

    export default ServiceOrdersList;