import React, { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useDebounce } from '@/hooks/useDebounce';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Truck, Loader2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const searchSuppliers = async (user, searchTerm) => {
    if (!user || !searchTerm) return [];
    const { data, error } = await supabase.rpc('search_suppliers', {
        p_user_id: user.id,
        p_term: searchTerm,
    });
    if (error) throw error;
    return data;
};

const SupplierSelector = ({ onSelectSupplier, initialSupplier }) => {
    const { user } = useAuth();
    const { t } = useTranslation('support');
    const [searchTerm, setSearchTerm] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);
    const wrapperRef = useRef(null);
    const debouncedSearchTerm = useDebounce(searchTerm, 250);

    useEffect(() => {
        if (initialSupplier) {
            setSearchTerm(initialSupplier.name);
        } else {
            setSearchTerm('');
        }
    }, [initialSupplier]);
    
    const { data: suppliers, isLoading } = useQuery({
        queryKey: ['supplier_search', debouncedSearchTerm, user?.id],
        queryFn: () => searchSuppliers(user, debouncedSearchTerm),
        enabled: !!user && !!debouncedSearchTerm && showSuggestions,
    });

    const handleSelect = (supplier) => {
        onSelectSupplier(supplier);
        setSearchTerm(supplier.name);
        setShowSuggestions(false);
    };

    const handleInputChange = (e) => {
        setSearchTerm(e.target.value);
        if (e.target.value === '') {
            onSelectSupplier(null);
        }
        setShowSuggestions(true);
    };

    useEffect(() => {
        function handleClickOutside(event) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [wrapperRef]);

    return (
        <div className="relative" ref={wrapperRef}>
            <div className="relative">
                {isLoading ? (
                    <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 animate-spin text-muted-foreground" />
                ) : (
                    <Truck className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                )}
                <Input
                    type="text"
                    placeholder={t("supplierSelector.placeholder")}
                    value={searchTerm}
                    onChange={handleInputChange}
                    onFocus={() => setShowSuggestions(true)}
                    className="pl-10"
                />
            </div>
            {showSuggestions && suppliers && suppliers.length > 0 && (
                <Card className="absolute z-10 w-full mt-1 shadow-lg">
                    <CardContent className="p-2 max-h-60 overflow-y-auto">
                        {suppliers.map(supplier => (
                            <div
                                key={supplier.id}
                                className="p-2 hover:bg-accent rounded-md cursor-pointer"
                                onMouseDown={() => handleSelect(supplier)}
                            >
                                <p className="font-medium">{supplier.name}</p>
                                <p className="text-xs text-muted-foreground">{supplier.email || supplier.phone}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default SupplierSelector;