import React, { useState, useEffect, useRef } from 'react';
    import { useQuery } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { Input } from '@/components/ui/input';
    import { Card, CardContent } from '@/components/ui/card';
    import { ScrollArea } from '@/components/ui/scroll-area';

    const EquipmentSelector = ({ userId, onSelect, onInputChange, inputValue, setAllEquipment }) => {
        const [showSuggestions, setShowSuggestions] = useState(false);
        const wrapperRef = useRef(null);

        const { data: equipmentList, isLoading } = useQuery({
            queryKey: ['equipmentForService', userId],
            queryFn: async () => {
                const { data, error } = await supabase
                    .from('equipment')
                    .select(`id, serial_number, brand, model, client_id, client:clients(name)`)
                    .eq('user_id', userId)
                    .order('serial_number', { ascending: true });
                if (error) throw error;
                return data;
            },
            enabled: !!userId,
        });

        useEffect(() => {
            if (equipmentList) {
                setAllEquipment(equipmentList);
            }
        }, [equipmentList, setAllEquipment]);

        useEffect(() => {
            function handleClickOutside(event) {
                if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
                    setShowSuggestions(false);
                }
            }
            document.addEventListener("mousedown", handleClickOutside);
            return () => {
                document.removeEventListener("mousedown", handleClickOutside);
            };
        }, [wrapperRef]);

        const handleSelect = (equipment) => {
            onSelect(equipment);
            setShowSuggestions(false);
        };
        
        const handleInputChange = (e) => {
            const value = e.target.value;
            onInputChange(value);
            setShowSuggestions(!!value);
        };
        
        const filteredList = equipmentList?.filter(e => 
            (e.serial_number && e.serial_number.toLowerCase().includes(inputValue.toLowerCase())) ||
            (e.brand && e.brand.toLowerCase().includes(inputValue.toLowerCase())) ||
            (e.model && e.model.toLowerCase().includes(inputValue.toLowerCase())) ||
            (e.client?.name && e.client.name.toLowerCase().includes(inputValue.toLowerCase()))
        );

        return (
            <div className="relative w-full" ref={wrapperRef}>
                <Input
                    value={inputValue}
                    onChange={handleInputChange}
                    onFocus={() => setShowSuggestions(!!inputValue)}
                    placeholder="Escriba el N° de Serie del equipo..."
                    className="w-full"
                    autoComplete="off"
                />
                {showSuggestions && (
                    <Card className="absolute z-10 w-full mt-1 max-h-60 overflow-y-auto">
                        <ScrollArea>
                            <CardContent className="p-2">
                                {isLoading && <div className="p-2 text-sm text-center text-muted-foreground">Buscando...</div>}
                                {!isLoading && (!filteredList || filteredList.length === 0) && (
                                    <div className="p-2 text-sm text-center text-muted-foreground">
                                        <p>No se encontró equipo con "{inputValue}".</p>
                                        <p className="text-xs">Puede continuar para registrarlo como nuevo.</p>
                                    </div>
                                )}
                                {filteredList?.map((equipment) => (
                                    <div
                                        key={equipment.id}
                                        onClick={() => handleSelect(equipment)}
                                        className="p-2 hover:bg-accent rounded-md cursor-pointer"
                                    >
                                        <p className="font-medium">{`#${equipment.serial_number} - ${equipment.brand || ''} ${equipment.model || ''}`}</p>
                                        <p className="text-xs text-muted-foreground">{equipment.client?.name || 'Cliente no asignado'}</p>
                                    </div>
                                ))}
                            </CardContent>
                        </ScrollArea>
                    </Card>
                )}
            </div>
        );
    };

    export default EquipmentSelector;