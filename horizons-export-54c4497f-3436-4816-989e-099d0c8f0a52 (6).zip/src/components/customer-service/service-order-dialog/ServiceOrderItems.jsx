import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import ProductSelector from '../ProductSelector';
import { fmtUSD, toNumberSafe, round2 } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const ServiceOrderItems = ({ 
    items, setItems, 
    discountPercentage, setDiscountPercentage,
    kmQuantity, setKmQuantity,
    kmPrice, setKmPrice,
    laborQuantity, setLaborQuantity,
    laborPrice, setLaborPrice,
    totals,
    deposits,
    isLoadingDeposits
}) => {
    const handleProductSelect = (product) => {
        if (!items.find(p => p.sku === product.sku)) {
            const price = product.sale_price !== null && product.sale_price !== undefined ? product.sale_price : 0;
            setItems(prevItems => [...prevItems, { 
                sku: product.sku,
                product_name_snapshot: product.name,
                quantity: 1, 
                price: parseFloat(price.toFixed(2)),
                deposit_id: null,
            }]);
        }
    };

    const handleItemFieldChange = (sku, field, value) => {
        setItems(items.map(p => {
            if (p.sku === sku) {
                let newValue = value;
                if (field === 'deposit_id' && value === 'auto') {
                    newValue = null;
                }
                return { ...p, [field]: newValue };
            }
            return p;
        }));
    };

    const removeItem = (sku) => {
        setItems(items.filter(p => p.sku !== sku));
    };

    const handleNumericInputChange = (setter) => (e) => {
        setter(e.target.value);
    };

    return (
        <div className="md:col-span-2 space-y-4">
            <h3 className="text-lg font-semibold">Detalle de la Orden</h3>
            <div className="border rounded-md p-4 space-y-4">
                <h4 className="font-medium text-sm">Repuestos Utilizados</h4>
                <ProductSelector onSelectProduct={handleProductSelect} />
                <div className="border rounded-md">
                <TooltipProvider>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Producto</TableHead>
                                <TableHead className="w-[15%]">Depósito</TableHead>
                                <TableHead className="w-[12%] text-right">Cant.</TableHead>
                                <TableHead className="w-[15%] text-right">Precio</TableHead>
                                <TableHead className="w-[15%] text-right">Subtotal</TableHead>
                                <TableHead className="w-[5%]"></TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {items.length > 0 ? items.map(item => (
                                <TableRow key={item.sku}>
                                     <TableCell>
                                        <p className="font-medium text-sm">{item.product_name_snapshot}</p>
                                        <p className="text-xs text-muted-foreground">{item.sku}</p>
                                    </TableCell>
                                    <TableCell>
                                        <Select
                                            value={item.deposit_id || 'auto'}
                                            onValueChange={(value) => handleItemFieldChange(item.sku, 'deposit_id', value)}
                                            disabled={isLoadingDeposits}
                                        >
                                            <SelectTrigger className="h-8">
                                                <SelectValue placeholder="Depósito..." />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="auto">
                                                    <div className="flex items-center">
                                                        Auto (recom.)
                                                        <Tooltip>
                                                            <TooltipTrigger asChild>
                                                                <Info className="h-3 w-3 ml-2 text-muted-foreground"/>
                                                            </TooltipTrigger>
                                                            <TooltipContent>
                                                                <p>Asigna el stock desde el depósito con mayor disponibilidad.</p>
                                                            </TooltipContent>
                                                        </Tooltip>
                                                    </div>
                                                </SelectItem>
                                                {deposits?.map(d => (
                                                    <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                        {item.backorder && <Badge variant="destructive" className="mt-1">Faltante</Badge>}
                                    </TableCell>
                                    <TableCell>
                                        <Input type="text" value={String(item.quantity).replace('.',',')} onChange={(e) => handleItemFieldChange(item.sku, 'quantity', e.target.value)} className="h-8 text-right" />
                                    </TableCell>
                                    <TableCell>
                                        <Input type="text" value={String(item.price).replace('.',',')} onChange={(e) => handleItemFieldChange(item.sku, 'price', e.target.value)} className="h-8 text-right" />
                                    </TableCell>
                                    <TableCell className="text-right font-medium">{fmtUSD(round2(toNumberSafe(item.quantity) * toNumberSafe(item.price)))}</TableCell>
                                    <TableCell>
                                        <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(item.sku)} className="h-8 w-8"><Trash2 className="h-4 w-4 text-red-500" /></Button>
                                    </TableCell>
                                </TableRow>
                            )) : (
                                <TableRow><TableCell colSpan={6} className="h-24 text-center text-muted-foreground">Añada repuestos desde el buscador.</TableCell></TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TooltipProvider>
                </div>

                <h4 className="font-medium text-sm pt-4">Otros Costos (IVA Incluido)</h4>
                <div className="grid grid-cols-3 gap-x-4 gap-y-2 items-center">
                    <Label>Kilómetros (km)</Label>
                    <Label>Precio por km</Label>
                    <Label>Total km</Label>
                    <Input type="text" placeholder="0" value={String(kmQuantity).replace('.',',')} onChange={handleNumericInputChange(setKmQuantity)} />
                    <Input type="text" placeholder="0,00" value={String(kmPrice).replace('.',',')} onChange={handleNumericInputChange(setKmPrice)} />
                    <Input value={fmtUSD(totals.kmTotal)} readOnly disabled />

                    <Label>Mano de obra (Cant.)</Label>
                    <Label>Precio Mano de obra</Label>
                    <Label>Total Mano de obra</Label>
                    <Input type="text" placeholder="0" value={String(laborQuantity).replace('.',',')} onChange={handleNumericInputChange(setLaborQuantity)} />
                    <Input type="text" placeholder="0,00" value={String(laborPrice).replace('.',',')} onChange={handleNumericInputChange(setLaborPrice)} />
                    <Input value={fmtUSD(totals.laborTotal)} readOnly disabled />
                </div>
            </div>
            <div className="flex justify-end pt-4">
                <div className="w-full max-w-sm space-y-2">
                    <div className="flex justify-between items-center">
                        <span className="text-sm">Base Imponible</span>
                        <span className="font-semibold">{fmtUSD(totals.netAmount)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          <Label htmlFor="discount">Descuento (%)</Label>
                        </div>
                        <Input id="discount" type="number" value={discountPercentage} onChange={(e) => setDiscountPercentage(parseFloat(e.target.value) || 0)} className="h-8 w-20 text-right" />
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-500">
                        <span>IVA (10%) incluido en Total</span>
                        <span>{fmtUSD(totals.taxAmount)}</span>
                    </div>
                    <div className="flex justify-between items-center font-bold text-lg border-t pt-2 mt-2">
                        <span>Total General</span>
                        <span>{fmtUSD(totals.total)}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ServiceOrderItems;