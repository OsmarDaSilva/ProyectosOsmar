import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { Label } from '@/components/ui/label';
    import { Input } from '@/components/ui/input';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import EquipmentSelector from './EquipmentSelector';
    import { useAuth } from '@/contexts/SupabaseAuthContext';

    const ServiceOrderForm = ({ formData, setFormData, clients, technicians, isOpen }) => {
        const { user } = useAuth();
        const [equipmentInputValue, setEquipmentInputValue] = useState('');
        const [isNewEquipment, setIsNewEquipment] = useState(false);
        const allEquipment = useMemo(() => formData.allEquipment || [], [formData.allEquipment]);

        const handleEquipmentInputChange = useCallback((value) => {
            setEquipmentInputValue(value);
            const trimmedValue = value ? value.trim().toLowerCase() : '';

            if (!trimmedValue) {
                setFormData(prev => ({
                    ...prev,
                    equipment_id: null,
                    unregistered_equipment: null,
                }));
                setIsNewEquipment(false);
                return;
            }

            const existingEquipment = allEquipment.find(
                (eq) => eq.serial_number && eq.serial_number.toLowerCase() === trimmedValue
            );

            if (existingEquipment) {
                setFormData(prev => ({
                    ...prev,
                    equipment_id: existingEquipment.id,
                    client_id: existingEquipment.client_id,
                    unregistered_equipment: null,
                }));
                setIsNewEquipment(false);
            } else {
                setFormData(prev => ({
                    ...prev,
                    equipment_id: null,
                    client_id: prev.equipment_id ? prev.client_id : (prev.client_id || null),
                    unregistered_equipment: value.trim(),
                }));
                setIsNewEquipment(true);
            }
        }, [setFormData, allEquipment]);


        const handleEquipmentSelect = useCallback((equipment) => {
            if (equipment) {
                setEquipmentInputValue(equipment.serial_number);
                setFormData(prev => ({
                    ...prev,
                    equipment_id: equipment.id,
                    client_id: equipment.client_id,
                    unregistered_equipment: null,
                }));
                setIsNewEquipment(false);
            }
        }, [setFormData]);

        useEffect(() => {
            if (isOpen) {
                if (formData.id) {
                    const initialValue = formData.equipment?.serial_number || formData.unregistered_equipment || '';
                    setEquipmentInputValue(initialValue);
                    handleEquipmentInputChange(initialValue);
                } else {
                    setEquipmentInputValue('');
                    handleEquipmentInputChange('');
                }
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [isOpen, formData?.id]);


        const isClientSelectDisabled = useMemo(() => {
            const hasSelectedEquipment = !!formData.equipment_id;
            return hasSelectedEquipment && !isNewEquipment;
        }, [formData.equipment_id, isNewEquipment]);
        
        const clientHelperText = useMemo(() => {
            if (isClientSelectDisabled) return "Cliente autocompletado del equipo registrado.";
            if (!formData.client_id) return "Por favor, seleccione un cliente.";
            return "Puede cambiar el cliente si es necesario.";
        }, [isClientSelectDisabled, formData.client_id]);

        return (
            <div className="md:col-span-1 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="order_number">N° Orden Interno</Label>
                        <Input id="order_number" value={String(formData.order_number || '').padStart(5, '0')} readOnly disabled />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="manual_order_number">N° Orden Manual</Label>
                        <Input 
                            id="manual_order_number" 
                            value={formData.manual_order_number || ''} 
                            onChange={(e) => setFormData({...formData, manual_order_number: e.target.value})}
                            placeholder="Opcional"
                        />
                    </div>
                </div>

                <div className="space-y-2">
                    <Label htmlFor="client_id">Cliente <span className="text-red-500">*</span></Label>
                    <Select
                        onValueChange={(value) => setFormData(prev => ({ ...prev, client_id: value }))}
                        value={formData.client_id || ''}
                        required
                        disabled={isClientSelectDisabled}
                    >
                        <SelectTrigger><SelectValue placeholder="Seleccione un cliente..." /></SelectTrigger>
                        <SelectContent>
                            {clients?.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                        </SelectContent>
                    </Select>
                     <p className="text-xs text-muted-foreground">{clientHelperText}</p>
                </div>

                <div className="space-y-2">
                    <Label>Equipo (N° de Serie) - Opcional</Label>
                    <EquipmentSelector
                        userId={user.id}
                        onSelect={handleEquipmentSelect}
                        onInputChange={handleEquipmentInputChange}
                        inputValue={equipmentInputValue}
                        selectedEquipmentId={formData.equipment_id}
                        setAllEquipment={(equipment) => setFormData(prev => ({ ...prev, allEquipment: equipment }))}
                    />
                </div>

                <div className="space-y-2">
                    <Label htmlFor="technician_id">Técnico Asignado</Label>
                    <Select onValueChange={(value) => setFormData(prev => ({...prev, technician_id: value === 'no_technician' ? null : value }))} value={formData.technician_id || 'no_technician'}>
                        <SelectTrigger><SelectValue placeholder="Seleccione un técnico..." /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="no_technician">No Asignado</SelectItem>
                            {technicians?.map(t => <SelectItem key={t.id} value={t.id}>{t.name || t.email}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="status">Estado</Label>
                    <Select onValueChange={(value) => setFormData(prev => ({...prev, status: value}))} value={formData.status || 'Borrador'}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="Borrador">Borrador</SelectItem>
                            <SelectItem value="En Proceso">En Proceso</SelectItem>
                            <SelectItem value="Cerrado">Cerrado</SelectItem>
                            <SelectItem value="Facturado">Facturado</SelectItem>
                            <SelectItem value="Cancelado">Cancelado</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <Label htmlFor="description">Diagnóstico / Descripción del Servicio</Label>
                    <Textarea id="description" value={formData.description || ''} onChange={(e) => setFormData(prev => ({...prev, description: e.target.value}))} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="notes">Observaciones</Label>
                    <Textarea id="notes" value={formData.notes || ''} onChange={(e) => setFormData(prev => ({...prev, notes: e.target.value}))} />
                </div>
            </div>
        );
    };

    export default ServiceOrderForm;