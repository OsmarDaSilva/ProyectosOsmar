import React, { useState, useEffect, useMemo, useCallback } from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Loader2 } from 'lucide-react';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { supabase } from '@/lib/customSupabaseClient';
    import ServiceOrderForm from './service-order-dialog/ServiceOrderForm';
    import ServiceOrderItems from './service-order-dialog/ServiceOrderItems';
    import { useToast } from '@/components/ui/use-toast';
    import { useQuery } from '@tanstack/react-query';
    import { useTranslation } from 'react-i18next';
    import { toNumberSafe, round2 } from '@/lib/utils';

    const AddEditServiceOrderDialog = ({ isOpen, setIsOpen, serviceOrder, onSave, clients, isLoading, lastOrderNumber }) => {
        const { user } = useAuth();
        const { toast } = useToast();
        const { t } = useTranslation('support');
        const [formData, setFormData] = useState({});
        const [items, setItems] = useState([]);
        const [discountPercentage, setDiscountPercentage] = useState(0);
        const [kmQuantity, setKmQuantity] = useState(0);
        const [kmPrice, setKmPrice] = useState(0);
        const [laborQuantity, setLaborQuantity] = useState(0);
        const [laborPrice, setLaborPrice] = useState(0);

        const { data: deposits, isLoading: isLoadingDeposits } = useQuery({
            queryKey: ['deposits', user?.id],
            queryFn: async () => {
                const { data, error } = await supabase.from('deposits').select('id, name').eq('user_id', user.id);
                if (error) throw error;
                return data;
            },
            enabled: !!user?.id,
        });

        const { data: technicians } = useQuery({
            queryKey: ['technicians', user?.company?.id],
            queryFn: async () => {
                if (!user.company?.id) return [];
                const { data, error } = await supabase.rpc('list_technicians', { p_org_id: user.company.id });
                if (error) {
                    console.error('Error fetching technicians:', error);
                    return [];
                }
                return data;
            },
            enabled: !!user?.company?.id,
        });

        const totals = useMemo(() => {
            const itemsTotal = items.reduce((acc, p) => acc + (toNumberSafe(p.quantity) * toNumberSafe(p.price)), 0);
            const kmTotal = toNumberSafe(kmQuantity) * toNumberSafe(kmPrice);
            const laborTotal = toNumberSafe(laborQuantity) * toNumberSafe(laborPrice);
            
            const grossTotal = itemsTotal + kmTotal + laborTotal;
            const discountAmount = round2(grossTotal * (toNumberSafe(discountPercentage) / 100));
            const totalWithDiscount = grossTotal - discountAmount;
            
            const taxAmount = round2(totalWithDiscount / 11);
            const netAmount = totalWithDiscount - taxAmount;
        
            return {
              itemsTotal: round2(itemsTotal),
              kmTotal: round2(kmTotal),
              laborTotal: round2(laborTotal),
              subtotal: round2(grossTotal),
              discountAmount,
              taxAmount,
              netAmount,
              total: round2(totalWithDiscount),
            };
        }, [items, kmQuantity, kmPrice, laborQuantity, laborPrice, discountPercentage]);

        const resetState = useCallback(() => {
            if (serviceOrder) {
                const initialFormData = {
                    ...serviceOrder,
                    client_id: serviceOrder.client_id || null,
                    technician_id: serviceOrder.technician_id || null,
                    equipment_id: serviceOrder.equipment_id || null,
                    status: serviceOrder.status || 'Borrador',
                    manual_order_number: serviceOrder.manual_order_number || '',
                };
                setFormData(initialFormData);
                setItems(serviceOrder.items.map(i => ({...i, deposit_id: i.deposit_id || null})) || []);
                setDiscountPercentage(serviceOrder.discount_percentage || 0);
                setKmQuantity(serviceOrder.km_quantity || 0);
                setKmPrice(serviceOrder.km_price || 0);
                setLaborQuantity(serviceOrder.labor_quantity || 0);
                setLaborPrice(serviceOrder.labor_price || 0);
            } else {
                setFormData({
                    client_id: null,
                    technician_id: null,
                    equipment_id: null,
                    status: 'Borrador',
                    description: '',
                    notes: '',
                    order_number: (lastOrderNumber || 0) + 1,
                    manual_order_number: '',
                    unregistered_equipment: null,
                });
                setItems([]);
                setDiscountPercentage(0);
                setKmQuantity(0);
                setKmPrice(0);
                setLaborQuantity(0);
                setLaborPrice(0);
            }
        }, [serviceOrder, lastOrderNumber]);

        useEffect(() => {
            if (isOpen) {
               resetState();
            }
        }, [serviceOrder, isOpen, resetState]);
        
        const handleSubmit = async (e) => {
            e.preventDefault();

            if (!formData.client_id) {
                toast({
                    variant: "destructive",
                    title: t("serviceOrderDialog.validationErrorTitle"),
                    description: t("serviceOrderDialog.clientRequired"),
                });
                return;
            }

            const isNewEquipment = !formData.equipment_id && formData.unregistered_equipment;

            if (isNewEquipment) {
                const serial = formData.unregistered_equipment;
                
                const { data: existingEquipment, error: checkError } = await supabase
                    .from('equipment')
                    .select('id, client:clients(name)')
                    .eq('serial_number', serial.trim())
                    .single();
                
                if (checkError && checkError.code !== 'PGRST116') {
                    toast({ variant: "destructive", title: t("serviceOrderDialog.dbErrorTitle"), description: checkError.message });
                    return;
                }

                if (existingEquipment) {
                    toast({
                        variant: "destructive",
                        title: t("serviceOrderDialog.duplicateEquipmentTitle"),
                        description: t("serviceOrderDialog.duplicateEquipmentDesc", { serial: serial, clientName: existingEquipment.client.name }),
                        duration: 7000
                    });
                    return;
                }
            }
            
            const dataToSave = { 
                ...formData, 
                user_id: user.id,
                items: items.map(i => ({...i, quantity: toNumberSafe(i.quantity), price: toNumberSafe(i.price)})),
                subtotal: totals.netAmount,
                discount_percentage: toNumberSafe(discountPercentage),
                discount_amount: totals.discountAmount,
                tax_amount: totals.taxAmount,
                total: totals.total,
                km_quantity: toNumberSafe(kmQuantity),
                km_price: toNumberSafe(kmPrice),
                km_total: totals.kmTotal,
                labor_quantity: toNumberSafe(laborQuantity),
                labor_price: toNumberSafe(laborPrice),
                labor_total: totals.laborTotal,
                unregistered_equipment: formData.unregistered_equipment ? formData.unregistered_equipment.trim() : null,
                equipment_id: formData.unregistered_equipment ? null : formData.equipment_id,
            };
            
            delete dataToSave.equipment;
            delete dataToSave.allEquipment;
            delete dataToSave.total_parts;
            delete dataToSave.client;
            delete dataToSave.quote;
            delete dataToSave.technician_profile;


            onSave(dataToSave);
        };
        
        return (
          <>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="sm:max-w-7xl">
                    <form id="service-order-form" onSubmit={handleSubmit}>
                        <DialogHeader>
                            <DialogTitle>{serviceOrder ? t("serviceOrderDialog.editTitle") : t("serviceOrderDialog.createTitle")}</DialogTitle>
                            <DialogDescription>{t("serviceOrderDialog.description")}</DialogDescription>
                        </DialogHeader>
                        <ScrollArea className="h-[70vh] pr-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
                                <ServiceOrderForm
                                    formData={formData}
                                    setFormData={setFormData}
                                    clients={clients}
                                    technicians={technicians}
                                    isOpen={isOpen}
                                />
                                <ServiceOrderItems
                                    items={items}
                                    setItems={setItems}
                                    discountPercentage={discountPercentage}
                                    setDiscountPercentage={setDiscountPercentage}
                                    kmQuantity={kmQuantity}
                                    setKmQuantity={setKmQuantity}
                                    kmPrice={kmPrice}
                                    setKmPrice={setKmPrice}
                                    laborQuantity={laborQuantity}
                                    setLaborQuantity={setLaborQuantity}
                                    laborPrice={laborPrice}
                                    setLaborPrice={setLaborPrice}
                                    totals={totals}
                                    deposits={deposits}
                                    isLoadingDeposits={isLoadingDeposits}
                                />
                            </div>
                        </ScrollArea>
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={() => setIsOpen(false)} disabled={isLoading}>{t("common:cancel")}</Button>
                            <Button type="submit" form="service-order-form" disabled={isLoading}>
                                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                {t("serviceOrderDialog.save")}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
          </>
        );
    };

    export default AddEditServiceOrderDialog;