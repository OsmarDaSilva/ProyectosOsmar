import React, { useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Trash2, Info } from 'lucide-react';
import ProductSelector from '../ProductSelector';
import { fmtUSD, toNumberSafe, round2 } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { useTranslation } from 'react-i18next';

const QuoteItems = ({
    items,
    setItems,
    deposits,
    isLoadingDeposits,
    kmQuantity,
    setKmQuantity,
    kmPrice,
    setKmPrice,
    laborQuantity,
    setLaborQuantity,
    laborPrice,
    setLaborPrice,
}) => {
    const { t } = useTranslation('support');

    const totals = useMemo(() => {
        const kmTotal = round2(toNumberSafe(kmQuantity) * toNumberSafe(kmPrice));
        const laborTotal = round2(toNumberSafe(laborQuantity) * toNumberSafe(laborPrice));
        return { kmTotal, laborTotal };
    }, [kmQuantity, kmPrice, laborQuantity, laborPrice]);

    const handleProductSelect = (product) => {
        if (!items.find(p => p.sku === product.sku)) {
            const price = product.sale_price !== null && product.sale_price !== undefined ? product.sale_price : 0;
            setItems(prevItems => [...prevItems, { 
                sku: product.sku,
                product_name_snapshot: product.name,
                quantity: 1, 
                price: parseFloat(price.toFixed(2)),
                deposit_id: null // Auto por defecto
            }]);
        }
    };

    const handleItemFieldChange = (sku, field, value) => {
        setItems(items.map(p => {
            if (p.sku === sku) {
                let newValue = value;
                if (field === 'deposit_id' && value === 'auto') {
                    newValue = null;
                }
                return { ...p, [field]: newValue };
            }
            return p;
        }));
    };
    
    const removeItem = (sku) => {
        setItems(items.filter(p => p.sku !== sku));
    };

    return (
        <div className="border rounded-md p-4 space-y-4">
            <h4 className="font-medium text-sm">{t("quoteDialog.productsAndServices")}</h4>
            <ProductSelector onSelectProduct={handleProductSelect} />
            <div className="border rounded-md">
            <TooltipProvider>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>{t("quoteDialog.productService")}</TableHead>
                            <TableHead className="w-[15%]">{t("quoteDialog.deposit")}</TableHead>
                            <TableHead className="w-[12%] text-right">{t("quoteDialog.quantity")}</TableHead>
                            <TableHead className="w-[15%] text-right">{t("quoteDialog.unitPrice")}</TableHead>
                            <TableHead className="w-[15%] text-right">{t("quoteDialog.total")}</TableHead>
                            <TableHead className="w-[5%]"></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {items.length > 0 ? items.map(item => {
                            const lineTotal = round2(toNumberSafe(item.quantity) * toNumberSafe(item.price));
                            return (
                            <TableRow key={item.sku}>
                                <TableCell>
                                    <p className="font-medium text-sm">{item.product_name_snapshot}</p>
                                    <p className="text-xs text-muted-foreground">{item.sku}</p>
                                </TableCell>
                                <TableCell>
                                    <Select
                                        value={item.deposit_id || 'auto'}
                                        onValueChange={(value) => handleItemFieldChange(item.sku, 'deposit_id', value)}
                                        disabled={isLoadingDeposits}
                                    >
                                        <SelectTrigger className="h-8">
                                            <SelectValue placeholder={t("quoteDialog.deposit")} />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="auto">
                                                <div className="flex items-center">
                                                    {t("quoteDialog.autoAssign")}
                                                    <Tooltip>
                                                        <TooltipTrigger asChild>
                                                            <Info className="h-3 w-3 ml-2 text-muted-foreground"/>
                                                        </TooltipTrigger>
                                                        <TooltipContent>
                                                            <p>{t("quoteItems.autoTooltip")}</p>
                                                        </TooltipContent>
                                                    </Tooltip>
                                                </div>
                                            </SelectItem>
                                            {deposits?.map(d => (
                                                <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                     {item.backorder && <Badge variant="destructive" className="mt-1">{t("quoteItems.missing")}</Badge>}
                                </TableCell>
                                <TableCell>
                                    <Input inputMode="decimal" type="text" value={String(item.quantity).replace('.',',')} onChange={(e) => handleItemFieldChange(item.sku, 'quantity', e.target.value)} className="h-8 text-right" />
                                </TableCell>
                                <TableCell>
                                    <Input inputMode="decimal" type="text" value={String(item.price).replace('.',',')} onChange={(e) => handleItemFieldChange(item.sku, 'price', e.target.value)} className="h-8 text-right" />
                                </TableCell>
                                <TableCell className="text-right font-medium">{fmtUSD(lineTotal)}</TableCell>
                                <TableCell>
                                    <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(item.sku)} className="h-8 w-8"><Trash2 className="h-4 w-4 text-red-500" /></Button>
                                </TableCell>
                            </TableRow>
                        )}) : (
                            <TableRow><TableCell colSpan={6} className="h-24 text-center text-muted-foreground">{t("quoteDialog.noItems")}</TableCell></TableRow>
                        )}
                    </TableBody>
                </Table>
            </TooltipProvider>
            </div>

            <h4 className="font-medium text-sm pt-4">{t("quoteDialog.otherCosts")}</h4>
            <div className="grid grid-cols-3 gap-x-4 gap-y-2 items-center">
                <Label>{t("quoteDialog.km")}</Label>
                <Label>{t("quoteDialog.kmPrice")}</Label>
                <Label>{t("quoteDialog.total")}</Label>
                <Input inputMode="decimal" type="text" placeholder="0" value={String(kmQuantity).replace('.',',')} onChange={e => setKmQuantity(e.target.value)} />
                <Input inputMode="decimal" type="text" placeholder="0,00" value={String(kmPrice).replace('.',',')} onChange={e => setKmPrice(e.target.value)} />
                <Input value={fmtUSD(totals.kmTotal)} readOnly disabled />

                <Label>{t("quoteDialog.labor")}</Label>
                <Label>{t("quoteDialog.laborPrice")}</Label>
                <Label>{t("quoteDialog.total")}</Label>
                <Input inputMode="decimal" type="text" placeholder="0" value={String(laborQuantity).replace('.',',')} onChange={e => setLaborQuantity(e.target.value)} />
                <Input inputMode="decimal" type="text" placeholder="0,00" value={String(laborPrice).replace('.',',')} onChange={e => setLaborPrice(e.target.value)} />
                <Input value={fmtUSD(totals.laborTotal)} readOnly disabled />
            </div>
        </div>
    );
};

export default QuoteItems;