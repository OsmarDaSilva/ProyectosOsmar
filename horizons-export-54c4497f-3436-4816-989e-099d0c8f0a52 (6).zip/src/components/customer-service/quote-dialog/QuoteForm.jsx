import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useTranslation } from 'react-i18next';

const QuoteForm = ({ formData, setFormData, clients }) => {
    const { t } = useTranslation('support');
    return (
        <div className="md:col-span-1 space-y-4">
            <div className="space-y-2">
                <Label htmlFor="quote_number">{t("quoteDialog.quoteNumber")}</Label>
                <Input id="quote_number" value={formData.quote_number || ''} readOnly disabled />
            </div>
            <div className="space-y-2">
                <Label htmlFor="manual_quote_number">{t("quoteDialog.manualQuoteNumber")}</Label>
                <Input 
                    id="manual_quote_number" 
                    value={formData.manual_quote_number || ''} 
                    onChange={(e) => setFormData({...formData, manual_quote_number: e.target.value})}
                    placeholder={t("quoteDialog.manualQuoteNumberPlaceholder")}
                />
            </div>
            <div className="space-y-2">
                <Label htmlFor="client_id">{t("quoteDialog.client")}</Label>
                <Select onValueChange={(value) => setFormData({...formData, client_id: value})} value={formData.client_id || ''}>
                    <SelectTrigger><SelectValue placeholder={t("quoteDialog.clientRequired")} /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value={null}>{t("quoteDialog.client")}</SelectItem>
                        {clients?.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
            <div className="space-y-2">
                <Label htmlFor="status">{t("quoteDialog.status")}</Label>
                <Select onValueChange={(value) => setFormData({...formData, status: value})} value={formData.status}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Borrador">{t("quoteDialog.statusDraft")}</SelectItem>
                        <SelectItem value="Enviado">{t("quoteDialog.statusSent")}</SelectItem>
                        <SelectItem value="Aceptado">{t("quoteDialog.statusAccepted")}</SelectItem>
                        <SelectItem value="Rechazado">{t("quoteDialog.statusRejected")}</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div className="space-y-2">
                <Label htmlFor="notes">{t("quoteDialog.notes")}</Label>
                <Textarea id="notes" value={formData.notes || ''} onChange={(e) => setFormData({...formData, notes: e.target.value})} />
            </div>
        </div>
    );
};

export default QuoteForm;