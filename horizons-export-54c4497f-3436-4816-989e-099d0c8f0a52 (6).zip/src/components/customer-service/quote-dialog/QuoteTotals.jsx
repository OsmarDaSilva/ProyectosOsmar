import React from 'react';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { fmtUSD } from '@/lib/utils';
    import { useTranslation } from 'react-i18next';

    const QuoteTotals = ({ netAmount, discountAmount, discountPercentage, setDiscountPercentage, taxAmount, total }) => {
        const { t } = useTranslation('support');
        return (
            <div className="flex justify-end pt-4">
                <div className="w-full max-w-sm space-y-2">
                    <div className="flex justify-between items-center">
                        <span className="text-sm">Base Imponible</span>
                        <span className="font-semibold text-sm">{fmtUSD(netAmount)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                            <Label htmlFor="discount" className="text-sm">{t("quoteDialog.discount")}</Label>
                            <Input 
                                id="discount" 
                                type="number" 
                                value={discountPercentage} 
                                onChange={(e) => setDiscountPercentage(parseFloat(e.target.value) || 0)} 
                                className="h-8 w-20 text-right"
                                placeholder="%"
                            />
                        </div>
                        <span className="text-sm">(-{fmtUSD(discountAmount)})</span>
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-500">
                        <span>IVA (10% - incluido en total)</span>
                        <span>{fmtUSD(taxAmount)}</span>
                    </div>
                    <div className="flex justify-between items-center font-bold text-lg border-t pt-2 mt-2">
                        <span>{t("quoteDialog.grandTotal")}</span>
                        <span>{fmtUSD(total)}</span>
                    </div>
                </div>
            </div>
        );
    };

    export default QuoteTotals;