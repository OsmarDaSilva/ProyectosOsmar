import React from 'react';
    import { Helmet } from 'react-helmet-async';
    import {
      Home, Beef, Tractor, Repeat, TrendingUp, FileText, LineChart, Leaf, Combine,
    } from 'lucide-react';
    import AppHeader from '@/components/layout/AppHeader';
    import CalculatorNavbar from '@/components/layout/CalculatorNavbar';
    import PageContent from '@/components/layout/PageContent';

    const AppLayout = ({
      projectData,
      agricultureData,
      ganaderiaData,
      currentView,
      setCurrentView,
      onProjectUpdate,
      onAgricultureUpdate,
      onGanaderiaUpdate,
    }) => {

      const menuItems = [
        { id: 'inicial', label: 'Inicio', icon: Home, required: true },
        { id: 'ganaderia', label: 'Ganadería', icon: Beef, module: 'ganaderia' },
        { id: 'agricultura', label: 'Agricultura', icon: Tractor, module: 'agricultura' },
        { id: 'viabilidad', label: 'Viabilidad', icon: Repeat, required: true },
        { id: 'analisis', label: 'Análisis Financiero', icon: TrendingUp, required: true },
        { id: 'resumen', label: 'Resumen Ejecutivo', icon: FileText, required: true },
        { id: 'graficos', label: 'Gráficos', icon: LineChart, required: true },
        { id: 'carbono', label: 'Balance Carbono', icon: Leaf, required: true },
        { id: 'livestock_simulation', label: 'Simulación', icon: Combine, module: 'ganaderia' },
      ];

      const currentMenuItem = menuItems.find(item => item.id === currentView);
      const pageTitle = currentMenuItem ? `${currentMenuItem.label} - ${projectData?.projectName || 'AGRO invest'}` : 'AGRO invest';

      return (
        <div className="min-h-screen bg-gray-100">
          <Helmet>
            <title>{pageTitle}</title>
          </Helmet>
          <AppHeader />
          <div className="flex">
            <CalculatorNavbar
              menuItems={menuItems}
              currentView={currentView}
              setCurrentView={setCurrentView}
              projectData={projectData}
            />
            <div className="flex-1">
              <PageContent
                currentView={currentView}
                projectData={projectData}
                agricultureData={agricultureData}
                ganaderiaData={ganaderiaData}
                onProjectUpdate={onProjectUpdate}
                onAgricultureUpdate={onAgricultureUpdate}
                onGanaderiaUpdate={onGanaderiaUpdate}
              />
            </div>
          </div>
        </div>
      );
    };

    export default AppLayout;