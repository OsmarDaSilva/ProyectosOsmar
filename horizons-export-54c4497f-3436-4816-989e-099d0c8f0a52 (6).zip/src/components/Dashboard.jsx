import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  BarChart3, 
  PieChart, 
  Calculator,
  Sprout,
  Droplets,
  AlertTriangle,
  Wheat,
  Tractor,
  Landmark
} from 'lucide-react';

const Dashboard = ({ projectData, calculations, ganaderiaCalculations, agricultureCalculations }) => {
  const formatCurrency = (value) => {
    if (isNaN(value)) return 'U$ 0';
    return `U$ ${new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value)}`;
  };

  if (!calculations || !ganaderiaCalculations || !agricultureCalculations) {
    return (
      <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
        <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800">Cargando Datos...</h2>
        <p className="text-gray-600 text-lg mt-2">
          Esperando la información del proyecto para generar el resumen.
        </p>
      </div>
    );
  }

  const { totalInvestment, totalFinancingCost } = calculations;
  const { tradicional: gTradicional, intensivo: gIntensivo } = ganaderiaCalculations;
  const { tradicional: aTradicional, tecnified: aTecnified } = agricultureCalculations.totalCalculations;
  
  const modules = projectData?.modules || { ganaderia: true, agricultura: true };
  const totalGananciaIntensivo = (modules.ganaderia ? gIntensivo.gananciaFinalRebano : 0) + (modules.agricultura ? aTecnified : 0);
  const totalGananciaTradicional = (modules.ganaderia ? gTradicional.gananciaFinalRebano : 0) + (modules.agricultura ? aTradicional : 0);
  const totalDiferencia = totalGananciaIntensivo - totalGananciaTradicional;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <h1 className="text-4xl font-bold gradient-text">Resumen Ejecutivo</h1>
        <p className="text-gray-600">Análisis completo de viabilidad del proyecto</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }}>
          <Card className="metric-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Inversión Total</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{formatCurrency(totalInvestment)}</div>
              <p className="text-xs text-gray-500 mt-1">Capital Inicial (Modelo Tecnificado)</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.15 }}>
          <Card className="metric-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Costo Total de Financiación</CardTitle>
              <Landmark className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{formatCurrency(totalFinancingCost)}</div>
              <p className="text-xs text-gray-500 mt-1">Capital + Intereses a {calculations.plazo} años</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }}>
          <Card className="metric-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Ganancia Anual (Tecnificado)</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{formatCurrency(totalGananciaIntensivo)}</div>
              <p className="text-xs text-gray-500 mt-1">Suma de Módulos Habilitados</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.3 }}>
          <Card className="metric-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Diferencia de Ganancia</CardTitle>
              {totalDiferencia >= 0 ? <TrendingUp className="h-4 w-4 text-green-600" /> : <TrendingDown className="h-4 w-4 text-red-600" />}
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${totalDiferencia >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(totalDiferencia)}</div>
              <p className="text-xs text-gray-500 mt-1">Tecnificado vs Tradicional</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {modules.ganaderia && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <h2 className="text-2xl font-bold text-gray-800 mb-3 text-center">Resumen Ganadería</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="traditional-card">
              <CardHeader><CardTitle className="flex items-center space-x-2"><Sprout className="h-5 w-5 text-orange-600" /><span>Modelo Tradicional</span></CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div><p className="text-sm text-gray-600">Ingresos (Venta)</p><p className="text-lg font-semibold text-gray-900">{formatCurrency(gTradicional.valorVentaRebano)}</p></div>
                  <div><p className="text-sm text-gray-600">Ganancia Final</p><p className={`text-lg font-semibold ${gTradicional.gananciaFinalRebano >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatCurrency(gTradicional.gananciaFinalRebano)}</p></div>
                </div>
              </CardContent>
            </Card>
            <Card className="tech-card">
              <CardHeader><CardTitle className="flex items-center space-x-2"><Droplets className="h-5 w-5 text-green-600" /><span>Modelo Intensivo</span></CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div><p className="text-sm text-gray-600">Ingresos (Venta)</p><p className="text-lg font-semibold text-gray-900">{formatCurrency(gIntensivo.valorVentaRebano)}</p></div>
                  <div><p className="text-sm text-gray-600">Ganancia Final</p><p className={`text-lg font-semibold ${gIntensivo.gananciaFinalRebano >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatCurrency(gIntensivo.gananciaFinalRebano)}</p></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      )}

      {modules.agricultura && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
          <h2 className="text-2xl font-bold text-gray-800 mb-3 text-center">Resumen Agricultura</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="traditional-card">
              <CardHeader><CardTitle className="flex items-center space-x-2"><Wheat className="h-5 w-5 text-orange-600" /><span>Modelo Tradicional</span></CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Ganancia Anual Total</p>
                <p className={`text-xl font-semibold ${aTradicional >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatCurrency(aTradicional)}</p>
              </CardContent>
            </Card>
            <Card className="tech-card">
              <CardHeader><CardTitle className="flex items-center space-x-2"><Tractor className="h-5 w-5 text-green-600" /><span>Modelo Tecnificado</span></CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Ganancia Anual Total</p>
                <p className={`text-xl font-semibold ${aTecnified >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatCurrency(aTecnified)}</p>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      )}

    </div>
  );
};

export default Dashboard;