import React, { useRef, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Printer, TrendingUp, DollarSign, Landmark, AlertTriangle, CheckCircle } from 'lucide-react';
import { useReactToPrint } from 'react-to-print';
import BreakEvenChart from '@/components/BreakEvenChart';
import useFinancialCalculations from '@/hooks/useFinancialCalculations';
import { useTirVanRoyPayback } from '@/hooks/useTirVanRoyPayback';
import { useCarbonCalculations } from '@/hooks/useCarbonCalculations';
import { formatNumber, formatCurrency } from '@/lib/utils';
import { useTranslation } from 'react-i18next';
import { SummarySection, GeneralData, CashFlowTable } from './executive-summary/SummarySection';
import KeyMetricsCards from './executive-summary/KeyMetricsCards';
import ProfitabilityCards from './executive-summary/ProfitabilityCards';
import AssetDescriptionCards from './executive-summary/AssetDescriptionCards';
import CarbonBalanceSection from './executive-summary/CarbonBalanceSection';
import { useAuth } from '@/contexts/SupabaseAuthContext';


const p = (value) => {
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const strValue = value.replace(/\./g, '').replace(/,/g, '.');
    return parseFloat(strValue) || 0;
  }
  return 0;
};

const ExecutiveSummary = ({ projectData, agricultureData, ganaderiaData }) => {
  const { t, i18n } = useTranslation(['viability', 'common']);
  const printableRef = useRef();
  const { user } = useAuth();
  
  const tirVanCalculations = useTirVanRoyPayback({ projectData, agricultureData, ganaderiaData });
  const financialCalculations = useFinancialCalculations(projectData, agricultureData, ganaderiaData, tirVanCalculations);
  const { calculations: carbonCalculations } = useCarbonCalculations(ganaderiaData, agricultureData, projectData);

  const handlePrint = useReactToPrint({
    content: () => printableRef.current,
    documentTitle: `${t('executiveSummary.pdfFilename')}_${projectData?.projectName?.replace(/\s+/g, '_') || 'proyecto'}`,
    pageStyle: `@page { size: A4 portrait; margin: 12mm; } @media print { body { -webkit-print-color-adjust: exact; } .no-print { display: none; } .page-break-after { page-break-after: always; } }`
  });

  const { conclusionText, isProjectViable } = useMemo(() => {
    if (!projectData || !financialCalculations || !tirVanCalculations.metrics || !carbonCalculations) return { conclusionText: '', isProjectViable: true };

    const { npv, irr, roi, paybackPeriod } = financialCalculations;
    const { discountRateUsed } = tirVanCalculations.metrics;
    const { modules, investments } = projectData;

    const isGanaderiaActive = modules.ganaderia && ganaderiaData?.isEnabled;
    const isAgriculturaActive = modules.agricultura && agricultureData?.isEnabled;

    let projectType;
    if (isGanaderiaActive && isAgriculturaActive) {
        projectType = t('executiveSummary.conclusion.projectTypeMixed');
    } else if (isGanaderiaActive) {
        projectType = t('executiveSummary.conclusion.projectTypeLivestock');
    } else if (isAgriculturaActive) {
        projectType = t('executiveSummary.conclusion.projectTypeAgriculture');
    } else {
        projectType = t('executiveSummary.conclusion.projectTypeGeneric');
    }

    const landInvestment = investments?.find(inv => inv.id === 'tierra');
    const hasLandInvestment = landInvestment && (p(landInvestment.cantidad) * p(landInvestment.valorUnitario) > 0);

    const photovoltaicInvestment = investments?.find(inv => inv.id === 'fotovoltaica');
    const hasPhotovoltaicInvestment = photovoltaicInvestment && (p(photovoltaicInvestment.cantidad) * p(photovoltaicInvestment.valorUnitario) > 0);

    const projectViability = (irr * 100) > discountRateUsed && npv > 0 && roi > 0;
    const isCarbonNegative = carbonCalculations.tech.netBalance < 0;

    let conclusionParts = [
        t('executiveSummary.conclusion.part1', {
            projectName: projectData.projectName || 'N/A',
            projectType,
            npv: `<strong>${formatCurrency(npv)}</strong>`,
            irr: `<strong>${(irr * 100).toFixed(2)}%</strong>`,
            roi: `<strong>${(roi * 100).toFixed(2)}%</strong>`,
            paybackPeriod: `<strong>${paybackPeriod}</strong>`
        }),
        t('executiveSummary.conclusion.part2')
    ];

    if (hasLandInvestment) {
        conclusionParts.push(t('executiveSummary.conclusion.part3_land'));
    }
    
    conclusionParts.push(t('executiveSummary.conclusion.part4_irrigation'));
    conclusionParts.push(t('executiveSummary.conclusion.part5_infra'));

    if (hasPhotovoltaicInvestment) {
        conclusionParts.push(t('executiveSummary.conclusion.part6_energy'));
    }
    
    if(isCarbonNegative) {
        conclusionParts.push(t('executiveSummary.conclusion.part7_carbon'));
    }

    if (projectViability) {
        conclusionParts.push(t('executiveSummary.conclusion.recommendation_positive'));
    } else {
        conclusionParts.push(t('executiveSummary.conclusion.recommendation_negative'));
    }

    return { conclusionText: conclusionParts.join('\n\n'), isProjectViable: projectViability };
  }, [projectData, financialCalculations, tirVanCalculations, ganaderiaData, agricultureData, carbonCalculations, t]);

  const dynamicAssetDescriptions = useMemo(() => {
    if (!projectData?.investments) return [];
    
    const assetsConfig = [
        { id: 'tierra', investmentKey: 'tierra' },
        { id: 'riego', investmentKey: 'riego' },
        { id: 'infraestructura', investmentKey: 'infraestructura' },
        { id: 'mecanizacion', investmentKey: 'mecanizacion' },
        { id: 'fotovoltaica', investmentKey: 'fotovoltaica' },
        { id: 'otros', investmentKey: 'otros' }
    ];

    return assetsConfig.map(asset => {
        const investment = projectData.investments.find(inv => inv.id === asset.investmentKey);
        const hasInvestment = investment && (p(investment.cantidad) * p(investment.valorUnitario) > 0);
        
        return {
            key: asset.id,
            id: asset.id,
            hasInvestment,
        };
    }).filter(asset => asset.hasInvestment);

  }, [projectData?.investments]);


  if (!projectData || !financialCalculations || !tirVanCalculations.metrics || !carbonCalculations) {
    return (
      <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
        <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800">{t('executiveSummary.loadingData')}</h2>
        <p className="text-gray-600 text-lg mt-2">{t('executiveSummary.loadingDataSubtitle')}</p>
      </div>
    );
  }
  
  const { totalInvestment, npv, irr, roi, paybackPeriod, totalFinancingCost, traditional, tech, profitDifference } = financialCalculations;
  const { discountRateUsed } = tirVanCalculations.metrics;

  const activeModules = projectData.modules || { ganaderia: false, agricultura: false };
  let activeModulesText = t('executiveSummary.modulesNotDefined');
  if (activeModules.ganaderia && activeModules.agricultura) {
    activeModulesText = t('executiveSummary.mixedModule');
  } else if (activeModules.ganaderia) {
    activeModulesText = t('executiveSummary.livestockModule');
  } else if (activeModules.agricultura) {
    activeModulesText = t('executiveSummary.agricultureModule');
  }

  const projectDuration = tirVanCalculations.tableData.length > 0 ? tirVanCalculations.tableData.length - 1 : 0;
  const projectedCashFlow = tirVanCalculations.tableData.map(row => ({ year: row.year, annualFlow: row.flujoCajaNeto, cumulativeFlow: row.flujoCajaAcumulado }));

  return (
    <div className="bg-gray-50 p-2 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4 no-print">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 text-center sm:text-left">{t('executiveSummary.title')}</h1>
            <div className="flex items-center bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                <CheckCircle className="w-4 h-4 mr-2" />
                <span>{t('validated', { ns: 'common'})}</span>
            </div>
          </div>
          <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700 w-full sm:w-auto">
            <Printer className="mr-2 h-4 w-4" />
            {t('exportPdf', { ns: 'common'})}
          </Button>
        </div>

        <motion.div ref={printableRef} className="p-4 sm:p-8 bg-white rounded-lg shadow-lg" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <header className="text-center border-b-2 border-gray-200 pb-4 mb-8">
            <h2 className="text-xl sm:text-3xl font-extrabold text-gray-900 tracking-tight">{projectData.projectName || t('executiveSummary.projectAnalysis')}</h2>
            <h3 className="text-lg sm:text-xl font-semibold text-gray-700 mt-2">{t('executiveSummary.headerSubtitle')}</h3>
            <p className="text-sm sm:text-md text-gray-500 mt-2">{new Date().toLocaleDateString(i18n.language)}</p>
          </header>

          <SummarySection number="" title={t('executiveSummary.generalData')}>
            <GeneralData projectData={projectData} />
          </SummarySection>
          
          <SummarySection number="" title={t('executiveSummary.introTitle')}>
            <p className="text-gray-700 leading-relaxed">{t('executiveSummary.introText', { projectName: projectData.projectName || 'N/A' })}</p>
          </SummarySection>

          <SummarySection number="" title={t('executiveSummary.projectDescTitle')}>
            <p className="text-gray-700 leading-relaxed mb-4">{t('executiveSummary.projectDescText', { years: projectDuration, modules: activeModulesText })}</p>
            <Card className="bg-gray-50 border-gray-200">
              <CardContent className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center"><DollarSign className="mx-auto h-8 w-8 text-green-600 mb-2" /><p className="text-sm font-semibold text-gray-600">{t('executiveSummary.totalInvestment')}</p><p className="text-xl sm:text-2xl font-bold text-gray-900">{formatCurrency(totalInvestment)}</p></div>
                <div className="text-center"><Landmark className="mx-auto h-8 w-8 text-indigo-600 mb-2" /><p className="text-sm font-semibold text-gray-600">{t('executiveSummary.totalFinancingCost')}</p><p className="text-xl sm:text-2xl font-bold text-gray-900">{formatCurrency(totalFinancingCost || 0)}</p></div>
                <div className="text-center"><TrendingUp className="mx-auto h-8 w-8 text-blue-600 mb-2" /><p className="text-sm font-semibold text-gray-600">{t('executiveSummary.annualDiscountRate')}</p><p className="text-xl sm:text-2xl font-bold text-gray-900">{typeof discountRateUsed === 'number' ? formatNumber(discountRateUsed, 2) : 'N/A'}%</p></div>
              </CardContent>
            </Card>
          </SummarySection>

          <SummarySection number="" title={t('executiveSummary.profitabilityTitle')}>
            <ProfitabilityCards traditional={traditional} tech={tech} profitDifference={profitDifference} formatCurrency={formatCurrency} />
          </SummarySection>

          <SummarySection number="" title={t('executiveSummary.keyMetricsTitle')}>
            <KeyMetricsCards metrics={{ irr, npv, roi, paybackPeriod }} formatCurrency={formatCurrency} />
          </SummarySection>
          
          <SummarySection number="" title={t('executiveSummary.assetDescriptionsTitle')}>
            <AssetDescriptionCards assets={dynamicAssetDescriptions} t={t} />
          </SummarySection>

          <SummarySection number="" title={t('executiveSummary.cashFlowTitle')}>
            <Card><CardContent className="pt-6"><div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6"><div className="text-center"><p className="text-sm font-semibold text-gray-600">{t('executiveSummary.riskLevel')}:</p><p className="text-xl sm:text-2xl font-bold text-green-600">{t('executiveSummary.low')}</p></div><div className="text-center"><p className="text-sm font-semibold text-gray-600">{t('executiveSummary.stability')}:</p><p className="text-xl sm:text-2xl font-bold text-green-600">{t('executiveSummary.high')}</p></div><div className="text-center"><p className="text-sm font-semibold text-gray-600">{t('executiveSummary.complexity')}:</p><p className="text-xl sm:text-2xl font-bold text-yellow-600">{t('executiveSummary.medium')}</p></div></div></CardContent><CardContent className="p-0"><CashFlowTable projectedCashFlow={projectedCashFlow} formatCurrency={formatCurrency} /></CardContent></Card>
          </SummarySection>

          <SummarySection number="" title={t('executiveSummary.breakEvenChartTitle')}>
            <Card><CardContent className="pt-6"><div className="h-80"><BreakEvenChart cashFlow={projectedCashFlow} paybackPeriod={paybackPeriod} /></div><p className="text-center mt-4 text-sm text-gray-600">{t('executiveSummary.breakEvenChartNote', { paybackPeriod: paybackPeriod })}</p></CardContent></Card>
          </SummarySection>
          
          <SummarySection number="" title={t('executiveSummary.carbonBalanceTitle')}>
             <CarbonBalanceSection carbonCalculations={carbonCalculations} projectData={projectData} />
          </SummarySection>

          <SummarySection number="" title={t('executiveSummary.conclusionTitle')} pageBreakAfter={false}>
            <p className={`leading-relaxed whitespace-pre-wrap ${!isProjectViable ? 'text-red-600 font-semibold' : 'text-gray-700'}`} dangerouslySetInnerHTML={{ __html: conclusionText }}></p>
          </SummarySection>
          
          <footer className="text-center mt-12 pt-4 border-t border-gray-200">
            <p className="text-sm text-gray-600 mb-1">{t('generatedBy', { ns: 'common' })}</p>
            {user && (
                <p className="text-xs text-gray-500">
                    {t('userInfo', { ns: 'common', name: user.full_name, email: user.email, phone: user.phone || 'N/A' })}
                </p>
            )}
          </footer>
        </motion.div>
      </div>
    </div>
  );
};

export default ExecutiveSummary;