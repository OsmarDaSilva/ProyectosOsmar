import React, { useState } from 'react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Mail, Phone, MapPin, Edit, Trash2, Plus, MoreVertical, FolderKanban, Upload, Download, ShieldCheck, User, Star, Globe, MessageSquare, Cake, AlertTriangle, FileArchive } from 'lucide-react';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuTrigger,
    } from "@/components/ui/dropdown-menu";
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
      AlertDialogTrigger,
    } from "@/components/ui/alert-dialog";
    import AddEditProjectDialog from './AddEditProjectDialog';
    import AddEditContactDialog from './AddEditContactDialog';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useQuery } from '@tanstack/react-query';
    import { Textarea } from '@/components/ui/textarea';
    import { Badge } from '@/components/ui/badge';
    import { formatDistanceToNow } from 'date-fns';
    import { es } from 'date-fns/locale';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useNavigate } from 'react-router-dom';
    import DocumentSummaryChips from './documents/DocumentSummaryChips';

    const fetchClientAlerts = async (clientId) => {
        if (!clientId) return [];
        const { data, error } = await supabase.from('alerts').select('*').eq('client_id', clientId).order('created_at', { ascending: false });
        if (error) throw new Error(error.message);
        return data;
    }
    
    const ClientAlerts = ({ clientId }) => {
        const { data: alerts, isLoading, isError } = useQuery({
            queryKey: ['clientAlerts', clientId],
            queryFn: () => fetchClientAlerts(clientId),
            enabled: !!clientId
        });

        if (isLoading) return <p>Cargando alertas...</p>;
        if (isError || !alerts) return <p>No se pudieron cargar las alertas.</p>;

        const getSeverityBadge = (severity) => {
            switch(severity) {
                case 'critical': return 'destructive';
                case 'warning': return 'secondary';
                default: return 'default';
            }
        }

        return (
            <div className="space-y-4">
                <h4 className="font-semibold">Notas y Alertas del Cliente</h4>
                <Textarea placeholder="Añadir una nueva nota sobre el cliente..." className="mb-2" />
                <Button size="sm">Guardar Nota</Button>
                <div className="max-h-60 overflow-y-auto space-y-3 pr-2">
                    {alerts.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-4">No hay alertas para este cliente.</p>
                    ) : (
                        alerts.map(alert => (
                             <div key={alert.id} className="text-sm p-3 rounded-lg border bg-gray-50">
                                <div className="flex justify-between items-start">
                                    <p className="font-medium text-gray-800">{alert.description}</p>
                                    <Badge variant={getSeverityBadge(alert.severity)}>{alert.severity}</Badge>
                                </div>
                                <p className="text-xs text-muted-foreground mt-1">
                                    {alert.module.toUpperCase()} - {formatDistanceToNow(new Date(alert.created_at), { addSuffix: true, locale: es })}
                                </p>
                            </div>
                        ))
                    )}
                </div>
            </div>
        );
    }


    const ClientDetail = ({ client, onEdit, onDelete, refreshClients, onLoadProject, onSaveProject }) => {
      const { toast } = useToast();
      const { user } = useAuth();
      const navigate = useNavigate();
      const [isProjectDialogOpen, setIsProjectDialogOpen] = useState(false);
      const [editingProject, setEditingProject] = useState(null);
      const [isContactDialogOpen, setIsContactDialogOpen] = useState(false);
      const [editingContact, setEditingContact] = useState(null);

      if (!client) {
        return (
          <Card className="flex items-center justify-center h-full min-h-[300px]">
            <CardContent className="text-center">
              <FolderKanban className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Seleccione un cliente</h3>
              <p className="mt-1 text-sm text-gray-500">Elija un cliente de la lista para ver sus detalles y proyectos.</p>
            </CardContent>
          </Card>
        );
      }

      const handleSaveProject = async (projectData) => {
        const isEditing = !!projectData.id;
        
        const dataToUpsert = { 
            ...projectData, 
            client_id: client.id, 
            updated_by: user.id,
        };

        if (!isEditing) {
            dataToUpsert.created_by = user.id;
        }

        const { error } = await supabase.from('client_projects').upsert(dataToUpsert);
        if (error) {
          toast({ variant: 'destructive', title: 'Error al guardar proyecto', description: error.message });
          return false;
        } else {
          toast({ title: 'Proyecto guardado' });
          setIsProjectDialogOpen(false); setEditingProject(null); refreshClients(); return true;
        }
      };

      const handleDeleteProject = async (projectId) => {
        const { error } = await supabase.from('client_projects').delete().eq('id', projectId);
        if (error) {
          toast({ variant: 'destructive', title: 'Error al eliminar proyecto', description: error.message });
        } else {
          toast({ title: 'Proyecto eliminado' }); refreshClients();
        }
      };

      const handleSaveContact = async (contactData) => {
        const dataToUpsert = { ...contactData, client_id: client.id, user_id: user.id };
        if (contactData.is_primary) {
          await supabase.from('contacts').update({ is_primary: false }).eq('client_id', client.id);
        }
        const { error } = await supabase.from('contacts').upsert(dataToUpsert);
        if (error) {
          toast({ variant: 'destructive', title: 'Error al guardar contacto', description: error.message });
          return false;
        } else {
          toast({ title: 'Contacto guardado' });
          setIsContactDialogOpen(false); setEditingContact(null); refreshClients(); return true;
        }
      };

      const handleDeleteContact = async (contactId) => {
        const { error } = await supabase.from('contacts').delete().eq('id', contactId);
        if (error) {
          toast({ variant: 'destructive', title: 'Error al eliminar contacto', description: error.message });
        } else {
          toast({ title: 'Contacto eliminado' }); refreshClients();
        }
      };

      const handleSetPrimaryContact = async (contactId) => {
        await supabase.from('contacts').update({ is_primary: false }).eq('client_id', client.id);
        const { error } = await supabase.from('contacts').update({ is_primary: true }).eq('id', contactId);
        if (error) {
          toast({ variant: 'destructive', title: 'Error al actualizar contacto', description: error.message });
        } else {
          toast({ title: 'Contacto principal actualizado' }); refreshClients();
        }
      };

      const getStatusBadge = (status) => {
        switch (status) {
          case 'Activo': return 'bg-green-100 text-green-800';
          case 'Finalizado': return 'bg-blue-100 text-blue-800';
          case 'Planificación': default: return 'bg-yellow-100 text-yellow-800';
        }
      };
      
      const formatWhatsAppLink = (phone) => {
        if (!phone) return '';
        const cleaned = phone.replace(/\D/g, '');
        return `https://wa.me/${cleaned}`;
      };

      const formatDate = (dateString) => {
        if (!dateString) return '';
        const date = new Date(dateString);
        // Adjust for timezone offset
        const userTimezoneOffset = date.getTimezoneOffset() * 60000;
        const adjustedDate = new Date(date.getTime() + userTimezoneOffset);
        return adjustedDate.toLocaleDateString('es-ES', { day: 'numeric', month: 'long' });
      };

      const getCreatorDisplayName = (project) => {
        return project.creator_profile?.full_name || 'Desconocido';
      }

      const getUpdaterDisplayName = (project) => {
        return project.updater_profile?.full_name || '-';
      }

      return (
        <div className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  {client.name}
                  {client.is_confidential && <ShieldCheck className="h-6 w-6 text-yellow-500" title="Cliente Confidencial"/>}
                </CardTitle>
                <CardDescription>RUC/CI: {client.ruc_ci || 'No especificado'}</CardDescription>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button></DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onSelect={() => onEdit(client)}><Edit className="mr-2 h-4 w-4" /> Editar Cliente</DropdownMenuItem>
                  <AlertDialog><AlertDialogTrigger asChild><DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600 focus:text-red-600"><Trash2 className="mr-2 h-4 w-4" /> Eliminar Cliente</DropdownMenuItem></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>¿Está seguro?</AlertDialogTitle><AlertDialogDescription>Esta acción eliminará al cliente y todos sus proyectos asociados. No se puede deshacer.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => onDelete(client.id)} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
                </DropdownMenuContent>
              </DropdownMenu>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                 <div className="flex items-center gap-2 col-span-full">
                    <MapPin className="h-4 w-4 text-gray-400" />
                    <span>{`${client.address || ''}, ${client.city_locality || ''}, ${client.department_province || ''}, ${client.country || ''}`.replace(/, $/,'').replace(/, ,/g,',')}</span>
                </div>
                {client.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-gray-400" />
                    <a href={`mailto:${client.email}`} className="text-blue-600 hover:underline">{client.email}</a>
                  </div>
                )}
                {client.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <a href={`tel:${client.phone}`} className="text-blue-600 hover:underline">{client.phone}</a>
                    <a href={formatWhatsAppLink(client.phone)} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline">
                      <MessageSquare className="h-4 w-4"/>
                    </a>
                  </div>
                )}
                {client.website && (
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 text-gray-400" />
                    <a href={client.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{client.website}</a>
                  </div>
                )}
                {client.birthday && (
                  <div className="flex items-center gap-2">
                    <Cake className="h-4 w-4 text-gray-400" />
                    <span>{formatDate(client.birthday)}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2"><User className="h-5 w-5"/> Contactos de la Empresa</CardTitle>
              <Button size="sm" onClick={() => { setEditingContact(null); setIsContactDialogOpen(true); }}><Plus className="mr-2 h-4 w-4" /> Añadir Contacto</Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow><TableHead>Nombre</TableHead><TableHead>Cargo</TableHead><TableHead>Email</TableHead><TableHead>Teléfono</TableHead><TableHead>Cumpleaños</TableHead><TableHead className="text-right">Acciones</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {client.contacts && client.contacts.length > 0 ? (
                      client.contacts.sort((a,b) => b.is_primary - a.is_primary).map(contact => (
                        <TableRow key={contact.id} className={contact.is_primary ? 'bg-yellow-50' : ''}>
                          <TableCell className="font-medium flex items-center gap-2">
                             {contact.is_primary && <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />}
                             {contact.name}
                          </TableCell>
                          <TableCell>{contact.role}</TableCell>
                          <TableCell>
                            {contact.email && (
                              <a href={`mailto:${contact.email}`} className="text-blue-600 hover:underline">{contact.email}</a>
                            )}
                          </TableCell>
                          <TableCell>
                            {contact.phone && (
                              <div className="flex items-center gap-2">
                                <a href={`tel:${contact.phone}`} className="text-blue-600 hover:underline">{contact.phone}</a>
                                <a href={formatWhatsAppLink(contact.phone)} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline">
                                  <MessageSquare className="h-4 w-4"/>
                                </a>
                              </div>
                            )}
                          </TableCell>
                          <TableCell>
                            {contact.birthday && (
                              <div className="flex items-center gap-2">
                                <Cake className="h-4 w-4 text-gray-400" />
                                <span>{formatDate(contact.birthday)}</span>
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="text-right space-x-1">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button></DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                {!contact.is_primary && <DropdownMenuItem onSelect={() => handleSetPrimaryContact(contact.id)}><Star className="mr-2 h-4 w-4" /> Marcar como Principal</DropdownMenuItem>}
                                <DropdownMenuItem onSelect={() => {setEditingContact(contact); setIsContactDialogOpen(true);}}><Edit className="mr-2 h-4 w-4" /> Editar</DropdownMenuItem>
                                <AlertDialog><AlertDialogTrigger asChild><DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600 focus:text-red-600"><Trash2 className="mr-2 h-4 w-4" /> Eliminar</DropdownMenuItem></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Eliminar Contacto</AlertDialogTitle><AlertDialogDescription>¿Seguro que quieres eliminar a {contact.name}?</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDeleteContact(contact.id)} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow><TableCell colSpan="6" className="text-center h-24">Este cliente no tiene contactos.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-orange-500" /> Alertas y Notas</CardTitle></CardHeader>
            <CardContent>
                <ClientAlerts clientId={client.id} />
            </CardContent>
          </Card>


          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Proyectos</CardTitle>
              <Button size="sm" onClick={() => { setEditingProject(null); setIsProjectDialogOpen(true); }}><Plus className="mr-2 h-4 w-4" /> Añadir Proyecto</Button>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader><TableRow><TableHead>Nombre del Proyecto</TableHead><TableHead>Ubicación</TableHead><TableHead>Estado</TableHead><TableHead>Creado por</TableHead><TableHead>Documentos</TableHead><TableHead className="text-right">Acciones</TableHead></TableRow></TableHeader>
                  <TableBody>
                    {client.client_projects && client.client_projects.length > 0 ? (
                      client.client_projects.map(project => (
                        <TableRow key={project.id}>
                          <TableCell className="font-medium flex items-center gap-2">
                            {project.is_confidential && <ShieldCheck className="h-4 w-4 text-yellow-500" title="Proyecto Confidencial"/>}
                            {project.project_name}
                          </TableCell>
                          <TableCell>{project.location}</TableCell>
                          <TableCell><span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(project.status)}`}>{project.status}</span></TableCell>
                          <TableCell>{getCreatorDisplayName(project)}</TableCell>
                          <TableCell>
                            <DocumentSummaryChips projectId={project.id} />
                          </TableCell>
                          <TableCell className="text-right space-x-1">
                            <Button variant="outline" size="sm" onClick={() => navigate(`/projects/${project.id}/documents`)} title="Ver Documentación"><FileArchive className="h-4 w-4" /></Button>
                            <Button variant="outline" size="sm" onClick={() => onSaveProject(project.id)} title="Guardar estado actual de la calculadora en este proyecto"><Upload className="h-4 w-4" /></Button>
                            <Button variant="outline" size="sm" onClick={() => onLoadProject(client, project)} title="Cargar datos de este proyecto en la calculadora"><Download className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="sm" onClick={() => {setEditingProject(project); setIsProjectDialogOpen(true);}}><Edit className="h-4 w-4" /></Button>
                            <AlertDialog><AlertDialogTrigger asChild><Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600"><Trash2 className="h-4 w-4" /></Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Eliminar Proyecto</AlertDialogTitle><AlertDialogDescription>¿Seguro que quieres eliminar el proyecto "{project.project_name}"?</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={() => handleDeleteProject(project.id)} className="bg-red-600 hover:bg-red-700">Eliminar</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow><TableCell colSpan="6" className="text-center h-24">Este cliente no tiene proyectos.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
          <AddEditProjectDialog isOpen={isProjectDialogOpen} setIsOpen={setIsProjectDialogOpen} project={editingProject} onSave={handleSaveProject} client={client} />
          <AddEditContactDialog isOpen={isContactDialogOpen} setIsOpen={setIsContactDialogOpen} contact={editingContact} onSave={handleSaveContact} />
        </div>
      );
    };

    export default ClientDetail;