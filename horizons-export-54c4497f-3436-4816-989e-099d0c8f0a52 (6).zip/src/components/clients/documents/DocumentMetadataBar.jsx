import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreVertical, Download, Edit, Trash2, ShieldCheck, ShieldAlert, BookOpen } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const statusConfig = {
    'Borrador': { variant: 'secondary', icon: <BookOpen className="mr-2 h-4 w-4" /> },
    'En revisión': { variant: 'default', icon: <ShieldAlert className="mr-2 h-4 w-4" /> },
    'Aprobado': { variant: 'success', icon: <ShieldCheck className="mr-2 h-4 w-4" /> },
    'Rechazado': { variant: 'destructive', icon: <ShieldAlert className="mr-2 h-4 w-4" /> },
};

const DocumentMetadataBar = ({ document, isInternalUser, onEdit, onDelete, onDownload, onChangeStatus }) => {
    if (!document) {
        return (
            <div className="sticky top-0 z-10 flex items-center justify-center p-4 h-[70px] bg-white dark:bg-slate-900 border-b">
                <p className="text-muted-foreground">Seleccione un documento para ver sus detalles</p>
            </div>
        );
    }
    
    const currentStatus = statusConfig[document.status] || { variant: 'outline', icon: <BookOpen className="mr-2 h-4 w-4" /> };

    return (
        <div className="sticky top-0 z-10 flex flex-wrap items-center justify-between gap-4 p-3 bg-white dark:bg-slate-900 border-b">
            <div className="flex-1 min-w-0">
                <h2 className="text-lg font-bold truncate" title={document.title}>{document.title}</h2>
                <div className="flex items-center gap-x-3 text-sm text-muted-foreground mt-1">
                    <span>v{document.version}</span>
                    <span className="text-gray-300 dark:text-gray-600">|</span>
                    <span>{format(new Date(document.created_at), "dd 'de' MMMM, yyyy", { locale: es })}</span>
                </div>
            </div>

            <div className="flex items-center gap-2">
                 <Badge variant={currentStatus.variant} className="text-sm px-3 py-1 capitalize hidden sm:inline-flex items-center">
                    {currentStatus.icon}
                    {document.status}
                </Badge>
                <Button variant="outline" size="sm" onClick={() => onDownload(document)}>
                    <Download className="mr-2 h-4 w-4" />
                    Descargar
                </Button>
                {isInternalUser && (
                     <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                                <MoreVertical className="h-5 w-5" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => onEdit(document)}>
                                <Edit className="mr-2 h-4 w-4" /> Editar Metadatos
                            </DropdownMenuItem>

                            <DropdownMenuSeparator />
                            
                            <DropdownMenuItem onClick={() => onChangeStatus(document, 'Aprobado')} disabled={document.status === 'Aprobado'}>
                                <ShieldCheck className="mr-2 h-4 w-4 text-green-500" /> Aprobar
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onChangeStatus(document, 'En revisión')} disabled={document.status === 'En revisión'}>
                                <ShieldAlert className="mr-2 h-4 w-4 text-blue-500" /> Poner en Revisión
                            </DropdownMenuItem>
                             <DropdownMenuItem onClick={() => onChangeStatus(document, 'Borrador')} disabled={document.status === 'Borrador'}>
                                <BookOpen className="mr-2 h-4 w-4 text-gray-500" /> Marcar como Borrador
                            </DropdownMenuItem>

                            <DropdownMenuSeparator />

                            <DropdownMenuItem className="text-red-600 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-900/50" onClick={() => onDelete(document)}>
                                <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                )}
            </div>
        </div>
    );
};

export default DocumentMetadataBar;