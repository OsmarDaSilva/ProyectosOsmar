import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle, FileCheck2 } from 'lucide-react';

const DocumentViewer = ({ document }) => {
    const [signedUrl, setSignedUrl] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchSignedUrl = async () => {
            if (!document || !document.file_path) {
                setSignedUrl(null);
                setError(null);
                return;
            }

            setIsLoading(true);
            setError(null);
            setSignedUrl(null);

            try {
                const { data, error: urlError } = await supabase.storage
                    .from('project-docs')
                    .createSignedUrl(document.file_path, 300); // 5 minutes validity

                if (urlError) throw urlError;
                
                setSignedUrl(data.signedUrl);
            } catch (err) {
                console.error("Error creating signed URL:", err);
                setError(err.message || 'No se pudo cargar el documento.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchSignedUrl();
    }, [document]);

    if (!document) {
        return (
            <div className="flex flex-col items-center justify-center w-full h-full bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="text-center text-gray-500">
                    <FileCheck2 className="mx-auto h-12 w-12" />
                    <p className="mt-2 font-medium">Seleccione un documento</p>
                    <p className="text-sm text-muted-foreground">El documento que elija de la lista de la izquierda se mostrará aquí.</p>
                </div>
            </div>
        );
    }
    
    return (
        <div className="flex-1 relative bg-gray-200 dark:bg-gray-900">
            {isLoading && <Skeleton className="absolute inset-0 w-full h-full" />}
            {error && (
                <div className="absolute inset-0 flex items-center justify-center p-4">
                    <Alert variant="destructive" className="max-w-md">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Error al Cargar Documento</AlertTitle>
                        <AlertDescription>{error}</AlertDescription>
                    </Alert>
                </div>
            )}
            {signedUrl && !error && (
                <iframe
                    src={signedUrl}
                    className="w-full h-full border-0"
                    title={document.title}
                />
            )}
            {!signedUrl && !isLoading && !error && (
                 <div className="absolute inset-0 flex items-center justify-center p-4">
                    <div className="text-center text-gray-500">
                         <FileCheck2 className="mx-auto h-12 w-12" />
                         <p className="mt-2 font-medium">Documento listo para visualizar</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DocumentViewer;