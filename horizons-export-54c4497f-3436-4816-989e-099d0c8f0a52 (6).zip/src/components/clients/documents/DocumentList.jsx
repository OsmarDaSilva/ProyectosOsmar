import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Eye, Download, Edit, Trash2, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const statusVariantMap = {
    'Borrador': 'secondary',
    'En revisión': 'default',
    'Aprobado': 'success',
    'Rechazado': 'destructive',
};

const DocumentList = ({ documents, onSelect, onEdit, onDelete, onDownload, selectedDocumentId }) => {
    const { user } = useAuth();
    const isInternalUser = user && ['admin', 'owner', 'technician'].includes(user.role);

    if (!documents || documents.length === 0) {
        return (
            <div className="text-center py-10 text-muted-foreground">
                <FileText className="mx-auto h-12 w-12" />
                <p className="mt-4">No hay documentos en esta categoría.</p>
            </div>
        );
    }

    return (
        <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Título</TableHead>
                        <TableHead>Versión</TableHead>
                        <TableHead>Estado</TableHead>
                        <TableHead>Fecha</TableHead>
                        <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {documents.map((doc) => (
                        <TableRow
                            key={doc.id}
                            className={`cursor-pointer ${selectedDocumentId === doc.id ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
                            onClick={() => onSelect(doc)}
                        >
                            <TableCell className="font-medium">{doc.title}</TableCell>
                            <TableCell>v{doc.version}</TableCell>
                            <TableCell>
                                <Badge variant={statusVariantMap[doc.status] || 'outline'}>{doc.status}</Badge>
                            </TableCell>
                            <TableCell>{format(new Date(doc.created_at), 'dd MMM yyyy', { locale: es })}</TableCell>
                            <TableCell className="text-right">
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" size="icon" onClick={(e) => e.stopPropagation()}>
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onSelect(doc); }}>
                                            <Eye className="mr-2 h-4 w-4" /> Ver
                                        </DropdownMenuItem>
                                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDownload(doc); }}>
                                            <Download className="mr-2 h-4 w-4" /> Descargar
                                        </DropdownMenuItem>
                                        {isInternalUser && (
                                            <>
                                                <DropdownMenuSeparator />
                                                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(doc); }}>
                                                    <Edit className="mr-2 h-4 w-4" /> Editar
                                                </DropdownMenuItem>
                                                <DropdownMenuItem className="text-red-600 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-900/50" onClick={(e) => { e.stopPropagation(); onDelete(doc); }}>
                                                    <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                                                </DropdownMenuItem>
                                            </>
                                        )}
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
};

export default DocumentList;