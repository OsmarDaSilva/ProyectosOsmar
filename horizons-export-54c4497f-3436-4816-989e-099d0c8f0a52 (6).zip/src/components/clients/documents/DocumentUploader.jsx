import React, { useState, useCallback } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useDropzone } from 'react-dropzone';
import { UploadCloud, File as FileIcon, Loader2 } from 'lucide-react';

const formSchema = z.object({
    title: z.string().min(3, { message: "El título debe tener al menos 3 caracteres." }),
    status: z.enum(['Borrador', 'En revisión', 'Aprobado']),
});

const DocumentUploader = ({ isOpen, onOpenChange, onUpload, project, documentToEdit, category }) => {
    const [file, setFile] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const { register, handleSubmit, control, formState: { errors }, reset } = useForm({
        resolver: zodResolver(formSchema),
        defaultValues: {
            title: documentToEdit?.title || '',
            status: documentToEdit?.status || 'Borrador',
        }
    });

    React.useEffect(() => {
        if (documentToEdit) {
            reset({
                title: documentToEdit.title,
                status: documentToEdit.status,
            });
        } else {
            reset({
                title: '',
                status: 'Borrador',
            });
        }
        setFile(null);
    }, [documentToEdit, isOpen, reset]);

    const onDrop = useCallback((acceptedFiles) => {
        if (acceptedFiles.length > 0) {
            setFile(acceptedFiles[0]);
        }
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: { 'application/pdf': ['.pdf'] },
        multiple: false,
    });

    const onSubmit = async (data) => {
        if (!file && !documentToEdit) {
            alert("Por favor, seleccione un archivo PDF.");
            return;
        }
        setIsSubmitting(true);
        await onUpload({ ...data, file });
        setIsSubmitting(false);
        onOpenChange(false);
    };

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{documentToEdit ? 'Editar Documento' : 'Subir Nuevo Documento'}</DialogTitle>
                    <DialogDescription>
                        {documentToEdit ? `Editando documento en la categoría "${category.label}".` : `Subiendo un nuevo documento a la categoría "${category.label}".`}
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div>
                        <Label htmlFor="title">Título del Documento</Label>
                        <Input id="title" {...register('title')} />
                        {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title.message}</p>}
                    </div>

                    <div>
                        <Label htmlFor="status">Estado</Label>
                        <Controller
                            name="status"
                            control={control}
                            render={({ field }) => (
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Seleccione un estado" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Borrador">Borrador</SelectItem>
                                        <SelectItem value="En revisión">En revisión</SelectItem>
                                        <SelectItem value="Aprobado">Aprobado</SelectItem>
                                    </SelectContent>
                                </Select>
                            )}
                        />
                    </div>

                    {!documentToEdit && (
                        <div>
                            <Label>Archivo PDF</Label>
                            <div {...getRootProps()} className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 ${isDragActive ? 'border-blue-500' : 'border-dashed'} rounded-md cursor-pointer`}>
                                <input {...getInputProps()} />
                                <div className="space-y-1 text-center">
                                    <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
                                    <p className="text-sm text-gray-600">
                                        {isDragActive ? 'Suelte el archivo aquí...' : 'Arrastre y suelte un archivo PDF, o haga clic para seleccionar'}
                                    </p>
                                </div>
                            </div>
                            {file && (
                                <div className="mt-2 flex items-center text-sm text-gray-600">
                                    <FileIcon className="h-5 w-5 mr-2" />
                                    <span>{file.name}</span>
                                </div>
                            )}
                        </div>
                    )}

                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
                            Cancelar
                        </Button>
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {documentToEdit ? 'Guardar Cambios' : 'Subir Documento'}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default DocumentUploader;