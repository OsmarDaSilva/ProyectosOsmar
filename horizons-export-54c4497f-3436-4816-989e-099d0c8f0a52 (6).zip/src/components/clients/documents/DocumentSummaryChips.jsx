import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/customSupabaseClient';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Skeleton } from '@/components/ui/skeleton';

const fetchSummary = async (projectId) => {
    const { data, error } = await supabase.rpc('get_project_document_summary', { p_project_id: projectId });
    if (error) throw new Error(error.message);
    return data;
};

const documentCategories = [
    { slug: 'disenos', label: 'Diseños' },
    { slug: 'ficha_tecnica', label: 'Ficha Téc.' },
    { slug: 'carta_aspersion', label: 'C. Aspersión' },
    { slug: 'cotizaciones', label: 'Cotizaciones' },
    { slug: 'entrega_tecnica', label: 'E. Técnica' },
    { slug: 'docs_adicionales', label: 'Adicionales' },
    { slug: 'ordenes_servicio', label: 'O.S.' },
    { slug: 'mantenimientos', label: 'Mantenim.' },
];

const DocumentSummaryChips = ({ projectId }) => {
    const { data: summary, isLoading } = useQuery({
        queryKey: ['projectDocSummary', projectId],
        queryFn: () => fetchSummary(projectId),
        staleTime: 1000 * 60, // 1 minute
    });

    if (isLoading) {
        return <Skeleton className="h-5 w-24" />;
    }

    return (
        <TooltipProvider>
            <div className="flex flex-wrap gap-1">
                {documentCategories.map(category => {
                    const categoryData = summary?.[category.slug];
                    const approved = categoryData?.approved || 0;
                    const total = categoryData?.total || 0;
                    const variant = approved > 0 && approved === total ? 'success' : approved > 0 ? 'secondary' : 'default';

                    if (total === 0) return null;

                    return (
                        <Tooltip key={category.slug}>
                            <TooltipTrigger>
                                <Badge variant={variant} className="cursor-default">
                                    {`${category.label}: ${approved}/${total}`}
                                </Badge>
                            </TooltipTrigger>
                            <TooltipContent>
                                <p>{`${category.label}: ${approved} Aprobado(s) de ${total} total(es)`}</p>
                            </TooltipContent>
                        </Tooltip>
                    );
                })}
            </div>
        </TooltipProvider>
    );
};

export default DocumentSummaryChips;