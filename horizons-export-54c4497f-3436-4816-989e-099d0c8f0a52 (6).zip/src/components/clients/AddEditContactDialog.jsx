import React, { useState, useEffect } from 'react';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogDescription,
      DialogFooter,
    } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Switch } from '@/components/ui/switch';
    import { Star, Cake } from 'lucide-react';
    
    const AddEditContactDialog = ({ isOpen, setIsOpen, contact, onSave }) => {
      const [formData, setFormData] = useState({
        name: '',
        role: '',
        email: '',
        phone: '',
        birthday: '',
        is_primary: false,
      });
      const [isSaving, setIsSaving] = useState(false);
    
      useEffect(() => {
        if (contact) {
          setFormData({
            ...contact,
            name: contact.name || '',
            role: contact.role || '',
            email: contact.email || '',
            phone: contact.phone || '',
            birthday: contact.birthday || '',
            is_primary: contact.is_primary || false,
          });
        } else {
          setFormData({ name: '', role: '', email: '', phone: '', birthday: '', is_primary: false });
        }
      }, [contact, isOpen]);
    
      const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
      };
    
      const handleSwitchChange = (checked) => {
        setFormData(prev => ({ ...prev, is_primary: checked }));
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        const dataToSave = { ...formData };
        if (!dataToSave.birthday) {
            dataToSave.birthday = null;
        }
        const success = await onSave(dataToSave);
        setIsSaving(false);
        if (success) {
          setIsOpen(false);
        }
      };
    
      return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>{contact ? 'Editar Contacto' : 'Nuevo Contacto'}</DialogTitle>
                <DialogDescription>
                  {contact ? 'Actualice los detalles del contacto.' : 'Añada un nuevo contacto a este cliente.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">Nombre</Label>
                  <Input id="name" value={formData.name} onChange={handleChange} className="col-span-3" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="role" className="text-right">Cargo</Label>
                  <Input id="role" value={formData.role} onChange={handleChange} className="col-span-3" placeholder="Ej: Gerente, Comprador" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">Email</Label>
                  <Input id="email" type="email" value={formData.email} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="phone" className="text-right">Teléfono</Label>
                  <Input id="phone" value={formData.phone} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="birthday" className="text-right flex items-center gap-2">
                    <Cake className="h-4 w-4 text-gray-500" />
                    Cumpleaños
                  </Label>
                  <Input id="birthday" type="date" value={formData.birthday} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="is_primary" className="text-right flex items-center gap-2">
                    <Star className="h-4 w-4 text-gray-500" />
                    Principal
                  </Label>
                   <div className="col-span-3 flex items-center">
                    <Switch
                        id="is_primary"
                        checked={formData.is_primary}
                        onCheckedChange={handleSwitchChange}
                    />
                    <span className="ml-3 text-sm text-gray-600">Marcar como contacto principal.</span>
                   </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
                <Button type="submit" disabled={isSaving}>{isSaving ? 'Guardando...' : 'Guardar'}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    };
    
    export default AddEditContactDialog;