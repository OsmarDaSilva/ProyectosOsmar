import React, { useState, useEffect, useCallback } from 'react';
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogDescription,
      DialogFooter,
    } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Switch } from '@/components/ui/switch';
    import { ShieldCheck, Cake, Globe, Users, X } from 'lucide-react';
    import { useQuery } from '@tanstack/react-query';
    import { supabase } from '@/lib/customSupabaseClient';
    import { Command, CommandInput, CommandList, CommandItem, CommandEmpty } from '@/components/ui/command';
    import { Badge } from '@/components/ui/badge';
    import { useAuth } from '@/contexts/SupabaseAuthContext';

    const fetchUsers = async () => {
        const { data, error } = await supabase.rpc('get_all_users');
        if (error) throw new Error(error.message);
        return data;
    };

    const fetchAccessList = async (clientId) => {
        if (!clientId) return [];
        const { data, error } = await supabase
            .from('confidential_access')
            .select('user_id')
            .eq('client_id', clientId);
        if (error) throw new Error(error.message);
        return data.map(item => item.user_id);
    };

    const AddEditClientDialog = ({ isOpen, setIsOpen, client, onSave }) => {
      const { user } = useAuth();
      const [formData, setFormData] = useState({ 
          name: '', ruc_ci: '', email: '', phone: '', address: '',
          website: '', birthday: '', country: '', department_province: '', city_locality: '',
          is_confidential: false,
      });
      const [isSaving, setIsSaving] = useState(false);
      const [searchQuery, setSearchQuery] = useState('');
      const [assignedUsers, setAssignedUsers] = useState([]);

      const { data: allUsers = [] } = useQuery({
        queryKey: ['allUsers'],
        queryFn: fetchUsers,
        enabled: isOpen,
      });

      const resetAndSetFormData = useCallback(() => {
        if (client) {
          setFormData({
            id: client.id, created_by: client.created_by, name: client.name || '',
            ruc_ci: client.ruc_ci || '', email: client.email || '', phone: client.phone || '',
            address: client.address || '', website: client.website || '', birthday: client.birthday || '',
            country: client.country || '', department_province: client.department_province || '',
            city_locality: client.city_locality || '', is_confidential: client.is_confidential || false,
            user_id: client.user_id
          });
          if (client.is_confidential && allUsers.length > 0) {
            fetchAccessList(client.id).then(userIds => {
                const users = allUsers.filter(u => userIds.includes(u.id));
                setAssignedUsers(users);
            });
          } else {
            setAssignedUsers([]);
          }
        } else {
          setFormData({ name: '', ruc_ci: '', email: '', phone: '', address: '', website: '', birthday: '', country: '', department_province: '', city_locality: '', is_confidential: false, user_id: user?.id });
          setAssignedUsers([]);
        }
      }, [client, user, allUsers]);

      useEffect(() => {
        if (isOpen) {
          resetAndSetFormData();
        }
      }, [isOpen, resetAndSetFormData]);

      const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
      };
    
      const handleSwitchChange = (checked) => {
        setFormData(prev => ({ ...prev, is_confidential: checked }));
        if (!checked) {
            setAssignedUsers([]);
        }
      };

      const handleAssignUser = (user) => {
        if (!assignedUsers.some(u => u.id === user.id)) {
            setAssignedUsers([...assignedUsers, user]);
        }
        setSearchQuery('');
      };

      const handleUnassignUser = (userId) => {
        setAssignedUsers(assignedUsers.filter(u => u.id !== userId));
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        const dataToSave = { ...formData };
        if (!dataToSave.birthday) dataToSave.birthday = null;
        
        const assignedUserIds = assignedUsers.map(u => u.id);
        // Always include the creator and current user if they are not already there
        if (client?.created_by && !assignedUserIds.includes(client.created_by)) {
            assignedUserIds.push(client.created_by);
        }
        if (user?.id && !assignedUserIds.includes(user.id)) {
            assignedUserIds.push(user.id);
        }

        const success = await onSave(dataToSave, assignedUserIds);
        setIsSaving(false);
        if (success) {
          setIsOpen(false);
        }
      };

      const filteredUsers = allUsers.filter(u => 
        (u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) || u.email?.toLowerCase().includes(searchQuery.toLowerCase()))
        && !assignedUsers.some(au => au.id === u.id)
      );
    
      return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent className="sm:max-w-lg">
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>{client ? 'Editar Cliente' : 'Nuevo Cliente'}</DialogTitle>
                <DialogDescription>
                  {client ? 'Actualice los detalles del cliente.' : 'Añada un nuevo cliente a su lista.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4 max-h-[70vh] overflow-y-auto pr-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">Nombre</Label>
                  <Input id="name" value={formData.name} onChange={handleChange} className="col-span-3" required />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="ruc_ci" className="text-right">RUC/CI</Label>
                  <Input id="ruc_ci" value={formData.ruc_ci} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">Email</Label>
                  <Input id="email" type="email" value={formData.email} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="phone" className="text-right">Teléfono</Label>
                  <Input id="phone" value={formData.phone} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="address" className="text-right">Dirección</Label>
                  <Input id="address" value={formData.address} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="country" className="text-right">País</Label>
                  <Input id="country" value={formData.country} onChange={handleChange} className="col-span-3" />
                </div>
                 <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="department_province" className="text-right">Dpto/Prov</Label>
                  <Input id="department_province" value={formData.department_province} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="city_locality" className="text-right">Ciudad</Label>
                  <Input id="city_locality" value={formData.city_locality} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="website" className="text-right">Página Web</Label>
                  <Input id="website" type="url" value={formData.website} onChange={handleChange} className="col-span-3" placeholder="https://ejemplo.com" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="birthday" className="text-right flex items-center gap-2">
                    <Cake className="h-4 w-4 text-gray-500" />
                    Cumpleaños
                  </Label>
                  <Input id="birthday" type="date" value={formData.birthday} onChange={handleChange} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="is_confidential" className="text-right flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-gray-500" />
                    Confidencial
                  </Label>
                   <div className="col-span-3 flex items-center">
                    <Switch
                        id="is_confidential"
                        checked={formData.is_confidential}
                        onCheckedChange={handleSwitchChange}
                    />
                   </div>
                </div>
                {formData.is_confidential && (
                    <div className="col-span-full space-y-2">
                        <Label htmlFor="assign-users">Asignar Acceso</Label>
                        <Command className="rounded-lg border shadow-md">
                            <CommandInput 
                                id="assign-users"
                                placeholder="Buscar usuario por nombre o email..."
                                value={searchQuery}
                                onValueChange={setSearchQuery}
                            />
                            <CommandList>
                                <CommandEmpty>No se encontraron usuarios.</CommandEmpty>
                                {filteredUsers.map(user => (
                                    <CommandItem key={user.id} onSelect={() => handleAssignUser(user)}>
                                        {user.full_name || user.email}
                                    </CommandItem>
                                ))}
                            </CommandList>
                        </Command>
                        <div className="flex flex-wrap gap-2 mt-2">
                            {assignedUsers.map(user => (
                                <Badge key={user.id} variant="secondary">
                                    {user.full_name || user.email}
                                    <button type="button" onClick={() => handleUnassignUser(user.id)} className="ml-2 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2">
                                        <X className="h-3 w-3" />
                                    </button>
                                </Badge>
                            ))}
                        </div>
                    </div>
                )}
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
                <Button type="submit" disabled={isSaving}>{isSaving ? 'Guardando...' : 'Guardar'}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    };
    
    export default AddEditClientDialog;