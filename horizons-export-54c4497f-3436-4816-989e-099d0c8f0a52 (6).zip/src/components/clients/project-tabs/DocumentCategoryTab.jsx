import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { useProjectDocuments, useDocumentMutations } from '@/hooks/useProjectDocuments';
import { useAuth } from '@/contexts/SupabaseAuthContext';

import DocumentList from '@/components/clients/documents/DocumentList';
import DocumentViewer from '@/components/clients/documents/DocumentViewer';
import DocumentMetadataBar from '@/components/clients/documents/DocumentMetadataBar';
import DocumentUploader from '@/components/clients/documents/DocumentUploader';
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Upload, FileText } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';

const DocumentCategoryTab = ({ category }) => {
    const { projectId } = useParams();
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const isInternalUser = user && ['admin', 'owner', 'technician'].includes(user.role);

    const { data: documents, isLoading, error } = useProjectDocuments(projectId, category.slug);
    const { uploadDocument, updateDocument, deleteDocument, isUploading, isUpdating, isDeleting } = useDocumentMutations(projectId, category.slug);

    const [selectedDocument, setSelectedDocument] = useState(null);
    const [documentToEdit, setDocumentToEdit] = useState(null);
    const [documentToDelete, setDocumentToDelete] = useState(null);
    const [documentToChangeStatus, setDocumentToChangeStatus] = useState(null);
    const [isUploaderOpen, setIsUploaderOpen] = useState(false);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [isChangeStatusDialogOpen, setIsChangeStatusDialogOpen] = useState(false);


    useEffect(() => {
        if (documents && documents.length > 0 && (!selectedDocument || !documents.find(d => d.id === selectedDocument.id))) {
            setSelectedDocument(documents[0]);
        } else if (documents && documents.length === 0) {
            setSelectedDocument(null);
        }
    }, [documents, selectedDocument]);

    const handleUpload = async (formData) => {
        try {
            const mutation = documentToEdit ? updateDocument : uploadDocument;
            const dataToSubmit = documentToEdit ? { id: documentToEdit.id, ...formData } : formData;

            const newOrUpdatedDoc = await mutation(dataToSubmit);
            toast({
                title: `Documento ${documentToEdit ? 'actualizado' : 'subido'}`,
                description: `El documento "${formData.title}" se ha ${documentToEdit ? 'actualizado' : 'subido'} correctamente.`,
            });
            setIsUploaderOpen(false);
            setDocumentToEdit(null);
            
            await queryClient.invalidateQueries({ queryKey: ['project_documents', projectId, category.slug] });
            await queryClient.invalidateQueries({ queryKey: ['projectDocSummary', projectId] });

            if (newOrUpdatedDoc) {
                 const refreshedData = await queryClient.fetchQuery({ queryKey: ['project_documents', projectId, category.slug] });
                 const docToSelect = refreshedData?.find(d => d.id === newOrUpdatedDoc.id) || refreshedData?.[0];
                 if(docToSelect){
                    setSelectedDocument(docToSelect);
                 }
            }
        } catch (e) {
            toast({
                variant: 'destructive',
                title: 'Error al subir',
                description: e.message,
            });
        }
    };

    const handleDelete = async () => {
        if (!documentToDelete) return;
        try {
            await deleteDocument(documentToDelete);
            
            toast({
                title: 'Documento eliminado',
                description: `El documento "${documentToDelete.title}" ha sido eliminado.`,
            });
            
            const remainingDocs = documents?.filter(d => d.id !== documentToDelete.id) || [];
            if (selectedDocument?.id === documentToDelete.id) {
                setSelectedDocument(remainingDocs.length > 0 ? remainingDocs[0] : null);
            }
        } catch (e) {
            toast({
                variant: 'destructive',
                title: 'Error al eliminar',
                description: e.message,
            });
        } finally {
            setDocumentToDelete(null);
            setIsDeleteDialogOpen(false);
        }
    };
    
    const handleChangeStatus = async () => {
        if (!documentToChangeStatus) return;
        const { doc, newStatus } = documentToChangeStatus;
        try {
            const updatedDoc = await updateDocument({ id: doc.id, status: newStatus });
            toast({
                title: 'Estado actualizado',
                description: `El estado de "${doc.title}" es ahora "${newStatus}".`,
            });
            if (selectedDocument?.id === doc.id) {
                setSelectedDocument(updatedDoc);
            }
        } catch (e) {
            toast({ variant: 'destructive', title: 'Error al cambiar estado', description: e.message });
        } finally {
            setIsChangeStatusDialogOpen(false);
            setDocumentToChangeStatus(null);
        }
    };


    const handleDownload = async (doc) => {
        if (!doc.file_path) {
            toast({ variant: 'destructive', title: 'Error', description: 'El documento no tiene un archivo asociado.' });
            return;
        }
        try {
             const { data, error } = await supabase.storage.from('project-docs').createSignedUrl(doc.file_path, 300);
            if (error) throw error;
            window.open(data.signedUrl, '_blank');
        } catch(error) {
             toast({ variant: 'destructive', title: 'Error de descarga', description: error.message });
        }
    };

    const openUploaderForNew = () => {
        setDocumentToEdit(null);
        setIsUploaderOpen(true);
    };

    const openUploaderForEdit = (doc) => {
        setDocumentToEdit(doc);
        setIsUploaderOpen(true);
    };

    const openDeleteDialog = (doc) => {
        setDocumentToDelete(doc);
        setIsDeleteDialogOpen(true);
    };
    
    const openChangeStatusDialog = (doc, newStatus) => {
        setDocumentToChangeStatus({ doc, newStatus });
        setIsChangeStatusDialogOpen(true);
    };

    if (isLoading) {
        return (
            <div className="grid grid-cols-1 md:grid-cols-[400px_1fr] h-full">
                <div className="p-4 border-r"><Skeleton className="h-full w-full" /></div>
                <div className="p-4"><Skeleton className="h-full w-full" /></div>
            </div>
        );
    }
    
    if (error) {
        return <div className="text-red-500 p-4">Error cargando documentos: {error.message}</div>;
    }

    return (
        <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b">
                <h3 className="text-xl font-bold tracking-tight">{category.label}</h3>
                {isInternalUser && (
                    <Button onClick={openUploaderForNew} size="sm">
                        <Upload className="mr-2 h-4 w-4" />
                        Subir PDF
                    </Button>
                )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-[400px_1fr] gap-4 p-4 flex-1 overflow-hidden">
                <div className="bg-white dark:bg-slate-900 border rounded-lg overflow-y-auto max-h-[calc(100vh-220px)]">
                    {documents && documents.length > 0 ? (
                        <DocumentList
                            documents={documents}
                            selectedDocumentId={selectedDocument?.id}
                            onSelect={setSelectedDocument}
                            onEdit={openUploaderForEdit}
                            onDelete={openDeleteDialog}
                            onDownload={handleDownload}
                        />
                    ) : (
                        <div className="text-center py-16 px-4 text-muted-foreground flex flex-col items-center justify-center h-full">
                            <FileText className="mx-auto h-16 w-16" />
                            <p className="mt-4 text-lg font-medium">No hay documentos</p>
                            <p className="text-sm text-muted-foreground">Empieza subiendo el primer archivo.</p>
                        </div>
                    )}
                </div>
                <div className="flex flex-col bg-white dark:bg-slate-900 border rounded-lg overflow-hidden min-h-[calc(100vh-220px)]">
                    <DocumentMetadataBar
                        document={selectedDocument}
                        isInternalUser={isInternalUser}
                        onEdit={openUploaderForEdit}
                        onDelete={openDeleteDialog}
                        onDownload={handleDownload}
                        onChangeStatus={openChangeStatusDialog}
                    />
                    <DocumentViewer document={selectedDocument} />
                </div>
            </div>

            {isInternalUser && (
                <DocumentUploader
                    isOpen={isUploaderOpen}
                    onOpenChange={setIsUploaderOpen}
                    onUpload={handleUpload}
                    documentToEdit={documentToEdit}
                    project={{ id: projectId }}
                    category={category}
                    isSubmitting={isUploading || isUpdating}
                />
            )}
            
            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>¿Eliminar documento?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Esta acción eliminará "{documentToDelete?.title}" de forma permanente. No se puede deshacer.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel disabled={isDeleting}>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-destructive hover:bg-destructive/90">
                            {isDeleting ? "Eliminando..." : "Eliminar"}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
            
            <AlertDialog open={isChangeStatusDialogOpen} onOpenChange={setIsChangeStatusDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Cambiar estado del documento</AlertDialogTitle>
                        <AlertDialogDescription>
                           ¿Confirma que desea cambiar el estado de "{documentToChangeStatus?.doc.title}" a "{documentToChangeStatus?.newStatus}"?
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                         <AlertDialogCancel disabled={isUpdating}>Cancelar</AlertDialogCancel>
                         <AlertDialogAction onClick={handleChangeStatus} disabled={isUpdating}>
                            {isUpdating ? "Actualizando..." : "Confirmar"}
                         </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
};

export default DocumentCategoryTab;