import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ShieldCheck } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const AddEditProjectDialog = ({ isOpen, setIsOpen, project, onSave, client }) => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({ project_name: '', location: '', status: 'Planificación', is_confidential: false });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (project) {
      setFormData({
        ...project,
        project_name: project.project_name || '',
        location: project.location || '',
        status: project.status || 'Planificación',
        is_confidential: project.is_confidential || client.is_confidential || false,
      });
    } else {
      setFormData({ project_name: '', location: '', status: 'Planificación', is_confidential: client.is_confidential || false });
    }
  }, [project, client, isOpen]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleStatusChange = (value) => {
    setFormData(prev => ({ ...prev, status: value }));
  };

  const handleConfidentialChange = (checked) => {
    setFormData(prev => ({ ...prev, is_confidential: checked }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    
    const dataToSave = { ...formData };
    if (!project) { // Is a new project
        dataToSave.created_by = user.id;
        dataToSave.client_id = client.id;
    }
    dataToSave.updated_by = user.id;

    const success = await onSave(dataToSave);
    setIsSaving(false);
    if (success) {
      setIsOpen(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>{project ? 'Editar Proyecto' : 'Nuevo Proyecto'}</DialogTitle>
            <DialogDescription>
              {project ? 'Actualice los detalles del proyecto.' : 'Añada un nuevo proyecto para este cliente.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="project_name" className="text-right">Nombre</Label>
              <Input id="project_name" value={formData.project_name} onChange={handleChange} className="col-span-3" required />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="location" className="text-right">Ubicación</Label>
              <Input id="location" value={formData.location} onChange={handleChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="status" className="text-right">Estado</Label>
              <Select value={formData.status} onValueChange={handleStatusChange}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Seleccione un estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Planificación">Planificación</SelectItem>
                  <SelectItem value="Activo">Activo</SelectItem>
                  <SelectItem value="Finalizado">Finalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="is_confidential" className="text-right flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-gray-500" />
                Confidencial
              </Label>
              <div className="col-span-3 flex items-center">
                <Switch
                    id="is_confidential"
                    checked={formData.is_confidential}
                    onCheckedChange={handleConfidentialChange}
                    disabled={client.is_confidential}
                />
                {client.is_confidential && <span className="ml-3 text-xs text-gray-500">Heredado del cliente</span>}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSaving}>{isSaving ? 'Guardando...' : 'Guardar'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddEditProjectDialog;