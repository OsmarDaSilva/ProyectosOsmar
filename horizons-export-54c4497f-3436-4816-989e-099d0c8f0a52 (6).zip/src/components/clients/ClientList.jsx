import React from 'react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { User, ShieldCheck } from 'lucide-react';

    const ClientList = ({ clients, selectedClient, onSelectClient }) => {
      return (
        <Card>
          <CardHeader>
            <CardTitle>Lista de Clientes ({clients.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[70vh] overflow-y-auto">
              {clients.length > 0 ? (
                clients.map(client => (
                  <div
                    key={client.id}
                    onClick={() => onSelectClient(client)}
                    className={`p-4 border-b cursor-pointer transition-colors ${selectedClient?.id === client.id ? 'bg-green-50 border-l-4 border-green-500' : 'hover:bg-gray-50'}`}
                  >
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-gray-100 rounded-full">
                                <User className="h-5 w-5 text-gray-600" />
                            </div>
                            <div>
                                <p className="font-semibold text-gray-800">{client.name}</p>
                                <p className="text-sm text-gray-500">{client.ruc_ci || 'Sin RUC/CI'}</p>
                                <p className="text-xs text-gray-400 mt-1">Creado por: {client.creator_profile?.full_name || 'Desconocido'}</p>
                            </div>
                        </div>
                        {client.is_confidential && (
                            <ShieldCheck className="h-5 w-5 text-yellow-500" title="Cliente Confidencial" />
                        )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-6 text-center text-gray-500">
                  <p>No hay clientes registrados.</p>
                  <p className="text-sm">Haga clic en "Nuevo Cliente" para empezar.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      );
    };

    export default ClientList;