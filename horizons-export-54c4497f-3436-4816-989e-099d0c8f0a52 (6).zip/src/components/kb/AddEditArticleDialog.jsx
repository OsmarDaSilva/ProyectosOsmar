import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { useDropzone } from 'react-dropzone';
import { UploadCloud, FileText, Loader2, Trash2, Image as ImageIcon, Video } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { v4 as uuidv4 } from 'uuid';

const getFileIcon = (fileType, filePreview) => {
  if (!fileType) return <FileText className="h-10 w-10 text-gray-500" />;
  if (fileType.startsWith('image/')) return <img src={filePreview} alt="Preview" className="h-16 w-16 object-cover rounded" />;
  if (fileType.startsWith('video/')) return <Video className="h-10 w-10 text-blue-500" />;
  if (fileType.includes('pdf')) return <FileText className="h-10 w-10 text-red-500" />;
  return <FileText className="h-10 w-10 text-gray-500" />;
};

const AddEditArticleDialog = ({ isOpen, setIsOpen, onSave, article }) => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({ title: '', content: '', tags: '', plain_text: '' });
  const [files, setFiles] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const [abortController, setAbortController] = useState(null);


  useEffect(() => {
    if (article) {
      setFormData({
        id: article.id || null,
        title: article.title || '',
        content: article.content || '',
        tags: article.tags ? (Array.isArray(article.tags) ? article.tags.join(', ') : article.tags) : '',
        plain_text: article.plain_text || ''
      });
      if (article.file_url) {
        setFiles([{
          name: article.file_name,
          type: article.file_type,
          size: article.file_size,
          preview: article.file_url,
          isUploaded: true,
        }]);
      } else {
        setFiles([]);
      }
    } else {
      setFormData({ title: '', content: '', tags: '', plain_text: '' });
      setFiles([]);
    }
  }, [article, isOpen]);

  const onDrop = useCallback((acceptedFiles) => {
    const newFiles = acceptedFiles.map(file => Object.assign(file, {
      preview: URL.createObjectURL(file),
      isUploaded: false,
    }));
    setFiles(prev => [...prev, ...newFiles].slice(0, 1));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    accept: {
      'image/*': ['.jpeg', '.png', '.gif', '.webp'],
      'application/pdf': ['.pdf'],
      'video/*': ['.mp4', '.mov', '.avi'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
    }
  });

  const removeFile = (fileToRemove) => {
    setFiles(files.filter(file => file !== fileToRemove));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCancelUpload = () => {
    if (abortController) {
      abortController.abort();
      setAbortController(null);
    }
    setIsSubmitting(false);
    setIsOpen(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    let uploadedFileUrl = article?.file_url || null;
    let uploadedFileName = article?.file_name || null;
    let uploadedFileType = article?.file_type || null;
    let uploadedFileSize = article?.file_size || null;

    if (files.length > 0 && !files[0].isUploaded) {
      const file = files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${uuidv4()}.${fileExt}`;
      const controller = new AbortController();
      setAbortController(controller);
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('knowledge_base_files')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
          contentType: file.type,
          signal: controller.signal
        });

      setAbortController(null);

      if (uploadError) {
        if(uploadError.name !== 'AbortError') {
          toast({ variant: 'destructive', title: 'Error al subir archivo', description: uploadError.message });
        }
        setIsSubmitting(false);
        return;
      }
      
      const { data: urlData } = supabase.storage.from('knowledge_base_files').getPublicUrl(uploadData.path);
      uploadedFileUrl = urlData.publicUrl;
      uploadedFileName = file.name;
      uploadedFileType = file.type;
      uploadedFileSize = file.size;

    } else if (files.length === 0 && article?.file_url) {
      uploadedFileUrl = null;
      uploadedFileName = null;
      uploadedFileType = null;
      uploadedFileSize = null;
      const filePath = new URL(article.file_url).pathname.split('/knowledge_base_files/')[1];
      await supabase.storage.from('knowledge_base_files').remove([filePath]);
    }

    const dataToSave = {
      ...formData,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean),
      file_name: uploadedFileName,
      file_url: uploadedFileUrl,
      file_type: uploadedFileType,
      file_size: uploadedFileSize,
    };

    const record = await onSave(dataToSave);
    if (record) {
      const { error: invokeError } = await supabase.functions.invoke('process-pdf-and-embed', {
          body: { record },
      });

      if (invokeError) {
          toast({
              variant: "destructive",
              title: "Error de Procesamiento",
              description: `El artículo se guardó, pero no se pudo procesar para la IA: ${invokeError.message}`
          });
      } else {
          toast({ title: 'Artículo guardado y procesando', description: 'El contenido se está procesando para la IA en segundo plano.' });
      }
      setIsOpen(false);
    }
    setIsSubmitting(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!isSubmitting) setIsOpen(open); }}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{article ? 'Editar' : 'Añadir Nuevo'} Artículo o Archivo</DialogTitle>
          <DialogDescription>
            Rellena los detalles y/o sube un archivo. Esto alimentará la Base de Conocimiento de la IA.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
          <div
            {...getRootProps()}
            className={`p-6 border-2 border-dashed rounded-lg text-center cursor-pointer ${isDragActive ? 'border-primary bg-primary/10' : 'border-input'}`}
          >
            <input {...getInputProps()} />
            <UploadCloud className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-2 text-sm text-muted-foreground">
              {isDragActive ? 'Suelta un archivo aquí...' : 'Arrastra y suelta un archivo aquí, o haz clic para seleccionar'}
            </p>
            <p className="text-xs text-muted-foreground">Imágenes, PDF, Videos, Documentos (1 archivo máx.)</p>
          </div>

          {files.length > 0 && (
            <div className="mt-4 space-y-2">
              <h4 className="font-medium">Archivo:</h4>
              {files.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-2 border rounded-md">
                  <div className="flex items-center gap-3">
                    {getFileIcon(file.type, file.preview)}
                    <div className="text-sm">
                      <p className="font-medium truncate max-w-xs">{file.name}</p>
                      <p className="text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeFile(file)} disabled={isSubmitting}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
          )}
          
          {isSubmitting && files.length > 0 && !files[0].isUploaded && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground p-2">
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              <span>Subiendo archivo... Esto puede tardar unos minutos.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} id="article-form" className="space-y-4">
            <div>
              <Label htmlFor="title">Título</Label>
              <Input
                id="title"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="plain_text">Resumen / Texto Indexable</Label>
              <Textarea
                id="plain_text"
                name="plain_text"
                value={formData.plain_text}
                onChange={handleChange}
                className="h-24"
                placeholder="Añade un resumen claro. Este texto será usado por la IA para encontrar este artículo. Si se deja en blanco, se usará el contenido de abajo o del archivo."
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="content">Contenido / Descripción (Opcional)</Label>
              <Textarea
                id="content"
                name="content"
                value={formData.content}
                onChange={handleChange}
                className="h-24"
                placeholder="Añade una descripción o el contenido del artículo..."
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="tags">Etiquetas (separadas por coma)</Label>
              <Input
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Ej: pivot, motor, bomba, riego"
                disabled={isSubmitting}
              />
            </div>
          </form>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={handleCancelUpload}>{isSubmitting ? 'Cancelar Subida' : 'Cancelar'}</Button>
          <Button type="submit" form="article-form" disabled={isSubmitting}>
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            {isSubmitting ? 'Guardando...' : 'Guardar y Procesar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddEditArticleDialog;