import React, { useState, useEffect, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import * as XLSX from 'xlsx';
import { UploadCloud, FileText, Loader2 } from 'lucide-react';

const AddEditCatalogDialog = ({ isOpen, setIsOpen, onSave, document }) => {
  const [formData, setFormData] = useState({ title: '', content: '', tags: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const fileInputRef = useRef(null);
  const { toast } = useToast();

  useEffect(() => {
    if (document) {
      setFormData({
        id: document.id || null,
        title: document.title || '',
        content: document.content || '',
        tags: document.tags ? (Array.isArray(document.tags) ? document.tags.join(', ') : document.tags) : '',
      });
    } else {
      setFormData({ title: '', content: '', tags: '' });
    }
  }, [document, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const extractTextFromXlsx = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target.result;
        const workbook = XLSX.read(data, { type: 'array' });
        let fullText = '';
        workbook.SheetNames.forEach(sheetName => {
          fullText += `--- Hoja: ${sheetName} ---\n\n`;
          const worksheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
          fullText += json.map(row => row.join('\t')).join('\n') + '\n\n';
        });
        setFormData(prev => ({
          ...prev,
          title: file.name.replace(/\.(xlsx|xls)$/i, ''),
          content: fullText,
        }));
        toast({ title: 'Texto extraído de Excel exitosamente.' });
      } catch (error) {
        toast({ variant: 'destructive', title: 'Error al extraer texto de Excel', description: error.message });
      } finally {
        setIsExtracting(false);
      }
    };
    reader.onerror = (error) => {
        toast({ variant: 'destructive', title: 'Error al leer el archivo', description: error.message });
        setIsExtracting(false);
    };
    reader.readAsArrayBuffer(file);
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsExtracting(true);
    const fileType = file.type;
    const fileName = file.name.toLowerCase();

    if (
      fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      fileType === 'application/vnd.ms-excel' ||
      fileName.endsWith('.xlsx') ||
      fileName.endsWith('.xls')
    ) {
      extractTextFromXlsx(file);
    } else {
      toast({ variant: 'destructive', title: 'Formato de archivo no soportado', description: 'Por favor, sube un archivo Excel (.xlsx, .xls).' });
      setIsExtracting(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const dataToSave = {
      ...formData,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean)
    };

    const success = await onSave(dataToSave);
    if (success) {
      setIsOpen(false);
    }
    setIsSubmitting(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{document ? 'Editar Documento' : 'Añadir Nuevo Catálogo'}</DialogTitle>
          <DialogDescription>
            Rellena los detalles o carga un archivo Excel para extraer el texto.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <Button
            variant="outline"
            className="w-full"
            onClick={() => fileInputRef.current.click()}
            disabled={isExtracting}
          >
            {isExtracting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Extrayendo texto...
              </>
            ) : (
              <>
                <UploadCloud className="mr-2 h-4 w-4" />
                Cargar y Extraer Texto de Archivo Excel
              </>
            )}
          </Button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept=".xlsx,.xls"
          />

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                O rellenar manualmente
              </span>
            </div>
          </div>

          <form onSubmit={handleSubmit} id="catalog-form" className="space-y-4">
            <div>
              <Label htmlFor="title">Título</Label>
              <Input
                id="title"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
              />
            </div>
            <div>
              <Label htmlFor="content">Contenido del Catálogo</Label>
              <Textarea
                id="content"
                name="content"
                value={formData.content}
                onChange={handleChange}
                required
                className="h-64"
                placeholder="Pega aquí el contenido o cárgalo desde un archivo..."
              />
            </div>
            <div>
              <Label htmlFor="tags">Etiquetas (separadas por coma)</Label>
              <Input
                id="tags"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="Ej: pivot, motor, bomba, riego"
              />
            </div>
          </form>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>Cancelar</Button>
          <Button type="submit" form="catalog-form" disabled={isSubmitting || isExtracting}>
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            {isSubmitting ? 'Guardando...' : 'Guardar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddEditCatalogDialog;