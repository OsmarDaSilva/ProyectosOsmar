import React from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
    
    const PdfViewerDialog = ({ isOpen, setIsOpen, fileUrl, title }) => {
        return (
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="max-w-4xl h-[90vh]">
                    <DialogHeader>
                        <DialogTitle>{title || 'Visor de PDF'}</DialogTitle>
                        <DialogDescription>Visualizando el documento adjunto.</DialogDescription>
                    </DialogHeader>
                    <div className="h-full w-full overflow-hidden">
                       <iframe
                         src={fileUrl}
                         className="w-full h-full border-0"
                         title={title || 'Visor de PDF'}
                       ></iframe>
                    </div>
                </DialogContent>
            </Dialog>
        );
    };
    
    export default PdfViewerDialog;