import React, { useState, useEffect, useMemo } from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Loader2, HardHat, FileText, UploadCloud, Trash2, Eye, Star, ListTodo } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { v4 as uuidv4 } from 'uuid';
    import PdfViewerDialog from '@/components/equipment/PdfViewerDialog';
    import ImportJobsDialog from '@/components/catalog/ImportJobsDialog';
    import { useCreateImportJob, useImportJobs } from '@/hooks/useImportJobs';

    const FileUploader = ({ serialNumber, onFilesUpdated, files, isSaving, equipmentId }) => {
        const { toast } = useToast();
        const { user } = useAuth();
        const [localFiles, setLocalFiles] = useState([]);
        const [isViewerOpen, setIsViewerOpen] = useState(false);
        const [viewingFileUrl, setViewingFileUrl] = useState('');
        const [viewingFileTitle, setViewingFileTitle] = useState('');
        const [isJobsOpen, setIsJobsOpen] = useState(false);

        const createJobMutation = useCreateImportJob();
        const { refetchJobs } = useImportJobs(user?.id, 'equipment_files');

        const isAdmin = useMemo(() => user?.role === 'admin', [user]);

        useEffect(() => {
          setLocalFiles(files || []);
        }, [files]);
    
        const handleFileChange = async (e) => {
            if (!serialNumber) {
                toast({ variant: 'destructive', title: 'Error', description: 'Por favor, ingrese un número de serie antes de subir archivos.' });
                return;
            }
            const file = e.target.files[0];
            if (!file) return;
    
            if (file.type !== 'application/pdf') {
                toast({ variant: 'destructive', title: 'Error', description: 'Solo se permiten archivos PDF.' });
                return;
            }
    
            const jobMetadata = {
                title: file.name.replace(/\.pdf$/i, ''),
                fileName: file.name,
                fileType: file.type,
                fileSize: file.size,
                isPrincipal: localFiles.length === 0,
                equipmentId: equipmentId, // Pass equipmentId if it exists
                serialNumber: serialNumber, // Pass serial number for new equipment
            };

            createJobMutation.mutate({ file, user, jobType: 'equipment_files', metadata: jobMetadata }, {
                onSuccess: () => {
                    toast({
                        title: 'Subida Iniciada',
                        description: `El archivo "${file.name}" se está procesando. Se adjuntará al equipo al guardar.`,
                    });
                    setIsJobsOpen(true);
                    refetchJobs();
                },
                onError: (error) => {
                    toast({ variant: 'destructive', title: 'Error al iniciar subida', description: error.message });
                },
            });
        };
    
        const handleFileDetailChange = (index, field, value) => {
            const updatedFiles = [...localFiles];
            updatedFiles[index][field] = value;
            setLocalFiles(updatedFiles);
            onFilesUpdated(updatedFiles);
        };
    
        const setAsPrincipal = (indexToSet) => {
            const updatedFiles = localFiles.map((file, index) => ({
                ...file,
                is_principal: index === indexToSet
            }));
            setLocalFiles(updatedFiles);
            onFilesUpdated(updatedFiles);
        };

        const deleteFile = (indexToDelete) => {
            const updatedFiles = localFiles.filter((_, index) => index !== indexToDelete);

            if (localFiles[indexToDelete].is_principal && updatedFiles.length > 0) {
                updatedFiles[0].is_principal = true;
            }
            setLocalFiles(updatedFiles);
            onFilesUpdated(updatedFiles);
            toast({ title: 'Archivo marcado para eliminar', description: 'El archivo se eliminará al guardar.' });
        };

        const viewFile = (file) => {
            setViewingFileUrl(file.file_url);
            setViewingFileTitle(file.title);
            setIsViewerOpen(true);
        };

        return (
          <>
            <div className="space-y-4 rounded-lg border p-4">
                <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold flex items-center gap-2"><FileText /> Fichas Técnicas (PDF)</h3>
                    <div className="flex items-center gap-2">
                        <Button type="button" size="sm" variant="outline" onClick={() => setIsJobsOpen(true)}>
                            <ListTodo className="mr-2 h-4 w-4" /> Subidas
                        </Button>
                        <Button type="button" size="sm" onClick={() => document.getElementById('pdf-upload').click()} disabled={createJobMutation.isPending || isSaving}>
                            {createJobMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                            Subir PDF
                        </Button>
                    </div>
                    <input type="file" id="pdf-upload" className="hidden" onChange={handleFileChange} accept=".pdf" />
                </div>
                <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                    {localFiles.map((file, index) => (
                        <div key={file.id || index} className="p-3 border rounded-md space-y-2 bg-muted/50">
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                                <div className="space-y-1">
                                    <Label>Título</Label>
                                    <Input value={file.title || ''} onChange={(e) => handleFileDetailChange(index, 'title', e.target.value)} disabled={!isAdmin} />
                                </div>
                                <div className="space-y-1">
                                    <Label>Versión</Label>
                                    <Input value={file.version || ''} onChange={(e) => handleFileDetailChange(index, 'version', e.target.value)} disabled={!isAdmin} />
                                </div>
                                <div className="space-y-1">
                                    <Label>Proveedor/Marca</Label>
                                    <Input value={file.provider_brand || ''} onChange={(e) => handleFileDetailChange(index, 'provider_brand', e.target.value)} disabled={!isAdmin} />
                                </div>
                                <div className="space-y-1">
                                    <Label>Fecha</Label>
                                    <Input type="date" value={file.file_date || ''} onChange={(e) => handleFileDetailChange(index, 'file_date', e.target.value)} disabled={!isAdmin} />
                                </div>
                                <div className="col-span-2 space-y-1">
                                    <Label>Observaciones</Label>
                                    <Textarea value={file.observations || ''} onChange={(e) => handleFileDetailChange(index, 'observations', e.target.value)} disabled={!isAdmin} />
                                </div>
                            </div>
                            <div className="flex items-center justify-between pt-2 border-t mt-2">
                                <Button type="button" variant={file.is_principal ? "default" : "outline"} size="sm" onClick={() => setAsPrincipal(index)} disabled={file.is_principal || !isAdmin}>
                                    <Star className={`mr-2 h-4 w-4 ${file.is_principal ? 'text-yellow-400' : ''}`} />
                                    {file.is_principal ? 'Principal' : 'Marcar como Principal'}
                                </Button>
                                <div className="flex items-center gap-2">
                                    <Button type="button" variant="ghost" size="sm" onClick={() => viewFile(file)}><Eye className="mr-2 h-4 w-4" />Ver</Button>
                                    {isAdmin && <Button type="button" variant="ghost" size="sm" className="text-red-600 hover:text-red-700" onClick={() => deleteFile(index)}><Trash2 className="mr-2 h-4 w-4" />Eliminar</Button>}
                                </div>
                            </div>
                        </div>
                    ))}
                    {localFiles.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No hay fichas técnicas adjuntas.</p>}
                </div>
            </div>
            {isViewerOpen && (
              <PdfViewerDialog
                isOpen={isViewerOpen}
                setIsOpen={setIsViewerOpen}
                fileUrl={viewingFileUrl}
                title={viewingFileTitle}
              />
            )}
            <ImportJobsDialog
                isOpen={isJobsOpen}
                setIsOpen={setIsJobsOpen}
                jobType="equipment_files"
                title="Subidas de Fichas Técnicas"
                description="Monitoriza el progreso de tus subidas de fichas técnicas."
            />
          </>
        );
    };

    const AddEditEquipmentDialog = ({ isOpen, setIsOpen, equipment, onSave, clients, isLoading }) => {
      const { toast } = useToast();
      const [formData, setFormData] = useState({});
      const [files, setFiles] = useState([]);

      useEffect(() => {
        if (isOpen) {
          if (equipment) {
            setFormData({
              id: equipment.id,
              client_id: equipment.client_id || '',
              serial_number: equipment.serial_number || '',
              equipment_type: equipment.equipment_type || '',
              brand: equipment.brand || '',
              model: equipment.model || '',
              manufacturing_year: equipment.manufacturing_year || '',
              installation_address: equipment.installation_address || '',
              gps_coordinates: equipment.gps_coordinates || '',
              installation_date: equipment.installation_date || '',
              status: equipment.status || 'Activo',
              technical_observations: equipment.technical_observations || '',
            });
            setFiles(equipment.equipment_files || []);
          } else {
            setFormData({
              client_id: '',
              serial_number: '',
              equipment_type: '',
              brand: '',
              model: '',
              manufacturing_year: new Date().getFullYear(),
              installation_date: new Date().toISOString().split('T')[0],
              status: 'Activo',
              technical_observations: '',
            });
            setFiles([]);
          }
        }
      }, [equipment, isOpen]);

      const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
      };

      const handleSelectChange = (id, value) => {
        setFormData(prev => ({ ...prev, [id]: value }));
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        
        if (files.length > 0 && !files.some(f => f.is_principal)) {
            toast({
                variant: 'destructive',
                title: 'Error de validación',
                description: 'Debe marcar una ficha técnica como principal.'
            });
            return;
        }

        onSave({ ...formData, filesToSave: files });
      };

      return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent className="sm:max-w-4xl">
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>{equipment ? 'Editar' : 'Añadir'} Equipo/Máquina</DialogTitle>
                <DialogDescription>Complete los detalles del equipo y adjunte sus fichas técnicas.</DialogDescription>
              </DialogHeader>
              <ScrollArea className="h-[70vh] pr-6 -mr-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                  
                  <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2"><HardHat /> Datos del Equipo</h3>
                      <div className="space-y-2">
                        <Label htmlFor="serial_number">Número de Serie (único)</Label>
                        <Input id="serial_number" value={formData.serial_number || ''} onChange={handleChange} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="client_id">Cliente Propietario</Label>
                        <Select onValueChange={(value) => handleSelectChange('client_id', value)} value={formData.client_id || ''} required>
                          <SelectTrigger><SelectValue placeholder="Seleccione un cliente" /></SelectTrigger>
                          <SelectContent>
                            {clients.map(client => (
                              <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="equipment_type">Tipo de Máquina/Equipo</Label>
                        <Input id="equipment_type" value={formData.equipment_type || ''} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="brand">Marca</Label>
                        <Input id="brand" value={formData.brand || ''} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="model">Modelo</Label>
                        <Input id="model" value={formData.model || ''} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="manufacturing_year">Año de Fabricación</Label>
                        <Input id="manufacturing_year" type="number" value={formData.manufacturing_year || ''} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="installation_date">Fecha de Instalación/Venta</Label>
                        <Input id="installation_date" type="date" value={formData.installation_date || ''} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="status">Estado</Label>
                         <Select onValueChange={(value) => handleSelectChange('status', value)} value={formData.status || ''}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Activo">Activo</SelectItem>
                            <SelectItem value="En mantenimiento">En mantenimiento</SelectItem>
                            <SelectItem value="Fuera de servicio">Fuera de servicio</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="installation_address">Dirección de Instalación</Label>
                        <Input id="installation_address" value={formData.installation_address || ''} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="gps_coordinates">Coordenadas GPS (lat, lng)</Label>
                        <Input id="gps_coordinates" value={formData.gps_coordinates || ''} onChange={handleChange} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="technical_observations">Observaciones Técnicas</Label>
                        <Textarea id="technical_observations" placeholder="Potencia, voltaje, capacidad, etc." value={formData.technical_observations || ''} onChange={handleChange} />
                      </div>
                  </div>

                  <div className="space-y-4">
                    <FileUploader 
                        serialNumber={formData.serial_number}
                        files={files}
                        onFilesUpdated={(updatedFiles) => setFiles(updatedFiles)}
                        isSaving={isLoading}
                        equipmentId={equipment?.id}
                    />
                  </div>

                </div>
              </ScrollArea>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)} disabled={isLoading}>Cancelar</Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Guardar
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    };

    export default AddEditEquipmentDialog;