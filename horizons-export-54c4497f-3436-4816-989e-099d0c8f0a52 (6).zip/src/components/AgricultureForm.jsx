import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import SafraSection from '@/components/SafraSection';
import { initialSafraData } from '@/utils/agricultureCalculations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAgricultureCalculations } from '@/hooks/useAgricultureCalculations';
import { Button } from '@/components/ui/button';
import { Printer, CheckCircle } from 'lucide-react';
import { useReactToPrint } from 'react-to-print';
import { useTranslation } from 'react-i18next';

const formatCurrency = (value) => {
    return `U$ ${new Intl.NumberFormat('es-PY', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value || 0)}`;
  };

const formatPercentage = (value) => {
    if (isNaN(value) || !isFinite(value)) return '0,00%';
    return `${(value * 100).toFixed(2)}%`.replace('.', ',');
};

const AgricultureForm = ({ initialData, onUpdate }) => {
  const { t } = useTranslation(['simulations', 'common']);
  const [safras, setSafras] = useState([]);
  const { totalCalculations } = useAgricultureCalculations({ cultivos: safras });
  const printableRef = useRef();

  const handlePrint = useReactToPrint({
    content: () => printableRef.current,
    documentTitle: "datos_agricultura",
  });

  useEffect(() => {
    const getDefaultData = () => {
      return [
        { id: 1, isEnabled: true, name: t('agriculture.safra1'), traditional: { ...initialSafraData, cultura: 'Soja', hectareas: '400', produccionHa: 2.8, precioVenta: 350, costoInsumosHa: 400, costoMaquinariasHa: 150, costoManutencionHa: 30, costoFletesTon: 7, costoEnergiaElectricaHa: 5, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '20' }, tecnified: { ...initialSafraData, cultura: 'Soja', hectareas: '400', produccionHa: 5, precioVenta: 350, costoInsumosHa: 500, costoMaquinariasHa: 170, costoManutencionHa: 60, costoFletesTon: 7, costoEnergiaElectricaHa: 100, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '30' } },
        { id: 2, isEnabled: true, name: t('agriculture.safra2'), traditional: { ...initialSafraData, cultura: 'Maíz', hectareas: '400', produccionHa: 5, precioVenta: 150, costoInsumosHa: 400, costoMaquinariasHa: 140, costoManutencionHa: 30, costoFletesTon: 7, costoEnergiaElectricaHa: 5, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '90' }, tecnified: { ...initialSafraData, cultura: 'Maíz', hectareas: '400', produccionHa: 10, precioVenta: 150, costoInsumosHa: 650, costoMaquinariasHa: 170, costoManutencionHa: 60, costoFletesTon: 7, costoEnergiaElectricaHa: 110, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '150' } },
        { id: 3, isEnabled: false, name: t('agriculture.safra3'), traditional: { ...initialSafraData, cultura: 'Frijol', hectareas: '400', impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '15' }, tecnified: { ...initialSafraData, cultura: 'Frijol', hectareas: '400', produccionHa: 2.5, precioVenta: 800, costoInsumosHa: 200, costoMaquinariasHa: 200, costoManutencionHa: 60, costoFletesTon: 7, costoEnergiaElectricaHa: 110, impuestosIrragroPct: '5%', impuestoRentaIRPPct: '10%', dosis_n: '25' } },
      ];
    };

    if (initialData && Array.isArray(initialData.cultivos) && initialData.cultivos.length > 0) {
        const mergedData = getDefaultData().map(defaultSafra => {
            const foundSafra = initialData.cultivos.find(d => d.id === defaultSafra.id);
            if (foundSafra) {
                return {
                    ...defaultSafra,
                    ...foundSafra,
                    traditional: { ...defaultSafra.traditional, ...foundSafra.traditional },
                    tecnified: { ...defaultSafra.tecnified, ...foundSafra.tecnified },
                };
            }
            return defaultSafra;
        });
        setSafras(mergedData);
    } else {
        setSafras(getDefaultData());
    }
  }, [initialData, t]);

  const handleUpdateSafra = (index, type, updatedData) => {
    const newSafras = [...safras];
    newSafras[index][type] = updatedData;
    setSafras(newSafras);
    onUpdate({ isEnabled: true, cultivos: newSafras });
  };

  const handleToggleSafra = (index) => {
    const newSafras = [...safras];
    newSafras[index].isEnabled = !newSafras[index].isEnabled;
    setSafras(newSafras);
    onUpdate({ isEnabled: true, cultivos: newSafras });
  };
  
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-2 flex-grow flex flex-col items-center"
        >
            <div className="flex items-center gap-3">
                <h1 className="text-4xl font-bold gradient-text">{t('agriculture.title')}</h1>
                <div className="flex items-center bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    <span>{t('common:validated')}</span>
                </div>
            </div>
          <p className="text-gray-600">{t('agriculture.asDesc')}</p>
        </motion.div>
        <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700 ml-4 no-print">
          <Printer className="mr-2 h-4 w-4" />
          {t('common:exportPdf')}
        </Button>
      </div>

      <div ref={printableRef} className="p-2 print-area">
        {safras.map((safra, index) => (
          <div key={safra.id} className="p-4 my-4 border rounded-lg bg-white shadow-md print-page-break">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">{safra.name}</h2>
              <label className="flex items-center space-x-2 cursor-pointer no-print">
                <input
                  type="checkbox"
                  checked={safra.isEnabled}
                  onChange={() => handleToggleSafra(index)}
                  className="form-checkbox h-5 w-5 text-blue-600"
                />
                <span className="text-gray-700">{t('agriculture.enableSafra')}</span>
              </label>
            </div>
            {safra.isEnabled && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <SafraSection
                  title={t('agriculture.traditionalSowing')}
                  safraData={safra.traditional}
                  onUpdate={(updatedData) => handleUpdateSafra(index, 'traditional', updatedData)}
                  safraIndex={index}
                  type="traditional"
                />
                <SafraSection
                  title={t('agriculture.irrigatedSowing')}
                  safraData={safra.tecnified}
                  onUpdate={(updatedData) => handleUpdateSafra(index, 'tecnified', updatedData)}
                  safraIndex={index}
                  type="tecnified"
                />
              </div>
            )}
          </div>
        ))}
         <Card className="mt-8 print-page-break">
              <CardHeader>
                  <CardTitle className="text-center text-lg">{t('agriculture.totalProfitSummary')}</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center text-center p-4 bg-gray-50">
                  <div className="p-4 bg-orange-100 rounded-lg">
                      <p className="font-semibold text-orange-800">{t('agriculture.totalTraditionalProfit')}</p>
                      <p className="text-2xl font-bold text-orange-600">{formatCurrency(totalCalculations.tradicional)}</p>
                  </div>
                   <div className="p-4 bg-[#e0e7ff] rounded-lg">
                      <p className="font-semibold text-indigo-800">{t('agriculture.totalTechProfit')}</p>
                      <p className="text-2xl font-bold text-indigo-600">{formatCurrency(totalCalculations.tecnified)}</p>
                  </div>
                  <div className="p-4 bg-yellow-100 rounded-lg">
                      <p className="font-semibold text-yellow-800">{t('agriculture.netIncomeDifferential')}</p>
                      <p className="text-2xl font-bold text-yellow-600">{formatCurrency(totalCalculations.diferencia)}</p>
                  </div>
                  <div className="p-4 bg-green-100 rounded-lg">
                      <p className="font-semibold text-green-800">{t('agriculture.netProfitDifference')}</p>
                      <p className="text-2xl font-bold text-green-600">{formatPercentage(totalCalculations.diferenciaPct)}</p>
                  </div>
              </CardContent>
          </Card>
      </div>
    </div>
  );
};

export default AgricultureForm;