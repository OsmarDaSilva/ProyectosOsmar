import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Users, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import UserManagement from '@/components/UserManagement';

const UserManagementLayout = () => {
  const navigate = useNavigate();

  return (
    <>
      <Helmet>
        <title>Gestión de Usuarios - Co$to Rural</title>
        <meta name="description" content="Administra colaboradores y clientes de la plataforma Co$to Rural." />
      </Helmet>
      <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-4">
                    <Button variant="outline" size="icon" onClick={() => navigate('/settings')}>
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                    <h1 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
                        <Users className="text-green-600" />
                        Gestión de Usuarios
                    </h1>
                </div>
            </div>
            <UserManagement />
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default UserManagementLayout;