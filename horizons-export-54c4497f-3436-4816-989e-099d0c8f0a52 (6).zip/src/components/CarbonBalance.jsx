import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useCarbonCalculations } from '@/hooks/useCarbonCalculations';
import { ArrowDown, ArrowUp, Leaf, DollarSign, Printer, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useReactToPrint } from 'react-to-print';
import { useTranslation } from 'react-i18next';
import { formatNumber, formatCurrency } from '@/lib/utils';


const CarbonBalance = ({ ganaderiaData, agricultureData, projectData }) => {
    const { t } = useTranslation(['carbonBalance', 'calculator', 'common']);
    const { calculations } = useCarbonCalculations(ganaderiaData, agricultureData, projectData);
    const printableRef = useRef();
    
    const handlePrint = useReactToPrint({
      content: () => printableRef.current,
      documentTitle: `${t('carbonBalance:pdfFilename')}_${projectData?.projectName?.replace(/\s+/g, '_') || 'proyecto'}.pdf`,
      pageStyle: `@page { size: auto; margin: 12mm; } @media print { body { -webkit-print-color-adjust: exact; } .no-print { display: none; } .print-page-break { page-break-after: always; } }`
    });

    const { traditional, tech, projectType, projectHectares, comparison } = calculations;

    const data = [
        {
            name: t('calculator:models.traditional'),
            [t('carbonBalance:emissions')]: traditional.totalEmissions,
            [t('carbonBalance:sequestration')]: -traditional.totalSequestration,
            [t('carbonBalance:balance')]: traditional.netBalance,
        },
        {
            name: t('calculator:models.technified'),
            [t('carbonBalance:emissions')]: tech.totalEmissions,
            [t('carbonBalance:sequestration')]: -tech.totalSequestration,
            [t('carbonBalance:balance')]: tech.netBalance,
        },
    ];

    const CustomTooltip = ({ active, payload, label }) => {
        if (active && payload && payload.length) {
            return (
                <div className="p-4 bg-white/90 backdrop-blur-sm rounded-lg shadow-lg border border-gray-200">
                    <p className="font-bold text-gray-800">{label}</p>
                    {payload.map(pld => {
                       const value = pld.dataKey === t('carbonBalance:sequestration') ? -pld.value : pld.value;
                       return (
                         <p key={pld.dataKey} style={{ color: pld.fill }}>
                            {`${pld.name}: ${formatNumber(value)} tCO2e`}
                        </p>
                       )
                    })}
                </div>
            );
        }
        return null;
    };

    const MetricCard = ({ title, value, change, unit, icon, positiveIsGood = true }) => {
        const Icon = icon;
        const isPositive = change > 0;
        const changeColor = (isPositive && positiveIsGood) || (!isPositive && !positiveIsGood) ? 'text-green-600' : 'text-red-600';
        const ChangeIcon = isPositive ? ArrowUp : ArrowDown;

        return (
            <Card className="metric-card">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{title}</CardTitle>
                    <Icon className="h-5 w-5 text-gray-400" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{value} <span className="text-sm font-normal text-gray-500">{unit}</span></div>
                    {change !== null && typeof change === 'number' && isFinite(change) && (
                        <p className={`text-xs ${changeColor} flex items-center`}>
                            <ChangeIcon className="h-4 w-4 mr-1" />
                            {`${formatNumber(change * 100, 1)}% ${t('carbonBalance:vsTraditional')}`}
                        </p>
                    )}
                </CardContent>
            </Card>
        );
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
        >
            <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4 no-print">
                <div className="flex items-center gap-3">
                    <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 text-center sm:text-left">{t('carbonBalance:title')}</h1>
                    <div className="flex items-center bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        <span>{t('common:validated')}</span>
                    </div>
                </div>
                <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700 w-full sm:w-auto">
                    <Printer className="mr-2 h-4 w-4" />
                    {t('common:exportPdf')}
                </Button>
            </div>

            <div ref={printableRef} className="p-2 space-y-8 print-area">
                <Card className="shadow-inner-strong bg-gray-50/50">
                    <CardHeader>
                        <div className="flex justify-between items-center">
                            <div>
                                <CardTitle className="text-xl">{projectData?.projectName || t('carbonBalance:projectName')}</CardTitle>
                                <CardDescription>{projectType}</CardDescription>
                            </div>
                            <div className="text-right">
                                <p className="text-sm font-medium text-gray-500">{t('carbonBalance:projectArea')}</p>
                                <p className="text-2xl font-bold text-gray-800">{formatNumber(projectHectares)} ha</p>
                            </div>
                        </div>
                    </CardHeader>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <MetricCard 
                        title={t('carbonBalance:netBalanceTech')}
                        value={formatNumber(tech.netBalance, 0)}
                        unit="tCO2e/año"
                        change={comparison.netBalancePct}
                        icon={Leaf}
                        positiveIsGood={false}
                    />
                    <MetricCard 
                        title={t('carbonBalance:emissionsReduction')}
                        value={`${formatNumber(comparison.emissionsReductionPct * 100, 1)}%`}
                        unit=""
                        change={null}
                        icon={ArrowDown}
                        positiveIsGood={true}
                    />
                    <MetricCard 
                        title={t('carbonBalance:sequestrationIncrease')}
                        value={`${formatNumber(comparison.sequestrationIncreasePct * 100, 1)}%`}
                        unit=""
                        change={null}
                        icon={ArrowUp}
                        positiveIsGood={true}
                    />
                    <Card className="col-span-1 lg:col-span-1 bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-lg">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-green-100">{t('carbonBalance:revenuePotential')}</CardTitle>
                            <DollarSign className="h-5 w-5 text-green-200" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-3xl font-bold">{formatCurrency(tech.potentialRevenue)}</div>
                            <p className="text-xs text-green-200 mt-1">{t('carbonBalance:revenueNote', { years: projectData?.projectYears || 10 })}</p>
                        </CardContent>
                    </Card>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>{t('carbonBalance:annualComparisonTitle')}</CardTitle>
                        <CardDescription>{t('carbonBalance:annualComparisonDesc')}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="h-96">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="name" />
                                    <YAxis tickFormatter={(tick) => `${formatNumber(tick)}`} label={{ value: 'tCO2e / ' + t('common:year'), angle: -90, position: 'insideLeft' }} />
                                    <Tooltip content={<CustomTooltip />} />
                                    <Legend />
                                    <ReferenceLine y={0} stroke="#000" strokeWidth={2} />
                                    <Bar dataKey={t('carbonBalance:emissions')} fill="#ef4444" name={t('carbonBalance:emissions')} stackId="a" />
                                    <Bar dataKey={t('carbonBalance:sequestration')} fill="#22c55e" name={t('carbonBalance:sequestration')} stackId="a" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardHeader>
                        <CardTitle>{t('carbonBalance:detailedSummaryTitle')}</CardTitle>
                        <CardDescription>{t('carbonBalance:detailedSummaryDesc')}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead className="font-bold">{t('carbonBalance:metric')} (tCO2e/{t('common:year')})</TableHead>
                                    <TableHead className="text-right font-bold">{t('calculator:models.traditional')}</TableHead>
                                    <TableHead className="text-right font-bold">{t('calculator:models.technified')}</TableHead>
                                    <TableHead className="text-right font-bold">{t('carbonBalance:improvement')}</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                <TableRow>
                                    <TableCell>{t('carbonBalance:totalEmissions')}</TableCell>
                                    <TableCell className="text-right text-red-600">{formatNumber(traditional.totalEmissions)}</TableCell>
                                    <TableCell className="text-right text-red-600">{formatNumber(tech.totalEmissions)}</TableCell>
                                    <TableCell className="text-right text-green-600">
                                        <div className="flex items-center justify-end">
                                            <ArrowDown className="h-4 w-4 mr-1"/>
                                            {formatNumber(comparison.emissionsReduction, 0)} ({formatNumber(comparison.emissionsReductionPct * 100, 1)}%)
                                        </div>
                                    </TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>{t('carbonBalance:totalSequestration')}</TableCell>
                                    <TableCell className="text-right text-green-600">{formatNumber(traditional.totalSequestration)}</TableCell>
                                    <TableCell className="text-right text-green-600">{formatNumber(tech.totalSequestration)}</TableCell>
                                    <TableCell className="text-right text-green-600">
                                        <div className="flex items-center justify-end">
                                            <ArrowUp className="h-4 w-4 mr-1"/>
                                            {formatNumber(comparison.sequestrationIncrease, 0)} ({formatNumber(comparison.sequestrationIncreasePct * 100, 1)}%)
                                        </div>
                                    </TableCell>
                                </TableRow>
                                <TableRow className="bg-gray-100 font-bold">
                                    <TableCell>{t('carbonBalance:netBalance')}</TableCell>
                                    <TableCell className={`text-right ${traditional.netBalance >= 0 ? 'text-red-700' : 'text-green-700'}`}>{formatNumber(traditional.netBalance)}</TableCell>
                                    <TableCell className={`text-right ${tech.netBalance >= 0 ? 'text-red-700' : 'text-green-700'}`}>{formatNumber(tech.netBalance)}</TableCell>
                                    <TableCell className={`text-right ${comparison.netBalanceChange >= 0 ? 'text-red-700' : 'text-green-700'}`}>
                                        <div className="flex items-center justify-end">
                                            {comparison.netBalanceChange < 0 ? <ArrowDown className="h-4 w-4 mr-1"/> : <ArrowUp className="h-4 w-4 mr-1"/>}
                                            {formatNumber(comparison.netBalanceChange, 0)} ({formatNumber(comparison.netBalancePct * 100, 1)}%)
                                        </div>
                                    </TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </motion.div>
    );
};

export default CarbonBalance;