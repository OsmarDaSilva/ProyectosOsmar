import React, { useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { FileImage as ImageIcon, Video, FileText, Edit, Trash2 } from 'lucide-react';

const AssetRow = ({ asset, onEdit, onDelete }) => {
  const fileType = asset.file_type || '';
  const Icon = useMemo(() => {
    if (fileType.startsWith('image')) return ImageIcon;
    if (fileType.startsWith('video')) return Video;
    return FileText;
  }, [fileType]);

  return (
    <tr className="hover:bg-muted/50">
      <td className="p-2"><Icon className="h-5 w-5 text-muted-foreground"/></td>
      <td className="p-2 font-medium truncate" title={asset.file_name}>{asset.file_name}</td>
      <td className="p-2 text-muted-foreground hidden md:table-cell">{asset.category}</td>
      <td className="p-2 text-muted-foreground hidden lg:table-cell">{asset.subcategory}</td>
      <td className="p-2 text-muted-foreground text-xs hidden md:table-cell">{new Date(asset.created_at).toLocaleDateString()}</td>
      <td className="p-2 text-right">
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(asset)}><Edit className="h-4 w-4" /></Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => onDelete(asset)}><Trash2 className="h-4 w-4" /></Button>
      </td>
    </tr>
  );
};

export default AssetRow;