import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { List, RefreshCw, Loader2 } from 'lucide-react';

const statusMapping = {
  queued: { text: "En Cola", variant: "default" },
  processing: { text: "Procesando", variant: "secondary" },
  completed: { text: "Completado", variant: "success" },
  completed_with_errors: { text: "Con Errores", variant: "destructive" },
  failed: { text: "Fallido", variant: "destructive" },
};

const ImportHistory = ({ jobs, onRefresh, isResuming, onResume }) => {
    return (
        <Card className="mt-6">
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2"><List /> Historial de Subidas</CardTitle>
                <Button variant="ghost" size="sm" onClick={onRefresh}><RefreshCw className="h-4 w-4"/></Button>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {(jobs?.length ?? 0) === 0 ? <p className="text-sm text-muted-foreground">No hay subidas recientes.</p> :
                     jobs?.map(job => {
                        const { text, variant } = statusMapping[job.status] || { text: 'Desconocido', variant: 'secondary' };
                        return (
                            <div key={job.id} className="p-3 border rounded-lg bg-background">
                                <div className="flex justify-between items-start flex-wrap gap-2">
                                    <div className="flex-1 min-w-[200px]">
                                        <p className="font-semibold text-sm truncate" title={job.summary?.fileName}>
                                          {job.summary?.fileName || 'Trabajo de subida'}
                                        </p>
                                        <div className="flex items-center gap-2">
                                            <Badge variant={variant}>{text}</Badge>
                                            <p className="text-xs text-muted-foreground">{new Date(job.created_at).toLocaleString()}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        {job.status === 'failed' && (
                                            <Button size="sm" variant="outline" onClick={() => onResume(job.id)} disabled={isResuming}>
                                                {isResuming ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <RefreshCw className="mr-2 h-4 w-4"/>} 
                                                Reintentar
                                            </Button>
                                        )}
                                    </div>
                                </div>
                                {job.status === 'failed' && job.summary?.error && (
                                  <div className="text-xs mt-2 border-t pt-2">
                                    <p className="text-red-600">
                                      <span className="font-bold">Error:</span> {job.summary.error}
                                    </p>
                                  </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
};

export default ImportHistory;