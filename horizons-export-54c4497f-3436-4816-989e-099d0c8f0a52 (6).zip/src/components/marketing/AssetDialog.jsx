import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useCreateImportJob } from '@/hooks/useImportJobs';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';

const AssetDialog = ({ isOpen, setIsOpen, asset, onSave }) => {
  const { user } = useAuth();
  const [currentAsset, setCurrentAsset] = useState(null);
  const [file, setFile] = useState(null);
  const createJobMutation = useCreateImportJob();

  useEffect(() => {
    if (asset) {
      setCurrentAsset({ ...asset });
    } else {
      setCurrentAsset({ file_name: '', description: '', category: '', subcategory: '' });
    }
    setFile(null);
  }, [asset, isOpen]);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!file && !asset?.id) {
      alert("Por favor, seleccione un archivo.");
      return;
    }

    if (file) {
      const metadata = {
        fileName: currentAsset.file_name || file.name,
        description: currentAsset.description,
        category: currentAsset.category,
        subcategory: currentAsset.subcategory,
        fileType: file.type,
      };
      await createJobMutation.mutateAsync({ file, user, jobType: 'marketing_assets', metadata });
      onSave();
    } else {
      onSave(currentAsset);
    }
  };

  if (!currentAsset) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent>
        <form onSubmit={handleSave}>
          <DialogHeader>
            <DialogTitle>{asset?.id ? 'Editar Activo' : 'Subir Nuevo Activo'}</DialogTitle>
            <DialogDescription>
              {asset?.id ? 'Modifique los detalles de su activo de marketing.' : 'Añada un nuevo archivo a su biblioteca de marketing.'}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {!asset?.id && (
              <div className="space-y-2">
                <Label htmlFor="file">Archivo</Label>
                <Input id="file" type="file" onChange={(e) => setFile(e.target.files[0])} required />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="file_name">Nombre del Archivo</Label>
              <Input id="file_name" value={currentAsset.file_name} onChange={(e) => setCurrentAsset({ ...currentAsset, file_name: e.target.value })} placeholder="Ej: Brochure Corporativo 2024.pdf" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea id="description" value={currentAsset.description} onChange={(e) => setCurrentAsset({ ...currentAsset, description: e.target.value })} placeholder="Breve descripción del contenido del archivo." />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Categoría</Label>
                <Input id="category" value={currentAsset.category} onChange={(e) => setCurrentAsset({ ...currentAsset, category: e.target.value })} placeholder="Ej: Fotos, Videos, Documentos" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subcategory">Subcategoría (Carpeta)</Label>
                <Input id="subcategory" value={currentAsset.subcategory} onChange={(e) => setCurrentAsset({ ...currentAsset, subcategory: e.target.value })} placeholder="Ej: Producto A, Campaña Invierno" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">Cancelar</Button>
            </DialogClose>
            <Button type="submit" disabled={createJobMutation.isPending}>
              {createJobMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {createJobMutation.isPending ? 'Procesando...' : 'Subir y Procesar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AssetDialog;