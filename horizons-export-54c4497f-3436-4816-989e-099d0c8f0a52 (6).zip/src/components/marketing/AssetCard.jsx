import React, { useMemo } from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileImage as ImageIcon, Video, FileText, Edit, Trash2 } from 'lucide-react';

const AssetCard = ({ asset, onEdit, onDelete }) => {
  const fileType = asset.file_type || '';
  const Icon = useMemo(() => {
    if (fileType.startsWith('image')) return ImageIcon;
    if (fileType.startsWith('video')) return Video;
    return FileText;
  }, [fileType]);

  return (
    <Card className="overflow-hidden group transition-all duration-300 hover:shadow-xl">
      <CardContent className="p-0">
        <div className="aspect-video bg-muted flex items-center justify-center relative overflow-hidden">
          {fileType.startsWith('image') || fileType.startsWith('video') ? (
            <img  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" alt={asset.description || asset.file_name} src={asset.thumbnail_url || asset.file_url} />
          ) : (
            <Icon className="w-16 h-16 text-muted-foreground" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-0 left-0 p-4 w-full">
            <h3 className="text-white font-bold text-sm truncate" title={asset.file_name}>{asset.file_name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="secondary" className="text-xs">{asset.category}</Badge>
              <Badge variant="outline" className="text-xs backdrop-blur-sm bg-white/20 text-white border-white/50">{asset.subcategory}</Badge>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-2 bg-background/50 flex justify-end gap-2">
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(asset)}><Edit className="h-4 w-4" /></Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => onDelete(asset)}><Trash2 className="h-4 w-4" /></Button>
      </CardFooter>
    </Card>
  );
};

export default AssetCard;