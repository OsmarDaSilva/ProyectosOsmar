import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const CreateTaskFromMessageDialog = ({ isOpen, onOpenChange, message, clients, deals, users, onTaskCreated }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const ACTIVITY_TYPES = ['Llamada', 'Reunión', 'Tarea', 'Email'];
  
  const [formData, setFormData] = useState({
    type: 'Tarea',
    notes: '',
    due_date: '',
    client_id: '',
    deal_id: '',
    user_id: user?.id,
    source_message_id: null,
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (message) {
      setFormData({
        type: 'Tarea',
        notes: message.content || '',
        due_date: '',
        client_id: '',
        deal_id: '',
        user_id: user?.id,
        source_message_id: message.id,
      });
    }
  }, [message, user]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id, value) => {
    const newState = { ...formData, [id]: value };
    if (id === 'client_id') {
      newState.deal_id = '';
    }
    setFormData(newState);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    const dataToSave = { ...formData };
    if (!dataToSave.client_id) dataToSave.client_id = null;
    if (!dataToSave.deal_id) dataToSave.deal_id = null;
    if (!dataToSave.due_date) dataToSave.due_date = null;

    const { error } = await supabase.from('activities').insert(dataToSave);
    
    setIsSaving(false);
    if (error) {
      toast({ variant: 'destructive', title: 'Error al crear la tarea', description: error.message });
    } else {
      toast({ title: '¡Tarea creada!', description: 'La tarea ha sido añadida a la agenda.' });
      onTaskCreated();
      onOpenChange(false);
    }
  };

  const filteredDeals = formData.client_id ? deals.filter(d => d.client_id === formData.client_id) : [];

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Crear Tarea desde Mensaje</DialogTitle>
            <DialogDescription>
              Convierte este mensaje en una actividad agendada.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="notes" className="text-right pt-2">Notas</Label>
              <Textarea id="notes" value={formData.notes} onChange={handleChange} className="col-span-3" rows={4} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">Tipo</Label>
              <Select value={formData.type} onValueChange={(v) => handleSelectChange('type', v)}>
                <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ACTIVITY_TYPES.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="due_date" className="text-right">Vencimiento</Label>
              <Input id="due_date" type="datetime-local" value={formData.due_date} onChange={handleChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="user_id" className="text-right">Asignado a</Label>
              <Select value={formData.user_id} onValueChange={(v) => handleSelectChange('user_id', v)}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccione un usuario" /></SelectTrigger>
                <SelectContent>
                  {users.map(u => <SelectItem key={u.id} value={u.id}>{u.email}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="client_id" className="text-right">Cliente</Label>
              <Select value={formData.client_id} onValueChange={(v) => handleSelectChange('client_id', v)}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccione un cliente" /></SelectTrigger>
                <SelectContent>
                  {clients.map(client => <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="deal_id" className="text-right">Oportunidad</Label>
              <Select value={formData.deal_id} onValueChange={(v) => handleSelectChange('deal_id', v)} disabled={!formData.client_id}>
                <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccione una oportunidad" /></SelectTrigger>
                <SelectContent>
                  {filteredDeals.map(deal => <SelectItem key={deal.id} value={deal.id}>{deal.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={isSaving}>{isSaving ? 'Creando...' : 'Crear Tarea'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateTaskFromMessageDialog;