import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

const ChatHeader = ({ onBack }) => {
  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm sticky top-0 z-20 flex-shrink-0">
      <div className="max-w-full mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-200">Chat Interno</h1>
        </div>
      </div>
    </header>
  );
};

export default ChatHeader;