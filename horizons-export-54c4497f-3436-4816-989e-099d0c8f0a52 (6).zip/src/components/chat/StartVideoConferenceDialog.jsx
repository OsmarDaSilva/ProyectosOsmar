import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { v4 as uuidv4 } from 'uuid';

const StartVideoConferenceDialog = ({ isOpen, onOpenChange, onCallStarted }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [allUsers, setAllUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchUsers = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('get-users');
      if (error) throw error;
      setAllUsers(data.filter(u => u.id !== user.id));
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo cargar la lista de usuarios.' });
    }
  }, [toast, user.id]);

  useEffect(() => {
    if (isOpen) {
      fetchUsers();
      setSelectedUsers([]);
      setSearchTerm('');
    }
  }, [isOpen, fetchUsers]);

  const handleStartCall = async () => {
    if (selectedUsers.length === 0) {
      toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar al menos un participante.' });
      return;
    }

    setIsLoading(true);
    try {
      const participantIds = [user.id, ...selectedUsers].sort();
      const roomName = `agroinvest-group-${participantIds.join('-').substring(0, 36)}`;
      
      // This is a simplified way to get/create a DM channel.
      // A robust solution would use an RPC function.
      const channelName = `dm-${participantIds.join('-')}`;
      
      let { data: existingChannel, error: findError } = await supabase
        .from('channels')
        .select('id')
        .eq('name', channelName)
        .single();

      if (findError && findError.code !== 'PGRST116') throw findError;

      let channelId;

      if (existingChannel) {
        channelId = existingChannel.id;
      } else {
        const { data: newChannel, error: createError } = await supabase
          .from('channels')
          .insert({
            name: channelName,
            description: 'Conversación privada',
            created_by: user.id,
            is_private: true,
          })
          .select()
          .single();
        
        if (createError) throw createError;
        channelId = newChannel.id;

        const membersToAdd = participantIds.map(id => ({ channel_id: channelId, user_id: id }));
        const { error: membersError } = await supabase.from('channel_members').insert(membersToAdd);
        if (membersError) throw membersError;
      }

      // Send a message to the channel to notify about the call
      const callMessage = {
        channel_id: channelId,
        user_id: user.id,
        content: `${user.email} ha iniciado una videollamada.`,
        attachment_url: `/meet/${roomName}`,
        attachment_name: 'Unirse a la llamada',
        attachment_type: 'call_link',
        user_profile: { email: user.email },
      };

      const { error: messageError } = await supabase.from('messages').insert(callMessage);
      if (messageError) throw messageError;

      toast({ title: '¡Llamada iniciada!', description: 'Se ha notificado a los participantes.' });
      onCallStarted(roomName);
      onOpenChange(false);

    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al iniciar la llamada', description: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUserSelection = (userId) => {
    setSelectedUsers(prev =>
      prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  const filteredUsers = allUsers.filter(u => 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Iniciar Videollamada</DialogTitle>
          <DialogDescription>
            Selecciona los participantes para la llamada.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Input
            placeholder="Buscar usuario..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Label>Participantes</Label>
          <ScrollArea className="h-60 w-full rounded-md border">
            <div className="p-2">
              {filteredUsers.length > 0 ? filteredUsers.map(u => (
                <div key={u.id} className="flex items-center space-x-3 p-2 hover:bg-gray-100 dark:hover:bg-gray-900/50 rounded-md cursor-pointer" onClick={() => handleUserSelection(u.id)}>
                  <Checkbox
                    id={`user-call-${u.id}`}
                    checked={selectedUsers.includes(u.id)}
                    onCheckedChange={() => handleUserSelection(u.id)}
                  />
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{u.email?.[0].toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <label htmlFor={`user-call-${u.id}`} className="flex-1 text-sm font-medium leading-none cursor-pointer">
                    {u.email}
                  </label>
                </div>
              )) : <p className="text-center text-sm text-gray-500 p-4">No se encontraron usuarios.</p>}
            </div>
          </ScrollArea>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleStartCall} disabled={isLoading || selectedUsers.length === 0}>
            {isLoading ? 'Iniciando...' : `Iniciar Llamada (${selectedUsers.length})`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default StartVideoConferenceDialog;