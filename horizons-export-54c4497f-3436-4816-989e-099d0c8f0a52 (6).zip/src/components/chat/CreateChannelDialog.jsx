import React, { useState, useEffect, useCallback } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const CreateChannelDialog = ({ isOpen, onOpenChange, onChannelCreated }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [channelName, setChannelName] = useState('');
  const [description, setDescription] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [users, setUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);

  const fetchUsers = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('get-users');
      if (error) throw error;
      setUsers(data.filter(u => u.id !== user.id)); // Exclude current user
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo cargar la lista de usuarios.' });
    }
  }, [toast, user.id]);

  useEffect(() => {
    if (isOpen) {
      fetchUsers();
    }
  }, [isOpen, fetchUsers]);

  const handleCreateChannel = async () => {
    if (!channelName.trim() || !user) {
      toast({ variant: 'destructive', title: 'Error', description: 'El nombre del canal es obligatorio.' });
      return;
    }

    setIsLoading(true);
    try {
      // 1. Create the channel
      const { data: channelData, error: channelError } = await supabase
        .from('channels')
        .insert({
          name: channelName,
          description,
          created_by: user.id,
          is_private: isPrivate,
        })
        .select()
        .single();

      if (channelError) throw channelError;

      // 2. Add members
      const membersToAdd = [{ channel_id: channelData.id, user_id: user.id }];
      if (isPrivate) {
        selectedUsers.forEach(userId => {
          membersToAdd.push({ channel_id: channelData.id, user_id: userId });
        });
      }

      const { error: membersError } = await supabase.from('channel_members').insert(membersToAdd);
      if (membersError) throw membersError;

      toast({ title: '¡Éxito!', description: `Canal "${channelName}" creado.` });
      onChannelCreated(channelData);
      setChannelName('');
      setDescription('');
      setIsPrivate(false);
      setSelectedUsers([]);
      onOpenChange(false);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al crear canal', description: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUserSelection = (userId) => {
    setSelectedUsers(prev =>
      prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Crear Nuevo Canal</DialogTitle>
          <DialogDescription>
            Crea un nuevo canal de comunicación para tu equipo.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">Nombre</Label>
            <Input
              id="name"
              value={channelName}
              onChange={(e) => setChannelName(e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="description" className="text-right">Descripción</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="col-span-3"
            />
          </div>
          <div className="flex items-center space-x-2 justify-end col-span-4">
            <Label htmlFor="private-switch">¿Canal Privado?</Label>
            <Switch
              id="private-switch"
              checked={isPrivate}
              onCheckedChange={setIsPrivate}
            />
          </div>
          {isPrivate && (
            <div className="col-span-4">
              <Label>Invitar Miembros</Label>
              <ScrollArea className="h-40 w-full rounded-md border p-2 mt-2">
                {users.map(u => (
                  <div key={u.id} className="flex items-center space-x-3 p-2 hover:bg-gray-100 rounded-md">
                     <Checkbox
                        id={`user-${u.id}`}
                        checked={selectedUsers.includes(u.id)}
                        onCheckedChange={() => handleUserSelection(u.id)}
                      />
                    <Avatar className="h-8 w-8">
                       <AvatarFallback>{u.email?.[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <label htmlFor={`user-${u.id}`} className="flex-1 text-sm font-medium leading-none cursor-pointer">
                      {u.email}
                    </label>
                  </div>
                ))}
              </ScrollArea>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleCreateChannel} disabled={isLoading}>
            {isLoading ? 'Creando...' : 'Crear Canal'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CreateChannelDialog;