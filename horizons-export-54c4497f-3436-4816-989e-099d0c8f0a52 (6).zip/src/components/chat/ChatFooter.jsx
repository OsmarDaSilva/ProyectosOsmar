import React, { useState, useRef, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Paperclip, X, FileText, Video } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { useQueryClient } from '@tanstack/react-query';

const ChatFooter = ({ channel, user, channelMembers }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newMessage, setNewMessage] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [attachmentPreview, setAttachmentPreview] = useState(null);
  const [sending, setSending] = useState(false);
  const [showMentions, setShowMentions] = useState(false);
  const [mentionQuery, setMentionQuery] = useState('');
  const inputRef = useRef(null);

  useEffect(() => {
    if (!attachment) {
      setAttachmentPreview(null);
      return;
    }

    const fileType = attachment.type;
    if (fileType.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachmentPreview(reader.result);
      };
      reader.readAsDataURL(attachment);
    } else if (fileType.startsWith('video/')) {
      setAttachmentPreview('video');
    } else {
      setAttachmentPreview('file');
    }
  }, [attachment]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if ((!newMessage.trim() && !attachment) || !user || !channel) return;
    setSending(true);

    const optimisticId = uuidv4();
    const tempMessage = {
      id: optimisticId,
      channel_id: channel.id,
      user_id: user.id,
      content: newMessage.trim(),
      attachment_url: attachmentPreview,
      attachment_name: attachment ? attachment.name : null,
      attachment_type: attachment ? attachment.type : null,
      created_at: new Date().toISOString(),
      user_profile: { email: user.email },
      read_receipts: [],
      isOptimistic: true,
    };

    queryClient.setQueryData(['messages', channel.id], (old) => [...(old || []), tempMessage]);
    setNewMessage('');
    setAttachment(null);

    try {
      let attachment_url = null;
      let attachment_name = null;
      let attachment_type = null;

      if (attachment) {
        const fileExt = attachment.name.split('.').pop();
        const fileName = `${uuidv4()}.${fileExt}`;
        const filePath = `${user.id}/${fileName}`;
        
        const { error: uploadError } = await supabase.storage
          .from('chat_attachments')
          .upload(filePath, attachment, {
            contentType: attachment.type,
            upsert: false
          });

        if (uploadError) throw uploadError;
        
        const { data: urlData } = supabase.storage
            .from('chat_attachments')
            .getPublicUrl(filePath);

        attachment_url = urlData.publicUrl;
        attachment_name = attachment.name;
        attachment_type = attachment.type;
      }

      const mentionedUserIds = [];
      const mentionRegex = /@\[([^\]]+)\]\(([^)]+)\)/g;
      let match;
      while ((match = mentionRegex.exec(tempMessage.content)) !== null) {
        mentionedUserIds.push(match[2]);
      }
      
      const messagePayload = {
        id: optimisticId,
        channel_id: channel.id,
        user_id: user.id,
        content: tempMessage.content,
        attachment_url,
        attachment_name,
        attachment_type,
        mentioned_users: mentionedUserIds.length > 0 ? mentionedUserIds : null,
        user_profile: { email: user.email },
      };

      const { error } = await supabase.from('messages').insert(messagePayload);

      if (error) throw error;

    } catch (error) {
      toast({ variant: 'destructive', title: 'Error al enviar mensaje', description: error.message });
      queryClient.setQueryData(['messages', channel.id], (old) => (old || []).filter(m => m.id !== optimisticId));
    } finally {
      setSending(false);
    }
  };

  const handleAttachmentChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setAttachment(e.target.files[0]);
    }
  };

  const handleInputChange = (e) => {
    const value = e.target.value;
    setNewMessage(value);

    const cursorPos = e.target.selectionStart;
    const textBeforeCursor = value.substring(0, cursorPos);
    const mentionMatch = textBeforeCursor.match(/@(\w*)$/);

    if (mentionMatch) {
      setShowMentions(true);
      setMentionQuery(mentionMatch[1]);
    } else {
      setShowMentions(false);
    }
  };

  const handleMentionSelect = (member) => {
    const currentMessage = newMessage;
    const cursorPos = inputRef.current.selectionStart;
    const textBeforeCursor = currentMessage.substring(0, cursorPos);
    const textAfterCursor = currentMessage.substring(cursorPos);

    const mentionPattern = /@(\w*)$/;
    const newTextBefore = textBeforeCursor.replace(mentionPattern, `@[${member.email}](${member.id}) `);
    
    setNewMessage(newTextBefore + textAfterCursor);
    setShowMentions(false);
    inputRef.current.focus();
  };

  const filteredMembers = (channelMembers || []).filter(member => 
    member.email.toLowerCase().includes(mentionQuery.toLowerCase())
  );

  return (
    <footer className="relative p-4 bg-white dark:bg-gray-900 border-t dark:border-gray-700">
      {showMentions && filteredMembers.length > 0 && (
        <div className="absolute bottom-full left-0 right-0 mb-1 p-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg max-h-48 overflow-y-auto z-10">
          {filteredMembers.map(member => (
            <div
              key={member.id}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md cursor-pointer"
              onClick={() => handleMentionSelect(member)}
            >
              {member.email}
            </div>
          ))}
        </div>
      )}
      {attachment && (
        <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-t-lg flex items-center justify-between">
          <div className="flex items-center gap-2">
            {attachmentPreview === 'video' && <Video className="h-10 w-10 text-gray-500" />}
            {attachmentPreview === 'file' && <FileText className="h-10 w-10 text-gray-500" />}
            {attachmentPreview && attachmentPreview.startsWith('data:image') && <img src={attachmentPreview} alt="preview" className="h-10 w-10 rounded object-cover" />}
            <p className="text-sm truncate">{attachment.name}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setAttachment(null)}><X className="h-4 w-4"/></Button>
        </div>
      )}
      <form onSubmit={handleSendMessage} className="flex items-center gap-2">
        <label htmlFor="file-upload" className="cursor-pointer p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
          <Paperclip className="h-6 w-6 text-gray-500 hover:text-green-600" />
        </label>
        <input id="file-upload" type="file" onChange={handleAttachmentChange} className="hidden" />
        <Input
          ref={inputRef}
          type="text"
          value={newMessage}
          onChange={handleInputChange}
          placeholder="Escribe un mensaje..."
          className="flex-grow bg-gray-100 dark:bg-gray-800 rounded-full px-4 border-transparent focus:border-green-500 focus:ring-green-500"
          disabled={sending}
        />
        <Button type="submit" disabled={sending || (!newMessage.trim() && !attachment)} className="rounded-full w-10 h-10 p-0">
          <Send className="h-5 w-5" />
        </Button>
      </form>
    </footer>
  );
};

export default ChatFooter;