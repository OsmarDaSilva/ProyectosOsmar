import React, { useEffect, useRef, useCallback, useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { FileText, Video, ListTodo, Check, CheckCheck, Download, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format, isToday, isYesterday } from 'date-fns';
import { es } from 'date-fns/locale';
import { useQuery } from '@tanstack/react-query';
import LoadingScreen from '@/components/LoadingScreen';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from '@/components/ui/use-toast';

const fetchMessages = async (channelId) => {
  if (!channelId) return [];
  const { data, error } = await supabase
    .from('messages')
    .select('*, read_receipts(user_id, read_at)')
    .eq('channel_id', channelId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data;
};

const MessageArea = ({ channel, user, channelMembers, onStartTaskCreation }) => {
  const messagesEndRef = useRef(null);
  const { toast } = useToast();

  const { data: messages = [], isLoading, isError, error } = useQuery({
    queryKey: ['messages', channel.id],
    queryFn: () => fetchMessages(channel.id),
    enabled: !!channel.id,
    staleTime: 5 * 60 * 1000,
  });

  const handleDownload = async (msg) => {
    if (!msg.attachment_url) {
      toast({ variant: 'destructive', title: 'Error', description: 'No hay archivo para descargar.' });
      return;
    }

    const urlParts = msg.attachment_url.split('/chat_attachments/');
    if (urlParts.length < 2) {
      toast({ variant: 'destructive', title: 'Error de descarga', description: 'URL de archivo inválida.' });
      return;
    }
    const filePath = urlParts[1];

    try {
      const { data, error } = await supabase.storage
        .from('chat_attachments')
        .download(filePath);

      if (error) throw error;

      const blob = data;
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = msg.attachment_name || 'download';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);

    } catch (error) {
      toast({ variant: 'destructive', title: 'No se pudo descargar', description: 'Asegúrese de tener permisos y que el archivo exista.' });
    }
  };

  const VideoPlayer = ({ msg }) => {
    const [videoSrc, setVideoSrc] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const { toast } = useToast();

    useEffect(() => {
      let objectUrl;

      const loadVideo = async () => {
        if (!msg.attachment_url) {
          setIsLoading(false);
          return;
        }

        const urlParts = msg.attachment_url.split('/chat_attachments/');
        if (urlParts.length < 2) {
          toast({ variant: 'destructive', title: 'Error de video', description: 'URL de video inválida.' });
          setIsLoading(false);
          return;
        }
        const filePath = urlParts[1];

        try {
          const { data, error } = await supabase.storage
            .from('chat_attachments')
            .download(filePath);

          if (error) throw error;

          const blob = data;
          objectUrl = URL.createObjectURL(blob);
          setVideoSrc(objectUrl);
        } catch (error) {
          console.error("Video load error:", error);
          toast({ variant: 'destructive', title: 'No se pudo cargar el video', description: 'Asegúrese de tener permisos y que el archivo exista.' });
        } finally {
          setIsLoading(false);
        }
      };

      loadVideo();

      return () => {
        if (objectUrl) {
          URL.revokeObjectURL(objectUrl);
        }
      };
    }, [msg.attachment_url, toast]);

    if (isLoading) {
      return (
        <div className="mt-2 rounded-lg max-w-xs h-48 flex flex-col items-center justify-center bg-gray-200 dark:bg-gray-700">
          <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">Cargando video...</p>
        </div>
      );
    }

    if (!videoSrc) {
      return (
        <div className="mt-2 rounded-lg max-w-xs h-48 flex flex-col items-center justify-center bg-gray-200 dark:bg-gray-700">
          <p className="text-sm text-red-500">Error al cargar video.</p>
          <Button variant="outline" size="sm" onClick={() => handleDownload(msg)} className="mt-2">
            <Download className="h-4 w-4 mr-2" />
            Intentar Descargar
          </Button>
        </div>
      );
    }

    return (
      <div className="mt-2 space-y-2">
        <video controls className="rounded-lg max-w-xs">
          <source src={videoSrc} type={msg.attachment_type} />
          Tu navegador no soporta la etiqueta de video.
        </video>
        <Button variant="outline" size="sm" onClick={() => handleDownload(msg)} className="w-full">
          <Download className="h-4 w-4 mr-2" />
          Descargar Video
        </Button>
      </div>
    );
  };

  const AttachmentPreview = ({ msg }) => {
    const isImage = msg.attachment_type?.startsWith('image/');
    const isVideo = msg.attachment_type?.startsWith('video/');

    if (isImage) {
      return (
        <Dialog>
          <DialogTrigger asChild>
            <img src={msg.attachment_url} alt={msg.attachment_name} className="mt-2 rounded-lg max-w-xs max-h-64 cursor-pointer object-cover" />
          </DialogTrigger>
          <DialogContent className="max-w-4xl h-auto">
            <DialogHeader>
              <DialogTitle>{msg.attachment_name}</DialogTitle>
            </DialogHeader>
            <div className="flex justify-center items-center">
              <img src={msg.attachment_url} alt={msg.attachment_name} className="max-w-full max-h-[80vh] object-contain" />
            </div>
          </DialogContent>
        </Dialog>
      );
    }

    if (isVideo) {
      return <VideoPlayer msg={msg} />;
    }

    return (
      <button onClick={() => handleDownload(msg)} className="mt-2 flex items-center gap-2 text-blue-600 hover:underline bg-gray-100 dark:bg-gray-600 p-2 rounded-lg w-full text-left">
        <FileText className="h-6 w-6"/>
        <span className="flex-1 truncate">{msg.attachment_name}</span>
        <Download className="h-5 w-5" />
      </button>
    );
  };

  const markAsRead = useCallback(async (channelId) => {
    if (!user || !channelId) return;
    const { error } = await supabase.rpc('mark_channel_as_read', { p_channel_id: channelId });
    if (error) console.error("Failed to mark channel as read", error);
  }, [user]);

  useEffect(() => {
    if (channel) {
      markAsRead(channel.id);
    }
  }, [channel, messages, markAsRead]);

  useEffect(() => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }, [messages]);

  const renderMessageContent = (content) => {
    if (!content) return null;
    const mentionRegex = /@\[([^\]]+)\]\(([^)]+)\)/g;
    const parts = content.split(mentionRegex);
    
    return parts.map((part, index) => {
      if (index % 3 === 1) {
        return <strong key={index} className="text-blue-500 font-semibold">@{part}</strong>;
      }
      if (index % 3 === 2) return null;
      return part;
    }).filter(Boolean);
  };

  const handleJoinCall = (url) => window.open(url, '_blank');

  const getReadStatus = (message) => {
    if (message.user_id !== user.id || message.isOptimistic) return null;
    
    const otherMembers = channelMembers.filter(m => m.id !== user.id);
    if (otherMembers.length === 0) return <Check className="h-4 w-4 text-gray-500" />;

    const receipts = message.read_receipts || [];
    const readByAll = otherMembers.every(member => 
      receipts.some(receipt => receipt.user_id === member.id)
    );

    if (readByAll) return <CheckCheck className="h-4 w-4 text-blue-500" />;
    return <Check className="h-4 w-4 text-gray-500" />;
  };

  const formatMessageTime = (dateString) => format(new Date(dateString), 'p', { locale: es });

  const renderDateSeparator = (message, prevMessage) => {
    if (!prevMessage) {
      const date = new Date(message.created_at);
      let dateText = isToday(date) ? 'Hoy' : isYesterday(date) ? 'Ayer' : format(date, 'PPPP', { locale: es });
      return <DateSeparator text={dateText} />;
    }

    const currentDate = new Date(message.created_at);
    const prevDate = new Date(prevMessage.created_at);

    if (currentDate.toDateString() !== prevDate.toDateString()) {
      let dateText = isToday(currentDate) ? 'Hoy' : isYesterday(currentDate) ? 'Ayer' : format(currentDate, 'PPPP', { locale: es });
      return <DateSeparator text={dateText} />;
    }
    return null;
  };

  const DateSeparator = ({ text }) => (
    <div className="flex justify-center my-4">
      <span className="bg-gray-300 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs font-semibold px-3 py-1 rounded-full">{text}</span>
    </div>
  );

  if (isLoading) return <LoadingScreen message="Cargando mensajes..." />;
  if (isError) return <div className="flex-grow p-4 flex items-center justify-center"><p className="text-red-500">Error: {error.message}</p></div>;

  return (
    <ScrollArea className="flex-grow p-4 bg-gray-200 dark:bg-gray-800">
      <div className="px-4">
        {messages.map((msg, index) => (
          <React.Fragment key={msg.id}>
            {renderDateSeparator(msg, messages[index - 1])}
            <div className={`group flex items-end gap-2 my-1 ${msg.user_id === user.id ? 'justify-end' : 'justify-start'}`}>
              {msg.user_id !== user.id && (
                <Avatar className="h-8 w-8 mb-1">
                  <AvatarFallback>{msg.user_profile?.email?.[0].toUpperCase()}</AvatarFallback>
                </Avatar>
              )}
              <div className={`relative max-w-lg p-2 px-3 rounded-xl shadow-md ${msg.user_id === user.id ? 'bg-green-200 dark:bg-green-800 rounded-br-none' : 'bg-white dark:bg-gray-700 rounded-bl-none'}`}>
                {msg.user_id !== user.id && <p className="text-xs font-bold text-green-600 mb-1">{msg.user_profile?.email}</p>}
                
                {msg.content && <div className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap break-words">{renderMessageContent(msg.content)}</div>}
                
                {msg.attachment_type === 'call_link' ? (
                  <Button className="mt-2 w-full" onClick={() => handleJoinCall(msg.attachment_url)}>
                    <Video className="h-4 w-4 mr-2" />
                    {msg.attachment_name}
                  </Button>
                ) : msg.attachment_url && (
                  <AttachmentPreview msg={msg} />
                )}
                <div className="flex items-center justify-end gap-2 mt-1">
                  <span className="text-xs text-gray-500 dark:text-gray-400">{formatMessageTime(msg.created_at)}</span>
                  {getReadStatus(msg)}
                </div>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity self-center">
                <Button variant="ghost" size="icon" onClick={() => onStartTaskCreation(msg)}>
                  <ListTodo className="h-4 w-4 text-gray-500" />
                </Button>
              </div>
            </div>
          </React.Fragment>
        ))}
      </div>
      <div ref={messagesEndRef} />
    </ScrollArea>
  );
};

export default MessageArea;