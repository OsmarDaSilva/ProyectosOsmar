import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Trash2, Users, Building } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const ChannelList = ({ channels, selectedChannel, onSelectChannel, onDeleteChannel, currentUser, unreadChannels }) => {
  return (
    <ScrollArea className="flex-grow">
      <ul>
        {channels.map(channel => (
          <li key={channel.id} className="group">
            <button
              onClick={() => onSelectChannel(channel)}
              className={`w-full text-left p-3 flex justify-between items-center hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-150 ${selectedChannel?.id === channel.id ? 'bg-green-50 dark:bg-green-900/30' : ''}`}
            >
              <div className="flex items-center gap-3 flex-1 overflow-hidden">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-gray-200 dark:bg-gray-700">
                    {channel.client ? <Building className="h-5 w-5" /> : <Users className="h-5 w-5" />}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 overflow-hidden">
                  <p className={`truncate font-semibold ${selectedChannel?.id === channel.id ? 'text-green-700 dark:text-green-300' : 'text-gray-800 dark:text-gray-200'}`}>
                    {channel.client ? channel.client.name : channel.name}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{channel.description}</p>
                </div>
                {unreadChannels.has(channel.id) && (
                  <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
                )}
              </div>
              {channel.created_by === currentUser.id && channel.name !== 'General' && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteChannel(channel);
                  }}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              )}
            </button>
          </li>
        ))}
      </ul>
    </ScrollArea>
  );
};

export default ChannelList;