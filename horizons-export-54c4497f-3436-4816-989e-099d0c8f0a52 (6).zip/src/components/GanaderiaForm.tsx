import React, { useRef, FC } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useGanaderiaCalculations } from '@/hooks/useGanaderiaCalculations';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Printer, Info } from 'lucide-react';
import { exportToPdf } from '@/lib/pdfUtils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { GanaderiaData, ProjectData } from '@/types/project';

interface FormattedInputProps {
  label: string;
  value: string;
  unit?: string;
  className?: string;
}

interface DataInputProps {
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement> | string) => void;
  unit?: string;
  isSelect?: boolean;
  options?: string[];
}

interface ModelSectionProps {
  title: string;
  data: any;
  calculations: any;
  onChange: (section: string, field: string, value: string) => void;
  section: string;
  headerClass: string;
  formatDateForInput: (dateString: string) => string;
}

interface GanaderiaFormProps {
  initialData: GanaderiaData;
  onUpdate: (data: GanaderiaData) => void;
  projectData: ProjectData;
}

const formatCurrency = (value: number, decimals = 2): string => {
  const num = Number(value) || 0;
  const options = {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  };
  return new Intl.NumberFormat('es-PY', options).format(num);
};

const formatPercentage = (value: number): string => {
  const num = Number(value) || 0;
  return `${(num * 100).toFixed(2)}%`.replace('.', ',');
};

const FormattedInput: FC<FormattedInputProps> = ({ label, value, unit, className }) => (
    <div className="grid grid-cols-2 items-center">
        <Label className="text-sm">{label}</Label>
        <div className="flex items-center space-x-2">
            <Input disabled value={value} className={cn("h-8 text-right text-sm font-semibold border-none bg-transparent shadow-none px-1", className)} />
            {unit && <span className="text-xs text-gray-500 w-8 text-left">{unit}</span>}
        </div>
    </div>
);

const DataInput: FC<DataInputProps> = ({ label, value, onChange, unit, isSelect = false, options = [] }) => {
    return (
        <div className="grid grid-cols-2 items-center">
            <Label className="text-sm">{label}</Label>
            <div className="flex items-center space-x-2">
                {isSelect ? (
                    <Select onValueChange={(val) => onChange(val)} value={value}>
                        <SelectTrigger className="h-8 text-right text-sm">
                            <SelectValue placeholder="Seleccione tipo" />
                        </SelectTrigger>
                        <SelectContent>
                            {options.map(option => (
                                <SelectItem key={option} value={option}>
                                    {option}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                ) : (
                    <Input
                        type={'text'}
                        value={value}
                        onChange={onChange as (e: React.ChangeEvent<HTMLInputElement>) => void}
                        className="h-8 text-right text-sm"
                    />
                )}
                 {unit && <span className="text-xs text-gray-500 w-8 text-left">{unit}</span>}
            </div>
        </div>
    );
};

const ModelSection: FC<ModelSectionProps> = ({ title, data, calculations, onChange, section, headerClass, formatDateForInput }) => (
  <Card>
    <CardHeader className={cn("p-3", headerClass)}>
      <CardTitle className="text-base text-center font-bold text-white">{title}</CardTitle>
    </CardHeader>
    <CardContent className="p-4 space-y-1">
        <div className="grid grid-cols-3 items-center">
            <Label className="text-sm col-span-1">Cantidad cab/ha/rebaño?</Label>
            <Input type="text" value={data.cantidad} onChange={(e) => onChange(section, 'cantidad', e.target.value)} className="h-8 text-right text-sm col-span-1"/>
            <FormattedInput value={formatCurrency(calculations.totalCabezas, 0)} unit="cab" label="" />
        </div>
        <div className="grid grid-cols-3 items-center">
            <Label className="text-sm col-span-1">Fecha Entrada/Salida:</Label>
            <Input type="date" value={formatDateForInput(data.fechaEntrada)} onChange={(e) => onChange(section, 'fechaEntrada', e.target.value)} className="h-8 text-center text-sm" />
            <Input type="date" value={formatDateForInput(data.fechaSalida)} onChange={(e) => onChange(section, 'fechaSalida', e.target.value)} className="h-8 text-center text-sm" />
        </div>
        <div className="grid grid-cols-2 items-center">
          <FormattedInput label="Días duración del engorde/año" value={formatCurrency(calculations.diasEngorde,0)} unit="día" />
          <FormattedInput label="" value={formatCurrency(calculations.duracionAnos, 1)} unit="año" />
        </div>
        <div className="grid grid-cols-3 items-center">
            <Label className="text-sm col-span-1">Flete de entrada/cab:</Label>
            <Input value={data.fleteEntrada} onChange={(e) => onChange(section, 'fleteEntrada', e.target.value)} className="h-8 text-right text-sm"/>
            <FormattedInput value={formatCurrency(calculations.fleteTotal)} unit="U$" label="" />
        </div>
         <div className="grid grid-cols-3 items-center">
            <Label className="text-sm col-span-1">Comisión vendedor:</Label>
            <Input value={data.comisionVendedor} onChange={(e) => onChange(section, 'comisionVendedor', e.target.value)} className="h-8 text-right text-sm"/>
            <FormattedInput value={formatCurrency(calculations.comisionTotal)} unit="U$" label="" />
        </div>
      <FormattedInput label="Costo de compra/cab:" value={formatCurrency(calculations.costoCompraAnimal)} unit="U$" />
      <FormattedInput label="Total de intereses del período" value={formatCurrency(calculations.totalInteresesPeriodo)} unit="U$" />
      <FormattedInput label="Valor total del rebaño ganadero" value={formatCurrency(calculations.valorRebano)} unit="U$" className="font-bold"/>
      
      <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Costos de suplementación/cab/año?</Label>
        <Input value={data.costoSuplementacion} onChange={(e) => onChange(section, 'costoSuplementacion', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalSuplementacion)} unit="U$" label="" />
      </div>
      <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Costos administrativos/cab/ha?</Label>
        <Input value={data.costoAdministrativo} onChange={(e) => onChange(section, 'costoAdministrativo', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalAdministrativo)} unit="U$" label="" />
      </div>
       <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Costos de guía y vacunación/cab/ha?</Label>
        <Input value={data.costoVacunacion} onChange={(e) => onChange(section, 'costoVacunacion', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalVacunacion)} unit="U$" label="" />
      </div>
       <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Costos de fertilización/ha?</Label>
        <Input value={data.costoFertilizacion} onChange={(e) => onChange(section, 'costoFertilizacion', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalFertilizacion)} unit="U$" label="" />
      </div>
       <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Costos de energía/anual/ha?</Label>
        <Input value={data.costoEnergia} onChange={(e) => onChange(section, 'costoEnergia', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalEnergia)} unit="U$" label="" />
      </div>
       <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Costos de manutención/ha?</Label>
        <Input value={data.costoManutencion} onChange={(e) => onChange(section, 'costoManutencion', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalManutencion)} unit="U$" label="" />
      </div>
      <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Combustible gasoil/ha?</Label>
        <Input value={data.combustibleGasoil} onChange={(e) => onChange(section, 'combustibleGasoil', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalCombustible)} unit="U$" label="" />
      </div>
      <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Otros costos varios/ha?</Label>
        <Input value={data.otrosCostos} onChange={(e) => onChange(section, 'otrosCostos', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalOtrosCostos)} unit="U$" label="" />
      </div>
      <div className="grid grid-cols-4 items-center">
        <Label className="text-sm col-span-1">Mortandad animal</Label>
        <Input value={data.mortandad} onChange={(e) => onChange(section, 'mortandad', e.target.value)} className="h-8 text-right text-sm col-span-1" />
        <FormattedInput value={formatCurrency(calculations.cabezasMuertas, 2)} unit="cab" label="" />
        <FormattedInput value={formatCurrency(calculations.totalMortandad)} unit="U$" label="" />
      </div>

      <FormattedInput label="Intereses generados durante el ciclo/costo operativo" value={formatCurrency(calculations.interesCostoOperativo)} unit="U$" />
      <FormattedInput label="Total de costos del área" value={formatCurrency(calculations.totalCostosArea)} unit="U$" className="font-bold"/>
      <FormattedInput label="Costo de producción por animal:" value={formatCurrency(calculations.costoProduccionAnimal)} unit="U$" />
      <FormattedInput label="Total de compra animales + costos operativos:" value={formatCurrency(calculations.totalCompraCostosOp)} unit="U$" className="font-bold"/>
      <FormattedInput label="Costo total por animal (compra + costos operativos)" value={formatCurrency(calculations.costoTotalAnimal)} unit="U$" />
      <FormattedInput label="Valor de venta del rebaño" value={formatCurrency(calculations.valorVentaRebano)} unit="U$" className="font-bold text-green-700"/>
      <FormattedInput label="Margen Bruto de ganancia del rebaño" value={formatCurrency(calculations.margenNeto)} unit="U$" className="font-bold text-blue-700"/>
      
      <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Impuestos gubernamentales IRAGRO</Label>
        <Input value={data.impuestoIragro} onChange={(e) => onChange(section, 'impuestoIragro', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalIragro)} unit="U$" label="" />
      </div>
      <div className="grid grid-cols-3 items-center">
        <Label className="text-sm">Impuestos gubernamentales IRP</Label>
        <Input value={data.impuestoIrp} onChange={(e) => onChange(section, 'impuestoIrp', e.target.value)} className="h-8 text-right text-sm" />
        <FormattedInput value={formatCurrency(calculations.totalIrp)} unit="U$" label="" />
      </div>

      <FormattedInput label="Ganancia final del rebaño" value={formatCurrency(calculations.gananciaFinalRebano)} unit="U$" className="font-bold text-lg text-green-800"/>
      <FormattedInput label="Ganancia final por animal" value={formatCurrency(calculations.gananciaFinalAnimal)} unit="U$" />
      <FormattedInput label="Ganancia final por hectárea" value={formatCurrency(calculations.gananciaFinalHectarea)} unit="U$" />
    </CardContent>
  </Card>
);

const GanaderiaForm: FC<GanaderiaFormProps> = ({ initialData, onUpdate, projectData }) => {
  const { formData, setFormData, calculations } = useGanaderiaCalculations(initialData);
  const printableRef = useRef<HTMLDivElement>(null);
  const footerText = "Generado por AGRO invest / Co$to Rural - Herramienta del Grupo LatamNegocios / Irrigar S.A. - Autor Osmar Da Silva";

  const animalTypeOptions = [
    "Novillo Toro",
    "Novillo Capon",
    "Vaquilla",
    "Vaca de cria",
    "Vaca descarte"
  ];

  const handlePrint = () => {
    const fileName = `datos_ganaderia_${projectData?.projectName?.replace(/\s+/g, '_') || 'proyecto'}.pdf`;
    if (printableRef.current) {
      exportToPdf(printableRef.current, fileName, 'portrait', true, footerText);
    }
  };

  const handleInputChange = (section: string, field: string, value: string) => {
    const newFormData = {
      ...formData,
      [section]: { ...formData[section], [field]: value }
    };
    setFormData(newFormData);
    if (onUpdate) {
      onUpdate(newFormData);
    }
  };

  const handleToggleEnabled = () => {
    const newFormData = {
      ...formData,
      isEnabled: !formData.isEnabled
    };
    setFormData(newFormData);
    if (onUpdate) {
      onUpdate(newFormData);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <div ref={printableRef} className="p-2">
        <Card>
          <CardHeader className="bg-gray-800 text-white p-3 flex flex-row items-center justify-between">
            <CardTitle className="text-lg text-center">Datos de Ganadería: {projectData?.projectName || ''}</CardTitle>
            <div className="flex items-center space-x-2">
              <Label htmlFor="ganaderia-enabled" className="text-white">Habilitar Ganadería</Label>
              <Switch
                id="ganaderia-enabled"
                checked={formData.isEnabled}
                onCheckedChange={handleToggleEnabled}
              />
            </div>
          </CardHeader>
          <CardContent className={cn("p-6 transition-opacity", !formData.isEnabled && "opacity-50 pointer-events-none")}>
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-xl text-gray-700">PARÁMETROS</h3>
                <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700">
                  <Printer className="mr-2 h-4 w-4" />
                  Exportar a PDF
                </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-2 items-start">
              <div className="space-y-2">
                <DataInput label="Tipo de animal:" value={formData.params.tipoAnimal} onChange={(value) => handleInputChange('params', 'tipoAnimal', value as string)} isSelect options={animalTypeOptions} />
                <DataInput label="Peso Vivo Entrada/Compra" value={formData.params.pesoVivoEntrada} onChange={(e) => handleInputChange('params', 'pesoVivoEntrada', (e.target as HTMLInputElement).value)} />
                <DataInput label="Precio de compra/kg/peso vivo?" value={formData.params.precioCompraKgVivo} onChange={(e) => handleInputChange('params', 'precioCompraKgVivo', (e.target as HTMLInputElement).value)} />
                <DataInput label="Hectáreas del proyecto" value={formData.params.hectareas} onChange={(e) => handleInputChange('params', 'hectareas', (e.target as HTMLInputElement).value)} />
                <div className="flex items-center justify-between p-1 bg-green-100 rounded-md mt-2">
                  <Label className="text-sm">Engorde prom./día</Label>
                  <span className="text-sm font-bold text-green-800">{formatCurrency(calculations.tradicional.engordeDiario, 0)} g/día</span>
                </div>
              </div>
              <div className="space-y-2">
                <DataInput label="Peso Vivo Salida/Venta" value={formData.params.pesoVivoSalida} onChange={(e) => handleInputChange('params', 'pesoVivoSalida', (e.target as HTMLInputElement).value)} />
                <DataInput label="Desbaste por traslado (%)" value={formData.params.desbaste} onChange={(e) => handleInputChange('params', 'desbaste', (e.target as HTMLInputElement).value)} />
                <DataInput label="Precio de venta/kg al gancho?" value={formData.params.precioVentaKgGancho} onChange={(e) => handleInputChange('params', 'precioVentaKgGancho', (e.target as HTMLInputElement).value)} />
                <DataInput label="Rendimiento carcasa/an:" value={formData.params.rendimientoCarcaza} onChange={(e) => handleInputChange('params', 'rendimientoCarcaza', (e.target as HTMLInputElement).value)} />
                <div className="grid grid-cols-2 gap-2">
                    <DataInput label="Tasa de interés anual" value={formData.params.tasaInteresAnual} onChange={(e) => handleInputChange('params', 'tasaInteresAnual', (e.target as HTMLInputElement).value)} />
                    <FormattedInput label="Tasa de interés mensual" value={calculations.params.tasaInteresMensual ? formatPercentage(calculations.params.tasaInteresMensual) : '0,00%'} />
                </div>
              </div>
              <div className="space-y-2">
                <FormattedInput label="Kilos Engordados" value={formatCurrency(calculations.params.kilosEngordado, 2)} />
                <FormattedInput label="Peso final con desbaste" value={formatCurrency(calculations.params.pesoFinalDesbaste, 2)} unit="kg" />
                <FormattedInput label="Precio de venta por kg/peso vivo" value={formatCurrency(calculations.params.precioVentaKgVivo)} />
                <FormattedInput label="Kg de carne al gancho:" value={formatCurrency(calculations.params.kgCarneGancho, 2)} />
                 <div className="flex items-center justify-between p-1 bg-blue-100 rounded-md mt-6">
                  <Label className="text-sm">Engorde promedio diario:</Label>
                  <span className="text-sm font-bold text-blue-800">{formatCurrency(calculations.intensivo.engordeDiario, 0)} g/día</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className={cn("grid grid-cols-1 lg:grid-cols-2 gap-6 transition-opacity", !formData.isEnabled && "opacity-50 pointer-events-none")}>
          <ModelSection title="MODELO TRADICIONAL NORMAL" data={formData.tradicional} calculations={calculations.tradicional} onChange={handleInputChange} section="tradicional" headerClass="bg-orange-500" formatDateForInput={calculations.formatDateForInput} />
          <ModelSection title="MODELO INTENSIVO CON SISTEMA DE RIEGO" data={formData.intensivo} calculations={calculations.intensivo} onChange={handleInputChange} section="intensivo" headerClass="bg-blue-500" formatDateForInput={calculations.formatDateForInput} />
        </div>

         <Card className={cn("transition-opacity mt-6", !formData.isEnabled && "opacity-50 pointer-events-none")}>
          <CardHeader className="p-3 bg-gray-100 border-b">
            <CardTitle className="text-base text-center font-semibold">Diferencias y comparativos</CardTitle>
          </CardHeader>
          <CardContent className="p-4 grid grid-cols-3 gap-4 text-center">
              <div>
                  <div className="flex justify-center items-center gap-2">
                    <p className="text-sm text-gray-600">Animales A+ con riego</p>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="max-w-xs">Diferencia en la cantidad total de animales entre el modelo intensivo y el tradicional.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(calculations.comparativos.animales, 0)}</p>
                  <p className="font-bold text-lg text-green-600">{formatPercentage(calculations.comparativos.animalesPct)}</p>
              </div>
              <div>
                  <div className="flex justify-center items-center gap-2">
                     <p className="text-sm text-gray-600">Margen por ha A+ con riego</p>
                     <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">Diferencia en la ganancia final por hectárea entre el modelo intensivo y el tradicional.</p>
                          </TooltipContent>
                        </Tooltip>
                     </TooltipProvider>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(calculations.comparativos.margenPorHa)}</p>
                  <p className="font-bold text-lg text-green-600">{isFinite(calculations.comparativos.margenPorHaPct) ? formatPercentage(calculations.comparativos.margenPorHaPct) : 'N/A'}</p>
              </div>
              <div>
                  <div className="flex justify-center items-center gap-2">
                    <p className="text-sm text-gray-600">Tiempo A- con riego</p>
                    <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-3 w-3 text-gray-400 cursor-pointer" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">Ahorro de tiempo en años y porcentaje que se logra con el modelo intensivo vs. el tradicional, basado en las fechas de entrada/salida.</p>
                          </TooltipContent>
                        </Tooltip>
                    </TooltipProvider>
                  </div>
                  <p className="font-bold text-lg">{formatCurrency(calculations.comparativos.tiempo, 2)} años</p>
                  <p className={`font-bold text-lg ${calculations.comparativos.tiempoPct >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatPercentage(calculations.comparativos.tiempoPct)}</p>
              </div>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
};

export default GanaderiaForm;