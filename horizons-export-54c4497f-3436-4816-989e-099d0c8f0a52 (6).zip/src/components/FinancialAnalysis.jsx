import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Printer, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useReactToPrint } from 'react-to-print';
import CashFlowAnalysis from '@/components/CashFlowAnalysis';
import ComparisonAnalysis from '@/components/ComparisonAnalysis';
import { useTirVanRoyPayback } from '@/hooks/useTirVanRoyPayback';
import { useProjectData } from '@/contexts/ProjectDataContext';
import { useTranslation } from 'react-i18next';

const FinancialAnalysis = () => {
  const { t } = useTranslation(['viability', 'common']);
  const { projectData, agricultureData, ganaderiaData } = useProjectData();
  const calculations = useTirVanRoyPayback({ projectData, agricultureData, ganaderiaData });
  const printableRef = useRef();
  
  const handlePrint = useReactToPrint({
    content: () => printableRef.current,
    documentTitle: `${t('financialAnalysis.pdfFilename')}_${projectData?.projectName?.replace(/\s+/g, '_') || 'proyecto'}.pdf`,
    pageStyle: `@page { size: auto; margin: 12mm; } @media print { body { -webkit-print-color-adjust: exact; } .no-print { display: none; } .print-page-break { page-break-after: always; } }`
  });

  if (!calculations || calculations.error) {
    return (
      <div className="text-center py-20 bg-white/50 rounded-lg shadow-inner">
        <AlertTriangle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800">{t('financialAnalysis.insufficientDataTitle')}</h2>
        <p className="text-gray-600 text-lg mt-2">
          {calculations?.error || t('financialAnalysis.insufficientDataSubtitle')}
        </p>
        <p className="text-gray-500 mt-1">
          {t('financialAnalysis.insufficientDataSuggestion')}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center no-print">
        <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-gray-800">{t('financialAnalysis.title')}</h1>
            <div className="flex items-center bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                <CheckCircle className="w-4 h-4 mr-2" />
                <span>{t('validated', { ns: 'common' })}</span>
            </div>
        </div>
        <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700">
          <Printer className="mr-2 h-4 w-4" />
          {t('print', { ns: 'common' })}
        </Button>
      </div>
      <div ref={printableRef} className="p-0 sm:p-2 print-area">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <CashFlowAnalysis calculations={calculations} />
        </motion.div>

        <div className="print-page-break"></div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <ComparisonAnalysis calculations={calculations} />
        </motion.div>
      </div>
    </div>
  );
};

export default FinancialAnalysis;