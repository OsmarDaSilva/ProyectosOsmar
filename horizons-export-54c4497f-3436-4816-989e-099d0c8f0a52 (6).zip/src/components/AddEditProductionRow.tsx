import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { TableCell, TableRow } from '@/components/ui/table';
import { Save, XCircle, Edit, Trash2 } from 'lucide-react';
import { ProductionData } from '@/types/production';

interface AddEditProductionRowProps {
  row: ProductionData;
  onSave: (row: ProductionData) => void;
  onCancel: () => void;
  onEdit: (row: ProductionData) => void;
  onDelete: (id: string) => void;
  isEditing?: boolean;
}

export const AddEditProductionRow: React.FC<AddEditProductionRowProps> = ({ row, onSave, onCancel, onEdit, onDelete, isEditing = false }) => {
    const [localRow, setLocalRow] = useState<ProductionData>(row);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>, field: keyof ProductionData) => {
        let value: string | number | null = e.target.value;
        if (field === 'year') {
            value = parseInt(value, 10) || null; // Ensure year is an integer or null
        }
        setLocalRow({ ...localRow, [field]: value });
    };
    
    const renderCell = (field: keyof ProductionData) => (
        <TableCell>
            <Input
                type={field === 'year' ? 'number' : (typeof localRow[field] === 'number' ? 'number' : 'text')}
                value={localRow[field] as string | number}
                onChange={(e) => handleInputChange(e, field)}
                className="h-8 min-w-[100px]"
            />
        </TableCell>
    );
    
    const getNumericValue = (value: any): number => parseFloat(String(value || '0').replace(',', '.')) || 0;

    const calculateNormalCost = (r: ProductionData): number => {
        return getNumericValue(r.input_cost_ha) + getNumericValue(r.machinery_cost_ha) + getNumericValue(r.freight_cost_ha);
    };

    const calculateFinalCost = (r: ProductionData): number => {
        const normalCost = calculateNormalCost(r);
        const otherCosts = getNumericValue(r.land_rent_ha) + getNumericValue(r.electrical_energy_cost_ha) + getNumericValue(r.maintenance_repair_cost_ha);
        return normalCost + otherCosts;
    };

    const formatCurrency = (value: number | undefined): string => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value || 0);

    if (!isEditing) {
        return (
            <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => onEdit(row)}><Edit className="h-4 w-4" /></Button>
                <Button size="sm" variant="destructive" onClick={() => onDelete(row.id)}><Trash2 className="h-4 w-4" /></Button>
            </div>
        )
    }
    
    return (
        <TableRow className="bg-green-50">
            {renderCell('country')}
            {renderCell('department_province')}
            {renderCell('city_locality')}
            {renderCell('year')}
            {renderCell('crop')}
            {renderCell('production_purpose')}
            {renderCell('sowing_season')}
            {renderCell('cultivation_method')}
            {renderCell('yield_ton_ha')}
            {renderCell('input_cost_ha')}
            {renderCell('machinery_cost_ha')}
            {renderCell('freight_cost_ha')}
            <TableCell className="font-semibold text-blue-700">{formatCurrency(calculateNormalCost(localRow))}</TableCell>
            {renderCell('land_rent_ha')}
            {renderCell('electrical_energy_cost_ha')}
            {renderCell('maintenance_repair_cost_ha')}
            <TableCell className="font-bold text-green-700">{formatCurrency(calculateFinalCost(localRow))}</TableCell>
            <TableCell className="sticky right-0 bg-green-50 z-10">
                <div className="flex gap-2">
                    <Button size="sm" onClick={() => onSave(localRow)}><Save className="h-4 w-4" /></Button>
                    <Button size="sm" variant="outline" onClick={onCancel}><XCircle className="h-4 w-4" /></Button>
                </div>
            </TableCell>
        </TableRow>
    );
};