import React, { useState, useEffect, useMemo } from 'react';
    import { Input } from '@/components/ui/input';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';
    import { Database } from 'lucide-react';
    import { calculateSafra, initialSafraData } from '@/utils/agricultureCalculations';
    import LoadDataModal from '@/components/LoadDataModal';
    import { useToast } from "@/components/ui/use-toast";
    import { cn } from "@/lib/utils";
    import { useTranslation } from 'react-i18next';

    const SafraSection = ({ title, safraData, onUpdate, safraIndex, type }) => {
      const { t } = useTranslation(['simulations', 'common']);
      const [localSafraData, setLocalSafraData] = useState(safraData || initialSafraData);
      const [isModalOpen, setIsModalOpen] = useState(false);
      const { toast } = useToast();

      useEffect(() => {
        setLocalSafraData(safraData || initialSafraData);
      }, [safraData]);

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        const updatedSafra = { ...localSafraData, [name]: value };
        setLocalSafraData(updatedSafra);
        onUpdate(updatedSafra);
      };

      const handleDataLoaded = (loadedData) => {
        const updatedSafra = {
          ...localSafraData,
          cultura: loadedData.crop || (localSafraData && localSafraData.cultura),
          produccionHa: loadedData.yield_ton_ha?.toString() || (localSafraData && localSafraData.produccionHa),
          costoInsumosHa: loadedData.input_cost_ha?.toString() || (localSafraData && localSafraData.costoInsumosHa),
          costoMaquinariasHa: loadedData.machinery_cost_ha?.toString() || (localSafraData && localSafraData.costoInsumosHa),
          costoManutencionHa: loadedData.maintenance_repair_cost_ha?.toString() || (localSafraData && localSafraData.costoManutencionHa),
          costoFletesTon: loadedData.freight_cost_ha?.toString() || (localSafraData && localSafraData.costoFletesTon),
          costoEnergiaElectricaHa: loadedData.electrical_energy_cost_ha?.toString() || (localSafraData && localSafraData.costoEnergiaElectricaHa),
        };
        setLocalSafraData(updatedSafra);
        onUpdate(updatedSafra);
        setIsModalOpen(false);
        toast({
          title: "Datos cargados con éxito",
          description: "Los campos de la calculadora han sido actualizados.",
        });
      };

      const results = useMemo(() => calculateSafra(localSafraData || {}), [localSafraData]);

      const formatCurrency = (value) => {
        const number = Number(value) || 0;
        return new Intl.NumberFormat('es-PY', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(number);
      };

      const formatNumber = (value) => {
        const number = Number(value) || 0;
        return new Intl.NumberFormat('es-PY', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(number);
      };

      const renderInputField = (label, name, value, placeholder = "0") => (
        <div className="grid grid-cols-2 items-center gap-2">
          <label htmlFor={`${name}-${safraIndex}-${type}`} className="text-sm font-medium">{label}</label>
          <Input
            id={`${name}-${safraIndex}-${type}`}
            name={name}
            value={value || ''}
            onChange={handleInputChange}
            placeholder={placeholder}
            className="h-8 bg-white/60"
          />
        </div>
      );
      
      const cardClasses = cn({
        'bg-orange-100': type === 'traditional',
        'bg-[#e0e7ff]': type === 'tecnified',
      });

      return (
        <Card className={cardClasses}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">{title}</CardTitle>
            <Button variant="outline" size="sm" onClick={() => setIsModalOpen(true)}>
              <Database className="h-4 w-4 mr-2" />
              Cargar Datos
            </Button>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-6">
              <div className="space-y-2">
                <h3 className="font-semibold text-md mb-2">Datos de Entrada</h3>
                {renderInputField("Cultura", "cultura", localSafraData?.cultura, "Ej: Soja")}
                {renderInputField("Hectáreas", "hectareas", localSafraData?.hectareas)}
                {renderInputField("Producción / ha (ton)", "produccionHa", localSafraData?.produccionHa)}
                {renderInputField("Precio de Venta / ton (USD)", "precioVenta", localSafraData?.precioVenta)}
                {renderInputField("Costo Insumos / ha (USD)", "costoInsumosHa", localSafraData?.costoInsumosHa)}
                {renderInputField("Costo Maquinarias / ha (USD)", "costoMaquinariasHa", localSafraData?.costoMaquinariasHa)}
                {renderInputField("Costo Manutención / ha (USD)", "costoManutencionHa", localSafraData?.costoManutencionHa)}
                {renderInputField("Costo Fletes / ton (USD)", "costoFletesTon", localSafraData?.costoFletesTon)}
                {renderInputField("Costo Energía Eléctrica / ha (USD)", "costoEnergiaElectricaHa", localSafraData?.costoEnergiaElectricaHa)}
                {renderInputField("Impuestos IRAGRO (%)", "impuestosIrragroPct", localSafraData?.impuestosIrragroPct, "0%")}
                {renderInputField("Impuesto a la Renta IRP (%)", "impuestoRentaIRPPct", localSafraData?.impuestoRentaIRPPct, "0%")}
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold text-md mb-2">Resultados Calculados</h3>
                <div className="overflow-x-auto">
                  <Table className="bg-white/50 rounded-lg min-w-full">
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium">Total Producción (ton)</TableCell>
                        <TableCell className="text-right">{formatNumber(results.totalProduccionAreaTon)}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Total Ventas (Ingresos)</TableCell>
                        <TableCell className="text-right text-green-600 font-semibold">{formatCurrency(results.totalVentasIngresos)}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Total de Costos (Egresos)</TableCell>
                        <TableCell className="text-right text-red-600 font-semibold">{formatCurrency(results.totalCostosEgresos)}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Costos Promedio / ha</TableCell>
                        <TableCell className="text-right">{formatCurrency(results.costosPromedioHa)}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Ganancia Bruto (antes imp.)</TableCell>
                        <TableCell className="text-right">{formatCurrency(results.gananciaNetaArea)}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Impuestos (IRAGRO + IRP)</TableCell>
                        <TableCell className="text-right">{formatCurrency(results.impuestosIrragro + results.impuestoRentaIRP)}</TableCell>
                      </TableRow>
                      <TableRow className="bg-gray-100/70">
                        <TableCell className="font-bold">Ganancia Líquida Final</TableCell>
                        <TableCell className="text-right font-bold text-lg">{formatCurrency(results.gananciaLiquidaFinalArea)}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Ganancia por Hectárea</TableCell>
                        <TableCell className="text-right">{formatCurrency(results.gananciaPorHectarea)}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Rentabilidad s/ Facturación</TableCell>
                        <TableCell className="text-right">{formatNumber(results.rentabilidadSobreFacturacion * 100)}%</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
            <LoadDataModal
              isOpen={isModalOpen}
              onClose={() => setIsModalOpen(false)}
              onLoadData={handleDataLoaded}
              culture={localSafraData?.cultura}
            />
          </CardContent>
        </Card>
      );
    };

    export default SafraSection;