# Guía para Desarrolladores de AGROinvest

Este documento proporciona una descripción técnica de los flujos clave, configuraciones y procedimientos de prueba para mantener y extender la aplicación AGROinvest.

## 1. Flujos Técnicos Clave

### 1.1. Importación por Lotes Reanudable (Catálogo de Productos)

El sistema de importación está diseñado para ser robusto, tolerante a fallos y reanudable, procesando grandes archivos Excel sin bloquear la interfaz de usuario.

**Flujo de Ejecución:**

1.  **UI (Cliente):**
    *   El usuario selecciona un archivo Excel desde `ProductCatalogPage.jsx`.
    *   El `useCreateImportJob` hook sube el archivo a Supabase Storage en la carpeta `catalog_imports`.
    *   Se crea un registro en la tabla `import_jobs` con estado `queued`.
    *   Inmediatamente después, se invoca la Edge Function `import-catalog` con el `jobId`.

2.  **Edge Function (`import-catalog`):**
    *   **Bloqueo:** La función primero llama al RPC `try_lock_job` para asegurar que solo una instancia procese este trabajo a la vez. Esto previene condiciones de carrera.
    *   **Procesamiento por Lotes:** La función lee el archivo Excel desde Storage, lo parsea y procesa las filas en lotes de `250`.
    *   **Checkpointing:** Después de cada lote, o si se acerca al límite de tiempo de ejecución (50s), la función actualiza el campo `last_processed_row` en la tabla `import_jobs`.
    *   **Reanudación Automática:** Si la función alcanza el límite de tiempo, se **re-invoca a sí misma** con el mismo `jobId`. La nueva instancia leerá el `last_processed_row` y continuará desde ese punto.
    *   **Manejo de Errores:** Los errores por fila (ej. SKU duplicado) se registran en la columna `error_details` del trabajo. Los errores fatales (ej. fallo de red) marcan el trabajo como `failed`.
    *   **Finalización:** Al completar todas las filas, el estado del trabajo se actualiza a `completed` o `completed_with_errors`, se libera el bloqueo y se elimina el archivo de Storage.

3.  **Reanudación Manual (UI):**
    *   Si un trabajo se queda en estado `processing` (detectado en `ImportHistory`), el usuario puede hacer clic en "Reanudar".
    *   Esto llama al RPC `force_release_job_lock` para romper un posible bloqueo obsoleto y luego re-invoca la Edge Function `import-catalog`, que retoma el proceso desde el último checkpoint.

### 1.2. Manejo de Errores y Logging

El objetivo es que ningún error pase desapercibido y que el usuario siempre reciba feedback claro.

*   **ErrorBoundary (`src/components/ErrorBoundary.jsx`):** Un componente de React que envuelve las rutas principales. Si ocurre un error de renderizado en cualquier componente hijo, este "guardián" lo captura y muestra una UI de emergencia en lugar de una pantalla en blanco.
*   **Captura Global de Errores (`src/lib/error-logger.js`):**
    *   Se han añadido listeners globales (`window.onerror`, `window.onunhandledrejection`) que capturan cualquier error de JavaScript no manejado en la aplicación.
    *   Estos errores se envían a la tabla `app_logs` de Supabase a través de la función `logError`.
*   **Tabla `app_logs`:**
    *   Registra errores de front-end y back-end.
    *   Campos: `level` (error, warn, info), `module` (ej. 'catalog_import', 'auth'), `message`, y `details` (JSON con el stack trace).
    *   **Visualizador en UI:** Los administradores pueden ver y filtrar estos logs en `Configuración > Logs del Sistema`.
*   **Respuestas de Edge Functions:**
    *   Las funciones deben estandarizar sus respuestas de error a un formato predecible: `{ ok: false, error: { code: 'ERROR_CODE', message: 'User-friendly message', details: '...' } }`.
    *   El cliente (UI) debe interpretar esta estructura para mostrar toasts informativos.

### 1.3. Notificaciones Realtime

Las notificaciones sobre el estado de las importaciones se gestionan mediante una combinación de polling y Supabase Realtime. El chat utiliza Supabase Realtime para la entrega instantánea de mensajes.

*   El hook `useImportJobs` utiliza `refetchInterval` de React Query para sondear el estado de los trabajos de importación.
*   El componente `ChatPage.jsx` utiliza `supabase.channel(...).subscribe()` para escuchar nuevos mensajes en tiempo real.

### 1.4. Asistente IA "Don Lindomar"

La plataforma integra un asistente de IA llamado "Don Lindomar".

*   **Acceso:** Se accede a través de un botón global "Preguntar a Don Lindomar" en la cabecera y un botón contextual en varios módulos.
*   **Panel:** Se abre en un panel lateral (`AIAssistantPanel.jsx`) que contiene varias pestañas (Chat, Resumen Diario, etc.).
*   **Lógica Principal (`ask-ai` Edge Function):**
    *   **Credenciales:** La función se inicializa con `SUPABASE_SERVICE_ROLE_KEY` para tener acceso de administrador a la base de datos, lo que le permite eludir las políticas de RLS para realizar consultas agregadas en nombre del usuario.
    *   **Detección de Intención:** La función analiza la consulta del usuario para determinar la intención (`detectIntentAndFilters`). Las palabras clave activan diferentes rutas:
        *   **Producción Agrícola:** Palabras como `soja`, `maíz`, `trigo`, `producción`, `rendimiento`. Llama a la función SQL `search_production_data`.
        *   **Forraje:** Palabras como `forraje`, `pasto`, `silo`, `ensilaje`, `alfalfa`, `silaje`. Llama a la función SQL `search_forage_data`.
        *   **Inventario/Producto:** Palabras como `stock`, `SKU`, `precio`. Llama a la función SQL `fuzzy_search_catalog_details`.
        *   **Fallback:** Si no se detecta una intención clara, la consulta se envía a la función `ask-ai-kb` para una búsqueda semántica en la base de conocimiento.
    *   **Funciones SQL:**
        *   `search_production_data`: Realiza búsquedas filtradas y agrupadas en la tabla `Produccion_Agricola`.
        *   `search_forage_data`: Realiza búsquedas filtradas y agrupadas en la tabla `forage_production`.
*   **Branding:** Todos los textos de la interfaz relacionados con la IA (títulos, botones, pies de página de respuesta) deben hacer referencia a "Don Lindomar" para mantener la consistencia.

## 2. Variables de Entorno y Flags

Todas las variables de entorno se gestionan como **Supabase Secrets**.

*   `SUPABASE_URL`: URL del proyecto Supabase.
*   `SUPABASE_ANON_KEY`: Clave anónima pública para el cliente.
*   `SUPABASE_SERVICE_ROLE_KEY`: Clave de servicio para operaciones de admin en Edge Functions.
*   `RESEND_API_KEY`: Para el envío de correos electrónicos.
*   `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_FROM`: Para notificaciones por WhatsApp.

## 3. Ejecución de Pruebas

Se ha configurado un entorno de pruebas con **Vitest** y **React Testing Library**.

### 3.1. Cómo Correr los Tests

Para ejecutar todas las pruebas unitarias y de integración, utiliza el siguiente comando:

```bash
npm test
```

Para ejecutar las pruebas en modo "watch" durante el desarrollo:

```bash
npm test -- --watch
```

### 3.2. Estructura de los Tests

*   Los archivos de prueba deben tener la extensión `.test.jsx` o `.test.js`.
*   Se recomienda colocar los archivos de prueba en una carpeta `src/tests` o en una carpeta `__tests__` dentro del directorio del componente.
*   **Setup:** El archivo `src/tests/setup.js` se ejecuta antes de todas las pruebas y configura `jest-dom` para tener acceso a matchers como `toBeInTheDocument()`.

### 3.3. Pruebas E2E (Playwright)

Se ha añadido la configuración básica para Playwright. Para añadir y ejecutar pruebas E2E:

1.  Añade tus archivos de prueba en la carpeta `e2e/`.
2.  Asegúrate de que la aplicación esté corriendo localmente o configura la `baseURL` en `playwright.config.js` para que apunte a tu entorno de staging.
3.  Ejecuta el siguiente comando:

```bash
npm run test:e2e
```

**Flujo E2E recomendado a probar:**
1.  Login.
2.  Navegar a "Clientes" y crear un nuevo cliente.
3.  Crear una "Oportunidad" para ese cliente.
4.  Crear una "Orden de Servicio" desde la oportunidad.
5.  Exportar la OS a PDF y verificar la descarga.

## 4. Checklist Post-Restauración

Para evitar la pérdida de funcionalidad después de una restauración del proyecto desde un backup:

1.  **Verificar Variables de Entorno:** Asegurarse de que todas las `Supabase Secrets` (`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, etc.) estén presentes y con los valores correctos en el nuevo proyecto.
2.  **Verificar Funciones SQL de Búsqueda:** Comprobar que las funciones `search_production_data` y `search_forage_data` existan en la base de datos restaurada. Si no existen, deben ser recreadas desde el código fuente del proyecto.
3.  **Desplegar Edge Functions:** Las Edge Functions no se incluyen en los backups de base de datos. Se deben volver a desplegar todas las funciones desde la CLI de Supabase, especialmente `ask-ai` y `ask-ai-kb`.

## 5. Checklist de Deploy (Staging -> Producción)

1.  **Revisión de Código:** Asegurarse de que todas las nuevas Pull Requests hayan sido revisadas y aprobadas.
2.  **CI Verde:** Confirmar que la pipeline de Integración Continua (CI) pase todas las verificaciones (linting, `npm test`).
3.  **Variables de Entorno:** Verificar que todas las Supabase Secrets necesarias para producción estén configuradas correctamente en el entorno de producción.
4.  **Migraciones de Base de Datos:** Aplicar cualquier nueva migración de base de datos o cambio de esquema al entorno de producción **antes** de desplegar el código del frontend.
5.  **Deploy:** Realizar el deploy de la rama principal (`main`/`master`) al entorno de producción.
6.  **Smoke Testing:** Realizar una verificación manual rápida de las funcionalidades críticas en producción después del deploy (login, acceso a módulos principales) para asegurar que todo funcione como se espera.