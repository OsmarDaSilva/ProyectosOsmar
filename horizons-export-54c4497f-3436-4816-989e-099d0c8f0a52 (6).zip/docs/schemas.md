# Esquemas de Datos para Importación

Este documento describe la estructura esperada para los archivos de Excel que se importan en los diferentes módulos de la plataforma Horizon.

## 1. Catálogo de Productos (`product_catalog`)

Este módulo importa una planilla de productos. La importación es flexible, pero para un funcionamiento óptimo, se recomienda la siguiente estructura.

- **Hoja de cálculo:** El sistema leerá la **primera hoja** del archivo Excel.
- **Primera Fila:** Siempre se interpreta como los **encabezados** de las columnas.

### Columnas Clave (Reconocidas y Mapeadas Automáticamente):

El sistema buscará estas columnas por sus nombres exactos o sus variantes (insensible a mayúsculas/minúsculas y acentos).

1.  **`SKU` / `Código de Producto` / `Código` / `ID` (OBLIGATORIA)**
    *   **Propósito:** Identificador único del producto. Si un SKU ya existe, el producto se **actualizará**. Si no existe, se **creará** uno nuevo.
    *   **Variantes Aceptadas:** `SKU`, `Código de Producto`, `Código`, `ID`.
    *   **Tipo de Dato:** Acepta tanto **números como texto**.
    *   **Validación:** No puede estar vacío. Si una fila tiene un SKU vacío, será **omitida** con una advertencia.

2.  **`Producto` / `Nombre del Producto` / `Descripción` (OPCIONAL)**
    *   **Propósito:** Nombre principal del producto.
    *   **Variantes Aceptadas:** `Producto`, `Nombre del Producto`, `Descripción`.
    *   **Si está vacío:** Se generará un nombre por defecto como "Producto [SKU]".

3.  **`Precio` / `Precio/Venta` / `Valor` / `PrecioVenta` (OPCIONAL)**
    *   **Propósito:** Precio de venta del producto.
    *   **Variantes Aceptadas:** `Precio`, `Precio/Venta`, `Valor`, `PrecioVenta`.
    *   **Si está vacío:** Se establecerá en `0`.
    *   **Validación:** Acepta números, textos con comas o puntos como separador decimal (ej: "1.234,50" o "1,234.50"). Se convertirá a un número decimal.

4.  **`Marca` / `Proveedor` / `Proveedores` (OPCIONAL)**
    *   **Propósito:** Marca o proveedor del producto.
    *   **Variantes Aceptadas:** `Marca`, `Proveedor`, `Proveedores`.

5.  **`Categoría` (OPCIONAL)**
    *   **Propósito:** Categoría a la que pertenece el producto.
    *   **Variantes Aceptadas:** `Categoría`.

### Otras Columnas (Especificaciones):

*   Cualquier otra columna que incluyas en tu Excel (ej: "Color", "Material", "Peso", "Dimensiones", "Moneda", "Origen", "% Comisión") será importada y guardada como una **especificación** del producto. Esto te permite tener un catálogo tan detallado como necesites sin límites predefinidos.
*   Los nombres de estas columnas se usarán **exactamente** como aparecen en los encabezados de tu Excel.

### Reglas de Validación y Comportamiento:

*   **Filas Vacías:** Las filas que estén completamente vacías (sin ningún dato en ninguna celda) serán **ignoradas**.
*   **Límites de Caracteres:** Actualmente, no hay límites de caracteres estrictos impuestos por el importador para los campos de texto.
*   **Actualización vs. Creación:** Si importas un producto con un SKU que ya existe en tu catálogo (bajo tu misma cuenta), el sistema **actualizará** ese producto con los nuevos datos. Si el SKU es nuevo, se **creará** un nuevo producto.

**Ejemplo de Archivo Excel Válido:**

| Código de Producto | Producto                  | Precio/Venta | Marca     | Categoría   | Color   | Material | % Comisión | Origen |
| :----------------- | :------------------------ | :----------- | :-------- | :---------- | :------ | :------- | :--------- | :----- |
| ABC001             | Semilla de Maíz Híbrido   | 125.50       | AgroCorp  | Semillas    | Amarillo| Granel   | 2.5%       | Paraguay |
| XYZ002             | Fertilizante NPK 15-15-15 | 80.00        | BioNutri  | Fertilizantes | Blanco  | Saco 50kg| 1.0%       | Brasil |
| PQR003             | Bomba de Agua Sumergible  | 350.75       | AquaFlow  | Maquinaria  | Azul    | Metal    | 0.0%       | China  |

---

## 2. Base de Datos de Producción Agrícola (`production_database`)

Este módulo importa datos históricos de producción.

-   **Hoja de cálculo:** El sistema buscará una hoja llamada `Produccion`. Si no la encuentra, usará la primera.
-   **Columnas Mapeadas:** El sistema buscará los siguientes encabezados (insensible a mayúsculas/minúsculas y variaciones):
    -   `País`
    -   `Dpto/Provincia`
    -   `Ciudad/Localidad`
    -   `Año`
    -   `Cultura` (Cultivo)
    -   `Finalidad` (Propósito de producción)
    -   `Época Siembra`
    -   `Forma Cultivo` (Ej: Normal, Riego)
    -   `Prod. (ton/ha)` (Rendimiento)
    -   `Costo Insumos/ha`
    -   `Costo Maquinas/ha`
    -   `Costo Fletes/ha`
    -   `Alquiler Tierra/ha`
    -   `Energía Eléctrica/ha`
    -   `Manutención/ha`

---

## 3. Balance Forrajero (`full_forage_database`)

Este módulo importa una planilla con perfiles de producción de forraje. La importación es literal y fiel al archivo.

-   **Hoja de cálculo:** El sistema leerá la primera hoja del archivo.
-   **Estructura:** No hay una estructura fija. El sistema importará todas las columnas y filas tal como están en el archivo Excel. La primera fila se tomará como los encabezados de la tabla.

**Ejemplo:**

| tipo_pastura | region/pais | forma_producida | mes | kg/ms/mes/region |
| :----------- | :---------- | :-------------- | :-- | :--------------- |
| BRS Zuri     | Oriental    | Regada          | Ene | 4789             |
| BRS Zuri     | Oriental    | Regada          | Feb | 4033             |