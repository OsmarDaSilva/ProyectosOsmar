import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

if (!Deno.env.get("SUPABASE_URL") || !Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")) {
  console.error("Missing Supabase credentials. Check function environment variables.");
}

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
);

const respond = (payload) => {
    const finalPayload = {
        ok: payload.ok ?? true,
        stage: payload.stage || "unknown_error",
        intent: payload.intent || 'unknown',
        answer: payload.answer || "",
        bullets: payload.bullets || [],
        sources: payload.sources || [],
        followups: payload.followups || [],
        error: payload.error || null,
    };
    return new Response(JSON.stringify(finalPayload), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
    });
};

const createSupabaseUserClient = (authHeader) => {
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        throw { stage: 'auth', error: 'auth_header_missing', answer: 'Debes iniciar sesión para usar el asistente.' };
    }
    return createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } }
    );
};

const getUserId = async (supabaseUserClient) => {
    const { data: { user }, error } = await supabaseUserClient.auth.getUser();
    if (error || !user) throw { stage: 'auth', error: 'invalid_token', answer: 'Tu sesión ha expirado.' };
    return user.id;
};

const normalizeText = (text) => {
  if (!text) return null;
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
};

const detectIntentAndFilters = (query) => {
    const q = query.toLowerCase().trim();
    const tokens = q.split(/\s+/).map(t => t.replace(/[^a-z0-9áéíóúüñ-]/gi, ''));

    const findKey = (arr, keys) => arr.find(t => keys.includes(t));
    
    const findLocation = (text) => {
        const knownCrops = ['soja', 'soya', 'maiz', 'trigo'];
        const knownMethods = ['regado', 'riego', 'normal', 'secano'];
        const prepositions = ['en', 'de', 'del', 'zona', 'area', 'region', 'distrito'];
        
        let cleanedText = text;
        [...knownCrops, ...knownMethods, ...prepositions].forEach(term => {
            cleanedText = cleanedText.replace(new RegExp(`\\b${term}\\b`, 'g'), '');
        });
        
        const potentialLocations = cleanedText.trim().split(/\s+/).filter(Boolean);
        if (potentialLocations.length > 0) {
            return potentialLocations.join(' ');
        }
        return null;
    };
    
    const forageTerms = ['forraje', 'pasto', 'silo', 'ensilaje', 'maíz forrajero', 'sorgo forrajero', 'alfalfa', 'pastura', 'silaje', 'brachiaria', 'gatton', 'panic', 'pennisetum', 'zuri'];
    if (forageTerms.some(term => q.includes(term))) {
        const pasture = findKey(tokens, forageTerms) || tokens.find(t => forageTerms.some(ft => ft.includes(t)));
        const region = findLocation(q);
        let method = null;
        if (findKey(tokens, ['regado', 'riego'])) method = 'Regada';
        if (findKey(tokens, ['normal', 'secano'])) method = 'Normal';
        
        return { intent: 'FORAGE', filters: { pasture, region, method } };
    }

    const productionTerms = ['soja', 'soya', 'maiz', 'trigo', 'produccion', 'rendimiento', 'cultivo'];
     if (productionTerms.some(term => q.includes(term))) {
        const crop = findKey(tokens, ['soja', 'soya', 'maiz', 'trigo']);
        const location = findLocation(q);
        let method = null;
        if (findKey(tokens, ['regado', 'riego'])) method = 'Regado';
        if (findKey(tokens, ['normal', 'secano'])) method = 'Normal';
        return { intent: 'PRODUCTION', filters: { crop, location, method } };
    }
    
    if (/(stock|disponibilidad|inventario)/i.test(q)) return { intent: "INVENTORY", term: q };
    if (/(equipo|maquina|tractor)/i.test(q)) return { intent: "EQUIPMENT", term: q };
    
    return { intent: 'PRODUCT', term: q };
};

const queryProduction = async (userId, filters) => {
    const table = 'agri_crops_v_compat';
    let query = supabaseAdmin.from(table)
      .select('anio,cultivo,dpto,ciudad,produccion,system');

    const cropNorm = normalizeText(filters.crop);
    const locationNorm = normalizeText(filters.location);

    if (cropNorm) {
      query = query.eq('cultivo_norm', cropNorm);
    }

    if (locationNorm) {
        const { data: cityData, error: cityError } = await supabaseAdmin.from(table).select('ciudad').eq('ciudad_norm', locationNorm).limit(1);
        if (cityData && cityData.length > 0) {
            query = query.eq('ciudad_norm', locationNorm);
        } else {
            const { data: deptData, error: deptError } = await supabaseAdmin.from(table).select('dpto').eq('dpto_norm', locationNorm).limit(1);
            if (deptData && deptData.length > 0) {
                query = query.eq('dpto_norm', locationNorm);
            } else {
                 query = query.or(`ciudad_norm.eq.${locationNorm},dpto_norm.eq.${locationNorm},pais_norm.eq.${locationNorm}`);
            }
        }
    }
    
    if (filters.method) {
        query = query.ilike('system', `%${filters.method}%`);
    }

    query = query.order('anio', { ascending: false }).limit(50);

    const { data, error } = await query;

    if (error) return { ok: false, stage: 'db_rpc', intent: 'PRODUCTION', error: error.message };
    if (!data || data.length === 0) {
        return { ok: true, answer: "No hay datos de producción agrícola disponibles para la consulta especificada.", stage: 'no_results', intent: 'PRODUCTION' };
    }

    const title = `Producción de ${filters.crop || 'cultivos'} en ${filters.location || 'la región'}:`;
    const groupedByLocation = data.reduce((acc, row) => {
        const key = `${row.dpto || 'N/A'}, ${row.ciudad || 'N/A'}`;
        if (!acc[key]) acc[key] = [];
        acc[key].push(row);
        return acc;
    }, {});
    
    const bullets = Object.entries(groupedByLocation).flatMap(([location, records]) => {
        const locationTitle = `**${location}**:`;
        const recordBullets = records.map(r => `  • *${r.cultivo} (${r.system || 'N/D'})*: ${r.produccion} t/ha (Año: ${r.anio})`);
        return [locationTitle, ...recordBullets];
    });

    return { ok: true, answer: title, bullets, followups: ["Comparar con otro cultivo", "Mostrar costos"], stage: 'ok', intent: 'PRODUCTION', sources: [{title: 'Fuente: Base de Producción Agrícola (Compat)'}] };
};

const queryForage = async (userId, filters) => {
    const { data, error } = await supabaseAdmin.from('forage_profiles_v').select('*');

    if (error) return { ok: false, stage: 'db_rpc', intent: 'FORAGE', error: error.message };
    if (!data || data.length === 0) {
        return { ok: true, answer: "No hay datos de forraje disponibles para la consulta especificada.", stage: 'no_results', intent: 'FORAGE' };
    }

    const title = `Producción de forraje para ${filters.pasture || 'pasturas'} en ${filters.region || 'la región'}:`;
    const bullets = data.map(r => `  • *${r.tipo_pastura}*`);

    return { ok: true, answer: title, bullets, followups: ["Comparar con otra pastura", "Ver producción mensual"], stage: 'ok', intent: 'FORAGE', sources: [{title: 'Fuente: Base de Forrajes'}] };
};


const queryProduct = async (userId, term) => {
    const { data, error } = await supabaseAdmin.rpc('fuzzy_search_catalog_details', { p_user_id: userId, p_query_text: term });
    if (error) return { ok: false, stage: 'db_rpc', intent: 'PRODUCT', error: error.message };
    if (!data?.length) {
        return { ok: true, answer: `No encontré productos para "${term}".`, stage: 'no_results', intent: 'PRODUCT' };
    }

    const p = data[0];
    const answer = `Encontré esto para "${term}": **${p.producto || 'N/A'}** (SKU ${p.sku}).`;
    return {
        ok: true, answer,
        bullets: [
            `**Marca:** ${p.marca || 'No especificada'}`,
            `**Precio Venta:** ${p.p_venta?.toFixed(2) || 'No definido'}`,
            `**Stock Disponible:** ${p.stock_disponible || 0} unidades`
        ],
        sources: [{ id: p.sku, title: p.producto, score: 1, url: `/product-catalog?sku=${p.sku}` }],
        followups: ["¿Ver stock por depósito?", "¿Mostrar ficha técnica?"],
        stage: 'ok', intent: 'PRODUCT'
    };
};

const fallbackToKB = async (supabaseUserClient, query) => {
    const { data: kb_data, error: kb_error } = await supabaseUserClient.functions.invoke('ask-ai-kb', {
        body: { query }
    });
    if (kb_error) throw { stage: 'kb_fallback', error: 'invoke_failed', answer: 'No pude consultar la base de conocimiento.' };
    return { ...kb_data, ok: true, intent: 'KNOWLEDGE', stage: `fallback_${kb_data.stage}` };
};

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

    try {
        const { query } = await req.json();
        if (!query) throw { stage: 'validation', error: 'query_required', answer: "La consulta es requerida." };

        const supabaseUserClient = createSupabaseUserClient(req.headers.get('Authorization'));
        const userId = await getUserId(supabaseUserClient);

        const { intent, filters, term } = detectIntentAndFilters(query);
        let result = null;

        switch (intent) {
            case 'PRODUCTION':
                result = await queryProduction(userId, filters);
                break;
            case 'FORAGE':
                result = await queryForage(userId, filters);
                break;
            case 'PRODUCT':
                 result = await queryProduct(userId, term);
                 break;
            default:
                result = await fallbackToKB(supabaseUserClient, query);
                break;
        }
        
        if (!result || result.stage === 'no_results') {
           return respond(await fallbackToKB(supabaseUserClient, query));
        }

        return respond(result);

    } catch (error) {
        console.error("Error en ask-ai:", error);
        return respond({
            ok: false,
            stage: error.stage || 'error',
            intent: 'error',
            answer: error.answer || "No se pudo procesar la solicitud.",
            error: error.message || error.error || 'internal_error',
        });
    }
});