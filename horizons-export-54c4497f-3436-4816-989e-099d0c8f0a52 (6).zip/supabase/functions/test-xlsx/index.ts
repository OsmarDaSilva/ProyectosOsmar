import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import * as XLSX from "https://esm.sh/xlsx@0.18.5";
import { corsHeaders } from "../_shared/cors.ts";

type Body = {
  bucket: string;
  path: string;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { bucket, path } = (await req.json()) as Body;
    if (!bucket || !path) {
      return new Response(JSON.stringify({ error: "Falta bucket o path" }), { status: 400, headers: { ...corsHeaders, "content-type": "application/json" } });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const { data, error } = await supabase.storage.from(bucket).download(path);
    if (error) throw error;
    const buf = await data.arrayBuffer();

    const workbook = XLSX.read(buf, { type: "array" });
    const sheetName = workbook.SheetNames[0];
    if (!sheetName) throw new Error("No se encontró hoja en el Excel");

    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets[sheetName], {
      defval: "",
      raw: false, 
    });

    const sample = rows.slice(0, 3);
    return new Response(JSON.stringify({ ok: true, sheetName, count: rows.length, sample }), {
      headers: { ...corsHeaders, "content-type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: err.message, stack: err.stack }), {
      status: 500,
      headers: { ...corsHeaders, "content-type": "application/json" },
    });
  }
});