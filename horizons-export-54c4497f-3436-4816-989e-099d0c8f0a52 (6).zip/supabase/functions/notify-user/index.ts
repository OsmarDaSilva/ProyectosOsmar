import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { Resend } from 'https://esm.sh/resend@3.2.0';
import { corsHeaders } from './cors.ts';

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const resend = new Resend(RESEND_API_KEY);

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_WHATSAPP_FROM = Deno.env.get('TWILIO_WHATSAPP_FROM'); // e.g., 'whatsapp:+14155238886'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { alert } = await req.json();
    if (!alert || !alert.user_id || alert.severity !== 'critical') {
      return new Response(JSON.stringify({ message: 'No critical alert to notify.' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { global: { headers: { 'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}` }} }
    );

    const { data: userSettings, error: settingsError } = await supabaseAdmin
        .from('user_alert_settings')
        .select('*')
        .eq('user_id', alert.user_id)
        .single();

    if (settingsError && settingsError.code !== 'PGRST116') {
        console.error('Error fetching user settings:', settingsError.message);
    }

    const settings = userSettings || {};
    const canSendEmail = settings.enable_email_notifications ?? true;
    const canSendWhatsApp = settings.enable_whatsapp_notifications ?? false;

    if (!canSendEmail && !canSendWhatsApp) {
        return new Response(JSON.stringify({ message: 'User has disabled all notifications.' }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
    }

    const { data: { user }, error: userError } = await supabaseAdmin.auth.admin.getUserById(alert.user_id);
    if (userError || !user) {
      throw new Error(`User not found: ${userError?.message || 'Unknown error'}`);
    }

    // Send Email
    if (canSendEmail && user.email) {
        if (!RESEND_API_KEY || RESEND_API_KEY === 'REPLACE_WITH_YOUR_RESEND_API_KEY') {
          console.warn('Resend API key is not configured. Skipping email notification.');
        } else {
          const emailHtml = `
            <h1>Alerta Crítica en AGROinvest</h1>
            <p>Hola,</p>
            <p>Se ha generado una nueva alerta crítica en tu proyecto que requiere tu atención inmediata:</p>
            <ul>
              <li><strong>Módulo:</strong> ${alert.module.toUpperCase()}</li>
              <li><strong>Tipo:</strong> ${alert.type}</li>
              <li><strong>Descripción:</strong> ${alert.description}</li>
            </ul>
            <p>Por favor, inicia sesión en la plataforma para revisar los detalles y tomar las acciones necesarias.</p>
            <p>El equipo de AGROinvest</p>
          `;

          await resend.emails.send({
            from: 'Alertas AGROinvest <onboarding@resend.dev>',
            to: [user.email],
            subject: `🚨 Alerta Crítica: ${alert.description}`,
            html: emailHtml,
          });
        }
    }

    // Send WhatsApp
    if (canSendWhatsApp && user.phone) {
        if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_WHATSAPP_FROM) {
            console.warn('Twilio WhatsApp credentials are not configured. Skipping WhatsApp notification.');
        } else {
            const whatsappBody = `🚨 *Alerta Crítica en AGROinvest*\n\n*Módulo:* ${alert.module.toUpperCase()}\n*Descripción:* ${alert.description}\n\nPor favor, revisa la plataforma para más detalles.`;
            
            await fetch(`https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                },
                body: new URLSearchParams({
                    To: `whatsapp:${user.phone}`,
                    From: TWILIO_WHATSAPP_FROM,
                    Body: whatsappBody,
                }),
            });
        }
    }
    
    return new Response(JSON.stringify({ message: `Notification process completed for user ${user.id}.` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error sending notification:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});