import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { Resend } from 'https://esm.sh/resend@3.2.0';
import { corsHeaders } from './cors.ts';

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const resend = new Resend(RESEND_API_KEY);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    if (!RESEND_API_KEY || RESEND_API_KEY === 'REPLACE_WITH_YOUR_RESEND_API_KEY') {
      throw new Error('Resend API key is not configured.');
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { global: { headers: { 'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}` }} }
    );

    const now = new Date();

    // Fetch activities that need reminders
    const { data: activities, error: activitiesError } = await supabaseAdmin
      .from('activities')
      .select('*, users:user_id(email)')
      .neq('reminder_minutes_before', null)
      .is('reminder_sent_at', null)
      .is('is_completed', false);

    if (activitiesError) throw activitiesError;

    const remindersToSend = activities.filter(activity => {
      const dueDate = new Date(activity.due_date);
      const reminderTime = new Date(dueDate.getTime() - activity.reminder_minutes_before * 60000);
      return now >= reminderTime && now < dueDate;
    });

    if (remindersToSend.length === 0) {
      return new Response(JSON.stringify({ message: 'No reminders to send.' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const emailPromises = remindersToSend.map(async (activity) => {
      const userEmail = activity.users?.email;
      if (!userEmail) return;

      const dueDate = new Date(activity.due_date);

      await resend.emails.send({
        from: 'AGROinvest <onboarding@resend.dev>', // Replace with your verified domain
        to: [userEmail],
        subject: `Recordatorio de Actividad: ${activity.type}`,
        html: `
          <h1>Recordatorio de Actividad</h1>
          <p>Hola,</p>
          <p>Este es un recordatorio para tu actividad programada:</p>
          <ul>
            <li><strong>Tipo:</strong> ${activity.type}</li>
            <li><strong>Notas:</strong> ${activity.notes || 'N/A'}</li>
            <li><strong>Fecha y Hora:</strong> ${dueDate.toLocaleString('es-ES')}</li>
          </ul>
          <p>¡Que tengas un día productivo!</p>
          <p>El equipo de AGROinvest</p>
        `,
      });

      // Mark reminder as sent
      await supabaseAdmin
        .from('activities')
        .update({ reminder_sent_at: new Date().toISOString() })
        .eq('id', activity.id);
    });

    await Promise.all(emailPromises);

    return new Response(JSON.stringify({ message: `${remindersToSend.length} reminders sent successfully.` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error sending reminders:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});