import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';
import "https://esm.sh/v135/@supabase/functions-js@2.4.1/src/edge-runtime.d.ts";

const supabaseAdmin: SupabaseClient = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const updateKbStatus = async (id: string, status: string, error_msg: string | null = null) => {
    const { error: updateError } = await supabaseAdmin
        .from('knowledge_base')
        .update({ index_status: status, index_error: error_msg, updated_at: new Date().toISOString() })
        .eq('id', id);
    if (updateError) {
        console.error(`[process-pdf] Fallo al actualizar el estado del documento ${id} a '${status}':`, updateError.message);
    } else {
        console.log(`[process-pdf] Estado del documento ${id} actualizado a '${status}'.`);
    }
};

const invokeEmbeddingFunction = async (text: string): Promise<number[]> => {
    // Retry logic for embedding generation
    for (let attempt = 1; attempt <= 3; attempt++) {
        const { data, error } = await supabaseAdmin.functions.invoke('generate-embedding', {
            body: { text }
        });
        
        if (!error && data.ok && data.embedding) {
            return data.embedding;
        }

        const errorMessage = error?.message || data?.error || 'Unknown embedding error';
        console.warn(`[process-pdf] Intento ${attempt} de generar embedding falló: ${errorMessage}`);

        if (attempt < 3) {
            await new Promise(res => setTimeout(res, 1000 * attempt)); // Exponential backoff
        } else {
            throw new Error(`Error al invocar generate-embedding tras 3 intentos: ${errorMessage}`);
        }
    }
    throw new Error('Logic error: loop should have returned or thrown.');
};

const extractTextFromPdf = async (fileUrl: string): Promise<string> => {
  console.warn("Extracción de texto de PDF es simulada (OCR/Stream no implementado). Se requiere una librería/servicio externo para producción.");
  // En un escenario real, aquí se usaría una librería como pdf-lib o un servicio de OCR para procesar el PDF por streams.
  // La simulación asume que el contenido puede ser procesado.
  return `Contenido simulado del archivo PDF en la URL: ${fileUrl}. Este es una prueba de la funcionalidad de extracción y segmentación de texto. En un escenario real, aquí estaría el texto completo extraído del documento (posiblemente con OCR para PDFs escaneados) para su posterior procesamiento y almacenamiento en la base de datos de vectores. Esto es para demostrar que el flujo completo de embeddings funciona.`;
};


const chunkText = (text: string, chunkSize = 1800, overlap = 200): string[] => {
    if (!text || text.trim().length === 0) return [];
    const chunks: string[] = [];
    if (text.length <= chunkSize) {
        chunks.push(text.trim());
        return chunks;
    }
    for (let i = 0; i < text.length; i += (chunkSize - overlap)) {
        const chunk = text.substring(i, i + chunkSize);
        if (chunk.trim()) chunks.push(chunk.trim());
    }
    return chunks;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }
  
  const body = await req.json().catch(() => ({}));
  if (body.healthcheck) {
    return new Response(JSON.stringify({ ok: true, message: "Health check passed" }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 });
  }

  let document_id: string | undefined;
  try {
    const { record } = body;
    const { id, user_id, file_url, title, content, plain_text, index_status } = record;
    document_id = id;

    console.log(`[process-pdf] Iniciando procesamiento para el documento ID: ${document_id}`);

    if (!document_id || !user_id) {
      throw new Error('Faltan datos del documento (id, user_id).');
    }
    
    if (index_status === 'procesando') {
        console.log(`[process-pdf] Documento ${document_id} ya está siendo procesado. Omitiendo.`);
        return new Response(JSON.stringify({ message: "Procesamiento omitido (ya en proceso)." }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 });
    }

    await updateKbStatus(document_id, 'procesando');

    let textToProcess = plain_text || content;
    if (!textToProcess && file_url) {
        if (file_url.toLowerCase().endsWith('.pdf')) {
            textToProcess = await extractTextFromPdf(file_url);
        } else {
             // Handle other file types if necessary
             console.warn(`[process-pdf] Tipo de archivo no soportado para extracción de texto: ${file_url}`);
        }
    }
    
    const combinedText = `${title}\n\n${textToProcess || ''}`.trim();

    if (!combinedText) {
        console.warn(`[process-pdf] No hay contenido textual para procesar en el documento ${document_id}.`);
        await updateKbStatus(document_id, 'error', 'No se encontró contenido textual para procesar.');
        return new Response(JSON.stringify({ message: "No hay contenido para procesar." }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 });
    }

    const textChunks = chunkText(combinedText);
    console.log(`[process-pdf] Documento ${document_id} dividido en ${textChunks.length} trozos.`);

    await supabaseAdmin.from('ai_embeddings').delete().eq('source_id', document_id);
    console.log(`[process-pdf] Embeddings antiguos para el doc ${document_id} eliminados.`);
    
    const embeddingsToInsert = [];
    for (const chunk of textChunks) {
        const embeddingVector = await invokeEmbeddingFunction(chunk);
        embeddingsToInsert.push({
            user_id: user_id,
            source_type: 'knowledge_base',
            source_id: document_id,
            content: chunk,
            embedding: embeddingVector,
        });
    }
    console.log(`[process-pdf] Se generaron ${embeddingsToInsert.length} nuevos embeddings para el doc ${document_id}.`);

    if (embeddingsToInsert.length > 0) {
        const { error: insertError } = await supabaseAdmin.from('ai_embeddings').insert(embeddingsToInsert);
        if (insertError) throw new Error(`Error al insertar embeddings: ${insertError.message}`);
        console.log(`[process-pdf] Nuevos embeddings insertados para el doc ${document_id}.`);
    }

    await updateKbStatus(document_id, 'procesado');

    return new Response(JSON.stringify({ message: `Documento ${document_id} procesado y vectorizado.` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (error) {
    console.error(`[process-pdf] Error procesando doc ${document_id}:`, error);
    if (document_id) {
        await updateKbStatus(document_id, 'error', error.message);
    }
    return new Response(JSON.stringify({ error: `Error procesando el documento: ${error.message}` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});