import { corsHeaders } from "../_shared/cors.ts";
import "https://esm.sh/v135/@supabase/functions-js@2.4.1/src/edge-runtime.d.ts";
import { pipeline, env } from "https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2";

// Configuration for Transformers.js
env.allowLocalModels = false;
env.useBrowserCache = false;

class PipelineSingleton {
  static task = 'feature-extraction';
  static model = 'Xenova/all-MiniLM-L6-v2';
  static instance = null;

  static async getInstance(progress_callback = null) {
    if (this.instance === null) {
      this.instance = await pipeline(this.task, this.model, { progress_callback });
    }
    return this.instance;
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { text } = await req.json();
    if (!text) {
      throw new Error("El texto es obligatorio para generar el embedding.");
    }
    
    // Get the pipeline instance. This will load the model on the first request.
    const extractor = await PipelineSingleton.getInstance();
    
    // Generate the embedding
    const output = await extractor(text, { pooling: 'mean', normalize: true });
    
    // Convert the Tensor output to a standard JavaScript array
    const embedding = Array.from(output.data);

    return new Response(JSON.stringify({ ok: true, embedding }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (error) {
    console.error('Error en generate-embedding:', error);
    return new Response(JSON.stringify({ ok: false, error: `Error interno en generate-embedding: ${error.message}`, details: error.stack }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});