import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import * as XLSX from "https://esm.sh/xlsx@0.18.5";
import { corsHeaders } from "../_shared/cors.ts";

const BATCH_SIZE = 250;
const TIME_LIMIT_MS = 50000;
const MAX_ATTEMPTS = 3;

const respond = (status, body) => {
    return new Response(JSON.stringify(body), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status,
    });
};

const processBatch = async (supabaseAdmin, batch, logs) => {
    if (batch.length === 0) return { successCount: 0, errors: [] };
    
    let lastError = null;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
        const { error } = await supabaseAdmin
            .from('product_catalog')
            .upsert(batch, { onConflict: 'user_id,sku' });

        if (!error) return { successCount: batch.length, errors: [] };
        
        lastError = error;
        const logMessage = `[import-catalog] Lote fallido (intento ${attempt}/${MAX_ATTEMPTS}): ${error.message}`;
        console.error(logMessage);
        logs.push(logMessage);
        if (attempt < MAX_ATTEMPTS) {
            await new Promise(res => setTimeout(res, 2000 * attempt));
        }
    }

    const batchErrors = batch.map(p => ({
        row: p.original_row_number,
        error: `Error de base de datos tras ${MAX_ATTEMPTS} intentos: ${lastError?.message || 'Error desconocido'}`,
        data: p
    }));
    return { successCount: 0, errors: batchErrors };
};

const reinvokeSelf = (jobId) => {
    try {
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        fetch(`${supabaseUrl}/functions/v1/import-catalog`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${serviceRoleKey}` },
            body: JSON.stringify({ jobId }),
        }).catch(err => console.error(`[import-catalog] La re-invocación falló para job ${jobId}:`, err));
    } catch(err) {
        console.error(`[import-catalog] La re-invocación falló para job ${jobId}:`, err);
    }
};

const normalizeHeader = (header) => {
    if (!header) return '';
    return header.toString().trim().toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]/g, '');
};

const parsePrice = (value) => {
    if (value === null || value === undefined || String(value).trim() === '') return 0.00;
    if (typeof value === 'number') return parseFloat(value.toFixed(2));
    const s = String(value).replace(/\$\s*/g, '').replace(/\./g, (m, o, str) => str.indexOf(',') > o ? '' : m).replace(',', '.');
    const num = parseFloat(s);
    return isNaN(num) ? 0.00 : parseFloat(num.toFixed(2));
};

const getHeaderMap = (headers) => {
    const normalizedHeaders = headers.map(normalizeHeader);
    const headerIndexMap = {};
    normalizedHeaders.forEach((nh, idx) => { headerIndexMap[nh] = idx; });
    const HEADER_ALIASES = {
        sku: ['sku', 'codigo', 'id', 'cod', 'articulo', 'codigoproducto'],
        product_name: ['producto', 'nombre', 'descripcion'],
        sale_price: ['precio', 'precioventa', 'preciodeventa', 'venta', 'valor'],
        purchase_price: ['preciocompra', 'preciodecompra', 'costo'],
        brand: ['marca', 'proveedor'],
        category: ['categoria'],
    };
    const finalMap = {};
    for (const [key, aliases] of Object.entries(HEADER_ALIASES)) {
        const foundAlias = aliases.find(alias => headerIndexMap[normalizeHeader(alias)] !== undefined);
        if (foundAlias) finalMap[key] = headerIndexMap[normalizeHeader(foundAlias)];
    }
    if (finalMap.sku === undefined) throw new Error("No se encontró columna SKU (o alias como 'código'). Es obligatoria.");
    return finalMap;
};

const updateJobStatus = async (supabaseAdmin, jobId, updates) => {
    const finalUpdates = { ...updates, updated_at: new Date().toISOString() };
    return await supabaseAdmin.from('import_jobs').update(finalUpdates).eq('id', jobId);
}

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return respond(200, { ok: true });
    
    const startTime = Date.now();
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '', 
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    let jobId;
    const logs = [];

    try {
        const { jobId: receivedJobId } = await req.json();
        jobId = receivedJobId;
        if (!jobId) throw new Error('ID de trabajo es requerido.');

        logs.push(`Función iniciada para el trabajo ${jobId}`);

        const { data: job, error: jobFetchError } = await supabaseAdmin.from('import_jobs').select('*').eq('id', jobId).single();
        if (jobFetchError) throw new Error(`Fallo al obtener detalles del trabajo: ${jobFetchError.message}`);
        
        if (['completed', 'completed_with_errors'].includes(job.status)) {
            logs.push("El trabajo ya está finalizado. Saliendo.");
            return respond(200, { ok: true, message: "Trabajo ya finalizado.", status: job.status, logs });
        }
        
        const { data: locked, error: lockError } = await supabaseAdmin.rpc('try_lock_job', { p_job_id: jobId });
        if (lockError) throw new Error(`Error al intentar bloquear el trabajo: ${lockError.message}`);
        if (!locked) {
            logs.push("El trabajo ya está siendo procesado por otro worker. Saliendo.");
            return respond(409, { ok: false, error: { code: 'JOB_LOCKED', message: "Trabajo ya bloqueado", details: { jobId, logs } } });
        }

        logs.push("Bloqueo del trabajo adquirido exitosamente.");
        await updateJobStatus(supabaseAdmin, jobId, { status: 'processing' });
        
        const { data: fileData, error: downloadError } = await supabaseAdmin.storage.from('catalog_imports').download(job.file_path);
        if (downloadError) {
             throw new Error(`Error al descargar el archivo: ${downloadError.message} (Detalles: ${JSON.stringify(downloadError)})`);
        }
        
        const fileArrayBuffer = await fileData.arrayBuffer();
        const workbook = XLSX.read(fileArrayBuffer, { type: "array" });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        if (!worksheet) throw new Error('El archivo Excel no tiene hojas.');
        
        const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '', raw: false });
        const headers = rows[0] ?? [];
        const dataRows = rows.slice(1);
        
        if (job.total_rows === null || job.total_rows !== dataRows.length) {
             await updateJobStatus(supabaseAdmin, jobId, { total_rows: dataRows.length });
        }

        const headerMap = getHeaderMap(headers);
        
        let batch = [];
        const errors = job.error_details?.rows || [];
        const startRow = job.last_processed_row || 0;
        let processedInThisRun = 0;

        logs.push(`Iniciando procesamiento desde la fila ${startRow}. Total de filas: ${dataRows.length}`);

        if (startRow >= dataRows.length && dataRows.length > 0) {
            logs.push("No hay más filas que procesar, el trabajo ya parece completo.");
        } else {
            for (let i = startRow; i < dataRows.length; i++) {
                if (Date.now() - startTime > TIME_LIMIT_MS) {
                    if(batch.length > 0) {
                        const batchResult = await processBatch(supabaseAdmin, batch, logs);
                        if (batchResult.errors.length > 0) errors.push(...batchResult.errors);
                        processedInThisRun += batch.length;
                    }
                    
                    logs.push(`Límite de tiempo alcanzado. Re-invocando para continuar desde la fila ${i}.`);
                    await updateJobStatus(supabaseAdmin, jobId, { 
                        last_processed_row: i,
                        processed_rows: (job.processed_rows || 0) + processedInThisRun,
                        error_details: errors.length > 0 ? { rows: errors } : null,
                    });
                    
                    reinvokeSelf(jobId);
                    return respond(202, { ok: true, message: "Reanudando proceso...", details: { jobId, logs } });
                }

                const row = dataRows[i];
                const skuValue = row[headerMap.sku]?.toString().trim();

                if (!skuValue) {
                    errors.push({ row: i + 2, error: "Fila omitida: SKU vacío.", data: {} });
                    continue;
                }

                const productData = { 
                    user_id: job.user_id, 
                    sku: skuValue, 
                    product_name: row[headerMap.product_name]?.toString() || `Producto ${skuValue}`, 
                    sale_price: parsePrice(row[headerMap.sale_price]),
                    purchase_price: parsePrice(row[headerMap.purchase_price]),
                    brand: row[headerMap.brand]?.toString() || null, 
                    category: row[headerMap.category]?.toString() || null, 
                    specifications: Object.fromEntries(headers.map((h, idx) => {
                        const headerName = String(h || `col_${idx}`);
                        return [headerName, row[idx]];
                    })),
                    original_row_number: i + 2
                };
                batch.push(productData);

                if (batch.length >= BATCH_SIZE) {
                    const batchResult = await processBatch(supabaseAdmin, batch, logs);
                    if (batchResult.errors.length > 0) errors.push(...batchResult.errors);
                    processedInThisRun += batch.length;
                    batch = [];
                }
            }
        
            if (batch.length > 0) {
                const batchResult = await processBatch(supabaseAdmin, batch, logs);
                if (batchResult.errors.length > 0) errors.push(...batchResult.errors);
                processedInThisRun += batch.length;
            }
        }
        
        const finalStatus = errors.length > 0 ? 'completed_with_errors' : 'completed';
        const totalProcessed = (job.processed_rows || 0) + processedInThisRun;
        const successful_rows = totalProcessed - errors.length;

        logs.push(`Proceso finalizado. Estado: ${finalStatus}.`);
        await updateJobStatus(supabaseAdmin, jobId, {
            status: finalStatus,
            processed_rows: totalProcessed,
            successful_rows,
            failed_rows: errors.length,
            last_processed_row: dataRows.length,
            error_details: errors.length > 0 ? { rows: errors } : null,
            summary: { total: job.total_rows || dataRows.length, success: successful_rows, failed: errors.length },
            processing_lock: null,
            lock_expires_at: null
        });
        
        await supabaseAdmin.storage.from('catalog_imports').remove([job.file_path]);

        return respond(200, { ok: true, message: `Importación finalizada. Éxito: ${successful_rows}, Fallos: ${errors.length}`, details: { jobId, status: "completed", logs } });

    } catch (error) {
        logs.push(`Error fatal: ${error.message}`);
        console.error(`[import-catalog] Error fatal en Job ${jobId}:`, error);
        if (jobId) {
            await updateJobStatus(supabaseAdmin, jobId, { 
                status: 'failed', 
                summary: { error: `Error fatal: ${error.message}` },
                processing_lock: null,
                lock_expires_at: null
            });
        }
        return respond(500, { ok: false, error: { code: 'FATAL_ERROR', message: `Error fatal: ${error.message}`, details: { logs } } });
    }
});