import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import * as XLSX from "https://esm.sh/xlsx@0.18.5";
import { corsHeaders } from "../_shared/cors.ts";

const BATCH_SIZE = 250;
const TIME_LIMIT_MS = 55000;

const processBatch = async (supabaseAdmin, batch) => {
    if (batch.length === 0) return { successCount: 0, errors: [] };
    
    const cleanBatch = batch.map(item => {
        const { original_row_number, ...rest } = item;
        return rest;
    });

    for (let attempt = 1; attempt <= 3; attempt++) {
        const { error } = await supabaseAdmin
            .from('Produccion_Agricola')
            .insert(cleanBatch);
        
        if (!error) return { successCount: batch.length, errors: [] };
        
        console.error(`[import-production] Error en lote (intento ${attempt}):`, error.message);
        if (attempt === 3) {
            const batchErrors = batch.map(p => ({ row: p.original_row_number, error: `Error de base de datos tras 3 intentos: ${error.message}` }));
            return { successCount: 0, errors: batchErrors };
        }
        await new Promise(res => setTimeout(res, 1000 * attempt));
    }
    return { successCount: 0, errors: batch.map(p => ({ row: p.original_row_number, error: "Fallo inesperado del lote." })) };
};

const reinvokeSelf = (jobId) => {
    try {
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        fetch(`${supabaseUrl}/functions/v1/import-production-data`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${serviceRoleKey}` },
            body: JSON.stringify({ jobId }),
        }).catch(err => console.error(`[import-production] Re-invocación falló para job ${jobId}:`, err));
    } catch(err) {
        console.error(`[import-production] La re-invocación falló para job ${jobId}:`, err);
    }
};

const normalizeHeader = (header) => {
    if (!header) return '';
    return header.toString().trim().toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]/g, '');
};

const parseNumericValue = (value) => {
  if (value === null || value === undefined || String(value).trim() === '') return 0;
  if (typeof value === 'number') return parseFloat(value.toFixed(2));
  const s = String(value).replace(/\$\s*/g, '').replace(/\./g, (m, o, str) => str.indexOf(',') > o ? '' : m).replace(',', '.');
  const num = parseFloat(s);
  return isNaN(num) ? 0 : parseFloat(num.toFixed(2));
};

const parseIntegerValue = (value) => {
    if (value === null || value === undefined || String(value).trim() === '') return null;
    const num = parseNumericValue(value);
    return Math.floor(num);
};


Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
    
    const startTime = Date.now();
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '', 
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    let jobId;

    try {
        const { jobId: receivedJobId } = await req.json();
        jobId = receivedJobId;
        if (!jobId) throw new Error('ID de trabajo es requerido.');

        const { data: locked, error: lockError } = await supabaseAdmin.rpc('try_lock_job', { p_job_id: jobId });
        if (lockError) throw new Error(`Error al intentar bloquear el trabajo: ${lockError.message}`);
        if (!locked) {
            return new Response(JSON.stringify({ message: "Trabajo ya bloqueado", jobId }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 409 });
        }

        const { data: job, error: jobFetchError } = await supabaseAdmin.from('import_jobs').select('*').eq('id', jobId).single();
        if (jobFetchError) throw new Error(`Fallo al obtener detalles del trabajo: ${jobFetchError.message}`);
        
        if (['completed', 'completed_with_errors'].includes(job.status)) {
            await supabaseAdmin.rpc('release_job_lock', { p_job_id: jobId });
            return new Response(JSON.stringify({ message: "Trabajo ya finalizado.", status: job.status }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
        }

        if (job.status !== 'processing') {
            await supabaseAdmin.from('import_jobs').update({ status: 'processing' }).eq('id', jobId);
        }

        const { data: fileData, error: downloadError } = await supabaseAdmin.storage.from('production_imports').download(job.file_path);
        if (downloadError) throw new Error(`Error al descargar el archivo: ${downloadError.message}`);
        
        const fileArrayBuffer = await fileData.arrayBuffer();
        const workbook = XLSX.read(fileArrayBuffer, { type: "array", cellDates: true });
        const worksheet = workbook.Sheets[workbook.SheetNames.find(name => name.toLowerCase() === 'produccion') || workbook.SheetNames[0]];
        if (!worksheet) throw new Error("El archivo Excel no tiene una hoja válida ('Produccion' o la primera).");
        
        const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '', raw: false });
        const headers = rows[0] ?? [];
        const dataRows = rows.slice(1);
        
        if (job.last_processed_row === 0 || job.last_processed_row === null) {
            await supabaseAdmin.from('Produccion_Agricola').delete().eq('user_id', job.user_id);
            await supabaseAdmin.from('import_jobs').update({ total_rows: dataRows.length, processed_rows: 0, last_processed_row: 0, error_details: null, summary: null }).eq('id', jobId);
            job.total_rows = dataRows.length;
            job.last_processed_row = 0;
        }

        const normalizedHeaders = headers.map(h => normalizeHeader(h));
        const headerMap = {};
        
        const columnMapping = {
          'country': ['pais', 'country'],
          'department_province': ['dptoprovincia', 'departamento', 'provincia', 'dpto'],
          'city_locality': ['ciudadlocalidad', 'ciudad', 'localidad'],
          'year': ['ano', 'year', 'safra'],
          'crop': ['cultura', 'cultivo', 'crop'],
          'production_purpose': ['finalidad', 'proposito'],
          'sowing_season': ['epocasiembra', 'epoca'],
          'cultivation_method': ['formacultivo', 'metodocultivo'],
          'yield_ton_ha': ['prodtonha', 'produccion', 'producciontha', 'rendimiento', 'prodtha', 'prodtonha'],
          'input_cost_ha': ['costoinsumosha', 'costoinsumos'],
          'machinery_cost_ha': ['costomaquinasha', 'costomaquinas'],
          'freight_cost_ha': ['costofletesha', 'costofletes'],
          'land_rent_ha': ['alquilertierraha', 'alquilertierra', 'renta'],
          'electrical_energy_cost_ha': ['energiaelectricaha', 'costoenergia'],
          'maintenance_repair_cost_ha': ['manutencionha', 'mantenimientoha', 'costomantenimiento', 'manutencionha'],
        };
        
        normalizedHeaders.forEach((nh, idx) => {
            for (const [key, aliases] of Object.entries(columnMapping)) {
                if (aliases.some(alias => nh.includes(alias))) {
                    if (headerMap[key] === undefined) headerMap[key] = idx;
                    break;
                }
            }
        });

        if (headerMap.crop === undefined) throw new Error("No se encontró columna de Cultura/Cultivo.");
        
        let batch = [];
        const errors = job.error_details?.errors || [];
        const startRow = job.last_processed_row || 0;
        let currentProcessedCount = job.processed_rows || 0;

        for (let i = startRow; i < dataRows.length; i++) {
            if (Date.now() - startTime > TIME_LIMIT_MS) {
                if (batch.length > 0) {
                    const result = await processBatch(supabaseAdmin, batch);
                    errors.push(...result.errors);
                }
                await supabaseAdmin.from('import_jobs').update({ last_processed_row: i, processed_rows: currentProcessedCount, error_details: errors.length > 0 ? { errors } : null }).eq('id', jobId);
                reinvokeSelf(jobId);
                return new Response(JSON.stringify({ message: "Reanudando proceso...", jobId }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 202 });
            }

            const row = dataRows[i];
            currentProcessedCount++;
            if (row.every(cell => String(cell).trim() === "")) continue;

            const newRecord = { user_id: job.user_id };
            for (const dbCol in columnMapping) {
                const colIndex = headerMap[dbCol];
                if (colIndex !== undefined) {
                    let value = row[colIndex];
                    if (dbCol === 'year') {
                        newRecord[dbCol] = parseIntegerValue(value);
                    } else if (['yield_ton_ha', 'input_cost_ha', 'machinery_cost_ha', 'freight_cost_ha', 'land_rent_ha', 'electrical_energy_cost_ha', 'maintenance_repair_cost_ha'].includes(dbCol)) {
                        newRecord[dbCol] = parseNumericValue(value);
                    } else {
                        newRecord[dbCol] = String(value || '').trim() || null;
                    }
                }
            }
            if (!newRecord.crop) {
                errors.push({ row: i + 2, error: "Fila omitida: Cultura/Cultivo vacío." });
                continue;
            }
            newRecord.original_row_number = i + 2;
            batch.push(newRecord);

            if (batch.length >= BATCH_SIZE) {
                const result = await processBatch(supabaseAdmin, batch);
                errors.push(...result.errors);
                batch = [];
            }
        }
        
        if (batch.length > 0) {
            const result = await processBatch(supabaseAdmin, batch);
            errors.push(...result.errors);
        }

        const finalStatus = errors.length > 0 ? 'completed_with_errors' : 'completed';
        const successful_rows = dataRows.length - errors.length;

        await supabaseAdmin.from('import_jobs').update({
            status: finalStatus,
            processed_rows: dataRows.length, successful_rows, failed_rows: errors.length,
            last_processed_row: dataRows.length,
            error_details: errors.length > 0 ? { errors } : null,
            summary: { total: dataRows.length, success: successful_rows, failed: errors.length },
            processing_lock: null, lock_expires_at: null
        }).eq('id', jobId);
        
        await supabaseAdmin.storage.from('production_imports').remove([job.file_path]);

        return new Response(JSON.stringify({ jobId, status: "completed", message: `Importación finalizada. Éxito: ${successful_rows}, Fallos: ${errors.length}` }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 });

    } catch (error) {
        console.error(`[import-production] Error fatal en Job ${jobId}:`, error);
        if (jobId) {
            await supabaseAdmin.from('import_jobs').update({ status: 'failed', error_details: { errors: [{ row: 0, error: `Error fatal: ${error.message}` }] }, processing_lock: null, lock_expires_at: null }).eq('id', jobId);
        }
        return new Response(JSON.stringify({ error: `Error fatal: ${error.message}` }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 });
    }
});