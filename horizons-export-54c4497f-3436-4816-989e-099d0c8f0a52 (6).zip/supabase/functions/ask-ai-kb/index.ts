import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');

const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
);

const respond = (payload) => {
    return new Response(JSON.stringify(payload), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
    });
};

const createSupabaseUserClient = (authHeader) => {
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        throw { stage: 'auth', error: 'auth_header_missing', answer: 'Debes iniciar sesión para usar el asistente.' };
    }
    return createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { 
            global: { headers: { Authorization: authHeader } },
            auth: { persistSession: false }
        }
    );
};

const getUserId = async (supabaseUserClient) => {
    const { data: { user }, error } = await supabaseUserClient.auth.getUser();
    if (error || !user) throw { stage: 'auth', error: 'invalid_token', answer: 'Tu sesión ha expirado.' };
    return user.id;
};

const fetchWithRetry = async (url, options, retries = 2) => {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await fetch(url, options);
            if (response.ok) return response;
            if (response.status >= 400 && response.status < 500 && response.status !== 429) return response;
            await new Promise(res => setTimeout(res, 1000 * (i + 1)));
        } catch (e) {
            if (i === retries - 1) throw e;
            await new Promise(res => setTimeout(res, 1000 * (i + 1)));
        }
    }
    throw new Error('Todos los reintentos fallaron.');
};

const generateAnswerFromContext = async (query, context) => {
    if (!OPENAI_API_KEY || !OPENAI_API_KEY.startsWith('sk-')) {
        throw { stage: 'openai_llm', error: 'provider_key_missing', trace: { step: 'generateAnswer' } };
    }
    const systemPrompt = "Eres Don Lindomar 2.0, un copiloto de inteligencia de negocios para el sector agropecuario. Responde en español claro y profesional. Basa tus respuestas únicamente en el contexto proporcionado. Si el contexto no contiene la respuesta, indícalo claramente. Estructura tu respuesta con un resumen conciso, seguido de 3 a 6 viñetas con datos clave. Finalmente, sugiere dos preguntas de seguimiento.";
    const userMessage = `Contexto:\n${context}\n\nPregunta: ${query}\n\nFormato de respuesta esperado (JSON válido):\n{\n  "answer": "...",\n  "bullets": ["...", "...", "..."],\n  "followups": ["...", "..."]\n}`;

    const response = await fetchWithRetry("https://api.openai.com/v1/chat/completions", {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
            model: "gpt-4o", messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userMessage }],
            response_format: { type: "json_object" }, temperature: 0.3, max_tokens: 800,
        })
    });
    if (!response.ok) throw { stage: 'openai_llm', error: 'provider_api_error', trace: { details: (await response.json()).error?.message } };
    const completion = await response.json();
    try {
        return JSON.parse(completion.choices[0].message.content);
    } catch (e) {
        throw { stage: 'openai_llm', error: 'ia_response_invalid_json', trace: { details: completion.choices[0].message.content } };
    }
};

const getFallbackAnswer = (context, reason) => ({
    answer: `${reason} **Mostrando resultados por coincidencia de texto:**`,
    bullets: [context.substring(0, 800) + (context.length > 800 ? '...' : '')],
    followups: ["¿Puedes reformular tu pregunta?", "¿Qué otro tema te gustaría explorar?"]
});

const hybridSearch = async (supabaseUserClient, userId, query) => {
    let embedding; let embeddingError = null;
    if (OPENAI_API_KEY && OPENAI_API_KEY.startsWith("sk-")) {
        try {
            const { data, error } = await supabaseAdmin.functions.invoke('generate-embedding', { body: { text: query } });
            if (error || !data?.embedding) embeddingError = { stage: 'embedding', error: data?.error || error?.message || 'gen_failed' };
            else embedding = data.embedding;
        } catch (e) {
            embeddingError = { stage: 'embedding', error: 'invoke_failed', trace: { details: e.message } };
        }
    } else {
        embeddingError = { stage: 'embedding', error: 'provider_key_missing' };
    }

    const [semanticResults, textResults] = await Promise.all([
        embedding ? supabaseUserClient.rpc('match_ai_embeddings', { user_id_param: userId, query_embedding: embedding, match_threshold: 0.25, match_count: 5 }) : Promise.resolve({ data: [], error: null }),
        supabaseUserClient.rpc('fuzzy_search_kb_combined', { p_user_id: userId, p_query_text: query })
    ]);

    if (semanticResults.error) throw { stage: 'db_rpc', error: 'semantic_search_failed', trace: { details: semanticResults.error.message } };
    if (textResults.error) throw { stage: 'db_rpc', error: 'text_search_failed', trace: { details: textResults.error.message } };

    const combined = [...(semanticResults.data || []), ...(textResults.data || [])];
    if (combined.length === 0) return { fragments: [], fallbackUsed: !!embeddingError };

    const uniqueResults = Array.from(new Map(combined.map(item => [item.id, item])).values());
    uniqueResults.sort((a, b) => (b.similarity || 0) - (a.similarity || 0));
    return { fragments: uniqueResults.slice(0, 5), fallbackUsed: !!embeddingError };
};

Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
    
    try {
        const { query } = await req.json();
        const supabaseUserClient = createSupabaseUserClient(req.headers.get('Authorization'));
        const userId = await getUserId(supabaseUserClient);

        const { fragments, fallbackUsed } = await hybridSearch(supabaseUserClient, userId, query);

        if (!fragments || fragments.length === 0) {
            return respond({ ok: true, stage: 'complete_no_results', answer: "No he encontrado información relevante.", followups: ["¿Cómo puedo cargar un nuevo documento?"] });
        }
        
        const context = fragments.map(f => `Documento '${f.title}':\n${f.content}`).join('\n\n---\n\n');
        const sources = Array.from(new Map(fragments.map(f => [f.id, { id: f.id, title: f.title || `Doc: ${f.id.substring(0,8)}...`, score: f.similarity, url: f.file_url }])).values());

        if (fallbackUsed) {
            return respond({ ok: true, ...getFallbackAnswer(context, "La búsqueda semántica no está disponible. "), sources, stage: 'fallback' });
        }
        
        try {
            const structuredAnswer = await generateAnswerFromContext(query, context);
            return respond({ ok: true, ...structuredAnswer, sources, stage: 'ok' });
        } catch(e) {
            return respond({ ok: true, ...getFallbackAnswer(context, "La IA no está disponible. "), sources, stage: 'fallback', error: e.error, trace: e.trace });
        }

    } catch (error) {
        return respond({ ok: false, stage: error.stage || 'unknown_error', answer: error.answer, error: error.error, trace: error.trace });
    }
});