import { corsHeaders } from './cors.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { email, password } = await req.json();
    
    if (!email || !password) {
      throw new Error("El correo electrónico y la contraseña son obligatorios.");
    }
    if (password.length < 6) {
      throw new Error("La contraseña debe tener al menos 6 caracteres.");
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { data: { users }, error: listError } = await supabaseAdmin.auth.admin.listUsers({ email });

    if (listError) {
        throw new Error(`Error al buscar usuario: ${listError.message}`);
    }

    const user = users.find(u => u.email === email);

    if (!user) {
        throw new Error("Usuario no encontrado.");
    }

    const { data: updatedUser, error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
        user.id,
        { password: password }
    );

    if (updateError) {
        throw new Error(`Error al actualizar la contraseña: ${updateError.message}`);
    }

    // Best-effort sign out
    await supabaseAdmin.auth.admin.signOut(user.id);

    return new Response(JSON.stringify({ message: `La contraseña para ${email} ha sido restablecida exitosamente.` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });
  } catch (error) {
    console.error("Error en reset-password-emergency:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    });
  }
});