import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const reindexProductionData = async (userId) => {
    console.log(`[reindex] Iniciando reindexación de production_data para el usuario: ${userId}`);
    
    // 1. Borrar embeddings antiguos para esta fuente
    await supabaseAdmin.from('ai_embeddings').delete().eq('user_id', userId).eq('source_table', 'production_data');

    // 2. Obtener todos los datos de producción
    const { data: records, error } = await supabaseAdmin.from('production_data').select('*').eq('user_id', userId);
    if (error) throw new Error(`Error al obtener datos de producción: ${error.message}`);
    if (!records || records.length === 0) {
        console.log(`[reindex] No hay datos de producción para reindexar para el usuario ${userId}.`);
        return;
    }

    // 3. Formatear y generar embeddings en lotes
    const embeddingsToInsert = [];
    for (const record of records) {
        const content = `Datos de Producción: Cultura: ${record.crop}, Año: ${record.year}, Región: ${record.department_province}, Rendimiento: ${record.yield_ton_ha} ton/ha.`;
        
        const { data: embeddingData, error: embeddingError } = await supabaseAdmin.functions.invoke('generate-embedding', {
            body: { text: content }
        });
        if (embeddingError) {
            console.error(`[reindex] Fallo al generar embedding para el registro ${record.id}: ${embeddingError.message}`);
            continue;
        }

        embeddingsToInsert.push({
            source_table: 'production_data',
            source_id: record.id,
            content: content,
            embedding: embeddingData.embedding,
            user_id: userId,
        });
    }

    // 4. Insertar nuevos embeddings
    if (embeddingsToInsert.length > 0) {
        const { error: insertError } = await supabaseAdmin.from('ai_embeddings').insert(embeddingsToInsert);
        if (insertError) throw new Error(`Error al insertar nuevos embeddings: ${insertError.message}`);
    }
    
    console.log(`[reindex] Reindexación completada para ${embeddingsToInsert.length} registros de production_data.`);
};


Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { user_id, source, source_id } = await req.json();
    if (!user_id || !source) {
      throw new Error('user_id and source are required.');
    }
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    console.log(`[index-enqueue] Received request to re-index source: ${source} for user: ${user_id}`);

    if (source === 'production_data') {
        // Ejecutar la reindexación de forma asíncrona (no esperar a que termine)
        reindexProductionData(user_id).catch(err => console.error(`[reindex] Error en segundo plano: ${err.message}`));
    } else if (source === 'document_library' && source_id) {
        fetch(`${supabaseUrl}/functions/v1/process-pdf-and-embed`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${serviceRoleKey}` },
            body: JSON.stringify({ document_id: source_id, user_id: user_id }),
        }).catch(err => console.error(`[index-enqueue] Failed to invoke process-pdf-and-embed for document ${source_id}:`, err));
    } else {
        console.warn(`[index-enqueue] Received request for unknown source: ${source}`);
    }

    return new Response(JSON.stringify({ message: `Re-indexing process for source '${source}' has been enqueued.` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 202,
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    });
  }
});