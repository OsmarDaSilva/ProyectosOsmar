import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from './cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { global: { headers: { 'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}` } } }
    );

    const { data: { users }, error: authUsersError } = await supabaseAdmin.auth.admin.listUsers();
    if (authUsersError) throw authUsersError;

    const userIds = users.map(u => u.id);

    const { data: profiles, error: profilesError } = await supabaseAdmin
      .from('profiles')
      .select('user_id, role, full_name, phone')
      .in('user_id', userIds);
      
    if (profilesError) throw profilesError;

    const profilesMap = profiles.reduce((acc, item) => {
        acc[item.user_id] = {
            role: item.role,
            full_name: item.full_name,
            phone: item.phone
        };
        return acc;
    }, {});

    const formattedUsers = users.map(user => ({
        id: user.id,
        email: user.email,
        role: profilesMap[user.id]?.role || 'collaborator',
        full_name: profilesMap[user.id]?.full_name || user.user_metadata?.full_name,
        phone: profilesMap[user.id]?.phone || user.phone,
        last_sign_in_at: user.last_sign_in_at,
    }));

    return new Response(JSON.stringify(formattedUsers), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    });
  }
});