import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from './cors.ts';

// THIS FUNCTION IS NO LONGER USED FOR INITIAL IMPORT TRIGGERS.
// THE import-catalog and import-production-data FUNCTIONS ARE INVOKED DIRECTLY FROM THE CLIENT.
// This function remains for legacy or future-proofing purposes, but its primary
// role in the import flow has been removed to simplify and strengthen reliability.

const supabaseAdmin = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const invokeImportFunction = (functionName, jobId) => {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    console.log(`[Worker] Invoking ${functionName} for job ID: ${jobId}`);
    fetch(`${supabaseUrl}/functions/v1/${functionName}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${serviceRoleKey}`,
        },
        body: JSON.stringify({ jobId }),
    }).catch(err => {
        console.error(`[Worker] Failed to invoke ${functionName} for job ${jobId}:`, err);
    });
};

const pickUpQueuedJobs = async () => {
    try {
        const { data: queuedJobs, error: fetchError } = await supabaseAdmin
            .from('import_jobs')
            .select('id, file_path')
            .eq('status', 'queued')
            .order('created_at', { ascending: true });

        if (fetchError) {
            console.error('[Worker] Error fetching queued jobs:', fetchError.message);
            return;
        }

        if (queuedJobs && queuedJobs.length > 0) {
            console.log(`[Worker] Found ${queuedJobs.length} queued job(s).`);
            for (const job of queuedJobs) {
                const { error: updateError } = await supabaseAdmin
                    .from('import_jobs')
                    .update({ status: 'processing', updated_at: new Date().toISOString() })
                    .eq('id', job.id)
                    .eq('status', 'queued');

                if (updateError) {
                    console.error(`[Worker] Failed to mark job ${job.id} as processing:`, updateError.message);
                } else {
                    console.warn(`[Worker] Legacy job ${job.id} picked up. Please check import flow.`);
                    const functionName = job.file_path.includes('catalog_imports') ? 'import-catalog' : 'import-production-data';
                    invokeImportFunction(functionName, job.id);
                }
            }
        }
    } catch (e) {
        console.error('[Worker] Fatal error in pickUpQueuedJobs:', e.message);
    }
};

setInterval(pickUpQueuedJobs, 15000); 

pickUpQueuedJobs();


Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders });
    }
    
    console.log("[Worker] Manual invocation received. Running pickup task.");
    await pickUpQueuedJobs();
    
    return new Response(JSON.stringify({ message: "Job pickup task executed." }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
    });
});